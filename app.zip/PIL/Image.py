"""See PIL/__init__.py: the browser bundle has no Pillow.  Any real use fails loudly."""
def _unavailable(*a, **k): raise RuntimeError('Bitmap images are not supported in the browser version of PS Nest')
open = new = frombytes = fromarray = _unavailable
class Image:  # isinstance() targets inside reportlab
    pass
