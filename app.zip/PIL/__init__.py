"""Browser build only (scripts/build-web.py).  reportlab imports PIL at module level but PS Nest never
rasterises an image (vector drawing + pypdf imposition only), so this stub satisfies the import and
raises if anything ever tries to open a bitmap — tests/test_web_stub.py proves every output kind
still builds with it in place of the real Pillow."""
__version__ = '0.0-stub'
