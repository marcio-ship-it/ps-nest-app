"""Release identity shared by the browser, desktop app and build scripts."""
RELEASE = {
    'version': '1.3.0',
    'name': 'Custom materials',
    'date': '2026-09-24',
}
