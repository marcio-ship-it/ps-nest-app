"""Release identity shared by the browser, desktop app and build scripts."""
RELEASE = {
    'version': '1.2.1',
    'name': 'Clearer workspace',
    'date': '2026-09-24',
}
