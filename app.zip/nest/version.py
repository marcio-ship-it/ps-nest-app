"""Release identity shared by the browser, desktop app and build scripts."""
RELEASE = {
    'version': '1.7.2',
    'name': 'Square bleed corners',
    'date': '2026-11-23',
}
