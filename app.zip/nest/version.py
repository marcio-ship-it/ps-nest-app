"""Release identity shared by the browser, desktop app and build scripts."""
RELEASE = {
    'version': '1.7.0',
    'name': 'Nest guard and double-sided files',
    'date': '2026-11-19',
}
