"""Release identity shared by the browser, desktop app and build scripts."""
RELEASE = {
    'version': '1.7.1',
    'name': 'Turning fix keeps order approvals',
    'date': '2026-11-19',
}
