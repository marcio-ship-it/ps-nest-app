"""Release identity shared by the browser, desktop app and build scripts."""
RELEASE = {
    'version': '1.1.0',
    'name': 'Offcut controls',
    'date': '2026-09-24',
}
