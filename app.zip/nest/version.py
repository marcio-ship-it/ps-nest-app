"""Release identity shared by the browser, desktop app and build scripts."""
RELEASE = {
    'version': '1.4.0',
    'name': 'Custom separation cuts',
    'date': '2026-09-25',
}
