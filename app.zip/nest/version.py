"""Release identity shared by the browser, desktop app and build scripts."""
RELEASE = {
    'version': '1.7.3',
    'name': 'Gap-free bleed trims',
    'date': '2026-11-23',
}
