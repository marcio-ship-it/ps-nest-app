"""PS Nest inside the browser.  Loaded by scripts/build-web.py's worker.js under Pyodide: the same
nest.server.dispatch() answers the UI, with the data folder in the page's in-memory file system.
Nothing leaves the visitor's computer; there is no server.  Trello fetch is off (no credentials)."""
import os
os.environ.setdefault('PSNEST_DATA', '/data')
os.environ.setdefault('PSNEST_TIME_BUDGET', '20')     # browser Python is slower than native: shorter budget
os.environ.setdefault('PSNEST_FONT_DIR', '/app/fonts')
from . import server                                  # noqa: E402  (env must be set before this import)

server._ensure_dirs(); server.load_artworks(); server.load_outlines()


def handle(method, path, body=None):
    """(Uint8Array body, status, content type, download filename) for one UI request."""
    from js import Uint8Array
    raw = body.to_bytes() if hasattr(body, 'to_bytes') else b''   # JS null/undefined → no body
    code, data, ctype, filename = server.dispatch(method, path, raw)
    arr = Uint8Array.new(len(data)); arr.assign(data)
    return arr, code, ctype, filename
