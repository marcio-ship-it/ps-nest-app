"""Process profiles: what is being made (material), how it is printed and what cuts it.

PS Nest began with one profile, ACM on the CNC router.  The shop prints on two machines and cuts on four, and
the right margins, gaps, sheet or roll sizes and output files differ for each, so a profile is now a
material + a cutter:

    MACHINES    the printers and cutters with the limits that matter for a layout
    CUTTERS     the cutting rules each technology imposes (edge, gap, tool width) with their sources
    MATERIALS   stock sizes, which printer feeds it, which cutters may cut it, reverse print or not
    PRODUCTS    every allowed material -> cutter pair, flat, in the shape the server and the UI read

Every default carries its source.  'assumed' lists the keys with no published or shop-recorded figure, where the
value is judgement and is labelled as such: prove those on an offcut.  Change a number here and every job picks
it up.  Machine limits are the shop's own capabilities table (platinum-shop CLAUDE.md, "Production
capabilities", read 17-Sep-2026), checked on 17-Sep-2026 against the full machine specs on file (Claude memory
project_production_equipment.md, reference_substrate_sheet_sizes.md, feedback_sheet_size_limit.md; 'memory' below);
the shop's per-material print / cut template
pairs (on the NAS) showed how each material is fed today: every one is a
2440 x 1220 mm frame, rigid materials with the sheet frame on both files, clear acrylic printed mirrored.
"""

# ---------------------------------------------------------------- machines
MACHINES = {
    'colorado': {
        'name': 'Canon Colorado M5S', 'kind': 'printer', 'feed': 'roll',
        'print_width': 1600,       # mm across the roll
        'max_thickness': 0.8,      # mm, media
        'limits': 'max 1600 mm print width, media up to 0.8 mm; wider work is panelled with a seam',
        'source': 'Shop capabilities table: "Max 1600mm print width". Canon M-series specification: roll width up to 1,625 mm (64 in), print margin 5.3 mm, '
                  '11.0 mm with Media Step Control (asia.canon/en/business/colorado-m-series/specification), so 1600 mm is inside the machine on a full-width roll. '
                  'Media up to 0.8 mm, roll up to 50 kg and 220 mm across: Canon spec sheet on file, Colorado_M-series_Specsheet_FINAL_METRIC p.4 (memory).',
    },
    'jv330': {
        'name': 'Mimaki JV330-160 roll printer', 'kind': 'printer', 'feed': 'roll',
        'print_width': 1610,       # mm across the roll
        'max_thickness': 1,        # mm, media
        'limits': 'max 1610 mm print width on media up to 1620 mm wide, media up to 1 mm; wider work is panelled with a seam',
        'source': 'The shop\'s second roll-to-roll printer: Thomas\'s 29-Aug-2026 machine-software list names the "Mimaki JV330-160" on ONYX Thrive (memory, '
                  'reference_onyx_data_access_api). Limits: Mimaki JV330 series specification, JV330-160 column, mimaki.com/product/inkjet/i-roll/jv330-series/specification.html '
                  '(read 17-Sep-2026): max print width 1,610 mm, max media width 1,620 mm, media thickness 1 mm or lower, roll up to 250 mm across and 45 kg.',
    },
    'flora': {
        'name': 'Flora XTRA 3220 UV flatbed', 'kind': 'printer', 'feed': 'flatbed',
        'field': (3200, 2000), 'max_thickness': 50,
        'limits': 'bed 3200 x 2000 mm, substrate up to 50 mm',
        'source': 'Shop capabilities table: "Bed 3200 x 2000mm, substrate up to 50mm". Flora: 2.00 x 3.20 m true flatbed, 4 vacuum zones (adver-tech.co.za/xtra-3220-uv).',
    },
    'jfx200': {
        'name': 'Mimaki JFX200-2513 EX UV flatbed', 'kind': 'printer', 'feed': 'flatbed',
        'field': (2500, 1300), 'max_thickness': 50,
        'limits': 'bed 2500 x 1300 mm, substrate up to 50 mm and under 50 kg/m2; a 3000 x 1500 panel goes on the Flora',
        'source': 'The shop\'s second UV flatbed, LUS150 CMYK + white + primer + clear; bed 2,500 x 1,300 mm per the Mimaki sales email of 8-Oct-2021 '
                  '(memory, project_production_equipment 2b). Limits: Mimaki JFX200-2513 EX specification, mimaki.com/product/inkjet/i-flat/jfx200-2513-ex/specification.html '
                  '(read 17-Sep-2026): media 2,500 x 1,300 mm, height max 50 mm, weight less than 50 kg/m2.',
    },
    'biesse': {
        'name': 'Biesse Rover Plast J FT 1530 CNC router', 'kind': 'cutter', 'field': (3078, 1563), 'max_thickness': 200,
        'limits': 'working field 3078 x 1563 x 200 mm',
        'source': 'Shop capabilities table: "Working field 3078 x 1563 x 200mm".',
    },
    'co2': {
        'name': 'DAHAN L6-1530 CO2 laser 300 W', 'kind': 'cutter', 'field': (3000, 1500),
        'max_thickness_by_material': {'acrylic': 40, 'acrylic_clear': 40, 'timber': 20},
        'limits': 'bed 3000 x 1500 mm; acrylic up to 40 mm, wood / MDF / ply up to 20 mm, no metal; a CCD camera for print-then-cut is optional on this model and not recorded as fitted',
        'source': 'Shop capabilities table: "Acrylic flame-polished edge up to 40mm, wood/MDF/plywood up to 20mm. Does not cut metal". '
                  'Bed 1,500 x 3,000 mm: DAHAN L6-1530 specification on file (memory, 15-Apr-2026), which also lists the CCD contour camera as optional. '
                  'Whether this machine has one is not recorded: without it a printed sheet is registered by hand on the laser.',
    },
    'fibre': {
        'name': 'Raycus 3 kW fibre laser', 'kind': 'cutter', 'field': (3000, 1500), 'max_thickness': 6,
        'limits': 'bed 3000 x 1500 mm; in-house cap 6 mm (shop policy 29-Apr-2026), thicker goes out; the machine itself stops earlier on brass 5, galvanised 3, copper 3 and Colorbond 1 mm',
        'source': 'Shop capabilities table: "Bed 3000 x 1500mm", "In-house cap (Marcio policy 2026-04-29): <= 6mm", O2 for mild steel / Corten, N2 for stainless / aluminium / brass. '
                  'Per-metal machine limits (Marcio correction 13-Jul-2026, memory; live in platinum-shop lce-machine-profiles.mjs "legacy_chinese_fiber_3kw"): '
                  'mild steel 12, stainless 6, aluminium 6, brass 5, galvanised 3, copper 3, Colorbond 1 mm.',
    },
    'ameida': {
        'name': 'Ameida B9 digital knife cutter (CCD)', 'kind': 'cutter', 'field': (3000, 1500), 'max_thickness': 50,
        'max_thickness_by_material': {'pvc': 6},       # acrylic never goes on the knife (Marcio, 17-Sep-2026)
        'roll_width': 1600,        # mm across a roll fed through the cutter (owner-stated)
        'limits': 'table 3000 x 1500 mm for boards, roll material in rows up to 1600 mm wide, up to 50 mm thick with the oscillating knife, PVC about 6 mm with the router head, no acrylic; print-then-cut with CCD registration; takes DXF, PDF, HPGL and PLT',
        'source': 'Shop capabilities table: "Print-then-cut with CCD registration; vinyl/card/Foamex/corflute/thin acrylic. 3000 x 1500mm, <= 50mm thick". '
                  'Rows of vinyl up to 1.6 m wide: Marcio, 17-Sep-2026 ("the knife cutter can also add rows of vinyl and then cut the rows up to 1.6 m wide"); the table width that allows it is not '
                  'on file - a 1600 mm row does not fit a 1500 mm table, so the plate is to be read (open question 9). '
                  'Machine specs on file (memory, Ameida quote): table "3,000 x 1,500 mm (to confirm: custom or B9-3020 3 x 2 m)"; tools EOT oscillating knife, V-cut, creasing wheel, '
                  'RZ router 350 W / 60,000 rpm for "thin acrylic, PVC, chevy/KT board up to ~6 mm", CCD 0.1 mm, conveyor table for roll material; data formats DXF, HPGL, PDF, PLT. '
                  'Roll feed with take-up confirmed by Marcio, 17-Sep-2026: dual function - vinyl and banner from the roll, boards (cardboard, corflute, foam PVC, acoustic felt) on the table, '
                  'a board up to 3000 x 1500 either way round. The model digits on the plate (B9-3015 / B9-3020) would settle the table width - still to be read.',
    },
}

# The biggest sheet the shop handles at all, whatever the machine: no stock sheet may exceed it (Marcio rule 27-Apr-2026, short side
# tightened to the router's 1563 mm on 29-Apr-2026; memory feedback_sheet_size_limit).  Machine beds are checked first; this catches
# the rest, e.g. a 3100 mm sheet that the flatbed's 3200 mm spec would take but the floor does not.
SHOP_ENVELOPE = (3060, 1563)

# ---------------------------------------------------------------- what each cutting technology asks of a layout
_ROUTER_SOURCES = {
    'edge': '15 mm. Cutlistor CNC nesting guide: "Most beds need 10-20 mm of untouched material around the perimeter for hold-down" (cutlistor.com/guides/cnc-nesting-optimizer). Toolstoday/Vectric nesting workflow: 0.5-1 in (13-25 mm) buffer on all sides for vacuum tables (toolstoday.com/learn/how-to-nest-in-vectric-vcarve-a-step-by-step-workflow). 15 mm sits inside both ranges. Was 10 mm (shop quoting code).',
    'gap': '12 mm = 2 x the 6 mm bit. Toolstoday/Vectric: "A common production-safe rule is 2x the cutter diameter" so each part gets its own kerf and chips clear; Cutlistor: set kerf to the cutter diameter actually run and never halve it for common-line cutting. Was 6 mm (one shared kerf = common-line cut, one deflection scraps two parts).',
    'clamp': '0 mm. Vacuum table, no mechanical clamps; the hold-down zone is already inside the 15 mm edge margin (same two sources as edge). Raise to 50 mm (Toolstoday: "2 in+" clearance) only if physical clamps are fitted.',
    'corner_radius': '0 mm on outside corners: a router cuts a square outside corner. Inside corners of cut-outs cannot be smaller than the bit radius, 3 mm with a 6 mm bit. No published client standard for rounded sign corners.',
    'bit_diameter': '6 mm single-flute (O-flute) upcut solid carbide. P&M Plastics ACM fabricator guide: "sharp, upcut spiral carbide bits" (pmplastics.com.au). YIHAICNC ACM routing guide for a 6 mm single-flute: 10,000-12,000 rpm, feed 5,000-7,000 mm/min, plunge 1,500 mm/min, chip load 0.1-0.2 mm, full-depth single pass up to 4 mm (yhcncrouter.com/cut-acm-on-cnc-guide). Machine-vendor figures, not Biesse-specific: prove on an offcut first.',}

CUTTERS = {
    'biesse': {
        'label': 'CNC router', 'tool': {'kind': 'bit', 'label': 'Bit diameter (mm)'}, 'output': 'dxf',
        'defaults': {'edge': 15, 'gap': 12, 'clamp': 0, 'corner_radius': 0, 'bit_diameter': 6},
        'sources': {k: _ROUTER_SOURCES[k] for k in ('edge', 'gap', 'clamp', 'corner_radius', 'bit_diameter')},
        'assumed': [],
    },
    'co2': {
        'label': 'CO2 laser', 'tool': {'kind': 'kerf', 'label': 'Kerf (mm)'}, 'output': 'dxf',
        'defaults': {'edge': 5, 'gap': 5, 'clamp': 0, 'corner_radius': 0, 'bit_diameter': 0.3},
        'sources': {
            'edge': '5 mm. No published figure for a CO2 bed; the sheet only has to lie flat on the slats and the beam needs no hold-down zone. Shop judgement. [assumption]',
            'gap': '5 mm. A CO2 kerf is 0.2-0.5 mm and the heat-affected band reaches 0.13-0.5 mm from each edge (rivcut.com/blog/laser-cutting-tolerances), so parts '
                   'physically need about 1.5 mm; thick acrylic holds heat, and cutting too slowly gives "rounded corners, wide cuts, and distortion" (gwklaser.com/how-to-laser-cut-acrylic.html). '
                   '5 mm keeps flame-polished edges of neighbours apart on 10-40 mm sheet. No published spacing figure for acrylic: prove on an offcut, thin sheet can go tighter. [assumption]',
            'clamp': '0 mm. Nothing clamps the sheet on a laser bed.',
            'corner_radius': '0 mm. A laser cuts a square corner; the beam radius (about 0.15 mm) is below anything a sign needs.',
            'bit_diameter': 'Kerf 0.3 mm, the middle of the published 0.20-0.51 mm CO2 range (rivcut.com/blog/laser-cutting-tolerances). Used only to check the gap; kerf compensation '
                            'belongs in the laser software, PS Nest never offsets a cut line.',
        },
        'assumed': ['edge', 'gap'],
    },
    'fibre': {
        'label': 'Fibre laser', 'tool': {'kind': 'kerf', 'label': 'Kerf (mm)'}, 'output': 'dxf',
        'defaults': {'edge': 10, 'gap': 6, 'clamp': 0, 'corner_radius': 0, 'bit_diameter': 0.2},
        'sources': {
            'edge': '10 mm. "Minimum edge distances should be at least 1x thickness"; the sheet margin is the no-cut zone kept for clamps or holders '
                    '(shop.machinemfg.com/part-nesting-the-dos-and-donts-of-nesting-laser-cut-shapes). 10 mm covers the 6 mm in-house cap with room for a skewed sheet.',
            'gap': '6 mm = 1 x the 6 mm in-house thickness cap. "A dependable rule of thumb is to set part spacing at one to two times the material thickness", wider for thin sheet '
                   'under 1.5 mm and for aluminium, because overlapping heat-affected zones weld or distort parts (same source; shop.adhmt.com nesting guide). '
                   'Type the thickness and PS Nest warns when the gap drops below it.',
            'clamp': '0 mm, inside the 10 mm edge. Raise it if the machine grips the sheet with clamps that reach further in.',
            'corner_radius': '0 mm.',
            'bit_diameter': 'Kerf 0.2 mm: "fiber lasers produce 0.006 in to 0.012 in kerf" = 0.15-0.30 mm (sendcutsend.com/guidelines/nesting). Used only to check the gap; '
                            'kerf compensation belongs in the laser software. Common-line cutting is not used: parts that share a line come out a kerf undersize.',
        },
        'assumed': [],
    },
    'ameida': {
        'label': 'Knife cutter', 'tool': {'kind': 'knife', 'label': 'Tool width (mm)'}, 'output': 'cut',
        'defaults': {'edge': 10, 'gap': 6, 'clamp': 0, 'corner_radius': 0, 'bit_diameter': 0},
        'sources': {
            'edge': '10 mm. Room for the sheet frame and any camera marks outside the parts; the CCD "scans registration marks printed at sheet corners" and corrects offset, '
                    'rotation and stretch (ldcut.com/blog/what-is-digital-flatbed-cutter.html). No published margin for the B9. [assumption]',
            'gap': '6 mm = 2 x the 3 mm bleed. A knife removes no material, so the gap only has to keep one part\'s bleed off its neighbour: PS Nest trims every bleed to half the gap. '
                   'Geometry, not a published figure; lower the bleed and the gap can follow.',
            'clamp': '0 mm. Vacuum table.',
            'corner_radius': '0 mm. A drag or oscillating knife lifts and turns at corners.',
            'bit_diameter': '0 mm: a knife has no kerf.',
        },
        'assumed': ['edge'],
    },
}

# ---------------------------------------------------------------- materials
_SHEET_2440 = {'label': '2440 x 1220 mm (standard stock)', 'w': 2440, 'h': 1220}
_SHEET_2400 = {'label': '2400 x 1200 mm (metric stock)', 'w': 2400, 'h': 1200}
_SHEET_3000 = {'label': '3000 x 1500 mm (some stock; Flora only)', 'w': 3000, 'h': 1500}
_PANELS = [_SHEET_2440, _SHEET_2400, _SHEET_3000]
_PANELS_SMALL = [_SHEET_2440, _SHEET_2400]
_FLATBEDS = ['flora', 'jfx200']    # first is the default; the operator picks per job
_ROLL_PRINTERS = ['colorado', 'jv330']
_BLEED = ('3 mm. Design-ops review rule for rigid substrates (shop record, not a published figure); the shop\'s own artwork carries 3 mm or 15 mm. [assumption]')
_OFFCUT = ('300 mm. No published standard for a reusable offcut. Shop judgement: a strip under 300 mm holds no saleable sign (the shop\'s vinyl minimum dimension is 300 mm too). [assumption]')
_PANEL_SIZES = ('Panels for the UV flatbeds are mostly 2400 x 1200 or 2440 x 1220 mm and some are 3000 x 1500 mm, depending on the substrate: Marcio, 17-Sep-2026. '
                'Only the Flora bed takes 3000 x 1500. ')
_STOCK = _PANEL_SIZES + 'Every print / cut template pair the shop keeps (ACM, acrylic, clear acrylic, PVC, corflute, vinyl) is a 2440 x 1220 mm frame (NAS, read 17-Sep-2026).'

MATERIALS = {
    'acm': {
        'name': 'ACM panel (aluminium composite)', 'printers': _FLATBEDS, 'cutters': ['biesse'],
        'sheets': [_SHEET_2440, _SHEET_2400, {'label': '3000 x 1500 mm (outdoor grade; Flora only)', 'w': 3000, 'h': 1500}], 'thicknesses_mm': [3, 4],
        'stock_source': _PANEL_SIZES + 'platinum-shop CLAUDE.md, production capabilities table (ACM stock 1220x2440 standard, 1500x3000 outdoor, 3/4 mm).',
    },
    'acrylic': {
        'name': 'Acrylic', 'printers': _FLATBEDS, 'cutters': ['co2', 'biesse'], 'sheets': _PANELS, 'stock_source': _STOCK,
        'notes': 'Laser for a flame-polished edge (up to 40 mm); router for thick or bevelled work. Never the knife cutter: shop rule, Marcio 17-Sep-2026.',
    },
    'acrylic_clear': {
        'name': 'Clear acrylic, reverse printed', 'printers': _FLATBEDS, 'cutters': ['co2', 'biesse'], 'sheets': _PANELS, 'mirror': True, 'stock_source': _STOCK,
        'notes': 'Second-surface print: the artwork is printed mirrored on the back and read through the sheet. The shop\'s PRINT_ACRYLIC_CLEAR template has every image mirrored '
                 '(7 of 7) where PRINT_ACRYLIC has none. PS Nest mirrors each part, artwork and cut line together, so print, cut and DXF files stay in register.',
    },
    'pvc': {
        'name': 'PVC foam board (Foamex / Palboard)', 'printers': _FLATBEDS, 'cutters': ['biesse', 'ameida'], 'sheets': _PANELS, 'stock_source': _STOCK,
    },
    'corflute': {
        'name': 'Corflute', 'printers': _FLATBEDS, 'cutters': ['ameida'], 'sheets': _PANELS_SMALL,
        'stock_source': _STOCK + ' No 3000 x 1500 corflute: Mulford does not stock it (memory, reference_mulford_corflute_prices).',
        'notes': 'Flutes run one way: untick Turn on parts that must keep the flute direction.',
    },
    'cardboard': {
        'name': 'Cardboard', 'printers': _FLATBEDS, 'cutters': ['co2', 'ameida'], 'sheets': [_SHEET_2440],
        'stock_source': 'Cardboard comes 2440 x 1220 mm and is cut on the CO2 laser or the Ameida knife - both suit many jobs, the job decides which: Marcio, 17-Sep-2026.',
        'notes': 'CO2 laser or knife: both suit most cardboard work, pick per job. Printing on the UV flatbeds, as for the other boards, is not confirmed by the shop [assumption]. '
                 'Flutes on corrugated board run one way: untick Turn on parts that must keep the flute direction.',
    },
    'timber': {
        'name': 'MDF / plywood / timber', 'printers': _FLATBEDS, 'cutters': ['co2', 'biesse'], 'sheets': _PANELS_SMALL,
        'stock_source': _PANEL_SIZES + '2440 x 1220 and 2400 x 1200 mm are the common board sizes; the shop keeps no template for them. [assumption]',
        'notes': 'CO2 laser up to 20 mm; grain runs one way: untick Turn on parts that must follow it.',
    },
    'metal': {
        'name': 'Metal sheet (steel, stainless, aluminium, brass)', 'printers': [], 'cutters': ['fibre'],
        'sheets': [{'label': '2400 x 1200 mm (standard metal sheet)', 'w': 2400, 'h': 1200},
                   {'label': '3000 x 1200 mm (Corten, special order)', 'w': 3000, 'h': 1200}, {'label': '3000 x 1500 mm (Corten, special order)', 'w': 3000, 'h': 1500}],
        'stock_source': 'Metals run 2400 x 1200 mm, not the 2440 x 1220 of rigid substrates: aluminium (raw and colour-coated) 1200 x 2400, Corten 1200 x 2400 standard with '
                        '1200 x 3000 and 1500 x 3000 special, Colorbond 2400 x 1200 (owner-confirmed 8-Jul-2026) - platinum-shop materials table, audited 8-Jul-2026 (memory). '
                        'All fit the 3000 x 1500 bed. Stock on hand is not recorded.',
        'notes': 'Cut only, nothing is printed. In-house up to 6 mm; O2 for mild steel and Corten, N2 for stainless, aluminium and brass.',
    },
    'vinyl': {
        'name': 'Vinyl / SAV on the roll (print & cut)', 'printers': _ROLL_PRINTERS, 'cutters': ['ameida'], 'roll': True,
        'sheets': [{'label': 'Roll 1370 mm wide (the usual roll)', 'w': 3000, 'h': 1370},              # w = one knife-table pass, not a sheet
                   {'label': 'Roll 1600 mm wide (the widest)', 'w': 3000, 'h': 1600},
                   {'label': 'Roll 1220 mm wide (shop vinyl template, 2440 mm passes)', 'w': 2440, 'h': 1220}],
        'stock_source': 'Rolls are around 1370 mm wide as a rule, some narrower, and 1600 mm at most on both roll printers; the roll length (about 45 m) never limits a job; the rows the shop actually cuts '
                        'are narrower than 1600 mm, that width is kept as the ceiling: Marcio, 17-Sep-2026. '
                        'A roll is nested one length at a time: a length is what the knife cutter takes in one go (3000 mm at most), the width is across the roll, '
                        'at most the print width (Colorado 1600 mm, JV330 1610 mm) and the 1600 mm the knife cuts in rows. The shop\'s vinyl template is 2440 mm long on 1220 mm across. '
                        'Use Custom size (length x roll width) for another roll.',
        'notes': 'Print & cut: the artwork carries the CutContour line. Layouts are chosen for the shortest printed length, so what is not used stays on the roll; the result shows the length used.',
    },
}


def _build():
    out = {}
    for mid, m in MATERIALS.items():
        for cid in m['cutters']:
            c = CUTTERS[cid]
            printers = list(m.get('printers') or []); printed = bool(printers)
            defaults = dict(c['defaults']); defaults['bleed'] = 3 if printed else 0; defaults['min_offcut'] = 300
            sources = dict(c['sources'])
            sources['sheets'] = m['stock_source']
            sources['bleed'] = _BLEED if printed else '0 mm. Nothing is printed on this material.'
            sources['min_offcut'] = _OFFCUT
            machines = [MACHINES[k]['name'] + ': ' + MACHINES[k]['limits'] for k in printers + [cid]]
            sources['machines'] = ' | '.join(machines) + '. ' + ' '.join(MACHINES[k]['source'] for k in printers + [cid])
            pid = 'acm' if (mid, cid) == ('acm', 'biesse') else f'{mid}-{cid}'
            out[pid] = {
                'name': f"{m['name']} \u2192 {c['label']}", 'material': mid, 'material_name': m['name'], 'cutter': cid, 'cutter_name': MACHINES[cid]['name'],
                'printer': printers[0] if printed else None, 'printer_name': MACHINES[printers[0]]['name'] if printed else None,   # the default
                'printers': [{'id': k, 'name': MACHINES[k]['name']} for k in printers],                                               # the operator's choice
                'roll': bool(m.get('roll')), 'mirror': bool(m.get('mirror')), 'tool': c['tool'], 'output': c['output'],
                'sheets': [dict(s) for s in m['sheets']], 'thicknesses_mm': m.get('thicknesses_mm', []),
                'defaults': defaults, 'sources': sources,
                'assumed': sorted(set(c['assumed']) | ({'bleed'} if printed else set()) | {'min_offcut'} | ({'sheets'} if '[assumption]' in m['stock_source'] else set())),
                'notes': ' '.join(x for x in (m.get('notes'), MACHINES[cid]['limits'].capitalize() + '.') if x),
            }
    return out


PRODUCTS = _build()
# the first profile, exactly as it was proven on the router: its wording and its extra notes are kept
PRODUCTS['acm'].update({
    'name': 'ACM panel (aluminium composite) \u2192 CNC router',
    'notes': 'The router working field is 3078 x 1563 mm, so both stock sheets fit whole. Parts larger than the usable sheet must be split into panels before nesting.',
})


def default_product(material_id):
    """The profile a card's material lands on: the material's first-listed cutter (the shop's usual one)."""
    return next((pid for pid, p in PRODUCTS.items() if p['material'] == material_id), None)

def machine_blocks(product_id, thickness=None, printer=None):
    """What stops the job outright (an error, not a warning): a thickness the in-house cutter cannot cut and no
    policy sends out, or one the chosen printer cannot take.  Metal past the fibre laser's cap stays a warning
    in machine_warnings (shop policy: thicker metal is sent out)."""
    p = PRODUCTS[product_id]; cutter = MACHINES[p['cutter']]; out = []
    if not thickness: return out
    cap = (cutter.get('max_thickness_by_material') or {}).get(p['material'], cutter.get('max_thickness'))
    if cap and thickness > cap + 1e-6 and p['cutter'] != 'fibre':
        out.append(f"{thickness:g} mm {p['material_name']} cannot be cut on the {cutter['name']} ({cap:g} mm at most in this material). "
                   "Choose another cutter or a thinner sheet.")
    pr_id = printer or p['printer']
    if pr_id and pr_id in MACHINES and MACHINES[pr_id].get('max_thickness') and thickness > MACHINES[pr_id]['max_thickness'] + 1e-6:
        out.append(f"{thickness:g} mm is thicker than the {MACHINES[pr_id]['name']} takes ({MACHINES[pr_id]['max_thickness']:g} mm). "
                   "Choose another printer or a thinner sheet.")
    return out

def machine_warnings(product_id, sheet_w, sheet_h, thickness=None, gap=None, printer=None):
    """What the machines of this profile would object to: a sheet that does not fit the printer or the cutter,
    a thickness past a machine's limit or the shop's in-house cap, a gap tighter than the metal is thick.
    `printer` is the operator's pick among the profile's printers (default: the first).
    Warnings, not errors: the limits are the shop's summary table, and the operator may know better."""
    p = PRODUCTS[product_id]; out = []
    long_side, short_side = max(sheet_w, sheet_h), min(sheet_w, sheet_h)
    cutter = MACHINES[p['cutter']]
    fl, fs = max(cutter['field']), min(cutter['field'])
    if p['roll']:
        rw = cutter.get('roll_width', fs)
        if long_side > fl + 1e-6:
            out.append(f"A {long_side:g} mm length is more than the {cutter['name']} takes in one go ({fl:g} mm).")
        if short_side > rw + 1e-6:
            out.append(f"The roll is {short_side:g} mm across; the {cutter['name']} cuts rows up to {rw:g} mm wide.")
    elif long_side > fl + 1e-6 or short_side > fs + 1e-6:
        out.append(f"The {sheet_w:g} x {sheet_h:g} mm sheet is larger than the {cutter['name']} takes ({fl:g} x {fs:g} mm): it cannot be cut in one setting.")
    pr_id = printer or p['printer']
    if pr_id:
        if pr_id not in [x['id'] for x in p['printers']]:
            raise ValueError(f'{MACHINES[pr_id]["name"] if pr_id in MACHINES else pr_id} does not print {p["material_name"]}.')
        pr = MACHINES[pr_id]
        if pr['feed'] == 'roll':
            if short_side > pr['print_width'] + 1e-6:
                out.append(f"The frame is {short_side:g} mm across the roll; the {pr['name']} prints {pr['print_width']:g} mm at most. Wider work has to be panelled with a seam.")
        else:
            pl, ps = max(pr['field']), min(pr['field'])
            if long_side > pl + 1e-6 or short_side > ps + 1e-6:
                fits = [MACHINES[x['id']]['name'] for x in p['printers'] if x['id'] != pr_id and MACHINES[x['id']]['feed'] == 'flatbed'
                        and long_side <= max(MACHINES[x['id']]['field']) + 1e-6 and short_side <= min(MACHINES[x['id']]['field']) + 1e-6]
                out.append(f"The {sheet_w:g} x {sheet_h:g} mm sheet is larger than the {pr['name']} bed ({pl:g} x {ps:g} mm)."
                           + (f" The {fits[0]} takes it." if fits else ''))
    if not out and not p['roll'] and (long_side > SHOP_ENVELOPE[0] + 1e-6 or short_side > SHOP_ENVELOPE[1] + 1e-6):   # a sheet rule; rolls are limited above
        out.append(f"The {sheet_w:g} x {sheet_h:g} mm sheet is outside the shop's sheet envelope ({SHOP_ENVELOPE[0]:g} x {SHOP_ENVELOPE[1]:g} mm): "
                   "the biggest sheet the production area takes (shop rule 29-Apr-2026).")
    if thickness:
        cap = (cutter.get('max_thickness_by_material') or {}).get(p['material'], cutter.get('max_thickness'))
        if cap and thickness > cap + 1e-6:
            out.append(f"{thickness:g} mm is more than the {cutter['name']} cuts in-house in this material ({cap:g} mm). " + ('Shop policy: thicker metal is sent out.' if p['cutter'] == 'fibre' else 'Choose another cutter.'))
        if pr_id and MACHINES[pr_id].get('max_thickness') and thickness > MACHINES[pr_id]['max_thickness'] + 1e-6:
            out.append(f"{thickness:g} mm is thicker than the {MACHINES[pr_id]['name']} takes ({MACHINES[pr_id]['max_thickness']:g} mm).")
        if p['cutter'] == 'fibre' and gap is not None and gap < thickness - 1e-6:
            out.append(f"Gap {gap:g} mm is less than the {thickness:g} mm sheet thickness. For laser-cut metal keep 1 to 2 x the thickness between parts, more on thin sheet and aluminium, or the heat of one cut spoils the next.")
    return out


def get(product_id):
    return PRODUCTS[product_id]

PRODUCTS['acm']['sources'].update({'bleed': '3 mm. Design-ops review rule for rigid substrates (shop record, not an ACM-specific published figure). [assumption]', 'min_offcut': '300 mm. No published standard for a reusable ACM offcut. Shop judgement: a strip under 300 mm holds no saleable sign, so a layout is not rewarded for leaving one. [assumption]', 'material': '3A Composites Alucobond fabrication guide, read 16-Sep-2026: minimum cold-bend radius without routing is 15 x thickness (3 mm = 45 mm, 4 mm = 60 mm); keep the router bit sharp to limit core heat; V-rout at least 25 mm from a panel edge before folding. Not nesting rules, kept for the operator.'})
PRODUCTS['acm']['assumed'] = ['bleed', 'min_offcut']
