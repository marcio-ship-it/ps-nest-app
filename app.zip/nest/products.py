"""Per-product settings, one entry per material so the numbers stay accurate per product.

Every default carries its source.  Values are set from published ACM / CNC-nesting guidance
(fetched and read 16-Sep-2026, links in 'sources'); 'assumed' lists the keys with no published
standard, where the value is shop judgement and is labelled as such.  Change a number here and
every job picks it up.  The router is a vacuum-table flatbed (Biesse Rover Plast J FT 1530).
"""

PRODUCTS = {
    'acm': {
        'name': 'ACM panel (aluminium composite)',
        'sheets': [
            {'label': '2440 x 1220 mm (standard stock)', 'w': 2440, 'h': 1220},
            {'label': '3000 x 1500 mm (outdoor grade)', 'w': 3000, 'h': 1500},
        ],
        'thicknesses_mm': [3, 4],
        'defaults': {
            'edge': 15,          # mm from sheet edge to any cut (vacuum hold-down zone)
            'gap': 12,           # mm between neighbouring parts = 2 x bit diameter (separate kerfs, no common-line cut)
            'bleed': 3,          # mm of artwork past the cut line, all sides
            'clamp': 0,          # mm extra kept clear on every edge for clamps or camera marks
            'corner_radius': 0,  # mm; 0 = square corners
            'bit_diameter': 6,   # mm; used to check the gap and the corner radius
            'min_offcut': 300,   # mm; an offcut strip narrower than this is not counted as reusable
        },
        'sources': {
            'sheets': 'platinum-shop CLAUDE.md, production capabilities table (ACM stock 1220x2440 standard, 1500x3000 outdoor, 3/4 mm).',
            'edge': '15 mm. Cutlistor CNC nesting guide: "Most beds need 10-20 mm of untouched material around the perimeter for hold-down" (cutlistor.com/guides/cnc-nesting-optimizer). Toolstoday/Vectric nesting workflow: 0.5-1 in (13-25 mm) buffer on all sides for vacuum tables (toolstoday.com/learn/how-to-nest-in-vectric-vcarve-a-step-by-step-workflow). 15 mm sits inside both ranges. Was 10 mm (shop quoting code).',
            'gap': '12 mm = 2 x the 6 mm bit. Toolstoday/Vectric: "A common production-safe rule is 2x the cutter diameter" so each part gets its own kerf and chips clear; Cutlistor: set kerf to the cutter diameter actually run and never halve it for common-line cutting. Was 6 mm (one shared kerf = common-line cut, one deflection scraps two parts).',
            'bleed': '3 mm. Design-ops review rule for rigid substrates (shop record, not an ACM-specific published figure). [assumption]',
            'clamp': '0 mm. Vacuum table, no mechanical clamps; the hold-down zone is already inside the 15 mm edge margin (same two sources as edge). Raise to 50 mm (Toolstoday: "2 in+" clearance) only if physical clamps are fitted.',
            'corner_radius': '0 mm on outside corners: a router cuts a square outside corner. Inside corners of cut-outs cannot be smaller than the bit radius, 3 mm with a 6 mm bit. No published client standard for rounded sign corners.',
            'bit_diameter': '6 mm single-flute (O-flute) upcut solid carbide. P&M Plastics ACM fabricator guide: "sharp, upcut spiral carbide bits" (pmplastics.com.au). YIHAICNC ACM routing guide for a 6 mm single-flute: 10,000-12,000 rpm, feed 5,000-7,000 mm/min, plunge 1,500 mm/min, chip load 0.1-0.2 mm, full-depth single pass up to 4 mm (yhcncrouter.com/cut-acm-on-cnc-guide). Machine-vendor figures, not Biesse-specific: prove on an offcut first.',
            'min_offcut': '300 mm. No published standard for a reusable ACM offcut. Shop judgement: a strip under 300 mm holds no saleable sign, so a layout is not rewarded for leaving one. [assumption]',
            'material': '3A Composites Alucobond fabrication guide, read 16-Sep-2026: minimum cold-bend radius without routing is 15 x thickness (3 mm = 45 mm, 4 mm = 60 mm); keep the router bit sharp to limit core heat; V-rout at least 25 mm from a panel edge before folding. Not nesting rules, kept for the operator.',
        },
        'assumed': ['bleed', 'min_offcut'],
        'notes': 'The router working field is 3078 x 1563 mm, so both stock sheets fit whole. Parts larger than the usable sheet must be split into panels before nesting.',
    },
}

def get(product_id):
    return PRODUCTS[product_id]
