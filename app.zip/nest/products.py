"""Process profiles: what is being made (material), how it is printed and what cuts it.

PS Nest began with one profile, ACM on the CNC router.  The shop prints on two machines and cuts on four, and
the right margins, gaps, sheet or roll sizes and output files differ for each, so a profile is now a
material + a cutter:

    MACHINES    the printers and cutters with the limits that matter for a layout
    CUTTERS     the cutting rules each technology imposes (edge, gap, tool width) with their sources
    MATERIALS   stock sizes, which printer feeds it, which cutters may cut it, reverse print or not
    PRODUCTS    every allowed material -> cutter pair, flat, in the shape the server and the UI read

Every default carries its source.  'assumed' lists the keys with no published or shop-recorded figure, where the
value is judgement and is labelled as such: prove those on an offcut.  Change a number here and every job picks
it up.  Machine limits are the shop's own capabilities table (platinum-shop CLAUDE.md, "Production
capabilities", read 17-Sep-2026), checked on 17-Sep-2026 against the full machine specs on file (Claude memory
project_production_equipment.md, reference_substrate_sheet_sizes.md, feedback_sheet_size_limit.md; 'memory' below);
the shop's per-material print / cut template
pairs (on the NAS) showed how each material is fed today: every one is a
2440 x 1220 mm frame, rigid materials with the sheet frame on both files, clear acrylic printed mirrored.
"""
import re

# ---------------------------------------------------------------- fibre laser thickness limits
# One table for the fibre (BUILD-CONTRACT "Fibre cap decision", resolved 16-Oct-2026).  cap: the shop's in-house limit, the
# only figure that blocks.  source_max: the Raycus 3000 W cutting table's non-trial maximum (sheet "3000", from Brent / Dahan,
# WhatsApp 5-Jun-2026), None where the table has no row.  gas: the assist gas in that table.  Stainless and aluminium stop at
# 6 mm because 8 mm needs 16 bar N2 and this machine "isn't set up for hi pressure gas control" (Brent, WhatsApp 27-May-2026);
# mild steel 10 mm is the owner's stated practice (16-Oct-2026); brass 2 and copper 2 are the owner's correction (16-Oct-2026);
# galvanised 3 and Colorbond 1 keep the prior shop table.
# Open: the N2 regulator's real maximum pressure is not recorded - until it is, stainless and aluminium stay at 6.
FIBRE_CAP_MM = {'mild_steel': {'cap': 10, 'source_max': 20, 'gas': 'O2'},
                'stainless': {'cap': 6, 'source_max': 8, 'gas': 'N2'},
                'aluminium': {'cap': 6, 'source_max': 6, 'gas': 'N2'},
                'brass': {'cap': 2, 'source_max': 5, 'gas': 'N2'},
                'galvanised': {'cap': 3, 'source_max': None, 'gas': None},
                'copper': {'cap': 2, 'source_max': None, 'gas': None},
                'colorbond': {'cap': 1, 'source_max': None, 'gas': None}}
_FIBRE_CAP_WHY = {'mild_steel': "owner's stated practice", 'brass': 'owner correction, 16-Oct-2026', 'copper': 'owner correction, 16-Oct-2026'}
FIBRE_METAL_NAMES = {'mild_steel': 'mild steel', 'stainless': 'stainless steel', 'aluminium': 'aluminium', 'brass': 'brass',
                     'galvanised': 'galvanised steel', 'copper': 'copper', 'colorbond': 'Colorbond'}
_FIBRE_METAL_ALIASES = {'ms': 'mild_steel', 'mild': 'mild_steel', 'mild_steel': 'mild_steel', 'steel': 'mild_steel', 'corten': 'mild_steel',
                        'ss': 'stainless', 'stainless': 'stainless', 'stainless_steel': 'stainless',
                        'al': 'aluminium', 'alu': 'aluminium', 'aluminium': 'aluminium', 'aluminum': 'aluminium',
                        'brass': 'brass', 'galv': 'galvanised', 'galvanised': 'galvanised', 'galvanized': 'galvanised',
                        'galvanised_steel': 'galvanised', 'galvanized_steel': 'galvanised',
                        'cu': 'copper', 'copper': 'copper', 'colorbond': 'colorbond', 'colourbond': 'colorbond'}


def fibre_metal(name):
    """The FIBRE_CAP_MM key for a metal the operator typed or picked, None when none was given.
    An unknown name is an error: guessing would let a thickness through that the machine cannot cut."""
    if name is None or not str(name).strip(): return None
    key = _FIBRE_METAL_ALIASES.get(re.sub(r'[\s\-]+', '_', str(name).strip().lower()))
    if not key:
        raise ValueError(f'Unknown metal "{name}" for the fibre laser: choose one of ' + ', '.join(FIBRE_METAL_NAMES.values()) + '.')
    return key


# Owner ruling 16-Oct-2026 ("name every metal"): a fibre job states its metal, or it is refused.
FIBRE_NAME_THE_METAL = 'Name the metal: mild steel, stainless, aluminium, brass, galvanised, copper or Colorbond.'
FIBRE_GIVE_THICKNESS = 'Give the thickness of the metal sheet in mm: each metal has its own in-house cap on the fibre laser.'


def machine_material_refusal(machine, product):
    """The refusal for a material sent to a machine that only takes certain material families (MACHINES[..]['materials_only']),
    None when the machine takes it.  The Gunner cuts vinyl only (owner ruling 16-Oct-2026)."""
    only = (MACHINES.get(machine) or {}).get('materials_only')
    if not only or (product or {}).get('material') in only: return None
    what = (product or {}).get('material_name') or 'This material'
    return f"{MACHINES[machine]['name'].split(' ')[0]} cuts {' / '.join(only)} only: {what} goes on another machine."


# Kiss cut (owner ruling d08, 16-Oct-2026): cuts the vinyl face and leaves the backing whole.  It runs on the Gunner only
# until further notice.  The Ameida can kiss cut but its table is not aligned yet: flip AMEIDA_KISS_CUT to True once it is.
AMEIDA_KISS_CUT = False
CUT_PROCESSES = ('through', 'kiss')
KISS_GUNNER_ONLY = 'Kiss cut runs on the Gunner only.'
KISS_AMEIDA_NOT_ALIGNED = 'Kiss cut runs on the Gunner only until the Ameida table is aligned.'
# Perforated vinyl is through cut only, never kiss cut (Danilo, 16-Oct-2026 10:39, owner relayed).  The vinyl families
# (monomeric, polymeric, frosted, perforated, reflective) all sit under the one 'vinyl' material, so perforated stock is
# known only by its name: a custom material such as "Perforated window vinyl" with family vinyl.
PERFORATED_THROUGH_ONLY = 'Perforated vinyl is through-cut only on the Gunner: no kiss cut.'


def is_perforated(product):
    """True for vinyl whose material name (or profile name) says perforated, case-insensitive."""
    p = _profile(product)
    return p.get('material') == 'vinyl' and 'perforated' in f"{p.get('material_name') or ''} {p.get('name') or ''}".lower()


def cut_process_for(product, cut_process=None, machine=None):
    """(process, note) for a nest request.  process is 'through' (the default) or 'kiss'; note is the line the reply
    carries when the process was chosen for the operator (the Gunner defaults to kiss cut, its normal job).
    The product's cutter decides both the default and the refusal; `machine` (the PC's ?machine=) is accepted but not used.
    Raises ValueError for an unknown value or for kiss cut on a cutter that may not do it."""
    p = _profile(product); cutter = p.get('cutter')
    asked = str(cut_process or '').strip().lower()
    if asked and asked not in CUT_PROCESSES:
        raise ValueError(f'Cut process "{cut_process}" is not known: use through or kiss.')
    perforated = cutter == 'gunner' and is_perforated(p)       # Danilo 16-Oct-2026: perforated vinyl = no kiss cut
    if not asked:
        if perforated:
            return 'through', 'Cut through: perforated vinyl is through-cut only on the Gunner (no kiss cut), so this job cuts right through.'
        if cutter == 'gunner':                     # the product's cutter decides, as for the refusal below (L5 round 2, N2)
            return 'kiss', 'Kiss cut: the Gunner kiss cuts by default (vinyl face only, backing left whole). Send cut_process "through" to cut right through.'
        return 'through', None
    if asked == 'kiss' and perforated: raise ValueError(PERFORATED_THROUGH_ONLY)
    if asked == 'kiss' and cutter != 'gunner':
        if cutter == 'ameida' and AMEIDA_KISS_CUT: return 'kiss', None
        raise ValueError(KISS_AMEIDA_NOT_ALIGNED if cutter == 'ameida' else KISS_GUNNER_ONLY)
    return asked, None


# ---------------------------------------------------------------- machines
MACHINES = {
    'colorado': {
        'name': 'Canon Colorado M5S', 'kind': 'printer', 'feed': 'roll',
        'print_width': 1600,       # mm across the roll
        'max_thickness': 0.8,      # mm, media
        'limits': 'max 1600 mm print width, media up to 0.8 mm; wider work is panelled with a seam',
        'source': 'Shop capabilities table: "Max 1600mm print width". Canon M-series specification: roll width up to 1,625 mm (64 in), print margin 5.3 mm, '
                  '11.0 mm with Media Step Control (asia.canon/en/business/colorado-m-series/specification), so 1600 mm is inside the machine on a full-width roll. '
                  'Media up to 0.8 mm, roll up to 50 kg and 220 mm across: Canon spec sheet on file, Colorado_M-series_Specsheet_FINAL_METRIC p.4 (memory).',
    },
    'jv330': {
        'name': 'Mimaki JV330-160 roll printer', 'kind': 'printer', 'feed': 'roll',
        'print_width': 1610,       # mm across the roll
        'max_thickness': 1,        # mm, media
        'limits': 'max 1610 mm print width on media up to 1620 mm wide, media up to 1 mm; wider work is panelled with a seam',
        'source': 'The shop\'s second roll-to-roll printer: Thomas\'s 29-Aug-2026 machine-software list names the "Mimaki JV330-160" on ONYX Thrive (memory, '
                  'reference_onyx_data_access_api). Limits: Mimaki JV330 series specification, JV330-160 column, mimaki.com/product/inkjet/i-roll/jv330-series/specification.html '
                  '(read 17-Sep-2026): max print width 1,610 mm, max media width 1,620 mm, media thickness 1 mm or lower, roll up to 250 mm across and 45 kg.',
    },
    'flora': {
        'name': 'Flora XTRA 3220 UV flatbed', 'kind': 'printer', 'feed': 'flatbed',
        'field': (3200, 2000), 'max_thickness': 50,
        'limits': 'bed 3200 x 2000 mm, substrate up to 50 mm',
        'source': 'Shop capabilities table: "Bed 3200 x 2000mm, substrate up to 50mm". Flora: 2.00 x 3.20 m true flatbed, 4 vacuum zones (adver-tech.co.za/xtra-3220-uv).',
    },
    'jfx200': {
        'name': 'Mimaki JFX200-2513 EX UV flatbed', 'kind': 'printer', 'feed': 'flatbed',
        'field': (2500, 1300), 'max_thickness': 50,
        'limits': 'bed 2500 x 1300 mm, substrate up to 50 mm and under 50 kg/m2; a 3000 x 1500 panel goes on the Flora',
        'source': 'The shop\'s second UV flatbed, LUS150 CMYK + white + primer + clear; bed 2,500 x 1,300 mm per the Mimaki sales email of 8-Oct-2021 '
                  '(memory, project_production_equipment 2b). Limits: Mimaki JFX200-2513 EX specification, mimaki.com/product/inkjet/i-flat/jfx200-2513-ex/specification.html '
                  '(read 17-Sep-2026): media 2,500 x 1,300 mm, height max 50 mm, weight less than 50 kg/m2.',
    },
    'biesse': {
        'name': 'Biesse Rover Plast J FT 1530 CNC router', 'kind': 'cutter', 'field': (3078, 1563), 'max_thickness': 200,
        'limits': 'working field 3078 x 1563 x 200 mm',
        'source': 'Shop capabilities table: "Working field 3078 x 1563 x 200mm".',
    },
    'co2': {
        'name': 'DAHAN L6-1530 CO2 laser', 'kind': 'cutter', 'field': (3000, 1500),
        'max_thickness_by_material': {'acrylic': 40, 'acrylic_clear': 40, 'timber': 20},
        'limits': 'bed 3000 x 1500 mm; acrylic up to 40 mm, wood / MDF / ply up to 20 mm, no metal; a CCD camera for print-then-cut is optional on this model and not recorded as fitted',
        'source': 'Shop capabilities table: "Acrylic flame-polished edge up to 40mm, wood/MDF/plywood up to 20mm. Does not cut metal". '
                  'Bed 1,500 x 3,000 mm: DAHAN L6-1530 specification on file (memory, 15-Apr-2026), which also lists the CCD contour camera as optional. '
                  'Whether this machine has one is not recorded: without it a printed sheet is registered by hand on the laser. '
                  'Tube power: 300 W was carried in this machine\'s name with no source on file and is [from memory - unverified], so the name no longer shows it. '
                  'The owner ruled 16-Oct-2026 that the Dahan is the stronger cutter of the two CO2 lasers and that tube figures are not to be read as capacity; '
                  'the caps above are what decides a job.',
    },
    'pulse': {
        # The shop's second CO2 laser, the owner's "Pulse CO2 laser": Pulse Laser Systems ART 2513, bought 19-Oct-2022,
        # PC desktop-5c27401 (192.168.15.34), LightBurn.  Same concept as the Dahan (same materials, LightBurn, colour-mapped DXF),
        # smaller bed and less cutting capacity.  The owner, 16-Oct-2026: "the type of materials are identical to the Dahan laser"
        # and "acrylic ... we only cut up to 20mm on the pulse laser".
        'name': 'Pulse ART 2513 CO2 laser', 'kind': 'cutter', 'field': (2500, 1300),
        'max_thickness_by_material': {'acrylic': 20, 'acrylic_clear': 20, 'timber': 6},
        'limits': 'bed 2500 x 1300 mm (a full 2440 x 1220 mm sheet fits whole, not 3000 x 1500); acrylic up to 20 mm, thin wood / MDF / ply only, up to 6 mm, no metal; '
                  'no CCD camera recorded, a printed sheet is registered by hand',
        'source': 'The Dahan is the stronger of the two CO2 lasers: owner 16-Oct-2026, "PULSE is about two thrid the power of DAHAN. Dahan is certainly more powrful. '
                  'IGnore than number saying pulse is more powerful, it is not". Read the caps below, never a tube figure. '
                  'Bed 1300 x 2500 mm, ZnSe lens, rack and pinion with Yaskawa servos, air assist, manual focus, LightBurn: Pulse Laser Systems proposal '
                  '"ART 1530 R350" (Gary Chapman, 20-Sep-2022, Platinum_Signs_350W.pdf) and tax invoice 8556 "Art 2513 350W laser cutter" (19-Oct-2022, A$42,650 ex GST), '
                  'which name a 350 W tube - a figure from a quote for the bigger 1530 bed, and not this machine\'s capacity, per the ruling above; '
                  'both in the marcio@ / info@ mailboxes; raw copies in Supabase analysis_snapshots 851 (175 emails) and 852 (facts). '
                  'Bed confirmed by the owner 16-Oct-2026 ("2500mm x 1300mm. Meaning we can take on that machine the standard full size - 2440mm x 1220mm"). '
                  'Acrylic 20 mm: owner 16-Oct-2026 ("acrylic ... we only cut up to 20mm on the pulse laser"); Pulse visit report 16-Mar-2023 (Maz Niroomand): 20 mm black acrylic '
                  'cuts at 85% power and 2 mm/s across the whole bed, masking removed first, edge not high-gloss. '
                  'Wood / MDF / ply 6 mm: owner 16-Oct-2026, "We only cut thin wood on the pulse, like up to 6mm thick max" - his figure, not an estimate; '
                  'it replaces the earlier 13 mm [estimate] (two-thirds of the Dahan\'s 20 mm). '
                  'Materials identical to the Dahan: owner 16-Oct-2026. LightBurn drives it (Gary Chapman, 11-May-2022: "its Lightburn software we use"; LightBurn Pro 2.1.01, '
                  'device "1325", seen on the PC 16-Oct-2026). The tube\'s real rating is unverified from here; the label on the tube or chiller, or Pulse Laser Systems, would settle it.',
    },
    'fibre': {
        # max_thickness: the warning line when no metal is named (stainless / aluminium cap); name the metal for its own cap.
        'name': 'Raycus 3 kW fibre laser', 'kind': 'cutter', 'field': (3000, 1500), 'max_thickness': FIBRE_CAP_MM['stainless']['cap'],
        'limits': 'bed 3000 x 1500 mm; in-house cap mild steel 10, stainless 6, aluminium 6, brass 2, galvanised 3, copper 2, Colorbond 1 mm (no high-pressure gas control), thicker goes out',
        'source': 'Shop capabilities table: "Bed 3000 x 1500mm", O2 for mild steel / Corten, N2 for stainless / aluminium / brass. '
                  'Raycus 3000 W cutting table (sheet "3000", Brent / Dahan, WhatsApp 5-Jun-2026), non-trial maximum: mild steel 20 mm (O2 0.6 bar), '
                  'stainless 8, aluminium 6, brass 5 mm (N2 14-16 bar). Brent, WhatsApp 27-May-2026: the machine is not set up for high-pressure gas control. '
                  'In-house caps (BUILD-CONTRACT fibre cap decision, 16-Oct-2026): mild steel 10 (owner), stainless 6, aluminium 6, brass 2 and copper 2 (owner correction); '
                  'galvanised 3, Colorbond 1 mm from the prior shop table.',
    },
    'ameida': {
        'name': 'Ameida B9 digital knife cutter (CCD)', 'kind': 'cutter', 'field': (3000, 1500), 'max_thickness': 50,
        'max_thickness_by_material': {'pvc': 6},       # acrylic never goes on the knife (Marcio, 17-Sep-2026)
        'roll_width': 1600,        # mm across a roll fed through the cutter (owner-stated)
        # Roll vinyl on the Ameida is printed (Colorado / solvent) and cut through ONYX from one PDF; the roll is about 45 m and
        # the file is the job length, so the 3000 mm table length no longer limits a roll job (Danilo + owner, 20-Oct-2026).
        # feed_unbounded is read for roll products only (machine_warnings), so boards keep the 3000 x 1500 table check.
        'feed_unbounded': True,
        'job_length_cap': 15000,   # mm; a warning above 15 m, never a refusal (Danilo + owner, 20-Oct-2026)
        'limits': 'table 3000 x 1500 mm for boards, roll material in rows up to 1600 mm wide, up to 50 mm thick with the oscillating knife, PVC about 6 mm with the router head, no acrylic; print-then-cut with CCD registration; takes DXF, PDF, HPGL and PLT',
        'source': 'Shop capabilities table: "Print-then-cut with CCD registration; vinyl/card/Foamex/corflute/thin acrylic. 3000 x 1500mm, <= 50mm thick". '
                  'Rows of vinyl up to 1.6 m wide: Marcio, 17-Sep-2026 ("the knife cutter can also add rows of vinyl and then cut the rows up to 1.6 m wide"); the table width that allows it is not '
                  'on file - a 1600 mm row does not fit a 1500 mm table, so the plate is to be read (open question 9). '
                  'Machine specs on file (memory, Ameida quote): table "3,000 x 1,500 mm (to confirm: custom or B9-3020 3 x 2 m)"; tools EOT oscillating knife, V-cut, creasing wheel, '
                  'RZ router 350 W / 60,000 rpm for "thin acrylic, PVC, chevy/KT board up to ~6 mm", CCD 0.1 mm, conveyor table for roll material; data formats DXF, HPGL, PDF, PLT. '
                  'Roll feed with take-up confirmed by Marcio, 17-Sep-2026: dual function - vinyl and banner from the roll, boards (cardboard, corflute, foam PVC, acoustic felt) on the table, '
                  'a board up to 3000 x 1500 either way round. The model digits on the plate (B9-3015 / B9-3020) would settle the table width - still to be read.',
    },
    'gunner': {
        # Bed 1565 mm wide x 1240 mm feed, auto-feeding every 1240 mm without splitting the file, so the length is unbounded:
        # reported by Danilo via the owner 16-Oct-2026 (unconfirmed then), confirmed by Danilo 16-Oct-2026 10:39 (owner relayed).
        # He caps a job at about 15 m (job_length_cap: a warning past it, never a refusal).  Supplier spec still pending; the
        # owner, 16-Oct-2026 11:40: it "should not be an impediment".
        'name': 'Gunner GR-1612F digital cutter', 'kind': 'knife', 'envelope': (1565, 1240), 'field': (1565, 1240), 'roll_width': 1565,
        'feed_unbounded': True, 'max_thickness': None,
        'roll_fits': 1600,                     # mm; Danilo 16-Oct-2026 10:39: a 1600 mm roll fits on the machine, only 1565 of it is cut
        'job_length_cap': 15000,               # mm; Danilo 16-Oct-2026 10:39: "no hard limit", he caps Gunner jobs at about 15 m
        'materials_only': ('vinyl',),          # owner ruling 16-Oct-2026: "Gunner we only cut vinyl, just vinyl ever."
        'limits': 'cut width 1565 mm (a 1600 mm roll fits and cuts 1565), 1240 mm per feed, about 840 mm of it usable after the feed dots [assumption], '
                  'any length (auto-feed, file not split), jobs capped at about 15 m by the operator; knife, no kerf, no heat; '
                  'vinyl only (monomeric, polymeric, frosted, perforated, reflective; perforated is through cut only, no kiss cut); '
                  'print and cut files come out of CorelDRAW, whose plugin (SignWorkPro) adds the registration dots, about 15 mm per side, dots at most 803 mm apart, and starts the cut '
                  '(confirmed by Danilo 16-Oct-2026 10:39, owner relayed; first reported the same morning, unconfirmed); '
                  "importing PS Nest's nested PDF/DXF into CorelDRAW for the plugin's dots is not proven (Corel import untested; Danilo's test cut pending)",
        'source': 'Supplier invoice GR240409D06, 9-Apr-2024, SKU GR1612F "DIGITAL CUTTER" (Supabase supplier_bill_line_search). '
                  'Bed 1600 x 1200 mm class from the model number, unmeasured; largest job seen 1520 mm wide (gunner_yd_jobs cut_YELLOW_7parts, 7-Oct-2026). '
                  'Bed 1565 x 1240 mm feed, auto-feed every 1240 mm, CorelDRAW plugin for the dots: Danilo via the owner, 16-Oct-2026, unconfirmed (this supersedes the SignWorkPro note '
                  'and the 1600 x 1200 model-number size). PS Nest\'s 5 x 6 mm marks were provisional (open decision d07). '
                  'Confirmed by Danilo 16-Oct-2026 10:39 (owner relayed): bed 1240 mm feed x 1565 mm max cut width; a 1600 mm roll physically fits and cuts 1565; rolls in use 1220, 1370, '
                  '1520 and 1600 mm wide; no hard length limit, auto-feed every 1240 mm, file not split, jobs capped at about 15 m; each 1240 mm feed loses about 400 mm to the feed dots, '
                  'so about 840 mm is usable per feed (TBC) [assumption]; the CorelDRAW plugin (SignWorkPro) on the Gunner PC generates the dots and starts the cut, so PS Nest draws no '
                  'dots for the Gunner (d07 closed; Corel import untested; Danilo\'s test cut pending); measured: 606 x 1606 mm artwork became 1635 mm wide with the dots, about 14.5 mm per side (inferred); dot spacing at most 803 mm '
                  '(the plugin\'s, recorded only); vinyl families monomeric, polymeric, frosted, perforated, reflective; perforated vinyl is through cut only. '
                  'Supplier spec still pending (owner, 16-Oct-2026 11:40: "should not be an impediment"). '
                  'Staff feed it per-piece cut-contour PDFs (gunner_yd_jobs 7-14 Oct 2026). Vinyl only, no thickness limit: owner ruling 16-Oct-2026 ("Gunner we only cut vinyl, just vinyl ever.").',
    },
}

# The biggest sheet the shop handles at all, whatever the machine: no stock sheet may exceed it (Marcio rule 27-Apr-2026, short side
# tightened to the router's 1563 mm on 29-Apr-2026; memory feedback_sheet_size_limit).  Machine beds are checked first; this catches
# the rest, e.g. a 3100 mm sheet that the flatbed's 3200 mm spec would take but the floor does not.
SHOP_ENVELOPE = (3060, 1563)

# ---------------------------------------------------------------- what each cutting technology asks of a layout
_ROUTER_SOURCES = {
    'edge': '15 mm. Cutlistor CNC nesting guide: "Most beds need 10-20 mm of untouched material around the perimeter for hold-down" (cutlistor.com/guides/cnc-nesting-optimizer). Toolstoday/Vectric nesting workflow: 0.5-1 in (13-25 mm) buffer on all sides for vacuum tables (toolstoday.com/learn/how-to-nest-in-vectric-vcarve-a-step-by-step-workflow). 15 mm sits inside both ranges. Was 10 mm (shop quoting code).',
    'gap': '12 mm = 2 x the 6 mm bit. Toolstoday/Vectric: "A common production-safe rule is 2x the cutter diameter" so each part gets its own kerf and chips clear; Cutlistor: set kerf to the cutter diameter actually run and never halve it for common-line cutting. Was 6 mm (one shared kerf = common-line cut, one deflection scraps two parts).',
    'clamp': '0 mm. Vacuum table, no mechanical clamps; the hold-down zone is already inside the 15 mm edge margin (same two sources as edge). Raise to 50 mm (Toolstoday: "2 in+" clearance) only if physical clamps are fitted.',
    'corner_radius': '0 mm on outside corners: a router cuts a square outside corner. Inside corners of cut-outs cannot be smaller than the bit radius, 3 mm with a 6 mm bit. No published client standard for rounded sign corners.',
    'bit_diameter': '6 mm single-flute (O-flute) upcut solid carbide. P&M Plastics ACM fabricator guide: "sharp, upcut spiral carbide bits" (pmplastics.com.au). YIHAICNC ACM routing guide for a 6 mm single-flute: 10,000-12,000 rpm, feed 5,000-7,000 mm/min, plunge 1,500 mm/min, chip load 0.1-0.2 mm, full-depth single pass up to 4 mm (yhcncrouter.com/cut-acm-on-cnc-guide). Machine-vendor figures, not Biesse-specific: prove on an offcut first.',}

CUTTERS = {
    'biesse': {
        'label': 'CNC router', 'tool': {'kind': 'bit', 'label': 'Bit diameter (mm)'}, 'output': 'dxf',
        'defaults': {'edge': 15, 'gap': 12, 'clamp': 0, 'corner_radius': 0, 'bit_diameter': 6},
        'sources': {k: _ROUTER_SOURCES[k] for k in ('edge', 'gap', 'clamp', 'corner_radius', 'bit_diameter')},
        'assumed': [],
        # BiesseWorks sets inside / outside compensation per layer, so holes, outlines and trim cuts get their own layer
        # (biesse.md M1; same names as make_bin_dxf.py).  Part names only ever go in the separate labelled file.
        'export': {'id': 'biesse', 'layers': {'hole': 'CUT_INNER', 'outer': 'CUT_OUTER', 'trim': 'TRIM'},
                   'colours': {'CUT_INNER': 1, 'CUT_OUTER': 5, 'TRIM': 4}, 'ccd_dots': None, 'labels': True, 'cap_by_material': None},
    },
    'co2': {
        'label': 'Dahan CO2 laser', 'tool': {'kind': 'kerf', 'label': 'Kerf (mm)'}, 'output': 'dxf',
        'defaults': {'edge': 5, 'gap': 5, 'clamp': 0, 'corner_radius': 0, 'bit_diameter': 0.3},
        'sources': {
            'edge': '5 mm. No published figure for a CO2 bed; the sheet only has to lie flat on the slats and the beam needs no hold-down zone. Shop judgement. [assumption]',
            'gap': '5 mm. A CO2 kerf is 0.2-0.5 mm and the heat-affected band reaches 0.13-0.5 mm from each edge (rivcut.com/blog/laser-cutting-tolerances), so parts '
                   'physically need about 1.5 mm; thick acrylic holds heat, and cutting too slowly gives "rounded corners, wide cuts, and distortion" (gwklaser.com/how-to-laser-cut-acrylic.html). '
                   '5 mm keeps flame-polished edges of neighbours apart on 10-40 mm sheet. No published spacing figure for acrylic: prove on an offcut, thin sheet can go tighter. [assumption]',
            'clamp': '0 mm. Nothing clamps the sheet on a laser bed.',
            'corner_radius': '0 mm. A laser cuts a square corner; the beam radius (about 0.15 mm) is below anything a sign needs.',
            'bit_diameter': 'Kerf 0.3 mm, the middle of the published 0.20-0.51 mm CO2 range (rivcut.com/blog/laser-cutting-tolerances). Used only to check the gap; kerf compensation '
                            'belongs in the laser software, PS Nest never offsets a cut line.',
        },
        'assumed': ['edge', 'gap'],
        # LightBurn maps a DXF by colour, not layer name: red ACI 1 = palette 02, blue ACI 5 = palette 01 #0000FF exactly.
        # Separation (trim) cuts go on blue so they stay out of the kerf offset and inner-first order (co2.md :33, :73).
        # No labels: LightBurn would burn the part names (co2.md :65).
        'export': {'id': 'co2', 'layers': {'hole': 'CUT', 'outer': 'CUT', 'trim': 'SEPARATION'},
                   'colours': {'CUT': 1, 'SEPARATION': 5}, 'ccd_dots': None, 'labels': False, 'cap_by_material': None},
    },
    'fibre': {
        'label': 'Fibre laser', 'tool': {'kind': 'kerf', 'label': 'Kerf (mm)'}, 'output': 'dxf',
        'defaults': {'edge': 10, 'gap': 6, 'clamp': 0, 'corner_radius': 0, 'bit_diameter': 0.2},
        'sources': {
            'edge': '10 mm. "Minimum edge distances should be at least 1x thickness"; the sheet margin is the no-cut zone kept for clamps or holders '
                    '(shop.machinemfg.com/part-nesting-the-dos-and-donts-of-nesting-laser-cut-shapes). 10 mm covers the 6 mm in-house cap with room for a skewed sheet.',
            'gap': '6 mm = 1 x the 6 mm in-house thickness cap. "A dependable rule of thumb is to set part spacing at one to two times the material thickness", wider for thin sheet '
                   'under 1.5 mm and for aluminium, because overlapping heat-affected zones weld or distort parts (same source; shop.adhmt.com nesting guide). '
                   'Type the thickness and PS Nest warns when the gap drops below it.',
            'clamp': '0 mm, inside the 10 mm edge. Raise it if the machine grips the sheet with clamps that reach further in.',
            'corner_radius': '0 mm.',
            'bit_diameter': 'Kerf 0.2 mm: "fiber lasers produce 0.006 in to 0.012 in kerf" = 0.15-0.30 mm (sendcutsend.com/guidelines/nesting). Used only to check the gap; '
                            'kerf compensation belongs in the laser software. Common-line cutting is not used: parts that share a line come out a kerf undersize.',
        },
        'assumed': [],
        # CypCut does lead-ins, kerf and order itself: clean closed outlines on one cut layer, never on layer 0 (not machined),
        # no labels (fibre.md F3).  Thickness: FIBRE_CAP_MM, enforced in machine_blocks.
        'export': {'id': 'fibre', 'layers': {'hole': 'CUT', 'outer': 'CUT', 'trim': 'CUT'},
                   'colours': {'CUT': 1}, 'ccd_dots': None, 'labels': False, 'cap_by_material': FIBRE_CAP_MM},
    },
    'ameida': {
        'label': 'Knife cutter', 'tool': {'kind': 'knife', 'label': 'Tool width (mm)'}, 'output': 'cut',
        'defaults': {'edge': 10, 'gap': 6, 'clamp': 0, 'corner_radius': 0, 'bit_diameter': 0},
        'sources': {
            'edge': '10 mm. Room for the sheet frame and any camera marks outside the parts; the CCD "scans registration marks printed at sheet corners" and corrects offset, '
                    'rotation and stretch (ldcut.com/blog/what-is-digital-flatbed-cutter.html). No published margin for the B9. [assumption]',
            'gap': '6 mm = 2 x the 3 mm bleed. A knife removes no material, so the gap only has to keep one part\'s bleed off its neighbour: PS Nest trims every bleed to half the gap. '
                   'Geometry, not a published figure; lower the bleed and the gap can follow.',
            'clamp': '0 mm. Vacuum table.',
            'corner_radius': '0 mm. A drag or oscillating knife lifts and turns at corners.',
            'bit_diameter': '0 mm: a knife has no kerf.',
        },
        'assumed': ['edge'],
        # Ameida picks the tool by line colour, so every entity carries colour 62 (ameida.md M4).  CCD registration: black
        # solid 5 mm dots, 4 or 6 (6 when the long side is over 1200 mm), 2-5 mm in from the edge, in the print AND the cut
        # file at the same coordinates, on their own MARK colour so they are not taken for small round cuts (B4 manual
        # 2105-2133, 1222-1224, 2260-2275; B9 not confirmed).  No labels: send outlines, not fonts [assumption].
        'export': {'id': 'ameida', 'layers': {'hole': 'CUT', 'outer': 'CUT', 'trim': 'CUT'},
                   'colours': {'CUT': 1, 'MARK': 6},
                   'ccd_dots': {'count': 6, 'diameter': 5, 'edge_gap': 3, 'six_over': 1200, 'layer': 'MARK'},
                   'labels': False, 'cap_by_material': None},
    },
    'gunner': {
        'label': 'Digital cutter (Gunner)', 'tool': {'kind': 'knife', 'label': 'Tool width (mm)'}, 'output': 'cut',
        'defaults': {'edge': 15, 'gap': 6, 'clamp': 0, 'corner_radius': 0, 'bit_diameter': 0},
        'sources': {
            'edge': '15 mm: room for the registration dots the CorelDRAW plugin adds round the artwork. Measured by Danilo (16-Oct-2026 10:39, owner relayed): '
                    '606 x 1606 mm artwork became 1635 mm wide with the dots, (1635 - 1606) / 2 = about 14.5 mm per side (inferred), rounded up to 15. '
                    'Was 10 mm, the Ameida figure. No published margin for the GR-1612F. [assumption]',
            'gap': '6 mm = 2 x the 3 mm bleed, as on the Ameida: a knife removes no material, so the gap only keeps one part\'s bleed off its neighbour. [assumption]',
            'clamp': '0 mm. Flatbed with auto-feed; no clamp zone recorded.',
            'corner_radius': '0 mm. A drag or oscillating knife lifts and turns at corners.',
            'bit_diameter': '0 mm: a knife has no kerf.',
        },
        'assumed': ['edge', 'gap'],
        # BUILD-CONTRACT "Gunner GR-1612F" profile.  Cut paths on CutContour (Jingwei / SignWorkPro convention), trim
        # cuts on TRIM; the per-sheet cut-contour PDF is the file staff use today.  The contract's registration marks (5 x 6 mm,
        # 'assumed') are gone: the CorelDRAW plugin (SignWorkPro) on the Gunner PC adds its own dots and starts the cut
        # (Danilo, 16-Oct-2026 10:39, owner relayed), so ccd_dots is None and no PDF or DXF gets dots from PS Nest.
        # 'registration' only records the plugin's dots; nothing draws from it.  15 mm per side: the edge source above.
        # 803 mm: the largest dot spacing Danilo read off the plugin, 16-Oct-2026 10:39.
        'export': {'dxf': 'gunner', 'layers': {'cut': 'CutContour', 'trim': 'TRIM'}, 'pdf_cut': True, 'labels': True,
                   'ccd_dots': None, 'kerf_mm': 0, 'max_thickness_mm': None,
                   'registration': {'by': 'CorelDRAW plugin (SignWorkPro) on the Gunner PC', 'clear_per_side_mm': 15, 'dot_spacing_max_mm': 803,
                                    'note': 'Registration dots are added by the Corel plugin on the Gunner PC (Corel import untested; Danilo\'s test cut pending); '
                                            'they need about 15 mm clear on each side across the roll, and PS Nest warns when the job is too wide for that.'}},
    },
}
# The Pulse is a second CO2 laser driven by LightBurn (MACHINES['pulse']): the Dahan's layout rules and colour-mapped DXF
# apply unchanged, so its profile is the co2 one under its own id.  Only the machine (bed, caps) differs.
CUTTERS['pulse'] = {**CUTTERS['co2'], 'label': 'Pulse CO2 laser', 'defaults': dict(CUTTERS['co2']['defaults']), 'sources': dict(CUTTERS['co2']['sources']),
                    'assumed': list(CUTTERS['co2']['assumed']), 'export': {**CUTTERS['co2']['export'], 'id': 'pulse'}}

# Download kinds each cutter is offered.  A kind the profile does not list is refused by server.job_files.
_ALL_KINDS = ['dxf', 'dxf-labels', 'print', 'print-files', 'cut', 'cut-files', 'layout', 'report', 'all']
_EXPORT_KINDS = {
    'biesse': _ALL_KINDS,                                                          # labelled DXF kept as a separate reference file
    'co2': [k for k in _ALL_KINDS if k != 'dxf-labels'],
    'pulse': [k for k in _ALL_KINDS if k != 'dxf-labels'],                         # LightBurn too: labels would be burned
    'fibre': ['dxf', 'layout', 'report', 'all'],                                   # metal: nothing printed, cut from the DXF only
    'ameida': [k for k in _ALL_KINDS if k != 'dxf-labels'],
    'gunner': _ALL_KINDS,                                                          # pdf_cut: the cut PDF is its primary file
}


def product_export(cutter_id):
    """The product's `export`: which cutter profile writes its DXF and which download kinds it offers.
    None for a custom cutter, whose files stay exactly as before profiles existed."""
    if cutter_id not in CUTTERS: return None
    return {'dxf': cutter_id, 'kinds': list(_EXPORT_KINDS[cutter_id])}

# ---------------------------------------------------------------- materials
ROLL_LENGTH = 45000      # mm: the default vinyl roll length, a default, not every roll (Danilo + owner, 20-Oct-2026)
_SHEET_2440 = {'label': '2440 x 1220 mm (standard stock)', 'w': 2440, 'h': 1220}
_SHEET_2400 = {'label': '2400 x 1200 mm (metric stock)', 'w': 2400, 'h': 1200}
_SHEET_3000 = {'label': '3000 x 1500 mm (some stock; Flora only)', 'w': 3000, 'h': 1500}
_PANELS = [_SHEET_2440, _SHEET_2400, _SHEET_3000]
_PANELS_SMALL = [_SHEET_2440, _SHEET_2400]
_FLATBEDS = ['flora', 'jfx200']    # first is the default; the operator picks per job
_ROLL_PRINTERS = ['colorado', 'jv330']
_BLEED = ('3 mm. Design-ops review rule for rigid substrates (shop record, not a published figure); the shop\'s own artwork carries 3 mm or 15 mm. [assumption]')
_OFFCUT = ('300 mm. No published standard for a reusable offcut. Shop judgement: a strip under 300 mm holds no saleable sign (the shop\'s vinyl minimum dimension is 300 mm too). [assumption]')
_PANEL_SIZES = ('Panels for the UV flatbeds are mostly 2400 x 1200 or 2440 x 1220 mm and some are 3000 x 1500 mm, depending on the substrate: Marcio, 17-Sep-2026. '
                'Only the Flora bed takes 3000 x 1500. ')
_STOCK = _PANEL_SIZES + 'Every print / cut template pair the shop keeps (ACM, acrylic, clear acrylic, PVC, corflute, vinyl) is a 2440 x 1220 mm frame (NAS, read 17-Sep-2026).'

MATERIALS = {
    'acm': {
        'name': 'ACM panel (aluminium composite)', 'printers': _FLATBEDS, 'cutters': ['biesse'],
        'sheets': [_SHEET_2440, _SHEET_2400, {'label': '3000 x 1500 mm (outdoor grade; Flora only)', 'w': 3000, 'h': 1500}], 'thicknesses_mm': [3, 4],
        'stock_source': _PANEL_SIZES + 'platinum-shop CLAUDE.md, production capabilities table (ACM stock 1220x2440 standard, 1500x3000 outdoor, 3/4 mm).',
    },
    'acrylic': {
        'name': 'Acrylic', 'printers': _FLATBEDS, 'cutters': ['co2', 'pulse', 'biesse'], 'sheets': _PANELS, 'sheets_by_cutter': {'pulse': _PANELS_SMALL}, 'stock_source': _STOCK,
        'notes': 'Laser for a flame-polished edge (up to 40 mm on the Dahan, 20 mm on the Pulse); router for thick or bevelled work. Never the knife cutter: shop rule, Marcio 17-Sep-2026.',
    },
    'acrylic_clear': {
        'name': 'Clear acrylic, reverse printed', 'printers': _FLATBEDS, 'cutters': ['co2', 'pulse', 'biesse'], 'sheets': _PANELS, 'sheets_by_cutter': {'pulse': _PANELS_SMALL},
        'mirror': True, 'stock_source': _STOCK,
        'notes': 'Second-surface print: the artwork is printed mirrored on the back and read through the sheet. The shop\'s PRINT_ACRYLIC_CLEAR template has every image mirrored '
                 '(7 of 7) where PRINT_ACRYLIC has none. PS Nest mirrors each part, artwork and cut line together, so print, cut and DXF files stay in register.',
    },
    'pvc': {
        'name': 'PVC foam board (Foamex / Palboard)', 'printers': _FLATBEDS, 'cutters': ['biesse', 'ameida'], 'sheets': _PANELS, 'stock_source': _STOCK,
    },
    'corflute': {
        'name': 'Corflute', 'printers': _FLATBEDS, 'cutters': ['ameida'], 'sheets': _PANELS_SMALL,
        'stock_source': _STOCK + ' No 3000 x 1500 corflute: Mulford does not stock it (memory, reference_mulford_corflute_prices).',
        'notes': 'Flutes run one way: untick Turn on parts that must keep the flute direction.',
    },
    'cardboard': {
        'name': 'Cardboard', 'printers': _FLATBEDS, 'cutters': ['co2', 'pulse', 'ameida'], 'sheets': [_SHEET_2440],
        'stock_source': 'Cardboard comes 2440 x 1220 mm and is cut on the CO2 laser or the Ameida knife - both suit many jobs, the job decides which: Marcio, 17-Sep-2026.',
        'notes': 'CO2 laser or knife: both suit most cardboard work, pick per job. Printing on the UV flatbeds, as for the other boards, is not confirmed by the shop [assumption]. '
                 'Flutes on corrugated board run one way: untick Turn on parts that must keep the flute direction.',
    },
    'timber': {
        'name': 'MDF / plywood / timber', 'printers': _FLATBEDS, 'cutters': ['co2', 'pulse', 'biesse'], 'sheets': _PANELS_SMALL,
        'stock_source': _PANEL_SIZES + '2440 x 1220 and 2400 x 1200 mm are the common board sizes; the shop keeps no template for them. [assumption]',
        'notes': 'CO2 laser up to 20 mm on the Dahan, thin wood only on the Pulse, up to 6 mm; grain runs one way: untick Turn on parts that must follow it.',
    },
    'metal': {
        'name': 'Metal sheet (steel, stainless, aluminium, brass)', 'printers': [], 'cutters': ['fibre'],
        'sheets': [{'label': '2400 x 1200 mm (standard metal sheet)', 'w': 2400, 'h': 1200},
                   {'label': '3000 x 1200 mm (Corten, special order)', 'w': 3000, 'h': 1200}, {'label': '3000 x 1500 mm (Corten, special order)', 'w': 3000, 'h': 1500}],
        'stock_source': 'Metals run 2400 x 1200 mm, not the 2440 x 1220 of rigid substrates: aluminium (raw and colour-coated) 1200 x 2400, Corten 1200 x 2400 standard with '
                        '1200 x 3000 and 1500 x 3000 special, Colorbond 2400 x 1200 (owner-confirmed 8-Jul-2026) - platinum-shop materials table, audited 8-Jul-2026 (memory). '
                        'All fit the 3000 x 1500 bed. Stock on hand is not recorded.',
        'notes': 'Cut only, nothing is printed. Name the metal and its thickness on every job. In-house caps: '
                 + ', '.join(f"{FIBRE_METAL_NAMES[k]} {v['cap']:g} mm" for k, v in FIBRE_CAP_MM.items())
                 + '; thicker is sent out. O2 for mild steel and Corten, N2 for stainless, aluminium and brass.',
    },
    'vinyl': {
        'name': 'Vinyl / SAV on the roll (print & cut)', 'printers': _ROLL_PRINTERS, 'cutters': ['ameida', 'gunner'], 'roll': True,
        # w = the roll length left (45 m by default, not every roll; typed in Roll left (m), owner 21-Oct-2026), h = across the roll.
        # The files are cut to the length the job uses (server.run_nest), never the 45 m (Danilo + owner, 20-Oct-2026).
        'sheets': [{'label': 'Roll 1370 mm wide, 45 m (the usual roll)', 'w': ROLL_LENGTH, 'h': 1370},
                   {'label': 'Roll 1600 mm wide, 45 m (the widest)', 'w': ROLL_LENGTH, 'h': 1600},
                   {'label': 'Roll 1220 mm wide, 45 m', 'w': ROLL_LENGTH, 'h': 1220}],
        'stock_source': 'Rolls are around 1370 mm wide as a rule, some narrower, and 1600 mm at most on both roll printers: Marcio, 17-Sep-2026. '
                        'Vinyl is always a roll, 45 m long by default (not every roll is 45 m: type the length left in Roll left (m)); the file is exactly the length the job uses, '
                        'with no edge margin (the printable area is set in ONYX with the media) and no offcut (the machine cuts the roll off after printing); '
                        'Maximum batch defaults to 10 m and may be reduced. Whole pieces are placed into separate batches; '
                        'an individual piece that cannot fit needs an approved panel or seam plan. Roll left is available stock, not the batch limit. '
                        'The width is across the roll, at most the print width (Colorado 1600 mm, JV330 1610 mm) and the 1600 mm the knife cuts.',
        'notes': 'Print & cut: the artwork carries the CutContour line. Layouts are chosen for the shortest printed length; the file is that length and the result shows it. '
                 'No registration marks, dots or QR code from PS Nest: ONYX adds them (Danilo + owner, 20-Oct-2026).',
        # Files per cutter (Danilo + owner, 20-Oct-2026): the Ameida gets ONE PDF, the art with the CutContour line on the same
        # page (ONYX finds CutContour and separates print and cut); the Gunner gets two, print and cut.
        'roll_files': {'ameida': 'one', 'gunner': 'two'},
        # The Gunner cuts 1565 mm across and feeds 1240 mm at a time with no length limit: the presets are one feed long;
        # Custom size takes any length.  Each feed loses about 400 mm to the feed dots, so about 840 mm of a 1240 mm feed is
        # usable (Danilo, 16-Oct-2026 10:39, TBC [assumption]): the labels say so, the sheet stays one whole feed.
        # One preset per roll in use (1220, 1370, 1520, 1600; Danilo 16-Oct-2026 10:39).  1370 stays first: it is the default
        # sheet (the usual roll, Marcio 17-Sep-2026), so a job sent with no sheet nests as before.
        'sheets_by_cutter': {'gunner': [{'label': 'Roll 1370 mm wide, 45 m (Gunner)', 'w': ROLL_LENGTH, 'h': 1370},
                                        {'label': 'Roll 1220 mm wide, 45 m (Gunner)', 'w': ROLL_LENGTH, 'h': 1220},
                                        {'label': 'Roll 1520 mm wide, 45 m (Gunner)', 'w': ROLL_LENGTH, 'h': 1520},
                                        {'label': 'Roll 1600 mm wide (cuts 1565 mm), 45 m (Gunner)', 'w': ROLL_LENGTH, 'h': 1565}]},
        'stock_source_by_cutter': {'gunner': 'Gunner: vinyl only (owner ruling 16-Oct-2026): monomeric, polymeric, frosted, perforated, reflective; perforated is through cut only. '
                                             'Rolls in use 1220, 1370, 1520 and 1600 mm wide; a 1600 mm roll fits and cuts 1565 mm across. '
                                             'The Gunner auto-feeds every 1240 mm without splitting an individual file; the roll is 45 m by default (type the length left in Roll left (m)). '
                                             'PS Nest places whole pieces in batches of at most 10 m, trimmed to the length each batch uses, with no margin and no offcut. '
                                             'Each 1240 mm feed loses about 400 mm to the feed dots, so about 840 mm per feed is usable (TBC). '
                                             '(Danilo via the owner, 16-Oct-2026, first unconfirmed; confirmed by Danilo 16-Oct-2026 10:39, owner relayed; '
                                             'rolls around 1370 mm wide, 1600 mm at most: Marcio, 17-Sep-2026.) [assumption]'},
    },
}


def _build():
    out = {}
    for mid, m in MATERIALS.items():
        for cid in m['cutters']:
            c = CUTTERS[cid]
            printers = list(m.get('printers') or []); printed = bool(printers)
            defaults = dict(c['defaults']); defaults['bleed'] = 3 if printed else 0; defaults['min_offcut'] = 300
            if m.get('roll'):       # vinyl: no edge margin (ONYX sets the printable area) and no offcut (Danilo + owner, 20-Oct-2026)
                defaults['edge'] = 0; defaults['min_offcut'] = 0
            export = product_export(cid)
            files = (m.get('roll_files') or {}).get(cid)
            if export is not None and files:
                export['roll_files'] = files
                if files == 'one': export['kinds'] = [k for k in export['kinds'] if k not in ('cut', 'cut-files')]
            sources = dict(c['sources'])
            stock = (m.get('stock_source_by_cutter') or {}).get(cid, m['stock_source']); sheets = (m.get('sheets_by_cutter') or {}).get(cid, m['sheets'])
            sources['sheets'] = stock
            sources['bleed'] = _BLEED if printed else '0 mm. Nothing is printed on this material.'
            sources['min_offcut'] = _OFFCUT
            if m.get('roll'):
                sources['edge'] = sources['min_offcut'] = '0 mm on a roll: no edge margin, no offcut (Danilo + owner, 20-Oct-2026).'
            machines = [MACHINES[k]['name'] + ': ' + MACHINES[k]['limits'] for k in printers + [cid]]
            sources['machines'] = ' | '.join(machines) + '. ' + ' '.join(MACHINES[k]['source'] for k in printers + [cid])
            pid = 'acm' if (mid, cid) == ('acm', 'biesse') else f'{mid}-{cid}'
            out[pid] = {
                'name': f"{m['name']} \u2192 {c['label']}", 'material': mid, 'material_name': m['name'], 'cutter': cid, 'cutter_name': MACHINES[cid]['name'],
                'printer': printers[0] if printed else None, 'printer_name': MACHINES[printers[0]]['name'] if printed else None,   # the default
                'printers': [{'id': k, 'name': MACHINES[k]['name']} for k in printers],                                               # the operator's choice
                'roll': bool(m.get('roll')), 'mirror': bool(m.get('mirror')), 'tool': c['tool'], 'output': c['output'], 'export': export,
                'sheets': [dict(s) for s in sheets], 'thicknesses_mm': m.get('thicknesses_mm', []),
                'defaults': defaults, 'sources': sources,
                'assumed': sorted((set(c['assumed']) | ({'bleed'} if printed else set()) | {'min_offcut'} | ({'sheets'} if '[assumption]' in stock else set()))
                                 - ({'edge', 'min_offcut'} if m.get('roll') else set())),   # roll: owner-approved 20-Oct-2026
                'notes': ' '.join(x for x in (m.get('notes'), MACHINES[cid]['limits'].capitalize() + '.') if x),
            }
    return out


PRODUCTS = _build()
# the first profile, exactly as it was proven on the router: its wording and its extra notes are kept
PRODUCTS['acm'].update({
    'name': 'ACM panel (aluminium composite) \u2192 CNC router',
    'notes': 'The router working field is 3078 x 1563 mm, so both stock sheets fit whole. Parts larger than the usable sheet must be split into panels before nesting.',
})


def custom_product(spec):
    """A job-owned profile, never a mutation of the shared shop presets."""
    if not isinstance(spec, dict): raise ValueError('Enter the custom material details.')
    name = str(spec.get('name') or '').strip()
    if not name or len(name) > 100: raise ValueError('Enter a custom material name (1–100 characters).')
    only = (MACHINES.get(spec.get('cutter')) or {}).get('materials_only') or ()
    family = spec.get('family') or (only[0] if len(only) == 1 else 'other')      # blank catalogue template only: a nest request must name the family (resolve_product)
    if family != 'other' and family not in MATERIALS: raise ValueError('Choose a material family from the list.')
    cid = spec.get('cutter') or 'custom'
    if cid not in (*CUTTERS, 'custom'): raise ValueError('Choose a cutting process from the list.')
    refusal = machine_material_refusal(cid, {'material': family, 'material_name': name})
    if refusal: raise ValueError(refusal)
    if family != 'other' and cid != 'custom' and cid not in MATERIALS[family]['cutters']:
        raise ValueError(f"{MATERIALS[family]['name']} is not assigned to {CUTTERS[cid]['label']}. Choose an allowed cutter.")
    kind = spec.get('tool_kind') or 'kerf'
    if kind not in ('bit', 'kerf', 'knife'): raise ValueError('Choose router bit, kerf or knife for the custom cutter.')
    c = CUTTERS[cid] if cid != 'custom' else CUTTERS[{'bit': 'biesse', 'kerf': 'co2', 'knife': 'ameida'}[kind]]
    cname = MACHINES[cid]['name'] if cid != 'custom' else str(spec.get('cutter_name') or 'Custom cutter').strip()[:100]
    roll = bool(spec.get('roll')) if ('roll' in spec or not only) else bool(MATERIALS[family].get('roll'))
    if family != 'other' and roll != bool(MATERIALS[family].get('roll')):
        raise ValueError('The stock type does not match the selected material family.')
    if roll and cid not in ('custom', 'ameida', 'gunner'): raise ValueError('Choose a roll cutter for roll material.')
    printers = [k for k, v in MACHINES.items() if v.get('feed') == ('roll' if roll else 'flatbed')]
    if family != 'other': printers = [k for k in printers if k in MATERIALS[family].get('printers', [])]
    printer = spec.get('printer') or None
    if printer and printer not in printers: raise ValueError('Choose a printer that takes this stock type and material family.')
    defaults = dict(c['defaults'], bleed=3 if printer else 0, min_offcut=300)
    sources = dict(c['sources'], bleed='Operator choice.', min_offcut=_OFFCUT, sheets='Operator-entered stock size.')
    notes = 'Custom material: confirm the selected cutting process and settings for this stock.'
    if cid != 'custom': notes += ' ' + MACHINES[cid]['limits'].capitalize() + '.'
    else: notes += ' Machine capacity is not recorded for this custom cutter.'
    return {'name': f'{name} → {cname}', 'material': family, 'material_name': name,
            'cutter': cid, 'cutter_name': cname, 'printer': printer,
            'printer_name': MACHINES[printer]['name'] if printer else None,
            'printers': [{'id': k, 'name': MACHINES[k]['name']} for k in printers] if printer else [],
            'roll': roll, 'mirror': False, 'tool': dict(c['tool']), 'output': c['output'], 'export': product_export(cid),
            'sheets': [{'label': 'Custom size…', 'w': 2440, 'h': 1220}], 'thicknesses_mm': [],
            'defaults': defaults, 'sources': sources, 'assumed': [], 'notes': notes, 'custom': True}


def resolve_product(product_id, spec=None):
    if product_id == 'custom':
        # A job on a single-family machine (the Gunner: vinyl only, ever) must name that family itself; a missing family is
        # refused, never taken as vinyl, so "ACM 3mm" sent with no family cannot slip onto the Gunner (L5 round 2, N1).
        # custom_product() still fills the family in for the catalogue's blank template.
        only = (MACHINES.get((spec or {}).get('cutter') if isinstance(spec, dict) else None) or {}).get('materials_only')
        if only and spec.get('family') not in only:
            name = str(spec.get('name') or '').strip() or 'This material'
            raise ValueError(machine_material_refusal(spec['cutter'], {'material': spec.get('family'), 'material_name': name}))
        return custom_product(spec)
    if product_id not in PRODUCTS: raise ValueError(f'Unknown material / cutter "{product_id}".')
    return PRODUCTS[product_id]


def _profile(product):
    return product if isinstance(product, dict) else PRODUCTS[product]


def on_machine(product, machine):
    """True when the product runs on `machine` (a ?machine= id): it is cut there, or, for a printer PC such as the
    Colorado, it is printed there (the machine is one of the product's printers)."""
    p = _profile(product)
    return p.get('cutter') == machine or any(x['id'] == machine for x in p.get('printers') or [])

def default_product(material_id, machine=None):
    """The profile a card's material lands on.  With `machine` (the PC's ?machine= bookmark) it is that machine's
    product for the material when there is one, so a card opened on the Pulse lands on acrylic-pulse, not on the
    material's first-listed cutter, and one opened on the Colorado lands on a product it prints; without one, or when
    the machine does not take the material, the first-listed cutter (the shop's usual one) - the caller warns in that
    second case (see server.card_product)."""
    if machine:
        hit = next((pid for pid, p in PRODUCTS.items() if p['material'] == material_id and on_machine(p, machine)), None)
        if hit: return hit
    return next((pid for pid, p in PRODUCTS.items() if p['material'] == material_id), None)

def machine_blocks(product_id, thickness=None, printer=None, metal=None, machine=None):
    """What stops the job outright (an error, not a warning): a thickness the in-house cutter cannot cut and no
    policy sends out, or one the chosen printer cannot take.  On the fibre, `metal` names the metal (FIBRE_CAP_MM key
    or a common name) and is required (owner ruling 16-Oct-2026); past that metal's in-house cap the job is blocked.
    `machine` is the PC's ?machine= id: a material that machine does not take is blocked (the Gunner cuts vinyl only)."""
    p = _profile(product_id); cutter = MACHINES.get(p['cutter'], {}); out = []
    m_id = str(machine or '').strip().lower()
    refusal = machine_material_refusal(m_id, p) or machine_material_refusal(p['cutter'], p)
    if refusal: return [refusal]
    key = fibre_metal(metal) if p['cutter'] == 'fibre' else None
    if p['cutter'] == 'fibre' and (not key or not thickness):     # owner ruling 16-Oct-2026: every fibre job names its metal and thickness
        return [m for m, missing in ((FIBRE_NAME_THE_METAL, not key), (FIBRE_GIVE_THICKNESS, not thickness)) if missing]
    if not thickness: return out
    cap = (cutter.get('max_thickness_by_material') or {}).get(p['material'], cutter.get('max_thickness'))
    if cap and thickness > cap + 1e-6 and p['cutter'] != 'fibre':
        out.append(f"{thickness:g} mm {p['material_name']} cannot be cut on the {cutter['name']} ({cap:g} mm at most in this material). "
                   "Choose another cutter or a thinner sheet.")
    if key and thickness > FIBRE_CAP_MM[key]['cap'] + 1e-6:
        f = FIBRE_CAP_MM[key]
        table = (f"Raycus 3 kW table allows {f['source_max']:g} mm" if f['source_max'] is not None
                 else f"Raycus 3 kW table has no row for {FIBRE_METAL_NAMES[key]}")
        why = _FIBRE_CAP_WHY.get(key) or {'N2': 'no high-pressure gas control'}.get(f['gas'], 'shop table')
        out.append(f"{thickness:g} mm {FIBRE_METAL_NAMES[key]} is blocked on the {cutter['name']}: {table}; in-house cap {f['cap']:g} mm ({why}). "
                   "Send this job out or choose a thinner sheet.")
    pr_id = printer or p['printer']
    if pr_id and pr_id in MACHINES and MACHINES[pr_id].get('max_thickness') and thickness > MACHINES[pr_id]['max_thickness'] + 1e-6:
        out.append(f"{thickness:g} mm is thicker than the {MACHINES[pr_id]['name']} takes ({MACHINES[pr_id]['max_thickness']:g} mm). "
                   "Choose another printer or a thinner sheet.")
    return out

def machine_warnings(product_id, sheet_w, sheet_h, thickness=None, gap=None, printer=None, metal=None):
    """What the machines of this profile would object to: a sheet that does not fit the printer or the cutter,
    a thickness past a machine's limit or the shop's in-house cap, a gap tighter than the metal is thick.
    `printer` is the operator's pick among the profile's printers (default: the first).  On the fibre, a named `metal`
    sets the cap (FIBRE_CAP_MM); past it machine_blocks refuses the job, so no "sent out" warning is given here.
    Warnings, not errors: the limits are the shop's summary table, and the operator may know better."""
    p = _profile(product_id); out = []
    if p.get('custom'):
        out.append('Custom material: machine compatibility and cutting settings must be confirmed for this stock.')
    long_side, short_side = max(sheet_w, sheet_h), min(sheet_w, sheet_h)
    cutter = MACHINES.get(p['cutter'], {'name': p['cutter_name'], 'field': SHOP_ENVELOPE})
    fl, fs = max(cutter['field']), min(cutter['field'])
    if p['roll']:
        rw = cutter.get('roll_width', fs)
        if cutter.get('feed_unbounded'):             # auto-feed: the length is free, only the width across the roll is limited
            # roll sizes are length x roll width; a roll that fits but is wider than the cut is nested on the cut width
            # (roll_nest_width), so only a roll the machine cannot take is warned about.  The length typed in is the roll
            # available, not the job: the 15 m job cap is checked on the length the job uses (server.run_nest).
            if sheet_h > cutter.get('roll_fits', rw) + 1e-6:
                out.append(f"The roll is {sheet_h:g} mm across; the {cutter['name']} cuts {rw:g} mm wide at most.")
        elif long_side > fl + 1e-6:
            out.append(f"A {long_side:g} mm length is more than the {cutter['name']} takes in one go ({fl:g} mm).")
        if short_side > rw + 1e-6 and not cutter.get('feed_unbounded'):
            out.append(f"The roll is {short_side:g} mm across; the {cutter['name']} cuts rows up to {rw:g} mm wide.")
    elif long_side > fl + 1e-6 or short_side > fs + 1e-6:
        out.append(f"The {sheet_w:g} x {sheet_h:g} mm sheet is outside the shop's sheet envelope ({fl:g} x {fs:g} mm)." if p['cutter'] == 'custom' else f"The {sheet_w:g} x {sheet_h:g} mm sheet is larger than the {cutter['name']} takes ({fl:g} x {fs:g} mm): it cannot be cut in one setting.")
    pr_id = printer or p['printer']
    if pr_id:
        if pr_id not in [x['id'] for x in p['printers']]:
            raise ValueError(f'{MACHINES[pr_id]["name"] if pr_id in MACHINES else pr_id} does not print {p["material_name"]}.')
        pr = MACHINES[pr_id]
        if pr['feed'] == 'roll':
            if short_side > pr['print_width'] + 1e-6:
                out.append(f"The frame is {short_side:g} mm across the roll; the {pr['name']} prints {pr['print_width']:g} mm at most. Wider work has to be panelled with a seam.")
        else:
            pl, ps = max(pr['field']), min(pr['field'])
            if long_side > pl + 1e-6 or short_side > ps + 1e-6:
                fits = [MACHINES[x['id']]['name'] for x in p['printers'] if x['id'] != pr_id and MACHINES[x['id']]['feed'] == 'flatbed'
                        and long_side <= max(MACHINES[x['id']]['field']) + 1e-6 and short_side <= min(MACHINES[x['id']]['field']) + 1e-6]
                out.append(f"The {sheet_w:g} x {sheet_h:g} mm sheet is larger than the {pr['name']} bed ({pl:g} x {ps:g} mm)."
                           + (f" The {fits[0]} takes it." if fits else ''))
    if len(out) == int(bool(p.get('custom'))) and not p['roll'] and (long_side > SHOP_ENVELOPE[0] + 1e-6 or short_side > SHOP_ENVELOPE[1] + 1e-6):   # a sheet rule; rolls are limited above
        out.append(f"The {sheet_w:g} x {sheet_h:g} mm sheet is outside the shop's sheet envelope ({SHOP_ENVELOPE[0]:g} x {SHOP_ENVELOPE[1]:g} mm): "
                   "the biggest sheet the production area takes (shop rule 29-Apr-2026).")
    if thickness:
        cap = (cutter.get('max_thickness_by_material') or {}).get(p['material'], cutter.get('max_thickness'))
        mkey = fibre_metal(metal) if p['cutter'] == 'fibre' else None
        if mkey: cap = FIBRE_CAP_MM[mkey]['cap']
        if cap and thickness > cap + 1e-6 and not mkey:
            out.append(f"{thickness:g} mm is more than the {cutter['name']} cuts in-house in this material ({cap:g} mm). " + ('Shop policy: thicker metal is sent out.' if p['cutter'] == 'fibre' else 'Choose another cutter.'))
        if pr_id and MACHINES[pr_id].get('max_thickness') and thickness > MACHINES[pr_id]['max_thickness'] + 1e-6:
            out.append(f"{thickness:g} mm is thicker than the {MACHINES[pr_id]['name']} takes ({MACHINES[pr_id]['max_thickness']:g} mm).")
        if p['cutter'] == 'fibre' and gap is not None and gap < thickness - 1e-6:
            out.append(f"Gap {gap:g} mm is less than the {thickness:g} mm sheet thickness. For laser-cut metal keep 1 to 2 x the thickness between parts, more on thin sheet and aluminium, or the heat of one cut spoils the next.")
    dots = ((CUTTERS.get(p['cutter']) or {}).get('export') or {}).get('ccd_dots') or {}
    if dots.get('assumed'):
        out.append(f"{cutter['name']}: registration marks assumed (not measured): {dots.get('count')} solid {dots.get('size_mm')} mm dots. "
                   "Check them on the machine before the first print-and-cut job.")
    return out


def length_cap_warning(product, length_mm, what='This job'):
    """The warning for a roll length past the cutter's practical job cap (MACHINES[..]['job_length_cap']), None within it.
    The Gunner has no hard length limit; Danilo caps its jobs at about 15 m (16-Oct-2026 10:39).  A warning, never a refusal."""
    p = _profile(product); cutter = MACHINES.get(p.get('cutter')) or {}
    cap = cutter.get('job_length_cap')
    if not cap or not length_mm or float(length_mm) <= cap + 1e-6: return None
    return (f"{what} is {float(length_mm):g} mm; the operator caps {cutter['name'].split(' ')[0]} jobs at about {cap / 1000:g} m ({cap:g} mm; "
            f"no hard limit on the machine). Split it into jobs of {cap / 1000:g} m or less.")


def roll_nest_width(product, across):
    """(width to nest on, note) for a roll `across` mm wide.  A roll the cutter takes but cuts only part of (the Gunner: a 1600
    mm roll fits, 1565 mm of it is cut; Danilo 16-Oct-2026 10:39) is nested on the cut width, with a note; anything else unchanged."""
    p = _profile(product); cutter = MACHINES.get(p.get('cutter')) or {}
    rw, fits = cutter.get('roll_width'), cutter.get('roll_fits')
    if not (p.get('roll') and cutter.get('feed_unbounded') and rw and fits) or not (rw + 1e-6 < float(across) <= fits + 1e-6):
        return across, None
    return float(rw), f"A {float(across):g} mm roll fits; the {cutter['name'].split(' ')[0]} cuts {rw:g} mm of it: nested on {rw:g} mm."


def plugin_registration(product):
    """The cutter's own registration marks (the Gunner's SignWorkPro dots: export['registration']), else None."""
    p = _profile(product)
    return ((CUTTERS.get(p.get('cutter')) or {}).get('export') or {}).get('registration')


CORNER_MARKS_BY_PLUGIN = ("Corner marks are off for the Gunner: the SignWorkPro plugin in CorelDRAW makes the registration marks, "
                          "so PS Nest draws none (Corel import untested; Danilo's test cut pending).")


def corner_marks_for(product, asked):
    """(draw PS Nest's corner marks?, note).  A cutter whose plugin makes the marks gets none from PS Nest: the box is a remembered
    page setting, so it is ignored with a note rather than refused (reviewer finding 1 on PR 5, 16-Oct-2026)."""
    if asked and plugin_registration(product): return False, CORNER_MARKS_BY_PLUGIN
    return bool(asked), None


def plugin_edge_warning(product, sides):
    """The warning when an edge (mm per side, {'l','r','b','t'}) is under the clear margin the cutter's plugin dots need, else None."""
    reg = plugin_registration(product) or {}
    need = reg.get('clear_per_side_mm')
    if not need: return None
    names = {'l': 'left', 'r': 'right', 'b': 'bottom', 't': 'top'}
    low = [f"{names[k]} {v:g} mm" for k, v in sides.items() if v < need - 1e-9]
    if not low: return None
    return f"Edge under {need:g} mm ({', '.join(low)}): the SignWorkPro dots need about {need:g} mm clear per side."


def registration_note(product):
    """The reply note for a cutter whose registration dots come from its own software (the Gunner's CorelDRAW plugin), else None."""
    p = _profile(product)
    return (((CUTTERS.get(p.get('cutter')) or {}).get('export') or {}).get('registration') or {}).get('note')


def get(product_id):
    return PRODUCTS[product_id]

PRODUCTS['acm']['sources'].update({'bleed': '3 mm. Design-ops review rule for rigid substrates (shop record, not an ACM-specific published figure). [assumption]', 'min_offcut': '300 mm. No published standard for a reusable ACM offcut. Shop judgement: a strip under 300 mm holds no saleable sign, so a layout is not rewarded for leaving one. [assumption]', 'material': '3A Composites Alucobond fabrication guide, read 16-Sep-2026: minimum cold-bend radius without routing is 15 x thickness (3 mm = 45 mm, 4 mm = 60 mm); keep the router bit sharp to limit core heat; V-rout at least 25 mm from a panel edge before folding. Not nesting rules, kept for the operator.'})
PRODUCTS['acm']['assumed'] = ['bleed', 'min_offcut']
