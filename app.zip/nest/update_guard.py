"""Atomic handoff from local API mutations to the desktop updater."""
from contextlib import contextmanager
from threading import Lock
from time import monotonic


class UpdateGuard:
    def __init__(self):
        self.lock = Lock()
        self.active = 0
        self.preparing_until = 0

    @contextmanager
    def mutation(self):
        with self.lock:
            if self.preparing_until > monotonic():
                raise ValueError('PS Nest is preparing an update. Try again after it restarts.')
            self.active += 1
        try:
            yield
        finally:
            with self.lock:
                self.active -= 1

    def prepare(self):
        with self.lock:
            if self.active:
                return False
            self.preparing_until = monotonic() + 120
            return True

    def cancel(self):
        with self.lock:
            self.preparing_until = 0
