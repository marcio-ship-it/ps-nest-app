"""Internal, revision-bound production worksheet. No customer approval is granted here.

Counts come from placed physical parts and stock, never from the number of PDF
files. Machine-file entries are supplied by the exporter that made those bytes.
"""
import hashlib
import io
import json
import math
import re
import zipfile
from collections import Counter
from dataclasses import asdict
from xml.sax.saxutils import escape

WORKSHEET_RENDERER_VERSION = 3
LEGACY_WORKSHEET_RENDERERS = (None, 2)
ROLL_PRODUCTION_BATCH_MAX_MM = 10_000.0
# This is only for binary floating-point noise.  It is not a production
# measurement or rounding allowance: any material used beyond the allocation
# must remain held.
ROLL_FLOAT_NOISE_MM = 1e-6


def package_cache_path(job, jobs_dir, renderer_version=WORKSHEET_RENDERER_VERSION):
    """A renderer correction preserves every earlier immutable export."""
    from pathlib import Path
    return Path(jobs_dir) / f'{job["report"]["job_id"]}-production-worksheet-v{renderer_version}.zip'


def roll_length_metrics(job):
    """Allocated export pages and placed extents for a saved roll layout."""
    from .outputs import roll_used_extent_mm
    if not job['rules'].roll:
        return []
    return [{'sheet': index,
             'allocated_length_mm': job['rules'].for_sheet(sheet).sheet_w,
             'used_extent_mm': roll_used_extent_mm(sheet, job['rules'])}
            for index, sheet in enumerate(job['sheets'], 1)]


def production_roll_hold(job):
    """Return the production-package hold for an unsafe saved roll, if any."""
    metrics = roll_length_metrics(job)
    reasons = []
    for row in metrics:
        if row['used_extent_mm'] > row['allocated_length_mm'] + ROLL_FLOAT_NOISE_MM:
            reasons.append(f'Roll length {row["sheet"]} placed work extends beyond its allocation: '
                           f'{row["allocated_length_mm"]:g} mm allocated/export versus '
                           f'{row["used_extent_mm"]:.1f} mm used extent including the right margin.')
    for row in metrics:
        if max(row['allocated_length_mm'], row['used_extent_mm']) > ROLL_PRODUCTION_BATCH_MAX_MM + ROLL_FLOAT_NOISE_MM:
            reasons.append(f'Roll length {row["sheet"]} exceeds the 10,000 mm production batch maximum: '
                           f'{row["allocated_length_mm"]:g} mm allocated/export and '
                           f'{row["used_extent_mm"]:.1f} mm used extent including the right margin.')
    if reasons:
        oversized = [row for row in metrics
                     if max(row['allocated_length_mm'], row['used_extent_mm'])
                     > ROLL_PRODUCTION_BATCH_MAX_MM + ROLL_FLOAT_NOISE_MM]
        oversized_piece_sheets = set()
        safe_multi_piece_sheets = set()
        allocation_only_sheets = set()
        for row in oversized:
            sheet = job['sheets'][row['sheet'] - 1]
            rs = job['rules'].for_sheet(sheet)
            has_oversized_piece = any(
                placement.w + rs.ml + rs.mr
                > ROLL_PRODUCTION_BATCH_MAX_MM + ROLL_FLOAT_NOISE_MM
                for placement in sheet.placed)
            if has_oversized_piece:
                oversized_piece_sheets.add(row['sheet'])
            elif len(sheet.placed) > 1:
                safe_multi_piece_sheets.add(row['sheet'])
            else:
                allocation_only_sheets.add(row['sheet'])
        actions = []
        if oversized_piece_sheets:
            actions.append('An intact oversized piece requires a production-approved panel/seam strategy '
                           'before a new layout can be prepared; this export will not invent a seam, split, '
                           'crop, move or re-nest the piece.')
        if safe_multi_piece_sheets:
            actions.append('For a multi-piece roll length, rebatch and nest again only where every piece can '
                           'remain whole before production export.')
        if allocation_only_sheets or not oversized:
            actions.append('Correct the saved allocation before production export; this export will not move, '
                           'split, crop or re-nest the layout.')
        return ' '.join(reasons + actions)
    return None


def safe_component(value):
    value = re.sub(r'[\\/:*?"<>|\x00-\x1f]', '-', str(value)).strip(' .')
    if not value or len(value.encode('utf-8')) > 240:
        raise ValueError('The production folder/file name is empty or too long. Shorten the batch references without dropping any order.')
    return value


def batch_folder(job):
    refs = [r['ref'] for r in job['report'].get('orders') or []]
    if not refs:
        raise ValueError('A shared production package requires identified orders.')
    jid = job['report'].get('job_id')
    if not jid or not re.fullmatch(r'[a-f0-9]+', jid):
        raise ValueError('Save this nesting result before exporting its production package.')
    return safe_component(f'NEST-{jid}-R1--' + '+'.join(refs))


def material_folder(job):
    st = job['settings']
    material = st.get('material')
    if not material or str(material).strip().lower() in ('material', 'custom material', 'unknown'):
        raise ValueError('Identify the material before producing a worksheet or machine package.')
    thickness = (job.get('request') or {}).get('thickness')
    if thickness not in (None, ''):
        n = float(thickness)
        if not math.isfinite(n) or n <= 0:
            raise ValueError('Material thickness must be a positive measurement in mm.')
        material = f'{material} - {n:g}mm'
    return safe_component(material)



def production_source_digest(job):
    """Bind every persisted geometry/export input, excluding solver telemetry.

    Dimensions and placements alone cannot identify a machine package: a mirror,
    contour, bleed, separation cut or printer recipe can change its actual bytes.
    Use the same native structures retained by save_job/load_job, never cache-
    supplied entries. Request/provenance preserve the source approval bindings.
    """
    source = {
        'rules': asdict(job['rules']),
        'settings': job['settings'],
        'print': job.get('print'),
        'request': job.get('request'),
        'parts': [asdict(part) for part in job['parts']],
        'sheets': [asdict(sheet) for sheet in job['sheets']],
        'orders': job['report'].get('orders') or [],
        'planning': job['info'].get('production_plan'),
    }
    return hashlib.sha256(json.dumps(source, sort_keys=True, separators=(',', ':'),
                                     allow_nan=False).encode()).hexdigest()

def manifest(job, machine_files=(), *, renderer_version=WORKSHEET_RENDERER_VERSION):
    """Build one material's stock/part reconciliation from the saved layout."""
    material = material_folder(job)
    rules = job['rules']
    refs = {r['ref']: r for r in job['report'].get('orders') or []}
    pieces, sheets, seen = [], [], set()
    for i, sheet in enumerate(job['sheets'], 1):
        rs = rules.for_sheet(sheet)
        order_refs, sites, states = [], [], []
        for placement in sheet.placed:
            p = placement.part
            identity = p.piece_id or p.name
            if identity in seen:
                raise ValueError(f'Duplicate placed piece {identity}; reconcile quantities before export.')
            seen.add(identity)
            order = refs.get(p.order_ref) or {}
            source = next((s for s in order.get('sources', []) if s['source_part_id'] == p.source_part_id), {})
            piece = {'piece_id': identity, 'order_ref': p.order_ref, 'item_number': p.item_number,
                     'source_part_id': p.source_part_id, 'copy_number': p.copy_number,
                     'line_id': source.get('line_id'), 'allocation_key': source.get('allocation_key'),
                     'site_ref': p.site_ref, 'state': p.state, 'artwork_version': p.artwork_version,
                     'artwork_sha256': source.get('artwork_sha256'), 'sheet': i,
                     'finished_mm': [p.w, p.h], 'position_mm': [placement.x, placement.y],
                     'angle': placement.angle}
            pieces.append(piece)
            for value, bucket in ((p.order_ref, order_refs), (p.site_ref, sites), (p.state, states)):
                if value and value not in bucket:
                    bucket.append(value)
        sheet_record = {'sheet': i, 'material': material, 'stock_mm': [rs.sheet_w, rs.sheet_h],
                        'stock_kind': 'roll_length' if rules.roll else 'supplied_stock_origin_unknown' if sheet.size else 'full_sheet',
                        'pieces': len(sheet.placed), 'order_refs': order_refs, 'sites': sites, 'states': states,
                        'files': [dict(f) for f in machine_files if f.get('sheet') == i]}
        if rules.roll and renderer_version is not None and renderer_version >= 3:
            from .outputs import roll_used_extent_mm
            sheet_record['allocated_length_mm'] = rs.sheet_w
            sheet_record['used_extent_mm'] = roll_used_extent_mm(sheet, rules)
        sheets.append(sheet_record)
    expected = Counter((p.order_ref, p.source_part_id) for p in job['parts'])
    placed = Counter((p['order_ref'], p['source_part_id']) for p in pieces)
    if placed != expected:
        raise ValueError('Placed quantities do not match the saved parts. Nest again before export.')
    for ref, order in refs.items():
        for source in order.get('sources', []):
            if placed[(ref, source['source_part_id'])] != source['quantity']:
                raise ValueError(f'{ref}/{source["source_part_id"]}: placed quantity differs from the source order.')
    if not sheets:
        raise ValueError('The production worksheet needs a non-empty saved layout.')
    kinds = Counter(s['stock_kind'] for s in sheets)
    counts = {'ordered_pieces': len(pieces), 'physical_sheets': None if rules.roll else len(sheets),
              'full_sheets': None if rules.roll else kinds['full_sheet'],
              'alternate_sheets': None if rules.roll else kinds['supplied_stock_origin_unknown'],
              'remnants': None if rules.roll or kinds['supplied_stock_origin_unknown'] else 0,
              'roll_lengths': len(sheets) if rules.roll else None,
              'linear_metres': sum(s['stock_mm'][0] for s in sheets) / 1000 if rules.roll else None,
              'roll_widths_mm': sorted({s['stock_mm'][1] for s in sheets}) if rules.roll else [],
              'machine_files': len(machine_files),
              'print_files': sum(f['operation'] == 'PRINT' for f in machine_files),
              'cut_files': sum(f['operation'] == 'CUT' for f in machine_files),
              # This exporter currently represents one face. Never invent two-sided passes.
              'print_passes': sum(f.get('print_passes', 0) for f in machine_files)}
    if rules.roll and renderer_version is not None and renderer_version >= 3:
        counts['allocated_linear_metres'] = sum(s['allocated_length_mm'] for s in sheets) / 1000
        counts['used_extent_linear_metres'] = sum(s['used_extent_mm'] for s in sheets) / 1000
    schedule = dict((job.get('request') or {}).get('production_schedule') or {})
    estimate = schedule.get('estimate')
    if estimate is not None:
        if not isinstance(estimate, dict) or not estimate.get('source') or not estimate.get('by'):
            raise ValueError('A production-time estimate needs its source and responsible person.')
        for key in ('machine_minutes', 'hands_on_minutes', 'elapsed_minutes'):
            value = estimate.get(key)
            if value is not None and (isinstance(value, bool) or not isinstance(value, (int, float))
                                      or not math.isfinite(value) or value <= 0):
                raise ValueError('Time estimates must be positive minutes or omitted; unknown is not zero.')
    payload = {'schema': 'ps-nest-production-worksheet-v1', 'batch_id': job['report'].get('job_id'),
               'revision': 1, 'internal_only': True, 'production_release': False,
               'production_source_sha256': production_source_digest(job),
               'material': material, 'finish': (job.get('request') or {}).get('finish') or None,
               'orders': list(refs), 'counts': counts, 'schedule': schedule,
               'source_bindings': {ref: record['source_binding'] for ref, record in refs.items()
                                   if record.get('source_binding')},
               'sheets': sheets, 'pieces': pieces,
               'planning': job['info'].get('production_plan'),
               'source_runtime_seconds': job['report'].get('seconds')}
    if renderer_version is not None:
        payload['worksheet_renderer_version'] = renderer_version
    payload['snapshot_sha256'] = hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(',', ':'),
                                                          allow_nan=False).encode()).hexdigest()
    return payload


def validate_cached_package(job, package, *, allow_legacy_renderer=False):
    """A retry must never serve truncated files or another saved layout's package."""
    folder = batch_folder(job)
    try:
        with zipfile.ZipFile(io.BytesIO(package)) as archive:
            if archive.testzip() is not None:
                raise ValueError('Production package contains a damaged file.')
            data = json.loads(archive.read(folder + '/production-manifest.json'))
            entries = [entry for sheet in data['sheets'] for entry in sheet['files']]
            version = data.get('worksheet_renderer_version')
            if version != WORKSHEET_RENDERER_VERSION and not (
                    allow_legacy_renderer and version in LEGACY_WORKSHEET_RENDERERS):
                raise ValueError('Production package uses a different worksheet renderer; retain the original export.')
            if manifest(job, entries, renderer_version=version) != data:
                raise ValueError('Production package no longer matches its saved layout.')
            expected = {entry['path'] for entry in entries} | {
                folder + '/production-manifest.json', folder + '/production-worksheet.pdf'}
            if len(archive.namelist()) != len(expected) or set(archive.namelist()) != expected:
                raise ValueError('Production package has missing or unexpected files.')
            for entry in entries:
                if hashlib.sha256(archive.read(entry['path'])).hexdigest() != entry['sha256']:
                    raise ValueError('Production machine file no longer matches its recorded hash.')
            from pypdf import PdfReader
            pdf = PdfReader(io.BytesIO(archive.read(folder + '/production-worksheet.pdf')))
            if pdf.metadata.get('/Subject') != data['snapshot_sha256']:
                raise ValueError('Production worksheet does not identify this saved layout.')
    except (KeyError, TypeError, zipfile.BadZipFile, json.JSONDecodeError) as exc:
        raise ValueError('Production package is incomplete or unreadable; retain it for investigation.') from exc
    return package


def write_pdf(job, data):
    """Summary / work order, followed by the existing one-sheet-per-page layouts."""
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
    from pypdf import PdfReader, PdfWriter
    from . import outputs
    buf = io.BytesIO()
    styles = getSampleStyleSheet()
    styles['BodyText'].fontSize = 9
    styles['BodyText'].leading = 12
    flow = []

    def para(text, style='BodyText'):
        return Paragraph(escape(str(text)), styles[style])

    def line(text, style='BodyText'):
        flow.append(para(text, style))
        flow.append(Spacer(1, 5))

    def table(headers, rows, widths):
        t = Table([[para(x) for x in headers]] + [[para(x) for x in row] for row in rows],
                  colWidths=widths, repeatRows=1, hAlign='LEFT')
        t.setStyle(TableStyle([('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#eeeeee')),
                               ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                               ('GRID', (0, 0), (-1, -1), .3, colors.HexColor('#bbbbbb')),
                               ('BOTTOMPADDING', (0, 0), (-1, -1), 7)]))
        flow.extend([t, Spacer(1, 12)])

    line('Production worksheet', 'Title')
    line(f'NEST-{data["batch_id"]} / revision {data["revision"]}', 'Heading2')
    if data.get('worksheet_renderer_version') is not None:
        line(f'Worksheet renderer {data["worksheet_renderer_version"]}. Saved layout and ordered quantities are unchanged.')
    line('INTERNAL - one batch, one production demand. Printing this worksheet again does not add quantities.')
    line('Orders: ' + ', '.join(data['orders']))
    line('Material: ' + data['material'], 'Heading2')
    line('Finish / laminate: ' + str(data['finish'] or 'Not recorded'))
    counts = data['counts']
    if counts['physical_sheets'] is not None:
        line(f'{counts["physical_sheets"]} physical sheets: {counts["full_sheets"]} full sheets + '
             f'{counts["alternate_sheets"]} supplied alternate sheets. {counts["ordered_pieces"]} finished pieces.', 'Heading2')
        if counts['alternate_sheets']:
            line('Supplied alternate stock: full-sheet or recovered-remnant origin is not recorded. '
                 'Do not count it as recovered material without stock evidence.')
    else:
        if 'allocated_linear_metres' in counts:
            line(f'{counts["allocated_linear_metres"]:.3f} LM allocated / exported in {counts["roll_lengths"]} roll lengths; '
                 f'{counts["used_extent_linear_metres"]:.3f} LM actual used extent including right margins. '
                 f'Widths: {", ".join(str(w) for w in counts["roll_widths_mm"])} mm. '
                 f'{counts["ordered_pieces"]} finished pieces.', 'Heading2')
        else:
            line(f'{counts["linear_metres"]:.3f} LM in {counts["roll_lengths"]} roll lengths. '
                 f'Widths: {", ".join(str(w) for w in counts["roll_widths_mm"])} mm. '
                 f'{counts["ordered_pieces"]} finished pieces.', 'Heading2')
    line(f'{counts["print_files"]} PRINT files + {counts["cut_files"]} CUT files '
         f'({counts["machine_files"]} machine files). {counts["print_passes"]} exported print passes.')
    line('Sheet counts are stock, not PDF counts. Reusable offcuts are separate from waste; '
         'the attached layouts describe potential offcuts, not measured workshop recovery.')
    schedule = data['schedule']
    line('Production planning', 'Heading2')
    line(f'Date: {schedule.get("date") or "Not scheduled"} | Shift: {schedule.get("shift") or "Not scheduled"} '
         f'| Sequence: {schedule.get("sequence") or "Not scheduled"}')
    estimate = schedule.get('estimate')
    if not estimate:
        line('Production time: not estimated. Nesting calculation time is not printing/cutting time.')
    else:
        for key, label in [('machine_minutes', 'Machine occupancy'), ('hands_on_minutes', 'Hands-on labour'),
                           ('elapsed_minutes', 'Elapsed production time')]:
            line(f'{label}: {str(estimate[key]) + " minutes" if estimate.get(key) is not None else "Not estimated"}')
        line(f'Estimate source: {estimate["source"]}. Responsible: {estimate["by"]}. '
             'Overlapping machine/labour stages must not be added twice.')
    totals = Counter((p['order_ref'], p['site_ref'], p['state'], p['item_number'] or p['source_part_id'])
                     for p in data['pieces'])
    line('Order / site quantities', 'Heading2')
    table(['Order', 'Site / state', 'Original item', 'Pieces'],
          [[ref, f'{site or "Not recorded"} / {state or "Not recorded"}', item, qty]
           for (ref, site, state, item), qty in totals.items()], [100, 220, 115, 80])
    line('Sheet sequence and files', 'Heading2')
    table(['Sheet / stock', 'Orders / sites', 'Machine files'],
          [[f'{s["sheet"]} / {s["stock_kind"]}\n{s["stock_mm"][0]:g} x {s["stock_mm"][1]:g} mm'
            + (f'\nAllocated/export: {s["allocated_length_mm"]:g} mm\nUsed extent: {s["used_extent_mm"]:.1f} mm'
               if 'allocated_length_mm' in s else ''),
            ', '.join(s['order_refs']) + ' / ' + ', '.join(s['sites']),
            '; '.join(f['name'] for f in s['files']) or 'No machine files in this export']
           for s in data['sheets']], [100, 155, 260])
    line('Identify each piece before removing it from its sheet. Keep each site kit together, '
         'including when several sites share one state or delivery pallet.')
    def footer(canvas, _doc):
        # Keep the source/release note on every summary page without creating a
        # nearly empty overflow page after the production tables.
        canvas.saveState()
        canvas.setFont('Helvetica', 7)
        canvas.drawString(40, 23, 'Snapshot: ' + data['snapshot_sha256'])
        canvas.drawString(40, 12, 'Software preparation only. Follow the existing machine setup and production release controls.')
        canvas.restoreState()

    doc = SimpleDocTemplate(buf, pagesize=A4, rightMargin=40, leftMargin=40, topMargin=36, bottomMargin=36)
    doc.build(flow, onFirstPage=footer, onLaterPages=footer)
    writer = PdfWriter()
    for page in PdfReader(io.BytesIO(buf.getvalue())).pages:
        writer.add_page(page)
    layout_title = f'NEST-{data["batch_id"]} R{data["revision"]} - {data["material"]}'
    layout = outputs.write_layout_pdf(job['sheets'], job['rules'], layout_title, job['info'],
                                      job['settings'].get('corner_radius', 0))
    for page in PdfReader(io.BytesIO(layout)).pages:
        writer.add_page(page)
    out = io.BytesIO()
    writer.add_metadata({'/Title': f'Internal production worksheet NEST-{data["batch_id"]}',
                         '/Subject': data['snapshot_sha256']})
    writer.write(out)
    return out.getvalue()
