"""Outline importers for PS Nest (Phase 2): DXF, SVG and TrueType text.

Every importer returns closed loops as lists of (x, y, bulge) in millimetres, y up, in the
file's own coordinates; `loops_to_parts` then sorts them into parts (outer loop + holes,
optionally islands) with the union bounding box at the origin, ready for engine.Part.

DXF: R12-2018 ASCII.  LWPOLYLINE (with bulges), POLYLINE/VERTEX, LINE, ARC, CIRCLE, ELLIPSE,
SPLINE (rational B-spline, Cox-de Boor), INSERT of BLOCKS (nested, arrays), $INSUNITS.
Open entities are chained end-to-end (0.1 mm) into closed loops.  Entities in paper space
and on info/dimension/text layers are ignored.  Design ported from the LCE quote engine
parser (dxf-parser.mjs) and re-implemented in pure Python.

SVG: path (M L H V C S Q T A Z, absolute/relative), rect, circle, ellipse, polygon, polyline,
line; nested transforms; viewBox + width/height units.  Curves are flattened to 0.02 mm.

TTF: glyf/loca/cmap/hmtx parsed directly (no fontTools).  Each character becomes a part
with its counters as holes and detached pieces (the dot of an i) as islands.
"""
from __future__ import annotations
import math, os, re, struct, sys
from xml.etree import ElementTree as ET
from . import geom

JOIN_TOL = 0.1          # mm: chain end points closer than this are joined
CURVE_TOL = 0.02        # mm: chord error when flattening curves
SKIP_LAYER = re.compile(r'info|dim|text|note|anno|print|format|title|border|frame', re.I)


class ImportResult:
    def __init__(self):
        self.loops = []          # closed loops [(x, y, bulge), ...] in mm, y up
        self.open = []           # chains that could not be closed
        self.warnings = []
        self.units = 'mm'
        self.skipped_layers = {}

    def summary(self):
        s = f'{len(self.loops)} closed loop(s)'
        if self.open: s += f', {len(self.open)} open chain(s) ignored'
        if self.skipped_layers: s += ', skipped layers: ' + ', '.join(f'{k} ({v})' for k, v in self.skipped_layers.items())
        return s


# ------------------------------------------------------------------ chains
def _reverse_chain(ch):
    """Reverse an open chain [(x, y, bulge)]: the bulge of segment k -> k+1 moves and flips sign."""
    n = len(ch)
    out = []
    for k in range(n - 1, -1, -1):
        b = -ch[k - 1][2] if k > 0 else 0.0
        out.append((ch[k][0], ch[k][1], b))
    return out


def _dist(a, b): return math.hypot(a[0] - b[0], a[1] - b[1])


def join_chains(chains, tol=JOIN_TOL):
    """Greedy end-to-end joining of open chains into closed loops.  Returns (loops, leftovers)."""
    chains = [list(c) for c in chains if len(c) >= 2]
    loops, left = [], []
    while chains:
        cur = chains.pop(0)
        while True:
            if len(cur) >= 3 and _dist(cur[0], cur[-1]) <= tol:
                loops.append(cur[:-1]); cur = None; break        # closing segment keeps cur[-2]'s bulge
            end, start = cur[-1], cur[0]
            hit = None
            for idx, ch in enumerate(chains):
                if _dist(end, ch[0]) <= tol: hit = _append(cur, ch)
                elif _dist(end, ch[-1]) <= tol: hit = _append(cur, _reverse_chain(ch))
                elif _dist(start, ch[-1]) <= tol: hit = _append(ch, cur)
                elif _dist(start, ch[0]) <= tol: hit = _append(_reverse_chain(ch), cur)
                if hit is not None: chains.pop(idx); cur = hit; break
            if hit is None: break
        if cur is not None: left.append(cur)
    return loops, left


def _append(a, b):
    """a + b where b starts where a ends: drop b's first point, keep a's last bulge only if b's first segment has none."""
    last = a[-1]; first = b[0]
    joined = a[:-1] + [(last[0], last[1], first[2])] + b[1:]
    return joined


# ------------------------------------------------------------------ DXF
_UNIT_SCALE = {0: 1.0, 1: 25.4, 2: 304.8, 4: 1.0, 5: 10.0, 6: 1000.0, 8: 0.001, 9: 0.0254, 10: 914.4}


def _pairs(text):
    lines = text.splitlines()
    out = []
    i = 0
    while i + 1 < len(lines):
        try: code = int(lines[i].strip())
        except ValueError: i += 1; continue
        out.append((code, lines[i + 1].strip())); i += 2
    return out


def _f(v):
    try: return float(v)
    except ValueError: return 0.0


def _bspline_points(degree, knots, ctrl, weights, n_samples):
    """Rational B-spline (Cox-de Boor) sampled uniformly over the valid parameter range."""
    p = degree; n = len(ctrl)
    if not knots or len(knots) < n + p + 1:                     # generate a clamped uniform knot vector
        inner = n - p - 1
        knots = [0.0] * (p + 1) + [(k + 1) / (inner + 1) for k in range(inner)] + [1.0] * (p + 1)
    if weights is None or len(weights) != n: weights = [1.0] * n
    t0, t1 = knots[p], knots[n]
    pts = []
    for s in range(n_samples + 1):
        t = t0 + (t1 - t0) * s / n_samples
        if s == n_samples: t = t1 - 1e-12 * (t1 - t0)
        # find span
        k = p
        while k < n - 1 and t >= knots[k + 1]: k += 1
        # de Boor
        d = [(ctrl[j][0] * weights[j], ctrl[j][1] * weights[j], weights[j]) for j in range(k - p, k + 1)]
        for r in range(1, p + 1):
            for j in range(p, r - 1, -1):
                i = k - p + j
                den = knots[i + p - r + 1] - knots[i]
                a = 0.0 if den == 0 else (t - knots[i]) / den
                d[j] = (d[j - 1][0] * (1 - a) + d[j][0] * a, d[j - 1][1] * (1 - a) + d[j][1] * a, d[j - 1][2] * (1 - a) + d[j][2] * a)
        x, y, w = d[p]
        pts.append((x / w if w else x, y / w if w else y))
    return pts


def _ellipse_points(cx, cy, mx, my, ratio, t0, t1):
    a = math.hypot(mx, my)
    nx, ny = -my * ratio, mx * ratio
    if t1 <= t0: t1 += 2 * math.pi
    sweep = t1 - t0
    if a <= CURVE_TOL: n = 8
    else: n = max(8, int(math.ceil(sweep / (2.0 * math.acos(max(-1.0, 1.0 - CURVE_TOL / a))))))
    n = ((n + 3) // 4) * 4                                      # vertices on the axes: exact extents
    return [(cx + mx * math.cos(t0 + sweep * k / n) + nx * math.sin(t0 + sweep * k / n),
             cy + my * math.cos(t0 + sweep * k / n) + ny * math.sin(t0 + sweep * k / n)) for k in range(n + 1)]


def _arc_chain(cx, cy, r, a0, a1):
    """DXF ARC (degrees CCW) as a chain of at most two bulge segments."""
    sweep = (a1 - a0) % 360.0
    if sweep <= 1e-9: sweep = 360.0
    pts = []
    parts = 2 if sweep > 180.0 else 1
    for k in range(parts + 1):
        a = math.radians(a0 + sweep * k / parts)
        b = math.tan(math.radians(sweep / parts) / 4.0) if k < parts else 0.0
        pts.append((cx + r * math.cos(a), cy + r * math.sin(a), b))
    return pts


def _xf_point(x, y, m):
    a, b, c, d, e, f = m
    return (a * x + c * y + e, b * x + d * y + f)


def _xf_chain(ch, m):
    a, b, c, d, e, f = m
    sx = math.hypot(a, b); sy = math.hypot(c, d)
    mirrored = (a * d - b * c) < 0
    if any(abs(v[2]) > 1e-12 for v in ch) and abs(sx - sy) > 1e-9 * max(sx, sy):
        closed = len(ch) >= 3 and _dist(ch[0], ch[-1]) <= 1e-9
        pts = geom.flatten(ch if closed else ch + [(ch[-1][0], ch[-1][1], 0.0)], CURVE_TOL / max(sx, sy))
        ch = [(x, y, 0.0) for x, y in pts]
    out = []
    for x, y, bl in ch:
        px, py = _xf_point(x, y, m)
        out.append((px, py, -bl if mirrored else bl))
    return out


def parse_dxf(text):
    """ASCII DXF text -> ImportResult (closed loops in mm, y up)."""
    res = ImportResult()
    pairs = _pairs(text)
    # split into sections
    sections = {}; cur = None; name = None
    i = 0
    while i < len(pairs):
        code, val = pairs[i]
        if code == 0 and val == 'SECTION' and i + 1 < len(pairs) and pairs[i + 1][0] == 2:
            name = pairs[i + 1][1]; cur = []; sections[name] = cur; i += 2; continue
        if code == 0 and val == 'ENDSEC': cur = None; i += 1; continue
        if cur is not None: cur.append((code, val))
        i += 1
    scale = 1.0
    hdr = sections.get('HEADER', [])
    for k, (code, val) in enumerate(hdr):
        if code == 9 and val == '$INSUNITS' and k + 1 < len(hdr) and hdr[k + 1][0] == 70:
            u = int(_f(hdr[k + 1][1])); scale = _UNIT_SCALE.get(u, 1.0)
            res.units = {1: 'in', 2: 'ft', 4: 'mm', 5: 'cm', 6: 'm', 8: 'micron', 9: 'mil', 10: 'yd'}.get(u, 'mm')
            if u not in _UNIT_SCALE: res.warnings.append(f'$INSUNITS {u} not understood; assuming mm')

    def entities(pairs_):
        """Group (code, value) pairs into entity dicts: {'type', 'codes': [(code, val)]}"""
        out = []; ent = None
        for code, val in pairs_:
            if code == 0:
                ent = {'type': val, 'codes': []}; out.append(ent)
            elif ent is not None: ent['codes'].append((code, val))
        return out

    blocks = {}
    blk = sections.get('BLOCKS', [])
    ents = entities(blk)
    k = 0
    while k < len(ents):
        e = ents[k]
        if e['type'] == 'BLOCK':
            bname = None; bx = by = 0.0
            for code, val in e['codes']:
                if code == 2: bname = val
                elif code == 10: bx = _f(val)
                elif code == 20: by = _f(val)
            body = []
            k += 1
            while k < len(ents) and ents[k]['type'] != 'ENDBLK':
                body.append(ents[k]); k += 1
            if bname is not None: blocks[bname] = (bx, by, body)
        k += 1

    def chains_of(ents_, m, depth):
        """Yield ('closed'|'open', chain) for every geometric entity in ents_, transformed by matrix m."""
        out = []
        idx = 0
        while idx < len(ents_):
            e = ents_[idx]; idx += 1
            t = e['type']; c = e['codes']
            layer = next((v for code, v in c if code == 8), '0')
            paper = any(code == 67 and v.strip() == '1' for code, v in c)
            if paper: continue
            if SKIP_LAYER.search(layer):
                res.skipped_layers[layer] = res.skipped_layers.get(layer, 0) + 1; continue
            g = {}
            lists = {}
            for code, v in c:
                if code in (10, 20, 11, 21, 42, 40, 41):
                    lists.setdefault(code, []).append(_f(v))
                g.setdefault(code, v)
            if t == 'LWPOLYLINE':
                xs, ys = lists.get(10, []), lists.get(20, [])
                flags = int(_f(g.get(70, '0')))
                # bulges (42) belong to the vertex they follow: rebuild by walking the codes
                verts = []; b_pending = None
                for code, v in c:
                    if code == 10: verts.append([_f(v), 0.0, 0.0])
                    elif code == 20 and verts: verts[-1][1] = _f(v)
                    elif code == 42 and verts: verts[-1][2] = _f(v)
                ch = [(x, y, b) for x, y, b in verts]
                if len(ch) < 2: continue
                out.append(('closed' if flags & 1 else 'open', _xf_chain(ch, m)))
            elif t == 'POLYLINE':
                flags = int(_f(g.get(70, '0')))
                verts = []
                while idx < len(ents_) and ents_[idx]['type'] == 'VERTEX':
                    vc = ents_[idx]['codes']; idx += 1
                    vx = vy = vb = 0.0
                    for code, v in vc:
                        if code == 10: vx = _f(v)
                        elif code == 20: vy = _f(v)
                        elif code == 42: vb = _f(v)
                    verts.append((vx, vy, vb))
                if idx < len(ents_) and ents_[idx]['type'] == 'SEQEND': idx += 1
                if flags & (8 | 16 | 32 | 64): continue          # 3D / mesh polylines
                if len(verts) >= 2: out.append(('closed' if flags & 1 else 'open', _xf_chain(verts, m)))
            elif t == 'LINE':
                ch = [(_f(g.get(10, 0)), _f(g.get(20, 0)), 0.0), (_f(g.get(11, 0)), _f(g.get(21, 0)), 0.0)]
                if _dist(ch[0], ch[1]) > 1e-9: out.append(('open', _xf_chain(ch, m)))
            elif t == 'CIRCLE':
                cx, cy, r = _f(g.get(10, 0)), _f(g.get(20, 0)), _f(g.get(40, 0))
                if r > 0: out.append(('closed', _xf_chain([(cx - r, cy, 1.0), (cx + r, cy, 1.0)], m)))
            elif t == 'ARC':
                cx, cy, r = _f(g.get(10, 0)), _f(g.get(20, 0)), _f(g.get(40, 0))
                a0, a1 = _f(g.get(50, 0)), _f(g.get(51, 360))
                if r > 0: out.append(('open', _xf_chain(_arc_chain(cx, cy, r, a0, a1), m)))
            elif t == 'ELLIPSE':
                cx, cy = _f(g.get(10, 0)), _f(g.get(20, 0)); mx, my = _f(g.get(11, 0)), _f(g.get(21, 0))
                ratio = _f(g.get(40, 1)); t0, t1 = _f(g.get(41, 0)), _f(g.get(42, 2 * math.pi))
                pts = _ellipse_points(cx, cy, mx, my, ratio, t0, t1)
                closed = abs((t1 - t0) % (2 * math.pi)) < 1e-6
                ch = [(x, y, 0.0) for x, y in (pts[:-1] if closed else pts)]
                out.append(('closed' if closed else 'open', _xf_chain(ch, m)))
            elif t == 'SPLINE':
                flags = int(_f(g.get(70, '0'))); degree = int(_f(g.get(71, '3')))
                knots = lists.get(40, []); weights = lists.get(41) or None
                ctrl = list(zip(lists.get(10, []), lists.get(20, [])))
                fit = list(zip(lists.get(11, []), lists.get(21, [])))
                if len(ctrl) > degree:
                    n = max(24, 12 * (len(ctrl) - degree))
                    pts = _bspline_points(degree, knots, ctrl, weights, n)
                elif fit:
                    pts = fit; res.warnings.append('SPLINE with fit points only: approximated by a polyline')
                else: continue
                closed = bool(flags & 1) or (len(pts) > 2 and _dist(pts[0], pts[-1]) <= JOIN_TOL)
                if closed:
                    if _dist(pts[0], pts[-1]) <= JOIN_TOL: pts = pts[:-1]
                    pts = geom.simplify(pts, CURVE_TOL / 2)
                else: pts = _simplify_open(pts, CURVE_TOL / 2)
                ch = [(x, y, 0.0) for x, y in pts]
                out.append(('closed' if closed else 'open', _xf_chain(ch, m)))
            elif t == 'INSERT':
                bname = g.get(2)
                if bname not in blocks or depth > 6: continue
                bx, by, body = blocks[bname]
                ix, iy = _f(g.get(10, 0)), _f(g.get(20, 0)); sx, sy = _f(g.get(41, 1)) or 1.0, _f(g.get(42, 1)) or 1.0
                rot = math.radians(_f(g.get(50, 0)))
                ncol, nrow = int(_f(g.get(70, 1))) or 1, int(_f(g.get(71, 1))) or 1
                dcol, drow = _f(g.get(44, 0)), _f(g.get(45, 0))
                cr, sr = math.cos(rot), math.sin(rot)
                for ci in range(ncol):
                    for ri in range(nrow):
                        # local: translate(-base) -> scale -> rotate -> translate(insert + array offset)
                        ox, oy = ix + ci * dcol, iy + ri * drow
                        a, b_, c_, d = sx * cr, sx * sr, -sy * sr, sy * cr
                        e_ = ox - (a * bx + c_ * by); f_ = oy - (b_ * bx + d * by)
                        local = (a, b_, c_, d, e_, f_)
                        # compose with the parent matrix m: p' = m(local(p))
                        ma, mb, mc, md, me, mf = m
                        comp = (ma * a + mc * b_, mb * a + md * b_, ma * c_ + mc * d, mb * c_ + md * d,
                                ma * e_ + mc * f_ + me, mb * e_ + md * f_ + mf)
                        out.extend(chains_of(body, comp, depth + 1))
            elif t in ('TEXT', 'MTEXT', 'DIMENSION', 'HATCH', 'POINT', 'ATTRIB', 'ATTDEF', 'LEADER', 'SOLID', 'IMAGE', 'VIEWPORT', 'XLINE', 'RAY', '3DFACE', 'VERTEX', 'SEQEND'):
                continue
            else:
                res.warnings.append(f'{t} entity ignored')
        return out

    base = (scale, 0.0, 0.0, scale, 0.0, 0.0)
    pieces = chains_of(entities(sections.get('ENTITIES', [])), base, 0)
    opens = []
    for kind, ch in pieces:
        if kind == 'closed':
            if len(ch) >= 2: res.loops.append(ch)
        else: opens.append(ch)
    loops, left = join_chains(opens)
    res.loops.extend(loops); res.open = left
    res.loops = [l for l in res.loops if _loop_ok(l)]
    return res


def _simplify_open(pts, tol):
    """Douglas-Peucker on an open chain of (x, y)."""
    if len(pts) < 3: return list(pts)
    ax, ay = pts[0]; bx, by = pts[-1]
    dx, dy = bx - ax, by - ay; L = math.hypot(dx, dy)
    best, bi = -1.0, -1
    for i in range(1, len(pts) - 1):
        d = abs((pts[i][0] - ax) * dy - (pts[i][1] - ay) * dx) / L if L > 1e-12 else math.hypot(pts[i][0] - ax, pts[i][1] - ay)
        if d > best: best, bi = d, i
    if best <= tol: return [pts[0], pts[-1]]
    return _simplify_open(pts[:bi + 1], tol)[:-1] + _simplify_open(pts[bi:], tol)


def _loop_ok(loop):
    try:
        geom.normalise(loop)
    except ValueError:
        return False
    return abs(geom.area(loop)) > 1e-6


# ------------------------------------------------------------------ SVG
_NUM = re.compile(r'[-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?')
_UNITS_MM = {'mm': 1.0, 'cm': 10.0, 'in': 25.4, 'pt': 25.4 / 72, 'pc': 25.4 / 6, 'px': 25.4 / 96, '': 25.4 / 96, 'm': 1000.0}


def _length_mm(s, default=None):
    if s is None: return default
    m = re.match(r'\s*([-+]?[\d.]+(?:[eE][-+]?\d+)?)\s*([a-z%]*)', s)
    if not m: return default
    v, u = float(m.group(1)), m.group(2)
    if u == '%': return default
    return v * _UNITS_MM.get(u, 25.4 / 96)


def _mat_mul(m, n):
    a, b, c, d, e, f = m; a2, b2, c2, d2, e2, f2 = n
    return (a * a2 + c * b2, b * a2 + d * b2, a * c2 + c * d2, b * c2 + d * d2, a * e2 + c * f2 + e, b * e2 + d * f2 + f)


def _parse_transform(s):
    m = (1.0, 0.0, 0.0, 1.0, 0.0, 0.0)
    if not s: return m
    for name, args in re.findall(r'(\w+)\s*\(([^)]*)\)', s):
        v = [float(x) for x in _NUM.findall(args)]
        if name == 'matrix' and len(v) == 6: t = tuple(v)
        elif name == 'translate': t = (1, 0, 0, 1, v[0], v[1] if len(v) > 1 else 0.0)
        elif name == 'scale': t = (v[0], 0, 0, v[1] if len(v) > 1 else v[0], 0, 0)
        elif name == 'rotate':
            a = math.radians(v[0]); c, s_ = math.cos(a), math.sin(a)
            t = (c, s_, -s_, c, 0, 0)
            if len(v) >= 3: t = _mat_mul(_mat_mul((1, 0, 0, 1, v[1], v[2]), t), (1, 0, 0, 1, -v[1], -v[2]))
        elif name == 'skewX': t = (1, 0, math.tan(math.radians(v[0])), 1, 0, 0)
        elif name == 'skewY': t = (1, math.tan(math.radians(v[0])), 0, 1, 0, 0)
        else: continue
        m = _mat_mul(m, t)
    return m


def _flatten_cubic(p0, p1, p2, p3, tol, out):
    # flatness: distance of control points from the chord
    dx, dy = p3[0] - p0[0], p3[1] - p0[1]
    dd = math.hypot(dx, dy)
    if dd < 1e-12: d1 = math.hypot(p1[0] - p0[0], p1[1] - p0[1]); d2 = math.hypot(p2[0] - p0[0], p2[1] - p0[1])
    else:
        d1 = abs((p1[0] - p0[0]) * dy - (p1[1] - p0[1]) * dx) / dd
        d2 = abs((p2[0] - p0[0]) * dy - (p2[1] - p0[1]) * dx) / dd
    if max(d1, d2) <= tol or len(out) > 100000:
        out.append(p3); return
    m01 = ((p0[0] + p1[0]) / 2, (p0[1] + p1[1]) / 2); m12 = ((p1[0] + p2[0]) / 2, (p1[1] + p2[1]) / 2); m23 = ((p2[0] + p3[0]) / 2, (p2[1] + p3[1]) / 2)
    m012 = ((m01[0] + m12[0]) / 2, (m01[1] + m12[1]) / 2); m123 = ((m12[0] + m23[0]) / 2, (m12[1] + m23[1]) / 2)
    mid = ((m012[0] + m123[0]) / 2, (m012[1] + m123[1]) / 2)
    _flatten_cubic(p0, m01, m012, mid, tol, out); _flatten_cubic(mid, m123, m23, p3, tol, out)


def _flatten_quad(p0, p1, p2, tol, out):
    c1 = (p0[0] + 2 * (p1[0] - p0[0]) / 3, p0[1] + 2 * (p1[1] - p0[1]) / 3)
    c2 = (p2[0] + 2 * (p1[0] - p2[0]) / 3, p2[1] + 2 * (p1[1] - p2[1]) / 3)
    _flatten_cubic(p0, c1, c2, p2, tol, out)


def _svg_arc(p0, rx, ry, phi, large, sweep, p1, tol, out):
    """SVG endpoint arc -> points (implementation of the W3C conversion to centre parameterisation)."""
    if rx == 0 or ry == 0: out.append(p1); return
    phi = math.radians(phi); cp, sp = math.cos(phi), math.sin(phi)
    x1p = cp * (p0[0] - p1[0]) / 2 + sp * (p0[1] - p1[1]) / 2
    y1p = -sp * (p0[0] - p1[0]) / 2 + cp * (p0[1] - p1[1]) / 2
    rx, ry = abs(rx), abs(ry)
    lam = (x1p / rx) ** 2 + (y1p / ry) ** 2
    if lam > 1: rx *= math.sqrt(lam); ry *= math.sqrt(lam)
    num = rx * rx * ry * ry - rx * rx * y1p * y1p - ry * ry * x1p * x1p
    den = rx * rx * y1p * y1p + ry * ry * x1p * x1p
    coef = 0.0 if den == 0 else math.sqrt(max(0.0, num / den))
    if large == sweep: coef = -coef
    cxp, cyp = coef * rx * y1p / ry, -coef * ry * x1p / rx
    cx = cp * cxp - sp * cyp + (p0[0] + p1[0]) / 2; cy = sp * cxp + cp * cyp + (p0[1] + p1[1]) / 2
    def ang(ux, uy, vx, vy):
        a = math.atan2(ux * vy - uy * vx, ux * vx + uy * vy); return a
    t1 = ang(1, 0, (x1p - cxp) / rx, (y1p - cyp) / ry)
    dt = ang((x1p - cxp) / rx, (y1p - cyp) / ry, (-x1p - cxp) / rx, (-y1p - cyp) / ry)
    if not sweep and dt > 0: dt -= 2 * math.pi
    if sweep and dt < 0: dt += 2 * math.pi
    r = max(rx, ry)
    n = max(4, int(math.ceil(abs(dt) / (2.0 * math.acos(max(-1.0, 1.0 - tol / r)))))) if r > tol else 4
    for k in range(1, n + 1):
        t = t1 + dt * k / n
        x = cp * rx * math.cos(t) - sp * ry * math.sin(t) + cx; y = sp * rx * math.cos(t) + cp * ry * math.sin(t) + cy
        out.append((x, y))
    out[-1] = p1


def _path_subpaths(d, tol):
    """SVG path data -> list of (points, closed_flag) in user units."""
    tokens = re.findall(r'[MmLlHhVvCcSsQqTtAaZz]|' + _NUM.pattern, d)
    subs = []; pts = []; closed = False
    cur = (0.0, 0.0); start = (0.0, 0.0); prev_c = None; prev_q = None
    i = 0; cmd = None
    def num():
        nonlocal i
        v = float(tokens[i]); i += 1; return v
    while i < len(tokens):
        t = tokens[i]
        if re.match(r'[A-Za-z]', t): cmd = t; i += 1
        elif cmd is None: i += 1; continue
        if cmd in 'Mm':
            if pts: subs.append((pts, closed))
            x, y = num(), num()
            if cmd == 'm': x += cur[0]; y += cur[1]
            cur = start = (x, y); pts = [cur]; closed = False; prev_c = prev_q = None
            cmd = 'L' if cmd == 'M' else 'l'
        elif cmd in 'Zz':
            closed = True; cur = start; prev_c = prev_q = None
            if pts: subs.append((pts, True)); pts = []
            cmd = None
            # a following coordinate without a command starts a new subpath at `start` (SVG rule)
        elif cmd in 'Ll':
            x, y = num(), num()
            if cmd == 'l': x += cur[0]; y += cur[1]
            cur = (x, y); pts.append(cur); prev_c = prev_q = None
        elif cmd in 'Hh':
            x = num(); x = x + cur[0] if cmd == 'h' else x
            cur = (x, cur[1]); pts.append(cur); prev_c = prev_q = None
        elif cmd in 'Vv':
            y = num(); y = y + cur[1] if cmd == 'v' else y
            cur = (cur[0], y); pts.append(cur); prev_c = prev_q = None
        elif cmd in 'CcSs':
            if cmd in 'Cc':
                x1, y1, x2, y2, x, y = num(), num(), num(), num(), num(), num()
                if cmd == 'c': x1 += cur[0]; y1 += cur[1]; x2 += cur[0]; y2 += cur[1]; x += cur[0]; y += cur[1]
            else:
                x2, y2, x, y = num(), num(), num(), num()
                if cmd == 's': x2 += cur[0]; y2 += cur[1]; x += cur[0]; y += cur[1]
                x1, y1 = (2 * cur[0] - prev_c[0], 2 * cur[1] - prev_c[1]) if prev_c else cur
            _flatten_cubic(cur, (x1, y1), (x2, y2), (x, y), tol, pts)
            prev_c = (x2, y2); prev_q = None; cur = (x, y)
        elif cmd in 'QqTt':
            if cmd in 'Qq':
                x1, y1, x, y = num(), num(), num(), num()
                if cmd == 'q': x1 += cur[0]; y1 += cur[1]; x += cur[0]; y += cur[1]
            else:
                x, y = num(), num()
                if cmd == 't': x += cur[0]; y += cur[1]
                x1, y1 = (2 * cur[0] - prev_q[0], 2 * cur[1] - prev_q[1]) if prev_q else cur
            _flatten_quad(cur, (x1, y1), (x, y), tol, pts)
            prev_q = (x1, y1); prev_c = None; cur = (x, y)
        elif cmd in 'Aa':
            rx, ry, phi, large, sweep, x, y = num(), num(), num(), int(num()), int(num()), num(), num()
            if cmd == 'a': x += cur[0]; y += cur[1]
            _svg_arc(cur, rx, ry, phi, large, sweep, (x, y), tol, pts)
            cur = (x, y); prev_c = prev_q = None
        else:
            i += 1
    if pts: subs.append((pts, closed))
    return subs


def _svg_hidden(el):
    """display:none / visibility:hidden or collapse, as attributes or inside style=."""
    st = (el.get('style') or '').replace(' ', '').lower()
    return (el.get('display') or '').strip().lower() == 'none' or (el.get('visibility') or '').strip().lower() in ('hidden', 'collapse') \
        or 'display:none' in st or 'visibility:hidden' in st or 'visibility:collapse' in st

def parse_svg(text):
    """SVG text -> ImportResult (closed loops in mm, y up)."""
    res = ImportResult()
    root = ET.fromstring(text)
    def tag(el): return el.tag.split('}')[-1]
    w_mm = _length_mm(root.get('width')); h_mm = _length_mm(root.get('height'))
    vb = root.get('viewBox')
    if vb:
        vx, vy, vw, vh = [float(v) for v in _NUM.findall(vb)][:4]
    else:
        vx = vy = 0.0; vw = w_mm if w_mm else 0; vh = h_mm if h_mm else 0
    if w_mm and vw: sx = w_mm / vw
    else: sx = 25.4 / 96; res.warnings.append('no physical width on <svg>: user units taken as 96 dpi pixels')
    if h_mm and vh: sy = h_mm / vh
    else: sy = sx
    res.units = 'mm' if w_mm else 'px'
    # y down -> y up: (x, y) -> (sx (x - vx), -sy (y - vy))
    base = (sx, 0.0, 0.0, -sy, -sx * vx, sy * vy)
    tol_user = CURVE_TOL / max(sx, sy)

    def walk(el, m):
        t = tag(el)
        if t in ('defs', 'clipPath', 'mask', 'symbol', 'marker', 'pattern', 'metadata', 'style', 'title', 'desc'): return
        if _svg_hidden(el): return                      # display:none / visibility:hidden: the exporter hid it
        if el.get('clip-path') or el.get('mask') or 'clip-path:' in (el.get('style') or '').replace(' ', ''):
            res.warnings.append(f'<{t}> has a clip-path or mask: imported at full size, unclipped')
        if t == 'text': res.warnings.append('<text> ignored: convert text to outlines before exporting'); return
        if t == 'use': res.warnings.append('<use> ignored: expand symbols before exporting'); return
        m = _mat_mul(m, _parse_transform(el.get('transform')))
        subs = []
        if t == 'path' and el.get('d'):
            subs = _path_subpaths(el.get('d'), tol_user)
        elif t == 'rect':
            x, y = float(el.get('x', 0)), float(el.get('y', 0)); w, h = float(el.get('width', 0)), float(el.get('height', 0))
            rx = float(el.get('rx', el.get('ry', 0)) or 0); ry = float(el.get('ry', el.get('rx', 0)) or 0)
            if w > 0 and h > 0:
                if rx > 0 and ry > 0:
                    rx = min(rx, w / 2); ry = min(ry, h / 2)
                    d = (f'M{x + rx},{y} H{x + w - rx} A{rx},{ry} 0 0 1 {x + w},{y + ry} V{y + h - ry} A{rx},{ry} 0 0 1 {x + w - rx},{y + h} '
                         f'H{x + rx} A{rx},{ry} 0 0 1 {x},{y + h - ry} V{y + ry} A{rx},{ry} 0 0 1 {x + rx},{y} Z')
                    subs = _path_subpaths(d, tol_user)
                else: subs = [([(x, y), (x + w, y), (x + w, y + h), (x, y + h)], True)]
        elif t in ('circle', 'ellipse'):
            cx, cy = float(el.get('cx', 0)), float(el.get('cy', 0))
            rx = float(el.get('r', el.get('rx', 0)) or 0); ry = float(el.get('r', el.get('ry', 0)) or 0)
            if rx > 0 and ry > 0:
                pts = _ellipse_points(cx, cy, rx, 0.0, ry / rx, 0.0, 2 * math.pi)
                subs = [(pts[:-1], True)]
        elif t in ('polygon', 'polyline'):
            v = [float(x) for x in _NUM.findall(el.get('points', ''))]
            pts = list(zip(v[0::2], v[1::2]))
            if len(pts) >= 2: subs = [(pts, t == 'polygon')]
        elif t == 'line':
            subs = [([(float(el.get('x1', 0)), float(el.get('y1', 0))), (float(el.get('x2', 0)), float(el.get('y2', 0)))], False)]
        for pts, closed in subs:
            if len(pts) < 2: continue
            ch = [(_xf_point(x, y, m) + (0.0,)) for x, y in pts]
            ch = [(x, y, 0.0) for x, y, _ in ch]
            if closed or (len(ch) >= 3 and _dist(ch[0], ch[-1]) <= JOIN_TOL):
                if _dist(ch[0], ch[-1]) <= JOIN_TOL: ch = ch[:-1]
                pts2 = geom.simplify([(x, y) for x, y, _ in ch], CURVE_TOL / 4)
                if len(pts2) >= 3: res.loops.append([(x, y, 0.0) for x, y in pts2])
            else: res.open.append(ch)
        for ch in list(el): walk(ch, m)

    walk(root, base)
    loops, left = join_chains(res.open); res.loops.extend(loops); res.open = left
    res.loops = [l for l in res.loops if _loop_ok(l)]
    return res


# ------------------------------------------------------------------ TrueType
FONT_DIRS = ['/Library/Fonts', '/System/Library/Fonts/Supplemental', '/System/Library/Fonts',
             os.path.expanduser('~/Library/Fonts'), 'C:/Windows/Fonts', os.path.expanduser('~/AppData/Local/Microsoft/Windows/Fonts'),
             '/usr/share/fonts/truetype', '/usr/share/fonts']
if os.environ.get('PSNEST_FONT_DIR'): FONT_DIRS.insert(0, os.environ['PSNEST_FONT_DIR'])   # browser build / tests


class TrueTypeFont:
    def __init__(self, path, index=0):
        self.path = path
        with open(path, 'rb') as fh: self.data = fh.read()
        data = self.data
        off = 0
        if data[:4] == b'ttcf':
            n = struct.unpack('>I', data[8:12])[0]
            off = struct.unpack('>I', data[12 + 4 * min(index, n - 1):16 + 4 * min(index, n - 1)])[0]
        ntab = struct.unpack('>H', data[off + 4:off + 6])[0]
        self.tables = {}
        for k in range(ntab):
            rec = off + 12 + 16 * k
            tg = data[rec:rec + 4].decode('latin-1'); o, ln = struct.unpack('>II', data[rec + 8:rec + 16])
            self.tables[tg] = (o, ln)
        if 'glyf' not in self.tables or 'loca' not in self.tables:
            raise ValueError(f'{os.path.basename(path)}: not a TrueType-outline font (no glyf table)')
        head = self.tables['head'][0]
        self.upem = struct.unpack('>H', data[head + 18:head + 20])[0]
        self.long_loca = struct.unpack('>h', data[head + 50:head + 52])[0] == 1
        self.nglyphs = struct.unpack('>H', data[self.tables['maxp'][0] + 4:self.tables['maxp'][0] + 6])[0]
        hhea = self.tables['hhea'][0]
        self.n_hmetrics = struct.unpack('>H', data[hhea + 34:hhea + 36])[0]
        self.ascent, self.descent = struct.unpack('>hh', data[hhea + 4:hhea + 8])
        self.cmap = self._read_cmap()
        self.cap_height = None
        if 'OS/2' in self.tables:
            o, ln = self.tables['OS/2']
            ver = struct.unpack('>H', data[o:o + 2])[0]
            if ver >= 2 and ln >= 90: self.cap_height = struct.unpack('>h', data[o + 88:o + 90])[0]
        if not self.cap_height:
            g = self.cmap.get(ord('H'))
            if g: _, _, ymax = self._glyph_bbox(g); self.cap_height = ymax
        if not self.cap_height: self.cap_height = int(0.716 * self.upem)

    def _read_cmap(self):
        data = self.data; o = self.tables['cmap'][0]
        n = struct.unpack('>H', data[o + 2:o + 4])[0]
        best = None
        for k in range(n):
            pid, eid, so = struct.unpack('>HHI', data[o + 4 + 8 * k:o + 12 + 8 * k])
            fmt = struct.unpack('>H', data[o + so:o + so + 2])[0]
            score = {(3, 10): 4, (0, 4): 3, (3, 1): 2, (0, 3): 1}.get((pid, eid), 0)
            if fmt in (4, 12) and (best is None or score > best[0]): best = (score, o + so, fmt)
        m = {}
        if best is None: return m
        _, so, fmt = best
        if fmt == 4:
            segx2 = struct.unpack('>H', data[so + 6:so + 8])[0]; seg = segx2 // 2
            ends = struct.unpack(f'>{seg}H', data[so + 14:so + 14 + segx2])
            starts = struct.unpack(f'>{seg}H', data[so + 16 + segx2:so + 16 + 2 * segx2])
            deltas = struct.unpack(f'>{seg}h', data[so + 16 + 2 * segx2:so + 16 + 3 * segx2])
            ro_off = so + 16 + 3 * segx2
            ros = struct.unpack(f'>{seg}H', data[ro_off:ro_off + segx2])
            for s in range(seg):
                for c in range(starts[s], min(ends[s], 0xFFFE) + 1):
                    if ros[s] == 0: g = (c + deltas[s]) & 0xFFFF
                    else:
                        gi = ro_off + 2 * s + ros[s] + 2 * (c - starts[s])
                        g = struct.unpack('>H', data[gi:gi + 2])[0]
                        if g: g = (g + deltas[s]) & 0xFFFF
                    if g: m[c] = g
        else:
            ngroups = struct.unpack('>I', data[so + 12:so + 16])[0]
            for k in range(ngroups):
                sc, ec, sg = struct.unpack('>III', data[so + 16 + 12 * k:so + 28 + 12 * k])
                for c in range(sc, min(ec, 0x10FFFF) + 1): m[c] = sg + (c - sc)
        return m

    def _glyph_span(self, g):
        data = self.data; lo = self.tables['loca'][0]
        if self.long_loca: a, b = struct.unpack('>II', data[lo + 4 * g:lo + 4 * g + 8])
        else: a, b = [v * 2 for v in struct.unpack('>HH', data[lo + 2 * g:lo + 2 * g + 4])]
        return self.tables['glyf'][0] + a, b - a

    def _glyph_bbox(self, g):
        o, ln = self._glyph_span(g)
        if ln == 0: return 0, 0, 0
        _, xmin, ymin, xmax, ymax = struct.unpack('>hhhhh', self.data[o:o + 10])
        return xmin, xmax, ymax

    def advance(self, g):
        o = self.tables['hmtx'][0]
        k = min(g, self.n_hmetrics - 1)
        return struct.unpack('>H', self.data[o + 4 * k:o + 4 * k + 2])[0]

    def contours(self, g, depth=0):
        """Glyph g -> list of contours, each [(x, y, on_curve)] in font units."""
        data = self.data
        o, ln = self._glyph_span(g)
        if ln == 0: return []
        nc = struct.unpack('>h', data[o:o + 2])[0]
        p = o + 10
        if nc >= 0:
            ends = struct.unpack(f'>{nc}H', data[p:p + 2 * nc]); p += 2 * nc
            npts = (ends[-1] + 1) if nc else 0
            il = struct.unpack('>H', data[p:p + 2])[0]; p += 2 + il
            flags = []
            while len(flags) < npts:
                f = data[p]; p += 1; flags.append(f)
                if f & 8:
                    rep = data[p]; p += 1; flags.extend([f] * rep)
            flags = flags[:npts]
            xs = []; v = 0
            for f in flags:
                if f & 2: d = data[p]; p += 1; v += d if f & 16 else -d
                elif not f & 16: v += struct.unpack('>h', data[p:p + 2])[0]; p += 2
                xs.append(v)
            ys = []; v = 0
            for f in flags:
                if f & 4: d = data[p]; p += 1; v += d if f & 32 else -d
                elif not f & 32: v += struct.unpack('>h', data[p:p + 2])[0]; p += 2
                ys.append(v)
            out = []; s = 0
            for e in ends:
                out.append([(xs[k], ys[k], bool(flags[k] & 1)) for k in range(s, e + 1)]); s = e + 1
            return out
        # composite
        out = []
        if depth > 5: return out
        while True:
            flags, gi = struct.unpack('>HH', data[p:p + 4]); p += 4
            if flags & 1: a1, a2 = struct.unpack('>hh', data[p:p + 4]); p += 4
            else: a1, a2 = struct.unpack('>bb', data[p:p + 2]); p += 2
            a = d = 1.0; b = c = 0.0
            if flags & 8: a = d = struct.unpack('>h', data[p:p + 2])[0] / 16384.0; p += 2
            elif flags & 0x40: a, d = [v / 16384.0 for v in struct.unpack('>hh', data[p:p + 4])]; p += 4
            elif flags & 0x80: a, b, c, d = [v / 16384.0 for v in struct.unpack('>hhhh', data[p:p + 8])]; p += 8
            dx, dy = (a1, a2) if flags & 2 else (0, 0)
            for cont in self.contours(gi, depth + 1):
                out.append([(a * x + c * y + dx, b * x + d * y + dy, on) for x, y, on in cont])
            if not flags & 0x20: break
        return out

    def glyph_loops(self, ch, tol_units):
        """Character -> (list of closed loops [(x, y)], advance) in font units, curves flattened."""
        g = self.cmap.get(ord(ch))
        if not g: return [], self.advance(0)
        loops = []
        for cont in self.contours(g):
            pts = [(x, y, on) for x, y, on in cont]
            if len(pts) < 2: continue
            # start at an on-curve point (insert the implied midpoint if none)
            k0 = next((k for k, q in enumerate(pts) if q[2]), None)
            if k0 is None:
                mid = ((pts[0][0] + pts[1][0]) / 2, (pts[0][1] + pts[1][1]) / 2, True); pts.insert(1, mid); k0 = 1
            pts = pts[k0:] + pts[:k0]
            out = [(pts[0][0], pts[0][1])]
            prev_off = None
            for x, y, on in pts[1:] + [pts[0]]:
                if on:
                    if prev_off is None: out.append((x, y))
                    else: _flatten_quad(out[-1], prev_off, (x, y), tol_units, out); prev_off = None
                else:
                    if prev_off is not None:
                        mid = ((prev_off[0] + x) / 2, (prev_off[1] + y) / 2)
                        _flatten_quad(out[-1], prev_off, mid, tol_units, out)
                    prev_off = (x, y)
            if _dist(out[0], out[-1]) < 1e-9: out.pop()
            if len(out) >= 3: loops.append(out)
        return loops, self.advance(g)


# Windows keeps the common families under short file names (arialbd.ttf, not "Arial Bold.ttf"), so the
# UI default and the usual picks need a name -> file map there.  Standard file names shipped with Windows.
WINDOWS_FONT_FILES = {'arial': 'arial.ttf', 'arial bold': 'arialbd.ttf', 'arial italic': 'ariali.ttf', 'arial bold italic': 'arialbi.ttf',
                      'arial black': 'ariblk.ttf', 'verdana': 'verdana.ttf', 'verdana bold': 'verdanab.ttf',
                      'tahoma': 'tahoma.ttf', 'tahoma bold': 'tahomabd.ttf', 'times new roman': 'times.ttf', 'times new roman bold': 'timesbd.ttf',
                      'calibri': 'calibri.ttf', 'calibri bold': 'calibrib.ttf', 'segoe ui': 'segoeui.ttf', 'segoe ui bold': 'segoeuib.ttf',
                      'georgia': 'georgia.ttf', 'georgia bold': 'georgiab.ttf', 'impact': 'impact.ttf'}


def find_font(name):
    """'Arial Bold' -> path of a .ttf/.ttc with that file name, searching the usual font folders."""
    if os.path.isfile(name): return name
    cands = [name, name + '.ttf', name + '.TTF', name + '.ttc', name.replace(' ', '') + '.ttf', name.replace(' ', '-') + '.ttf']
    if name.lower() in WINDOWS_FONT_FILES: cands.append(WINDOWS_FONT_FILES[name.lower()])
    for d in FONT_DIRS:
        if not os.path.isdir(d): continue
        low = {f.lower(): f for f in os.listdir(d)}
        for c in cands:
            if c.lower() in low: return os.path.join(d, low[c.lower()])
    return None


def list_fonts():
    """Names of TrueType-outline fonts available on this machine (sorted, de-duplicated)."""
    names = {}
    for d in FONT_DIRS:
        if not os.path.isdir(d): continue
        for f in sorted(os.listdir(d)):
            if not f.lower().endswith(('.ttf', '.ttc')): continue
            nm = os.path.splitext(f)[0]
            if nm in names: continue
            try:
                TrueTypeFont(os.path.join(d, f)); names[nm] = os.path.join(d, f)
            except Exception:
                continue
    return sorted(names)


def text_outlines(text, height_mm, font='Arial Bold', tracking=0.0):
    """Text -> list of (char, loops) in mm, y up, laid out along a baseline (cap height = height_mm).
    Each loop is a closed [(x, y, 0.0)].  Spaces advance the pen only.  Raises ValueError when the font
    cannot be found or has no glyph outlines."""
    path = find_font(font)
    if not path: raise ValueError(f'font "{font}" not found (looked in {", ".join(d for d in FONT_DIRS if os.path.isdir(d))})')
    ft = TrueTypeFont(path)
    k = height_mm / float(ft.cap_height)
    tol_units = CURVE_TOL / k
    pen = 0.0
    out = []
    for ch in text:
        loops, adv = ft.glyph_loops(ch, tol_units)
        if ch.strip():
            ls = []
            for lp in loops:
                pts = geom.simplify([(pen + x * k, y * k) for x, y in lp], CURVE_TOL / 2)
                if len(pts) >= 3: ls.append([(x, y, 0.0) for x, y in pts])
            out.append((ch, ls))
        pen += adv * k + tracking
    return out


# ------------------------------------------------------------------ loops -> parts
def _contains(outer_poly, inner_poly):
    """True when the first vertex of inner lies inside outer (loops do not cross by assumption)."""
    x, y = inner_poly[0]
    if geom.point_in_poly(x, y, outer_poly): return True
    # a vertex on the boundary is ambiguous: try the midpoint of the first edge
    mx, my = (inner_poly[0][0] + inner_poly[1][0]) / 2, (inner_poly[0][1] + inner_poly[1][1]) / 2
    return geom.point_in_poly(mx, my, outer_poly)


def classify_loops(loops):
    """Nesting depth of each loop (0 = outer, 1 = hole, 2 = island inside a hole, ...) and parent index."""
    polys = [geom.flatten(l, 0.05) for l in loops]
    areas = [abs(geom.signed_area(p)) for p in polys]
    bbs = [geom.bbox_poly(p) for p in polys]
    n = len(loops)
    parent = [None] * n
    for i in range(n):
        best = None
        for j in range(n):
            if i == j or areas[j] <= areas[i]: continue
            if bbs[j][0] > bbs[i][0] + 1e-9 or bbs[j][1] > bbs[i][1] + 1e-9 or bbs[j][2] < bbs[i][2] - 1e-9 or bbs[j][3] < bbs[i][3] - 1e-9: continue
            if _contains(polys[j], polys[i]) and (best is None or areas[j] < areas[best]): best = j
        parent[i] = best
    depth = [0] * n
    for i in range(n):
        d = 0; p = parent[i]
        while p is not None: d += 1; p = parent[p]
        depth[i] = d
    return depth, parent


def loops_to_parts(loops, mode='separate'):
    """Closed loops -> list of dicts {outline, islands, holes, w, h} with the union bbox at the origin.
    mode 'separate': every even-depth loop is its own part with its immediate holes.
    mode 'one': everything is one part (largest outer = outline, other outers = islands, odd-depth loops = holes)."""
    if not loops: return []
    depth, parent = classify_loops(loops)
    outers = [i for i in range(len(loops)) if depth[i] % 2 == 0]
    holes_of = {i: [j for j in range(len(loops)) if parent[j] == i and depth[j] % 2 == 1] for i in outers}
    def build(outer_ids):
        outer_ids = sorted(outer_ids, key=lambda i: -abs(geom.area(loops[i])))
        outs = [loops[i] for i in outer_ids]
        hs = [loops[j] for i in outer_ids for j in holes_of[i]]
        norm, w, h = geom.normalise_loops(outs)
        x0, y0, _, _ = geom.bbox_loops(outs)
        hs = [geom.translate(geom.reverse(geom.normalise(hh)[0]), geom.bbox_outline(hh)[0] - x0, geom.bbox_outline(hh)[1] - y0) for hh in hs]
        return {'outline': norm[0], 'islands': norm[1:], 'holes': hs, 'w': w, 'h': h}
    if mode == 'one': return [build(outers)]
    return [build([i]) for i in outers]


def text_parts(text, height_mm, font='Arial Bold', tracking=0.0):
    """Text -> [(char, part_dict)] ready for engine.Part (one part per character, holes and islands kept)."""
    out = []
    for ch, loops in text_outlines(text, height_mm, font, tracking):
        parts = loops_to_parts(loops, 'one')
        if parts: out.append((ch, parts[0]))
    return out
