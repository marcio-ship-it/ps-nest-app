"""Sheet media: a print & cut piece bigger than every sheet is split into butt-joined panels at its colour edges.

Danilo, 17 Nov 2026 (SP-1367 DIR-019, 5780 x 400 mm ACM: white | yellow | white): a long sign that no sheet holds is
cut into panels where one background colour meets the next, so no join falls inside a colour.  The joins are cleaner,
the panels are easier to install and the sign looks better.  The same must happen by itself for every such file.

How the edges are found, without a renderer:
  * the print copy's content is read operator by operator (CTM, clip, fill colour, forms, text, images);
  * a filled axis-aligned rectangle that covers the whole cut height (vertical joins) or width (horizontal joins) is a
    BACKGROUND band; the colour you see at each point along the sign is the last band painted over it;
  * everything else painted - paths, strokes, text, images, shadings, rectangles that stop short of the cut's edges -
    is ARTWORK, and a join must keep at least ``CLEARANCE_MM`` away from it; text is measured generously (the font's
    widest glyph, character/word spacing, TJ gaps) so a join never lands inside a word;
  * see-through or blended paint (ExtGState /ca, /CA, /BM, soft mask) and pattern or indexed colour are never a join
    colour: an edge next to them is refused;
  * a spot colour is the same colour wherever it is reached from (page or form resources), by its ink name;
  * a join candidate is a point where the visible background colour changes and no artwork is near.

Choice: the fewest panels that each fit a usable sheet (turned when allowed), then the most even split.  Joins are
snapped to whole millimetres; the thin strip between the true edge and the snapped join is repainted in the panel's
own colour, and so is the bleed past every join, so a cut a little off the line shows the panel's own colour, never
the neighbour's.  A panel next to unprinted media (no band) is clipped at the edge instead of repainted.

Anything PS Nest cannot do safely is refused with a staff message (``NoSplit``): a shaped cut line, artwork across
every colour edge, a single colour, a pattern or image background, or panels that still do not fit.
"""
import io
import math

from . import outputs, pdfcut

MM = outputs.MM
FIT_TOL = 1e-6
CLEARANCE_MM = 10.0          # [assumption] artwork kept this far from a join; well clear of a 4 mm bleed and the knife
COVER_TOL_MM = 1.0           # a band must reach the cut edges within this to count as covering the full height
                             # (DIR-019's white rectangles stop 0.76 mm short of the cut line)
MIN_RUN_MM = 0.05            # a colour run thinner than this is a rounding seam between two bands, not a colour
COLOUR_TOL = 0.004           # colour values closer than this are the same colour
MIN_PANEL_MM = 50.0          # a panel narrower than this is not worth handling as its own piece
MAX_PANELS = 12
SOURCE = ('Danilo, 17 Nov 2026 (SP-1367 DIR-019): split long signs at the colour edges so no join falls inside a colour.')


def _unsafe(why):
    """Paint PS Nest cannot repaint (see-through, blended, pattern, indexed): never a join colour, never unprinted."""
    return {'key': ('unsafe', why, ()), 'unsafe': True}


class NoSplit(ValueError):
    """The piece fits no sheet and PS Nest will not split it automatically; the message says why, for staff."""


# ------------------------------------------------------------------ fitting
def beds(rules):
    """Usable (w, h) of the default sheet and every stock sheet."""
    out = [(rules.usable_w, rules.usable_h)]
    for sz in rules.stock_sizes():
        r = rules.for_size(sz); out.append((r.usable_w, r.usable_h))
    return out


def fits(w, h, sizes, rotate):
    return any((w <= uw + FIT_TOL and h <= uh + FIT_TOL) or (rotate and h <= uw + FIT_TOL and w <= uh + FIT_TOL)
               for uw, uh in sizes)


def fits_turned(outline, sizes, angles, tol=0.05):
    """True when the outline (points (x, y[, bulge])) fits some sheet whole at one of ``angles`` (degrees), measured
    the way the shapes engine measures it: the bounding box of the turned outline against the usable sheet."""
    pts = [(p[0], p[1]) for p in outline]
    for a in angles:
        c, s = math.cos(math.radians(a)), math.sin(math.radians(a))
        xs = [x * c - y * s for x, y in pts]; ys = [x * s + y * c for x, y in pts]
        w, h = max(xs) - min(xs), max(ys) - min(ys)
        if any(w <= uw + tol and h <= uh + tol for uw, uh in sizes): return True
    return False


def max_length(cross, sizes, rotate):
    """Longest panel (along the split axis) whose other side is ``cross`` mm that fits some sheet; 0 when none."""
    best = 0.0
    for uw, uh in sizes:
        if cross <= uh + FIT_TOL: best = max(best, uw)
        if rotate and cross <= uw + FIT_TOL: best = max(best, uh)
    return best


# ------------------------------------------------------------------ reading the artwork
_DEVICE = {'/DeviceGray': 'g', '/DeviceRGB': 'rg', '/DeviceCMYK': 'k', '/G': 'g', '/RGB': 'rg', '/CMYK': 'k'}


def _bbox(pts):
    xs = [p[0] for p in pts]; ys = [p[1] for p in pts]
    return (min(xs), min(ys), max(xs), max(ys))


def _meet(a, b):
    if a is None: return b
    if b is None: return a
    r = (max(a[0], b[0]), max(a[1], b[1]), min(a[2], b[2]), min(a[3], b[3]))
    return r if r[0] < r[2] and r[1] < r[3] else (r[0], r[1], r[0], r[1])


class _Reader:
    """Collects background bands and artwork boxes from a print copy, in page points.

    bands: [(x0, y0, x1, y1, colour)] in painting order, colour = {'key', 'ops' | 'cs'} (see _colour);
    art:   [(x0, y0, x1, y1, what)]."""

    def __init__(self, reader):
        self.reader = reader
        self.bands, self.art = [], []

    def run(self, contents, resources, ctm, xpath=(), depth=0, inherit=None):
        from pypdf.generic import ContentStream
        if depth > 12: self.art.append((-1e9, -1e9, 1e9, 1e9, 'forms nested too deep')); return
        ops = ContentStream(contents, self.reader).operations
        st = {'ctm': ctm, 'clip': None, 'fill': {'key': ('k', (0.0, 0.0, 0.0, 1.0)), 'ops': '0 0 0 1 k'},
              'space': ('k', None), 'lw': 1.0, 'blend': False, 'font': 1.0, 'tc': 0.0, 'tw': 0.0, 'ts': 0.0}
        if inherit: st.update(inherit)
        stack, path, pending_clip = [], [], None
        tm = tlm = (1, 0, 0, 1, 0, 0); tsize, tz, tl = 12.0, 100.0, 0.0
        for operands, op in ops:
            o = op.decode('latin-1') if isinstance(op, bytes) else op
            if o == 'q': stack.append(dict(st))
            elif o == 'Q':
                if stack: st = stack.pop()
            elif o == 'cm': st['ctm'] = pdfcut._mul(tuple(float(v) for v in operands), st['ctm'])
            elif o == 'w':
                try: st['lw'] = float(operands[0])
                except Exception: pass
            elif o in ('g', 'rg', 'k'):
                vals = tuple(round(float(v), 4) for v in operands)
                st['space'] = (o, None)
                st['fill'] = {'key': (o, vals), 'ops': ' '.join('%g' % v for v in vals) + ' ' + o}
            elif o == 'cs':
                st['space'] = self._space(resources, operands[0], xpath)
                st['fill'] = _unsafe('colour space set, colour not')
            elif o in ('sc', 'scn'):
                st['fill'] = self._colour(st['space'], operands)
            elif o == 'gs':
                st['blend'] = self._blend(resources, operands[0], st['blend'])
            elif o == 'm': path.append([pdfcut._pt(st['ctm'], float(operands[0]), float(operands[1]))])
            elif o == 'l' and path: path[-1].append(pdfcut._pt(st['ctm'], float(operands[0]), float(operands[1])))
            elif o in ('c', 'v', 'y') and path:
                v = [float(t) for t in operands]
                for i in range(0, len(v), 2): path[-1].append(pdfcut._pt(st['ctm'], v[i], v[i + 1]))
                path[-1].append(None)                                  # marks a curve: not a rectangle
            elif o == 'h': pass
            elif o == 're':
                x, y, w, h = (float(t) for t in operands)
                path.append([pdfcut._pt(st['ctm'], *p) for p in ((x, y), (x + w, y), (x + w, y + h), (x, y + h))])
            elif o in ('W', 'W*'): pending_clip = True
            elif o in ('S', 's', 'f', 'F', 'f*', 'B', 'B*', 'b', 'b*', 'n'):
                pts = [p for sp in path for p in sp if p is not None]
                if pts:
                    box = _bbox(pts)
                    stroke = o in ('S', 's', 'B', 'B*', 'b', 'b*'); fill = o in ('f', 'F', 'f*', 'B', 'B*', 'b', 'b*')
                    if fill:
                        rect = self._rect(path)
                        if rect and not stroke:
                            # see-through or blended paint shows a mix PS Nest cannot repaint: never a join colour
                            self.bands.append(_meet(rect, st['clip']) + (_unsafe('transparency') if st['blend'] else st['fill'],))
                        else: self._add_art(box, st['clip'], 'shape')
                    if stroke:
                        sc = math.sqrt(abs(st['ctm'][0] * st['ctm'][3] - st['ctm'][1] * st['ctm'][2])) or 1.0
                        g = st['lw'] * sc / 2 + 0.5
                        self._add_art((box[0] - g, box[1] - g, box[2] + g, box[3] + g), st['clip'], 'line')
                    if pending_clip: st['clip'] = _meet(st['clip'], box)
                pending_clip = None; path = []
            elif o == 'BT': tm = tlm = (1, 0, 0, 1, 0, 0)
            elif o == 'Tf':
                try: tsize = abs(float(operands[1]))
                except Exception: pass
                st['font'] = self._font_em(resources, operands[0] if operands else None)
            elif o in ('Tc', 'Tw', 'Ts'):
                try: st[o.lower()] = float(operands[0])
                except Exception: pass
            elif o == 'Tz':
                try: tz = float(operands[0])
                except Exception: pass
            elif o == 'TL':
                try: tl = float(operands[0])
                except Exception: pass
            elif o == 'Tm': tm = tlm = tuple(float(v) for v in operands)
            elif o in ('Td', 'TD'):
                tlm = pdfcut._mul((1, 0, 0, 1, float(operands[0]), float(operands[1])), tlm); tm = tlm
                if o == 'TD': tl = -float(operands[1])
            elif o == 'T*': tlm = pdfcut._mul((1, 0, 0, 1, 0, -tl), tlm); tm = tlm
            elif o in ('Tj', 'TJ', "'", '"'):
                if o in ("'", '"'): tlm = pdfcut._mul((1, 0, 0, 1, 0, -tl), tlm); tm = tlm
                if o == '"' and len(operands) >= 3:
                    try: st['tw'], st['tc'] = float(operands[0]), float(operands[1])
                    except Exception: pass
                    operands = operands[2:]
                wid = self._text_width(operands, tsize, tz, st)
                m = pdfcut._mul(tm, st['ctm'])
                lo_y, hi_y = st['ts'] - tsize * 0.4, st['ts'] + tsize * 1.2
                corners = [pdfcut._pt(m, x, y) for x, y in ((-tsize * 0.2, lo_y), (wid, lo_y),
                                                             (wid, hi_y), (-tsize * 0.2, hi_y))]
                self._add_art(_bbox(corners), st['clip'], 'text')
                tm = pdfcut._mul((1, 0, 0, 1, wid, 0), tm)
            elif o == 'INLINE IMAGE':
                self._add_art(_bbox([pdfcut._pt(st['ctm'], x, y) for x, y in ((0, 0), (1, 0), (1, 1), (0, 1))]), st['clip'], 'image')
            elif o == 'sh':
                self._add_art(st['clip'] or (-1e9, -1e9, 1e9, 1e9), None, 'shading')
            elif o == 'Do':
                self._do(operands[0], resources, st, xpath, depth)

    @staticmethod
    def _bytes(v):
        if hasattr(v, 'original_bytes'): return bytes(v.original_bytes)
        if isinstance(v, bytes): return v
        if isinstance(v, str): return v.encode('latin-1', 'replace')
        return None

    def _text_width(self, operands, tsize, tz, st):
        """A width the shown text cannot exceed, in text space: every glyph as wide as the font's widest (at least
        1 em), plus character and word spacing when they widen it, plus the gaps a TJ array opens."""
        em, tc, tw = max(1.0, st['font']), max(0.0, st['tc']), max(0.0, st['tw'])
        wid = 0.0
        items = operands[0] if operands and isinstance(operands[0], list) else operands
        for v in items:
            b = self._bytes(v)
            if b is not None:
                wid += len(b) * (em * tsize + tc) + b.count(b' ') * tw
                continue
            try: adj = float(v)
            except Exception: continue
            if adj < 0: wid += -adj / 1000.0 * tsize            # a negative TJ number moves the next glyph right
        return max(wid, em * tsize) * tz / 100.0

    def _font_em(self, resources, name):
        """The font's widest glyph in em (from /Widths, /W or the font box); 1.0 when it says nothing."""
        best = 1.0
        try:
            font = None
            for r in resources:
                fs = pdfcut._resolve(pdfcut._resolve(r).get('/Font')) if r is not None else None
                if fs is not None and name in fs: font = pdfcut._resolve(fs[name]); break
            if font is None: return best
            fonts = [font] + [pdfcut._resolve(d) for d in (pdfcut._resolve(font.get('/DescendantFonts')) or [])]
            for f in fonts:
                ws = [float(pdfcut._resolve(w)) for w in (pdfcut._resolve(f.get('/Widths')) or [])]
                for item in (pdfcut._resolve(f.get('/W')) or []):
                    item = pdfcut._resolve(item)
                    if isinstance(item, list): ws += [float(pdfcut._resolve(w)) for w in item]
                if f.get('/DW') is not None: ws.append(float(pdfcut._resolve(f['/DW'])))
                fd = pdfcut._resolve(f.get('/FontDescriptor'))
                if fd is not None and fd.get('/FontBBox') is not None:
                    bb = [float(pdfcut._resolve(v)) for v in pdfcut._resolve(fd['/FontBBox'])]
                    ws.append(bb[2] - bb[0])
                if ws: best = max(best, max(ws) / 1000.0)
        except Exception:
            return 2.0                                      # unreadable font: assume wide glyphs
        return min(best, 20.0)

    def _blend(self, resources, name, current):
        """True while paint is see-through or blended: an ExtGState with /ca or /CA below 1, a blend mode other than
        Normal, or a soft mask.  A state that sets them back to opaque Normal ends it."""
        gs = None
        try:
            for r in resources:
                es = pdfcut._resolve(pdfcut._resolve(r).get('/ExtGState')) if r is not None else None
                if es is not None and name in es: gs = pdfcut._resolve(es[name]); break
        except Exception:
            return True
        if gs is None: return current
        out = current
        keys = [k for k in ('/ca', '/CA', '/BM', '/SMask') if gs.get(k) is not None]
        if not keys: return current
        opaque = True
        for k in ('/ca', '/CA'):
            if gs.get(k) is not None:
                try: opaque = opaque and float(pdfcut._resolve(gs[k])) >= 1.0 - 1e-6
                except Exception: opaque = False
        if gs.get('/BM') is not None:
            bm = pdfcut._resolve(gs['/BM'])
            bms = [str(pdfcut._resolve(x)) for x in bm] if isinstance(bm, list) else [str(bm)]
            opaque = opaque and bms[0] in ('/Normal', '/Compatible')
        if gs.get('/SMask') is not None:
            opaque = opaque and str(pdfcut._resolve(gs['/SMask'])) == '/None'
        out = not opaque
        return out

    @staticmethod
    def _rect(path):
        """The axis-aligned box when the path is one rectangle, else None."""
        if len(path) != 1: return None
        sp = path[0]
        if any(p is None for p in sp): return None
        pts = list(sp)
        if len(pts) == 5 and abs(pts[0][0] - pts[4][0]) < 1e-6 and abs(pts[0][1] - pts[4][1]) < 1e-6: pts = pts[:4]
        if len(pts) != 4: return None
        xs = sorted({round(p[0], 3) for p in pts}); ys = sorted({round(p[1], 3) for p in pts})
        if len(xs) != 2 or len(ys) != 2: return None
        for i in range(4):                                  # every side horizontal or vertical
            a, b = pts[i], pts[(i + 1) % 4]
            if abs(a[0] - b[0]) > 1e-3 and abs(a[1] - b[1]) > 1e-3: return None
        return (xs[0], ys[0], xs[1], ys[1])

    def _add_art(self, box, clip, what):
        b = _meet(box, clip)
        if b[2] > b[0] or b[3] > b[1]: self.art.append(b + (what,))

    def _space(self, resources, name, xpath):
        """('g'|'rg'|'k', None) for device spaces, ('named', (xpath, name)) for a resource space we can name again,
        or (None, why) for a space we cannot repaint with (pattern, indexed, lab...)."""
        n = str(name)
        if n in _DEVICE: return (_DEVICE[n], None)
        if n == '/Pattern': return (None, 'pattern')
        for depth, r in enumerate(resources):
            try:
                css = pdfcut._resolve(pdfcut._resolve(r).get('/ColorSpace')) if r is not None else None
            except Exception:
                css = None
            if css is not None and name in css:
                obj = pdfcut._resolve(css[name])
                fam = str(pdfcut._resolve(obj[0])) if isinstance(obj, list) or hasattr(obj, '__getitem__') and not isinstance(obj, str) else str(obj)
                if fam in ('/Pattern', '/Indexed', '/I'): return (None, fam.lstrip('/').lower())
                path = (tuple(xpath[:len(xpath) - depth]) if depth else tuple(xpath), n)
                return ('named', (path, self._ident(css.raw_get(name) if hasattr(css, 'raw_get') else css[name], obj, fam)))
        return (None, 'unknown colour space')

    @staticmethod
    def _ident(ref, obj, fam):
        """What a named colour space IS, so the same ink reached under two resource names (page and form) is one
        colour and two different inks under the same name are two."""
        try:
            if fam == '/Separation': return ('sep', str(pdfcut._resolve(obj[1])))
            if fam == '/DeviceN': return ('devn', tuple(str(pdfcut._resolve(v)) for v in pdfcut._resolve(obj[1])))
            if fam == '/ICCBased':
                import hashlib
                return ('icc', hashlib.md5(pdfcut._resolve(obj[1]).get_data()).hexdigest())
        except Exception:
            pass
        if hasattr(ref, 'idnum'): return ('ref', ref.idnum, ref.generation)
        return ('obj', repr(obj))

    @staticmethod
    def _colour(space, operands):
        kind, info = space
        try: vals = tuple(round(float(v), 4) for v in operands)
        except Exception: return _unsafe('pattern')            # a pattern name
        if kind in ('g', 'rg', 'k'):
            return {'key': (kind, vals), 'ops': ' '.join('%g' % v for v in vals) + ' ' + kind}
        if kind == 'named':
            path, ident = info
            return {'key': ('named', ident, vals), 'cs': path, 'vals': vals}
        return _unsafe(info or 'unknown colour space')

    def _do(self, name, resources, st, xpath, depth):
        xo = None
        try:
            for r in resources:
                xs = pdfcut._resolve(pdfcut._resolve(r).get('/XObject')) if r is not None else None
                if xs is not None and name in xs: xo = pdfcut._resolve(xs[name]); break
        except Exception:
            xo = None
        if xo is None: return
        if xo.get('/Subtype') == '/Image':
            self._add_art(_bbox([pdfcut._pt(st['ctm'], x, y) for x, y in ((0, 0), (1, 0), (1, 1), (0, 1))]), st['clip'], 'image')
            return
        if xo.get('/Subtype') != '/Form': return
        m = tuple(float(v) for v in xo.get('/Matrix', [1, 0, 0, 1, 0, 0]))
        ctm = pdfcut._mul(m, st['ctm'])
        inner = dict(st); inner['ctm'] = ctm
        if xo.get('/BBox') is not None:
            x0, y0, x1, y1 = (float(v) for v in xo['/BBox'])
            inner['clip'] = _meet(st['clip'], _bbox([pdfcut._pt(ctm, x, y) for x, y in ((x0, y0), (x1, y0), (x1, y1), (x0, y1))]))
        if xo.get('/Group') is not None:
            g = pdfcut._resolve(xo['/Group'])
            if g is not None and g.get('/S') == '/Transparency' and xpath is not None:
                pass                                       # a transparency group still paints its bands opaquely here
        res = ([xo.get('/Resources')] + list(resources)) if xo.get('/Resources') is not None else list(resources)
        sub = (tuple(xpath) + (str(name),)) if xo.get('/Resources') is not None else tuple(xpath)
        self.run(xo, res, ctm, sub, depth + 1, inherit={k: inner[k] for k in ('ctm', 'clip', 'fill', 'space', 'lw', 'blend', 'font', 'tc', 'tw', 'ts')})


def read(clean):
    """Print-copy bytes -> _Reader with bands and art (page points)."""
    from pypdf import PdfReader
    reader = PdfReader(io.BytesIO(clean))
    page = reader.pages[0]
    rd = _Reader(reader)
    if page.get_contents() is not None:
        rd.run(page.get_contents(), [page.get('/Resources')], (1, 0, 0, 1, 0, 0))
    return rd


# ------------------------------------------------------------------ the plan
def _same(a, b):
    if a is None or b is None: return a is b
    ka, kb = a['key'], b['key']
    if ka[0] != kb[0] or ka[:-1] != kb[:-1] or len(ka[-1]) != len(kb[-1]): return False
    return all(abs(x - y) <= COLOUR_TOL for x, y in zip(ka[-1], kb[-1]))


def _bands(rd, cut, axis):
    """[(a0, a1, colour, covers)] for every band crossing the cut, in page mm along the axis; covers = the band
    reaches across the whole cut (within COVER_TOL_MM), so it is background rather than artwork."""
    if axis == 'x': lo, hi, c0, c1 = cut['x0'], cut['x0'] + cut['w'], cut['y0'], cut['y0'] + cut['h']
    else: lo, hi, c0, c1 = cut['y0'], cut['y0'] + cut['h'], cut['x0'], cut['x0'] + cut['w']
    out = []
    for b in rd.bands:
        x0, y0, x1, y1 = (v / MM for v in b[:4])
        a0, a1, s0, s1 = (x0, x1, y0, y1) if axis == 'x' else (y0, y1, x0, x1)
        if a1 > lo and a0 < hi and s1 > c0 and s0 < c1:
            out.append((a0, a1, b[4], s0 <= c0 + COVER_TOL_MM and s1 >= c1 - COVER_TOL_MM))
    return out


def profile(rd, cut, axis):
    """[(start, end, colour|None)] along the axis in page mm, from the cut's start to its end, adjacent runs merged.
    colour None = no band (unprinted media)."""
    if axis == 'x': lo, hi, c0, c1 = cut['x0'], cut['x0'] + cut['w'], cut['y0'], cut['y0'] + cut['h']
    else: lo, hi, c0, c1 = cut['y0'], cut['y0'] + cut['h'], cut['x0'], cut['x0'] + cut['w']
    full = [(max(a0, lo), min(a1, hi), col) for a0, a1, col, covers in _bands(rd, cut, axis) if covers]
    cuts = sorted({lo, hi} | {v for a0, a1, _ in full for v in (a0, a1)})
    runs = []
    for s, e in zip(cuts, cuts[1:]):
        if e - s < MIN_RUN_MM: continue              # a rounding seam between two bands, not a colour of its own
        mid = (s + e) / 2
        colour = None
        for a0, a1, col in full:                       # painting order: the last band over a point is what shows
            if a0 <= mid <= a1: colour = col
        if runs and _same(runs[-1][2], colour): runs[-1] = (runs[-1][0], e, runs[-1][2])
        else: runs.append((s, e, colour))
    return runs


def candidates(rd, cut, axis, clearance=CLEARANCE_MM):
    """Colour edges along the axis that artwork keeps clear of: [(edge mm, colour before, colour after)]."""
    runs = profile(rd, cut, axis)
    if axis == 'x': c0, c1 = cut['y0'], cut['y0'] + cut['h']
    else: c0, c1 = cut['x0'], cut['x0'] + cut['w']
    art = []
    for a in rd.art:
        x0, y0, x1, y1 = (v / MM for v in a[:4])
        s0, s1, b0, b1 = (x0, x1, y0, y1) if axis == 'x' else (y0, y1, x0, x1)
        if b1 > c0 and b0 < c1: art.append((s0, s1))      # only artwork across the cut's height matters
    # a filled rectangle that stops short of the cut's edges (a stripe, a box, a clipped band) is artwork too
    art += [(a0, a1) for a0, a1, _, covers in _bands(rd, cut, axis) if not covers]
    out = []
    for (s, e, ca), (_, _, cb) in zip(runs, runs[1:]):
        if ca is None and cb is None: continue
        if any(c is not None and c.get('ops') is None and c.get('cs') is None for c in (ca, cb)): continue
        if any(a0 - clearance < e < a1 + clearance for a0, a1 in art): continue
        out.append((e, ca, cb))
    return out


def choose(length, edges, lmax, snap=True):
    """Fewest panels with every panel <= lmax (and >= MIN_PANEL_MM), then the most even.  edges are cut-relative mm.
    Returns the chosen edge indexes, or None."""
    pos = [0.0] + [(round(e) if snap else e) for e in edges] + [length]
    n = len(pos)
    best = [None] * n                                     # best[i] = (panels, max panel, sum of squares, prev)
    best[0] = (0, 0.0, 0.0, None)
    for j in range(1, n):
        for i in range(j):
            if best[i] is None: continue
            seg = pos[j] - pos[i]
            if seg > lmax + FIT_TOL or seg < MIN_PANEL_MM: continue
            cand = (best[i][0] + 1, max(best[i][1], seg), best[i][2] + seg * seg, i)
            if best[j] is None or cand[:3] < best[j][:3]: best[j] = cand
    if best[-1] is None or best[-1][0] > MAX_PANELS or best[-1][0] < 2: return None
    path, j = [], n - 1
    while best[j][3] is not None:
        path.append(j); j = best[j][3]
    return sorted(k - 1 for k in path if k != n - 1)


def plan(art_bytes, cut, sizes, rotate, clearance=CLEARANCE_MM):
    """-> {'axis', 'joins': [{'at', 'edge', 'before', 'after'}], 'windows': [(x, y, w, h)], 'clean': bytes}.
    Raises NoSplit with the reason."""
    clean = pdfcut.print_copy(art_bytes)
    rd = read(clean)
    w, h = cut['w'], cut['h']
    tried = []
    for axis, length, cross in (('x', w, h), ('y', h, w)):
        lmax = max_length(cross, sizes, rotate)
        if lmax <= 0:
            tried.append(f'{"vertical" if axis == "x" else "horizontal"} joins: a {cross:g} mm panel fits no sheet'); continue
        start = cut['x0'] if axis == 'x' else cut['y0']
        edges = candidates(rd, cut, axis, clearance)
        if not edges:
            tried.append(f'{"vertical" if axis == "x" else "horizontal"} joins: no colour edge clear of the artwork'); continue
        pick = choose(length, [e[0] - start for e in edges], lmax)
        if pick is None:
            tried.append(f'{"vertical" if axis == "x" else "horizontal"} joins: the colour edges at '
                         + ', '.join('%.0f' % (e[0] - start) for e in edges) + f' mm do not give panels of {lmax:g} mm or less')
            continue
        joins = []
        for k in pick:
            e, before, after = edges[k]
            joins.append({'at': start + round(e - start), 'edge': e, 'before': before, 'after': after})
        cuts = [start] + [j['at'] for j in joins] + [start + length]
        if axis == 'x': windows = [(a, cut['y0'], b - a, h) for a, b in zip(cuts, cuts[1:])]
        else: windows = [(cut['x0'], a, w, b - a) for a, b in zip(cuts, cuts[1:])]
        return {'axis': axis, 'joins': joins, 'windows': windows, 'clean': clean}
    raise NoSplit('; '.join(tried) if tried else 'no colour edge found')


# ------------------------------------------------------------------ making the panels
def _fill_ops(colour, page, writer, k):
    """PDF operators that set ``colour`` as the fill on ``page`` (owned by writer)."""
    from pypdf.generic import DictionaryObject, NameObject
    if colour.get('ops'): return colour['ops']
    xpath, name = colour['cs']
    res = page['/Resources']
    src = res
    for form in xpath:
        src = pdfcut._resolve(pdfcut._resolve(pdfcut._resolve(src)['/XObject'])[form])['/Resources']
    obj = pdfcut._resolve(pdfcut._resolve(src)['/ColorSpace'])[name]
    if not xpath: use = name
    else:
        use = '/PSNestJoin%d' % k
        pres = pdfcut._resolve(res)
        if '/ColorSpace' not in pres: pres[NameObject('/ColorSpace')] = DictionaryObject()
        pdfcut._resolve(pres['/ColorSpace'])[NameObject(use)] = obj
    return '%s cs %s scn' % (use, ' '.join('%g' % v for v in colour['vals']))


def panel_pdf(clean, window, bleed, axis, sides):
    """Print-copy bytes -> one panel's artwork PDF bytes.

    sides: {'lo': join | None, 'hi': join | None} - the join on the panel's low (left / bottom) and high side.
    The panel is the artwork clipped to its window grown by the bleed, on a page that size, with a CutContour
    rectangle on the window.  At a join the bleed and the strip up to the true colour edge are painted in the
    panel's own colour; next to unprinted media the clip stops at the edge."""
    from pypdf import PdfReader, PdfWriter
    from pypdf.generic import ContentStream, DecodedStreamObject, RectangleObject
    from reportlab.lib.colors import CMYKColorSep
    from reportlab.pdfgen import canvas
    wx, wy, ww, wh = window
    b = max(0.0, float(bleed or 0))
    bx0, by0 = wx - b, wy - b                       # page origin, mm
    pw, ph = ww + 2 * b, wh + 2 * b
    lo = wx if axis == 'x' else wy
    hi = lo + (ww if axis == 'x' else wh)
    clip = [bx0, by0, bx0 + pw, by0 + ph]            # x0 y0 x1 y1 in mm
    paint = []                                       # (colour, a0, a1) along the axis, mm
    j = sides.get('lo')
    if j:
        own = j['after']
        if own is None: clip[0 if axis == 'x' else 1] = max(lo, j['edge'])
        else: paint.append((own, lo - b - 1, max(lo, j['edge'])))
    j = sides.get('hi')
    if j:
        own = j['before']
        if own is None: clip[2 if axis == 'x' else 3] = min(hi, j['edge'])
        else: paint.append((own, min(hi, j['edge']), hi + b + 1))
    writer = PdfWriter()
    page = writer.add_page(PdfReader(io.BytesIO(clean)).pages[0])
    head = ('q 1 0 0 1 %.4f %.4f cm %.4f %.4f %.4f %.4f re W n q\n'
            % (-bx0 * MM, -by0 * MM, clip[0] * MM, clip[1] * MM, (clip[2] - clip[0]) * MM, (clip[3] - clip[1]) * MM))
    tail = '\nQ\n'
    for k, (colour, a0, a1) in enumerate(paint):
        ops = _fill_ops(colour, page, writer, k)
        if axis == 'x': r = (a0, by0 - 1, a1 - a0, ph + 2)
        else: r = (bx0 - 1, a0, pw + 2, a1 - a0)
        tail += '%s %.4f %.4f %.4f %.4f re f\n' % (ops, r[0] * MM, r[1] * MM, r[2] * MM, r[3] * MM)
    tail += 'Q\n'
    body = ContentStream(page.get_contents(), writer) if page.get_contents() is not None else None
    merged = DecodedStreamObject()
    merged.set_data(head.encode() + (body.get_data() if body is not None else b'') + tail.encode())
    page.replace_contents(ContentStream(merged, writer))
    from pypdf.generic import NameObject
    for box in ('/CropBox', '/TrimBox', '/BleedBox', '/ArtBox'):
        if NameObject(box) in page: del page[NameObject(box)]
    if NameObject('/Annots') in page: del page[NameObject('/Annots')]
    page.mediabox = RectangleObject([0, 0, pw * MM, ph * MM])
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=(pw * MM, ph * MM))
    c.setStrokeColor(CMYKColorSep(0, 1, 0, 0, spotName='CutContour', density=1))
    c.setLineWidth(0.25)
    c.rect(b * MM, b * MM, ww * MM, wh * MM, stroke=1, fill=0)
    c.showPage(); c.save()
    page.merge_page(PdfReader(io.BytesIO(buf.getvalue())).pages[0])
    out = io.BytesIO(); writer.write(out)
    return out.getvalue()


def split(name, art, cut, pl, bleed, register, lookup):
    """Make the panel artworks.  register(name, bytes) -> key; lookup(key) -> stored record with 'cut'.
    Returns [(label, key, cut)] with each panel's CutContour checked against its window."""
    n = len(pl['windows'])
    out = []
    for k, win in enumerate(pl['windows'], 1):
        sides = {'lo': pl['joins'][k - 2] if k > 1 else None, 'hi': pl['joins'][k - 1] if k < n else None}
        label = f'panel {k} of {n}'
        data = panel_pdf(pl['clean'], win, bleed, pl['axis'], sides)
        key = register(f'{art["name"]} {label}', data)
        pc = (lookup(key) or {}).get('cut') or {}
        if (not pc.get('found') or pc.get('error') or pc.get('loops') != 1
                or abs(pc.get('w', 0) - win[2]) > 0.5 or abs(pc.get('h', 0) - win[3]) > 0.5):
            raise NoSplit(f'{label} did not come out as a clean {win[2]:.1f} x {win[3]:.1f} mm CutContour rectangle')
        out.append((label, key, pc))
    return out


def _name(c):
    if c is None: return 'unprinted'
    k = c['key']
    if k[0] == 'k':
        v = k[1]
        if all(x <= COLOUR_TOL for x in v): return 'white'
        return 'C%g M%g Y%g K%g' % tuple(round(x * 100) for x in v)
    if k[0] == 'g': return 'white' if k[1][0] >= 1 - COLOUR_TOL else ('black' if k[1][0] <= COLOUR_TOL else 'grey %g%%' % round(k[1][0] * 100))
    if k[0] == 'rg': return 'white' if all(x >= 1 - COLOUR_TOL for x in k[1]) else 'RGB %g/%g/%g' % tuple(round(x * 255) for x in k[1])
    if k[0] == 'unsafe': return 'see-through/pattern colour'
    if k[0] == 'named' and k[1][0] == 'sep': return 'spot ' + k[1][1].lstrip('/')
    return 'named colour'


def note(name, w, h, pl):
    sizes = ' | '.join(f'{round(win[2], 1):g} x {round(win[3], 1):g}' for win in pl['windows'])
    w, h = round(w, 1), round(h, 1)
    where = ', '.join(f'{j["at"] - (pl["windows"][0][0] if pl["axis"] == "x" else pl["windows"][0][1]):g} mm '
                      f'({_name(j["before"])} | {_name(j["after"])})' for j in pl['joins'])
    return (f'{name}: {w:g} x {h:g} mm fits no sheet, so it is split into {len(pl["windows"])} butt-joined panels at its '
            f'colour edges ({"vertical" if pl["axis"] == "x" else "horizontal"} joins at {where}): {sizes} mm. '
            f'Each panel bleeds its own colour past the join. Rule: {SOURCE}')
