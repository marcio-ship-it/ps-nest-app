"""Nest guard: a production nest never goes out silently worse than it could be.

Two checks run on every nest, for staff in the app and for AI agents on the API alike:

  turning   Turning was switched off (or held to 180) for some parts.  PS Nest nests the same parts again with turning
            allowed and compares.  When turning would save a sheet, roll length or a stock-sized offcut, the machine
            files are held until somebody records why the parts must stay as they are - from a short closed list.
            "The job is double-sided" is not on the list: PS Nest writes the back print file from the same nest.

  earlier   The same parts on the same material were nested before (a quote nest, an earlier production try) and
            that nest did better.  The machine files are held until the difference is explained, so a quote layout
            and a production layout can no longer part ways unnoticed behind the same sheet count.

Source of the rule: KIVARI INV-15431, 19 Nov 2026 - the quote nest was 46 + 20 with a half sheet left for stock; the
production setup switched turning off to suit a one-off double-sided script and went out as 36 + 30, same "two sheets".

Everything here is plain data in, plain data out; server.py owns the solving, the saved job and the routes.
"""
from __future__ import annotations
import hashlib, json, os, re, time

# --- what counts as a material difference (owner rule: never silently worse) ---------------------------------------
MIN_KEEP_SIDE = 150.0        # mm: a leftover narrower than this is not counted as a piece worth keeping
OFFCUT_GAIN_M2 = 0.15        # the better layout must leave at least this much more in its best piece ...
OFFCUT_GAIN_SHARE = 0.20     # ... and at least this share more than the layout it is compared with
ROLL_GAIN_MM = 100.0         # on a roll: at least this much shorter ...
ROLL_GAIN_SHARE = 0.03       # ... and at least this share shorter

TURN_REASONS = {
    'grain': 'Material grain or brushed finish must run one way',
    'pattern': 'Printed pattern or material direction must run one way',
    'customer': 'Customer asked for this direction',
    'machine': 'Machine or handling limit',
}
EARLIER_REASONS = {
    'tool': 'The tool or cut method needs these settings',
    'material': 'Different material or sheet than the earlier nest',
    'customer': 'The job changed since the earlier nest',
    'earlier-wrong': 'The earlier nest was wrong and must not be used',
}
REASONS = {'turning': TURN_REASONS, 'earlier': EARLIER_REASONS}

_TWO_SIDED = re.compile(r'double|duplex|two[\s-]*sided|2[\s-]*sided|both\s+sides|front\s+and\s+back|frente\s+e\s+verso|dupla\s+face',
                        re.I)
TWO_SIDED_ANSWER = ('Double-sided is not a reason to lock turning. PS Nest writes the back print file itself from the same '
                    'nest: tick Double-sided, choose the back artwork on the part row, nest with turning allowed and download '
                    '"Print files - BACK" (API: artwork_back on the part, then print-back-files).')


def parse_ack(raw, check):
    """The recorded reason for keeping a held layout: {'reason', 'note', 'by'} -> a clean record, or None when absent.
    Raises ValueError with a sentence staff can act on when the reason is not acceptable."""
    if raw in (None, '', {}): return None
    reasons = REASONS[check]
    if not isinstance(raw, dict): raise ValueError('The reason must be given as reason, note and name.')
    reason = str(raw.get('reason') or '').strip().lower()
    note = ' '.join(str(raw.get('note') or '').split())[:300]
    by = ' '.join(str(raw.get('by') or '').split())[:60]
    if _TWO_SIDED.search(reason) or _TWO_SIDED.search(note): raise ValueError(TWO_SIDED_ANSWER)
    if reason not in reasons:
        raise ValueError('Choose one of these reasons: ' + '; '.join(f'{k} ({v})' for k, v in reasons.items()) + '.')
    if len(note) < 8: raise ValueError('Write a short note saying what exactly requires it (at least a few words).')
    if not by: raise ValueError('Give the name of the person or agent recording this reason.')
    return {'reason': reason, 'label': reasons[reason], 'note': note, 'by': by,
            'at': time.strftime('%Y-%m-%d %H:%M', time.localtime())}


# --- measuring a layout --------------------------------------------------------------------------------------------
def metrics(rep, roll=False, min_offcut=0.0):
    """What a layout costs, read from its report: sheets, parts per sheet, roll length and the best piece left over."""
    sheets = rep.get('sheets') or []
    keep = max(float(min_offcut or 0.0), MIN_KEEP_SIDE)
    best = {'w': 0.0, 'h': 0.0, 'area_m2': 0.0, 'sheet': 0}
    if not roll:
        for s in sheets:
            w, h = (list(s.get('largest_empty_rect_mm') or [0, 0]) + [0, 0])[:2]
            if min(w, h) < keep: continue
            a = w * h / 1e6
            if a > best['area_m2']: best = {'w': round(w, 1), 'h': round(h, 1), 'area_m2': round(a, 3), 'sheet': s.get('n', 0)}
    return {'sheets': len(sheets), 'per_sheet': [int(s.get('parts') or 0) for s in sheets],
            'used_length_mm': round(sum(float(s.get('used_length_mm') or 0.0) for s in sheets), 1),
            'offcut': best, 'roll': bool(roll)}


def _mm(v): return f'{v:,.0f}'


def layout_words(m):
    """'46 + 20, biggest piece left 1,100 x 1,220 mm (1.34 m2)' - the way the workshop talks about a nest."""
    counts = ' + '.join(str(n) for n in m['per_sheet']) or '0'
    if m['roll']:
        return f"{counts} over {m['used_length_mm'] / 1000:.2f} m of roll"
    o = m['offcut']
    left = (f"biggest piece left {_mm(o['w'])} x {_mm(o['h'])} mm ({o['area_m2']:.2f} m2)" if o['area_m2'] > 0
            else 'no piece worth keeping left')
    n = m['sheets']
    return f"{counts} on {n} sheet{'s' if n != 1 else ''}, {left}"


def better(a, b):
    """Is layout `a` materially better than layout `b`?  Returns the saving in words, or '' when it is not."""
    if a['sheets'] < b['sheets']:
        n = b['sheets'] - a['sheets']
        return f"{n} {'roll length' if b['roll'] else 'sheet'}{'s' if n != 1 else ''} fewer"
    if a['sheets'] > b['sheets']: return ''
    if b['roll']:
        gain = b['used_length_mm'] - a['used_length_mm']
        if gain >= max(ROLL_GAIN_MM, ROLL_GAIN_SHARE * b['used_length_mm']): return f'{_mm(gain)} mm less roll'
        return ''
    gain = a['offcut']['area_m2'] - b['offcut']['area_m2']
    if gain >= max(OFFCUT_GAIN_M2, OFFCUT_GAIN_SHARE * b['offcut']['area_m2']):
        return f"a {_mm(a['offcut']['w'])} x {_mm(a['offcut']['h'])} mm piece for stock instead of " + (
            f"{_mm(b['offcut']['w'])} x {_mm(b['offcut']['h'])} mm" if b['offcut']['area_m2'] > 0 else 'nothing worth keeping')
    return ''


# --- check 1: turning --------------------------------------------------------------------------------------------
def turning_restricted(parts, policy):
    """How many of the expanded parts may not turn a quarter turn, by the request (a per-part switch or the policy)."""
    if str(policy or '') == '180': return len(parts)
    return sum(1 for p in parts if not p.rotate)


def turning_check(locked_count, parts_total, policy, now, free=None, why_unchecked='', ack=None):
    """Build the turning record for the job.  `now` / `free` are metrics(); `free` None means the comparison nest
    could not be finished (then the layout is held too: nobody knows what the lock costs)."""
    rec = {'locked_parts': locked_count, 'parts_total': parts_total, 'policy': policy, 'now': now, 'free': free,
           'checked': free is not None, 'saving': '', 'ack': ack}       # a reason only counts while the lock costs something
    who = ('every part' if locked_count >= parts_total else f'{locked_count} of {parts_total} parts')
    how = 'held to half turns (180)' if str(policy) == '180' else 'switched off'
    if free is None:
        rec['words'] = (f'Turning is {how} for {who}, and PS Nest could not finish the comparison with turning allowed'
                        f'{" (" + why_unchecked + ")" if why_unchecked else ""}, so what the lock costs is not known.')
        rec['costly'] = True
        return rec
    rec['saving'] = better(free, now)
    rec['costly'] = bool(rec['saving'])
    if not rec['costly']: rec['ack'] = None
    if rec['costly']:
        rec['words'] = (f'Turning is {how} for {who}. With turning allowed the same parts nest {layout_words(free)}; '
                        f'as set they nest {layout_words(now)}. Turning would save {rec["saving"]}.')
    else:
        rec['words'] = (f'Turning is {how} for {who}. Checked: with turning allowed the same parts nest {layout_words(free)}, '
                        f'no material saving over this layout.')
    return rec


# --- check 2: the same parts were nested before ------------------------------------------------------------------
def size_counts(parts):
    """{'125x430': 66}: how many pieces of each size, whichever way round they were typed."""
    sizes = {}
    for p in parts:
        w, h = (p['w'], p['h']) if isinstance(p, dict) else (p.w, p.h)
        key = f'{round(min(w, h), 1):g}x{round(max(w, h), 1):g}'
        sizes[key] = sizes.get(key, 0) + 1
    return sizes


def material_key(settings):
    s = settings or {}
    return f"{s.get('product') or ''}|{s.get('material') or ''}"


def fingerprint(material, sheet_w, sheet_h, parts):
    """The same parts on the same material and sheet, whatever they were called and however the nest was set up."""
    blob = json.dumps([str(material or ''), round(float(sheet_w), 1), round(float(sheet_h), 1), sorted(size_counts(parts).items())])
    return hashlib.sha1(blob.encode()).hexdigest()[:16]


def setup(settings, locked_count):
    """The settings that change how tightly parts pack - compared between two nests of the same parts."""
    s = settings or {}
    return {'edge': s.get('edge'), 'gap': s.get('gap'), 'clamp': s.get('clamp'), 'policy': str(s.get('policy') or ''),
            'mode': s.get('mode'), 'bleed': s.get('bleed'), 'turn_locked_parts': int(locked_count or 0)}


_SETUP_WORDS = {'edge': 'edge {} mm', 'gap': 'gap {} mm', 'clamp': 'clamp {} mm', 'policy': 'turning policy {}', 'mode': 'mode {}',
                'bleed': 'bleed {} mm'}


def setup_diff(then, now):
    """['gap 8 mm (was 6 mm)', 'turning off for 66 parts (was allowed)'] - what changed since the earlier nest."""
    out = []
    for k, words in _SETUP_WORDS.items():
        a, b = then.get(k), now.get(k)
        if a in (None, '') and b in (None, ''): continue
        try: same = abs(float(a) - float(b)) < 1e-6
        except (TypeError, ValueError): same = a == b
        if not same: out.append(f'{words.format(_g(b))} (was {_g(a)})')
    a, b = int(then.get('turn_locked_parts') or 0), int(now.get('turn_locked_parts') or 0)
    if a != b:
        out.append((f'turning off for {b} part{"s" if b != 1 else ""}' if b else 'turning allowed')
                   + (f' (was off for {a})' if a else ' (was allowed)'))
    return out


def _g(v):
    try: return f'{float(v):g}'
    except (TypeError, ValueError): return str(v)


_INDEX = {}      # job file name -> (mtime, entry or None); saved jobs are read once per server run


def _entry(rec, jid):
    """What the earlier-nest check needs from one saved job record, or None when the record cannot be compared."""
    if not isinstance(rec, dict) or not rec.get('parts') or not rec.get('report'): return None
    if isinstance((rec.get('request') or {}).get('test_record'), dict): return None       # disposable TEST jobs
    rules, settings, req = rec.get('rules') or {}, rec.get('settings') or {}, rec.get('request') or {}
    if rules.get('pins') or rules.get('stock') or req.get('production_plan'): return None  # hand-placed or sequenced
    try:
        fp = fingerprint(material_key(settings), rules['sheet_w'], rules['sheet_h'], rec['parts'])
        half = abs(float(rules.get('rot_step') or 90.0) - 180.0) < 1e-6
        locked = turning_restricted_records(rec['parts'], '180' if half else settings.get('policy'))
        m = metrics(rec['report'], roll=bool(rules.get('roll')), min_offcut=rules.get('min_offcut') or 0.0)
    except (KeyError, TypeError, ValueError): return None
    return {'id': jid, 'job': rec.get('job') or '', 'created': rec.get('created') or 0, 'fp': fp, 'metrics': m,
            'setup': setup(settings, locked), 'parts_total': len(rec['parts']), 'sizes': sorted(size_counts(rec['parts'])),
            'stopped': bool((rec.get('report') or {}).get('stopped'))}


def turning_restricted_records(parts, policy):
    if str(policy or '') == '180': return len(parts)
    return sum(1 for p in parts if not p.get('rotate', True))


def earlier_jobs(jobs_dir, fp, exclude=()):
    """Saved, comparable jobs with this fingerprint, newest first."""
    out = []
    try: names = os.listdir(jobs_dir)
    except OSError: return out
    live = set()
    for fn in names:
        if not fn.endswith('.json'): continue
        live.add(fn)
        path = os.path.join(jobs_dir, fn)
        try: mtime = os.path.getmtime(path)
        except OSError: continue
        hit = _INDEX.get(fn)
        if not hit or hit[0] != mtime:
            try:
                with open(path) as f: entry = _entry(json.load(f), fn[:-5])
            except (OSError, ValueError): entry = None
            hit = _INDEX[fn] = (mtime, entry)
        e = hit[1]
        if e and e['fp'] == fp and e['id'] not in exclude and not e['stopped']: out.append(e)
    for fn in list(_INDEX):
        if fn not in live: _INDEX.pop(fn, None)
    return sorted(out, key=lambda e: -float(e['created'] or 0))


def earlier_check(candidates, now, now_setup, ack=None, turn_free=None):
    """Compare this nest with the best earlier nest of the same parts.  Returns the record, or None when no earlier
    nest did materially better.

    `turn_free` is what this setup nests with turning allowed, given when the turning check already holds this job for
    a costly lock.  The earlier nest is then measured against that, so the lock is asked about once (by the turning
    check) and this check only speaks up for what the lock does not explain: a wider gap, a bigger edge, another mode."""
    base = turn_free or now
    best, saving = None, ''
    for e in candidates:
        s = better(e['metrics'], base)
        if not s: continue
        if best is None or better(e['metrics'], best['metrics']): best, saving = e, s
    if best is None: return None
    if turn_free: now_setup = {**now_setup, 'turn_locked_parts': best['setup'].get('turn_locked_parts'), 'policy': best['setup'].get('policy')}
    diff = setup_diff(best['setup'], now_setup)
    when = time.strftime('%d %b %Y %H:%M', time.localtime(float(best['created']))) if best['created'] else 'earlier'
    this = (f'this setup nests {layout_words(base)} even with turning allowed' if turn_free else f'this run nests {layout_words(now)}')
    words = (f'The same parts were nested better before: job "{best["job"]}" ({when}) nested {layout_words(best["metrics"])}; '
             f'{this}. The earlier nest saves {saving}. '
             + ('Changed since then: ' + '; '.join(diff) + '.' if diff else 'The settings that PS Nest compares are the same, '
                'so nest again with a longer time or check the part list.'))
    return {'job_id': best['id'], 'job': best['job'], 'created': best['created'], 'then': best['metrics'], 'now': base,
            'saving': saving, 'diff': diff, 'words': words, 'costly': True, 'ack': ack}


def quantity_note(candidates_same_name, parts_total):
    """A plain warning when an earlier nest of the same job name carried a different number of parts."""
    for e in candidates_same_name:
        if e['parts_total'] != parts_total:
            return (f'Part count differs from the earlier nest of this job: {e["parts_total"]} parts then, {parts_total} now. '
                    f'Check the quantity against the order (ordered pieces plus any stated spares) before cutting.')
    return ''


def same_name_jobs(job_name, parts, exclude=()):
    """Comparable saved jobs with the same job name and the same piece sizes (any quantity), newest first.
    Reads the index earlier_jobs() has just refreshed."""
    key = ' '.join(str(job_name or '').lower().split())
    if not key or key == 'untitled job': return []
    sizes = sorted(size_counts(parts))
    out = [hit[1] for hit in _INDEX.values() if hit[1] and hit[1]['id'] not in exclude
           and ' '.join(hit[1]['job'].lower().split()) == key and hit[1]['sizes'] == sizes]
    return sorted(out, key=lambda e: -float(e['created'] or 0))


# --- the hold ------------------------------------------------------------------------------------------------------
HOLD_TAIL = {'turning': 'Machine files are held: nest again with turning allowed, or record why the parts must stay as they are.',
             'earlier': 'Machine files are held: nest again with the earlier settings, or record why this layout is right.'}
HELD_WORD, HELD_END = 'HELD. ', ' || '
HELD_KINDS = ('print', 'cut', 'corel-cut', 'print-files', 'cut-files', 'dxf', 'dxf-labels', 'all', 'worksheet', 'production',
              'print-back', 'print-back-files')


def open_holds(g):
    """The checks still holding the machine files: [(check, sentence), ...]."""
    out = []
    for check in ('turning', 'earlier'):
        rec = (g or {}).get(check)
        if rec and rec.get('costly') and not rec.get('ack'): out.append((check, rec['words'] + ' ' + HOLD_TAIL[check]))
    return out


def hold_reason(g):
    """One sentence for the person at the screen when machine files are held; '' when they are not."""
    return ' '.join(s for _, s in open_holds(g))


def notes(g):
    """Lines for the job notes: every lock that was kept on purpose stays visible with what it costs."""
    out = []
    for check in ('turning', 'earlier'):
        rec = (g or {}).get(check)
        if not rec: continue
        ack = rec.get('ack')
        if rec.get('costly') and ack:
            out.append(f'{rec["words"]} Kept on purpose - {ack["label"]}: {ack["note"]} (recorded by {ack["by"]}, {ack["at"]}).')
        elif check == 'turning' and not rec.get('costly'):
            out.append(rec['words'])
    if (g or {}).get('quantity_note'): out.append(g['quantity_note'])
    return out


def public(g):
    """The guard record as the app and API clients see it."""
    g = g or {}
    holds = open_holds(g)
    return {'turning': g.get('turning'), 'earlier': g.get('earlier'), 'quantity_note': g.get('quantity_note') or '',
            'held': [c for c, _ in holds], 'hold': ' '.join(s for _, s in holds),
            'held_kinds': list(HELD_KINDS),
            'reasons': {k: dict(v) for k, v in REASONS.items()}}


def log(path, jid, job_name, check, rec):
    """Append one line per recorded reason, so kept locks can be reviewed later.  Never fails the request."""
    try:
        line = {'at': time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()), 'job_id': jid, 'job': job_name, 'check': check,
                'ack': rec.get('ack'), 'saving': rec.get('saving'), 'words': rec.get('words')}
        with open(path, 'a') as f: f.write(json.dumps(line) + '\n')
    except OSError: pass


def read_excluded(path):
    try:
        with open(path) as f: return set(json.load(f))
    except (OSError, ValueError, TypeError): return set()


def add_excluded(path, jid):
    """An earlier nest declared wrong is never used as the yardstick again."""
    cur = read_excluded(path); cur.add(jid)
    try:
        tmp = path + '.tmp'
        with open(tmp, 'w') as f: json.dump(sorted(cur), f)
        os.replace(tmp, path)
    except OSError: pass
