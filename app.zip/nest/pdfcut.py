"""CutContour in artwork PDFs (print & cut, 17-Sep-2026).

Print-and-cut artwork carries its cut line as a spot colour named CutContour (pink on screen), the way
Flexi, Onyx, Caldera, Summa and Roland expect.  This module
  * reads those paths from page 1 of the artwork, form XObjects included, with every transformation
    applied (analyse), and
  * writes a copy of the artwork with the CutContour paths no longer painted (print_copy), so the
    print file never carries the cut line.
The cut line is only ever taken from the artwork: nothing here draws, closes or offsets a path.
Paths are kept as their original segments (lines and Bezier curves) in mm, page user space; the
nesting outline is a fine polyline of the same paths.
"""
from __future__ import annotations
import io, math

from . import geom

MM = 72 / 25.4
CLOSE_TOL = 0.1      # mm: a subpath whose end is this close to its start counts as closed (drawn without 'h')
FLAT_TOL = 0.05      # mm: Bezier flattening error for the nesting outline
SPOT = 'CutContour'


def is_cut_name(name):
    n = str(name).lstrip('/').replace(' ', '').replace('_', '').replace('-', '').lower()
    return n == 'cutcontour'


def _mul(m, n):
    """m then n (PDF row-vector order: point . m . n)."""
    a, b, c, d, e, f = m; A, B, C, D, E, F = n
    return (a * A + b * C, a * B + b * D, c * A + d * C, c * B + d * D, e * A + f * C + E, e * B + f * D + F)


def _pt(m, x, y):
    a, b, c, d, e, f = m
    return (a * x + c * y + e, b * x + d * y + f)


def _resolve(o):
    return o.get_object() if hasattr(o, 'get_object') else o


def _cs_cut(resources, name, match=is_cut_name):
    """How colour space `name` relates to CutContour: False (not at all), True (a Separation called CutContour,
    or a one-ink DeviceN of it) or (index, n) for a DeviceN of n inks with CutContour at `index`: there the path
    is a cut line whenever CutContour carries any tint, whatever the other inks do (see _tints_cut).
    `resources` is the chain of resource dicts, innermost first (a form without the entry falls back to its
    parent's).  A name defined nowhere is judged by the name itself (some exporters leave it out of forms)."""
    for r in resources:
        try:
            css = _resolve(_resolve(r).get('/ColorSpace')) if r is not None else None
            cs = _resolve(css.get(name)) if css is not None else None
        except Exception:
            cs = None
        if cs is None: continue
        if isinstance(cs, str) or not hasattr(cs, '__len__') or len(cs) < 2: return False
        kind = str(_resolve(cs[0]))
        if kind == '/Separation': return match(_resolve(cs[1]))
        if kind == '/DeviceN':
            names = [_resolve(n) for n in _resolve(cs[1])]
            hits = [i for i, n in enumerate(names) if match(n)]
            if not hits: return False
            return True if len(names) == 1 else (hits[0], len(names))
        return False
    return match(name)


def _tints_cut(info, operands):
    """DeviceN (index, n) + the SCN / scn operands -> True when CutContour carries a tint.  A path the designer put
    CutContour on is a cut line even if another ink rides along (F3, 20-Sep-2026); the print copy unpaints it."""
    idx, n = info
    try: v = [float(x) for x in operands[:n]]
    except (TypeError, ValueError): return False
    return len(v) == n and v[idx] > 0


class _Walker:
    """Walks content streams: collects CutContour subpaths (page space, points) and, when edit=True,
    neutralises the painting operators that would put CutContour ink on the page."""

    def __init__(self, reader, edit, match=is_cut_name):
        self.reader, self.edit, self.match = reader, edit, match
        self.subpaths = []          # [(closed, [('M', x, y) | ('L', x, y) | ('C', x1, y1, x2, y2, x3, y3)])] in points
        self.edited_forms = set()
        self.found = False

    def run(self, contents_obj, resources, ctm, depth=0, inherit=None):
        """resources: chain of resource dicts, innermost first.  inherit: the graphics state in force at the Do that
        draws this form: a form starts with its caller's colours, it does not reset them."""
        from pypdf.generic import ContentStream
        if depth > 12: return None
        cs = ContentStream(contents_obj, self.reader)
        ops = cs.operations
        st = {'scut': False, 'fcut': False, 'sdn': None, 'fdn': None}                # sdn / fdn: DeviceN (index, n) in force
        if inherit: st.update({k: inherit[k] for k in st})
        st['ctm'] = ctm
        stack = []
        path = []                    # current path: list of [segments], each starting with 'M'
        cur = None; start = None
        changed = False
        out = []
        for operands, op in ops:
            o = op.decode('latin-1') if isinstance(op, bytes) else op
            if o == 'q': stack.append(dict(st))
            elif o == 'Q':
                if stack: st = stack.pop()
            elif o == 'cm':
                st['ctm'] = _mul(tuple(float(v) for v in operands), st['ctm'])
            elif o in ('CS', 'cs'):
                info = _cs_cut(resources, operands[0], self.match); k = 's' if o == 'CS' else 'f'
                st[k + 'dn'] = info if isinstance(info, tuple) else None
                st[k + 'cut'] = bool(info)          # a multi-ink DeviceN starts with every ink at full tint: CutContour included
                if self.edit and info is True: changed = True; continue        # the space itself is dropped from the print copy: no operator may name it
            elif o in ('SCN', 'SC') and st['sdn']: st['scut'] = _tints_cut(st['sdn'], operands)
            elif o in ('scn', 'sc') and st['fdn']: st['fcut'] = _tints_cut(st['fdn'], operands)
            elif o in ('SCN', 'SC', 'scn', 'sc') and self.edit and st['scut' if o.isupper() else 'fcut']:
                changed = True; continue                                        # the tint of a dropped cut space
            elif o in ('G', 'RG', 'K'): st['scut'] = False; st['sdn'] = None
            elif o in ('g', 'rg', 'k'): st['fcut'] = False; st['fdn'] = None
            elif o == 'm':
                x, y = _pt(st['ctm'], float(operands[0]), float(operands[1]))
                path.append([('M', x, y)]); cur = start = (x, y)
            elif o == 'l' and path:
                x, y = _pt(st['ctm'], float(operands[0]), float(operands[1]))
                path[-1].append(('L', x, y)); cur = (x, y)
            elif o in ('c', 'v', 'y') and path:
                v = [float(t) for t in operands]
                if o == 'c': p1 = _pt(st['ctm'], v[0], v[1]); p2 = _pt(st['ctm'], v[2], v[3]); p3 = _pt(st['ctm'], v[4], v[5])
                elif o == 'v': p1 = cur; p2 = _pt(st['ctm'], v[0], v[1]); p3 = _pt(st['ctm'], v[2], v[3])
                else: p1 = _pt(st['ctm'], v[0], v[1]); p3 = _pt(st['ctm'], v[2], v[3]); p2 = p3
                path[-1].append(('C', p1[0], p1[1], p2[0], p2[1], p3[0], p3[1])); cur = p3
            elif o == 'h' and path:
                path[-1].append(('Z',)); cur = start
            elif o == 're':
                x, y, w, h = (float(t) for t in operands)
                pts = [_pt(st['ctm'], *p) for p in ((x, y), (x + w, y), (x + w, y + h), (x, y + h))]
                path.append([('M',) + pts[0]] + [('L',) + p for p in pts[1:]] + [('Z',)]); cur = start = pts[0]
            elif o in ('S', 's', 'f', 'F', 'f*', 'B', 'B*', 'b', 'b*', 'n'):
                stroke = o in ('S', 's', 'B', 'B*', 'b', 'b*'); fill = o in ('f', 'F', 'f*', 'B', 'B*', 'b', 'b*')
                cut_s, cut_f = stroke and st['scut'], fill and st['fcut']
                if (cut_s or cut_f) and path:
                    self.found = True
                    force_close = o in ('s', 'b', 'b*')
                    for sp in path: self._keep(sp, force_close)
                    if self.edit:
                        if (cut_s or not stroke) and (cut_f or not fill): new = 'n'              # all ink is CutContour
                        elif cut_s: new = {'B': 'f', 'B*': 'f*', 'b': 'f', 'b*': 'f*'}[o]        # keep the other fill
                        else: new = {'B': 'S', 'B*': 'S', 'b': 's', 'b*': 's'}[o]                # keep the other stroke
                        out.append((operands, new.encode('latin-1'))); changed = True
                        path = []; continue
                path = []
            elif o == 'Do':
                self._do(operands[0], resources, st, depth)
            out.append((operands, op))
        if self.edit and changed:
            cs.operations = out
            return cs
        return None

    def _keep(self, sp, force_close):
        segs = [s for s in sp if s[0] != 'Z']
        closed = force_close or any(s[0] == 'Z' for s in sp)
        if len(segs) < 2: return
        x0, y0 = segs[0][1], segs[0][2]; xe, ye = segs[-1][-2], segs[-1][-1]
        if not closed and math.hypot(xe - x0, ye - y0) <= CLOSE_TOL * MM: closed = True
        self.subpaths.append((closed, segs))

    def _do(self, name, resources, st, depth):
        try:
            xo = None
            for r in resources:
                xs = _resolve(_resolve(r).get('/XObject')) if r is not None else None
                if xs is not None and name in xs: xo = _resolve(xs[name]); break
        except Exception:
            return
        if xo is None or xo.get('/Subtype') != '/Form': return
        m = tuple(float(v) for v in xo.get('/Matrix', [1, 0, 0, 1, 0, 0]))
        res = [xo.get('/Resources')] + list(resources) if xo.get('/Resources') is not None else list(resources)
        new = self.run(xo, res, _mul(m, st['ctm']), depth=depth + 1, inherit=st)
        ident = getattr(getattr(xo, 'indirect_reference', None), 'idnum', id(xo))
        if new is not None and ident not in self.edited_forms:
            replace_stream(self.reader, xo, new.get_data()); self.edited_forms.add(ident)


def replace_stream(writer, xo, data):
    """Give the stream object `xo` (owned by `writer`) new decoded content, Flate-compressed.  pypdf's own
    set_data refuses streams with other or chained filters (ASCII85 + Flate is common), so the object is rebuilt."""
    from pypdf.generic import DecodedStreamObject, NameObject
    new = DecodedStreamObject()
    for k, v in xo.items():
        if k not in ('/Filter', '/DecodeParms', '/Length'): new[NameObject(k)] = v
    new.set_data(data)
    new = new.flate_encode()
    ref = xo.indirect_reference
    writer._objects[ref.idnum - 1] = new
    new.indirect_reference = ref


def _load(data):
    """Artwork bytes -> (writer, page 1) with any /Rotate baked into the content, so the coordinates read here, the
    print copy and what the designer sees on screen all agree."""
    from pypdf import PdfReader, PdfWriter
    try: reader = PdfReader(io.BytesIO(data))
    except Exception as e: raise ValueError(f'this is not a readable PDF ({type(e).__name__}).')
    if reader.is_encrypted:
        try: opened = reader.decrypt('')
        except Exception: opened = 0
        if not opened: raise ValueError('the PDF is password-protected. Save it without a password.')
    try: first = reader.pages[0]
    except Exception: raise ValueError('the PDF has no readable first page.')
    writer = PdfWriter()
    page = writer.add_page(first)
    if (page.rotation or 0) % 360: page.transfer_rotation_to_content()
    unit = float(page.get('/UserUnit', 1) or 1)        # Illustrator "large canvas" files: 1 unit = several points
    if abs(unit - 1) > 1e-9:
        page.scale_by(unit); del page['/UserUnit']
    return writer, page


def analyse(data, match=is_cut_name):
    """Artwork PDF bytes -> dict:
       {'found': bool, 'paths': [[segments in mm]], 'error': str|None, 'w', 'h', 'x0', 'y0', 'loops', 'holes', 'islands'}
    'paths' are closed subpaths (segments 'M'/'L'/'C', no closing segment: closing is implied).
    x0, y0 = min corner of the cut contour in page mm; the part frame is the contour with that corner at (0, 0).
    match: test for the spot colour's name (the tests use it to find a marker colour in the print PDF)."""
    reader, page = _load(data)
    wk = _Walker(reader, edit=False, match=match)
    if page.get_contents() is not None: wk.run(page.get_contents(), [page.get('/Resources')], (1, 0, 0, 1, 0, 0))
    res = {'found': wk.found, 'paths': [], 'error': None}
    if not wk.found: return res
    k = 1 / MM
    paths, seen, n_open = [], set(), 0
    for closed, segs in wk.subpaths:
        mm = [tuple([s[0]] + [v * k for v in s[1:]]) for s in segs]
        if not closed: n_open += 1; continue
        sig = tuple(round(v, 2) for s in mm for v in s[1:])
        if sig in seen: continue       # the same line stroked twice (a common export artefact) is one cut
        seen.add(sig); paths.append(mm)
    if n_open:
        res['error'] = (f'{n_open} CutContour path{"s are" if n_open > 1 else " is"} not closed. '
                        'Close the cut line in the design program; PS Nest never closes or draws cut lines.')
        return res
    if not paths:
        res['error'] = 'CutContour colour is used but no cut path was found.'
        return res
    for p in paths:
        poly = flatten_path(p, FLAT_TOL)
        if len(poly) < 3 or abs(geom.signed_area(poly)) < 1.0:
            res['error'] = 'a CutContour path encloses no area (a single line or a dot). Cut lines must be closed shapes.'
            return res
    from .importers import classify_loops
    res['paths'] = [[list(s) for s in p] for p in paths]
    g, loops = geometry(res, with_loops=True)
    depth, _ = classify_loops(loops)
    xs = [pt[0] for lp in loops for pt in lp]; ys = [pt[1] for lp in loops for pt in lp]
    res.update(w=g['w'], h=g['h'], x0=min(xs), y0=min(ys),
               loops=len(loops), holes=sum(1 for d in depth if d % 2 == 1), islands=sum(1 for d in depth if d % 2 == 0) - 1)
    res['page_mm'] = [float(page.mediabox.left) * k, float(page.mediabox.bottom) * k, float(page.mediabox.right) * k, float(page.mediabox.top) * k]
    return res


def geometry(cut, with_loops=False):
    """analyse() result -> part geometry {outline, holes, islands, w, h} in the part frame (for engine.Part)."""
    from .importers import loops_to_parts
    loops = []
    for p in cut['paths']:
        poly = flatten_path(p, FLAT_TOL)
        if len(poly) > 8: poly = geom.simplify(poly, 0.02)
        loops.append([(x, y, 0.0) for x, y in poly])
    g = loops_to_parts(loops, 'one')[0]
    return (g, loops) if with_loops else g


def flatten_path(segs, tol):
    """Closed subpath segments (mm) -> polygon points [(x, y)] (no repeated closing point)."""
    from .importers import _flatten_cubic
    pts = [(segs[0][1], segs[0][2])]
    for s in segs[1:]:
        if s[0] == 'L': pts.append((s[1], s[2]))
        elif s[0] == 'C': _flatten_cubic(pts[-1], (s[1], s[2]), (s[3], s[4]), (s[5], s[6]), tol, pts)
    clean = [pts[0]]
    for p in pts[1:]:
        if math.hypot(p[0] - clean[-1][0], p[1] - clean[-1][1]) > 1e-6: clean.append(p)
    if len(clean) > 1 and math.hypot(clean[0][0] - clean[-1][0], clean[0][1] - clean[-1][1]) <= CLOSE_TOL: clean.pop()
    return clean


def clip_ops(polys, r):
    """Content-stream text of a clip path that is the polygons grown by r on every side (a Minkowski sum with a
    disc), in the polygons' own units.  No polygon offsetting is needed: under the non-zero winding rule the
    union of same-way-round shapes is simply all of them in one path, so the path is each polygon, a strip of
    half-width r along every edge and a disc of radius r on every corner, all counter-clockwise."""
    k = 0.5522847498 * r
    out = []
    for poly in polys:
        if geom.signed_area(poly) < 0: poly = poly[::-1]
        n = len(poly)
        out.append(' '.join('%.3f %.3f %s' % (x, y, 'l' if i else 'm') for i, (x, y) in enumerate(poly)) + ' h')
        if r <= 0: continue
        for i in range(n):
            (ax, ay), (bx, by) = poly[i], poly[(i + 1) % n]
            L = math.hypot(bx - ax, by - ay)
            if L < 1e-9: continue
            nx, ny = -(by - ay) / L * r, (bx - ax) / L * r             # left normal, length r
            out.append('%.3f %.3f m %.3f %.3f l %.3f %.3f l %.3f %.3f l h' % (ax - nx, ay - ny, bx - nx, by - ny, bx + nx, by + ny, ax + nx, ay + ny))
            (px, py) = poly[i - 1]
            turn = abs(math.atan2((ax - px) * (by - ay) - (ay - py) * (bx - ax), (ax - px) * (bx - ax) + (ay - py) * (by - ay)))
            if turn < math.radians(8): continue                         # on a smooth curve the strips already meet (notch < r / 400)
            out.append('%.3f %.3f m %.3f %.3f %.3f %.3f %.3f %.3f c %.3f %.3f %.3f %.3f %.3f %.3f c %.3f %.3f %.3f %.3f %.3f %.3f c %.3f %.3f %.3f %.3f %.3f %.3f c h' % (
                ax + r, ay, ax + r, ay + k, ax + k, ay + r, ax, ay + r, ax - k, ay + r, ax - r, ay + k, ax - r, ay,
                ax - r, ay - k, ax - k, ay - r, ax, ay - r, ax + k, ay - r, ax + r, ay - k, ax + r, ay))
    return '\n'.join(out) + '\nW n\n'


def print_copy(data, bleed_limit=None):
    """Artwork PDF bytes -> (page 1 only) PDF bytes with every CutContour path left unpainted.
    bleed_limit (mm): also clip the artwork to its cut line grown by that much, so bleed wider than half the
    nesting gap cannot print onto a neighbouring part.  The clip follows the real contour, not its bounding box."""
    writer, page = _load(data)
    wk = _Walker(writer, edit=True)
    if page.get_contents() is not None:
        new = wk.run(page.get_contents(), [page.get('/Resources')], (1, 0, 0, 1, 0, 0))
        if new is not None: page.replace_contents(new)
    if bleed_limit is not None and wk.subpaths:
        from pypdf.generic import ContentStream, DecodedStreamObject
        polys = []
        for closed, segs in wk.subpaths:
            if not closed: continue
            poly = flatten_path([tuple([s[0]] + [v / MM for v in s[1:]]) for s in segs], 0.1)
            if len(poly) >= 3: polys.append([(x * MM, y * MM) for x, y in (geom.simplify(poly, 0.1) if len(poly) > 8 else poly)])
        if polys:
            head = DecodedStreamObject(); head.set_data(('q\n' + clip_ops(polys, bleed_limit * MM)).encode())
            tail = DecodedStreamObject(); tail.set_data(b'\nQ\n')
            body = ContentStream(page.get_contents(), writer)
            merged = DecodedStreamObject(); merged.set_data(head.get_data() + body.get_data() + tail.get_data())
            page.replace_contents(ContentStream(merged, writer))
    drop_cut_spaces(page.get('/Resources'))
    out = io.BytesIO(); writer.write(out)
    return out.getvalue()


def drop_cut_spaces(resources, seen=None, match=is_cut_name):
    """Remove every colour space that IS CutContour (a Separation of it, or a one-ink DeviceN) from a resource
    dict and the forms under it.  Called after the walker has unpainted every use, so nothing refers to them any
    more; a RIP that lists the spot colours a file defines would otherwise still see CutContour on the print file.
    A DeviceN that mixes CutContour with real inks stays (its other inks still paint) but the CutContour colourant is
    renamed None, which a RIP never marks and never lists."""
    seen = seen if seen is not None else set()
    try: r = _resolve(resources)
    except Exception: return
    if r is None or id(r) in seen: return
    seen.add(id(r))
    try: css = _resolve(r.get('/ColorSpace'))
    except Exception: css = None
    if css is not None:
        from pypdf.generic import NameObject
        for name in list(css.keys()):
            info = _cs_cut([r], name, match)
            if info is True: del css[name]
            elif isinstance(info, tuple):
                try: _resolve(_resolve(css[name])[1])[info[0]] = NameObject('/None')
                except Exception: del css[name]
    try: xos = _resolve(r.get('/XObject'))
    except Exception: xos = None
    for _, xo in (xos or {}).items():
        try: xo = _resolve(xo)
        except Exception: continue
        if xo.get('/Subtype') == '/Form': drop_cut_spaces(xo.get('/Resources'), seen, match)
