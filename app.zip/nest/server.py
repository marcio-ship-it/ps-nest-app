"""PS Nest local server.  Standard library only for the HTTP side; reportlab + pypdf for the PDFs.

    python3 -m nest.server            # serves http://127.0.0.1:8765
    PSNEST_BIND=0.0.0.0 PSNEST_PORT=8770 python3 -m nest.server   # one shared PS Nest for the cutter PCs (see LAN hosting below)
"""
from __future__ import annotations
import copy
from . import customcuts
import base64, hashlib, ipaddress, json, math, os, re, shutil, socket, sys, threading, time, uuid, urllib.request, urllib.parse, urllib.error
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler

from .engine import Part, Rules, expand, nest, validate, Stopped, ROLL_NO_FIT
from dataclasses import replace as _replace
from .shapenest import validate_shapes
from . import outputs, shapes, importers, pdfcut, orders, order_labels, artwork_identity, roll_batches, roll_test_lifecycle, rollpanels, sheetpanels
from .products import PRODUCTS, MACHINES, MATERIALS, machine_warnings, machine_blocks, default_product, resolve_product, custom_product, CUTTERS, cut_process_for, registration_note, length_cap_warning, roll_nest_width, corner_marks_for, plugin_edge_warning, plugin_registration
from . import nas_settings
from . import products as _products        # looked up by name: machine_material_refusal arrives with the export-profiles branch
from .version import RELEASE
from .build_identity import BUILD
from .update_guard import UpdateGuard
from .production_worksheet import production_roll_hold
from . import guard
UPDATE_GUARD = UpdateGuard()

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.environ.get('PSNEST_DATA') or os.path.join(os.path.dirname(HERE), 'data')
JOBS_DIR = os.path.join(DATA, 'jobs'); ART_DIR = os.path.join(DATA, 'artworks'); OUT_DIR = os.path.join(DATA, 'outlines')
ARCHIVE_DIR = os.path.join(DATA, 'archive', 'test-jobs')
KEEP_DAYS = 60   # job and artwork files older than this are removed at start-up
JOBS = {}        # job id -> dict (cache; the file in JOBS_DIR is the record)
ARTWORKS = {}    # artwork key -> {'name', 'bytes', 'w_mm', 'h_mm', 'cut'}  (cut = pdfcut.analyse result)
RUNS = {}        # run id (chosen by the page) -> {'stops', 'progress', 'started'} while a nest runs
PROGRESS_HOOK = None   # the browser build sets a callable(**fields) that pushes live progress to the page
DATA_LOCK = threading.RLock()  # saved jobs, source files and exact TEST-job retirement are one local transaction boundary

# LAN hosting (owner decision 16 Oct 2026): one PS Nest runs on the Ameida PC and the other cutter PCs open it in a
# browser, each from a bookmark like /?machine=biesse.  Off by default: the Mac office app binds loopback exactly as
# before.  PSNEST_BIND=0.0.0.0 listens on the LAN; a client is answered only when its address is loopback or inside
# PSNEST_ALLOW_NET (comma-separated CIDRs), otherwise it gets 403 before any route runs.  PSNEST_LAN_HOSTS lists
# extra host names the page may be served from (the POST origin check); the host PC's own LAN address needs no entry.
LOOPBACK = ('127.0.0.1', 'localhost', '::1')
# PSNEST_BIND may list several addresses (comma); duplicates collapse and 0.0.0.0 covers every interface, so it
# replaces the rest.  Each address is bound exactly once.  PSNEST_LAN_HOSTS entries are names for the page-origin
# check only and are never bound, even when one repeats a bind address.
BIND_LIST = tuple(dict.fromkeys(b.strip() for b in (os.environ.get('PSNEST_BIND') or '127.0.0.1').split(',') if b.strip())) or ('127.0.0.1',)
if any(b in ('0.0.0.0', '') for b in BIND_LIST): BIND_LIST = ('0.0.0.0',)
BIND = BIND_LIST[0]
PORT = int(os.environ.get('PSNEST_PORT') or 8765)
ALLOW_NET = os.environ.get('PSNEST_ALLOW_NET') or '192.168.15.0/24'
LAN_HOSTS = tuple(h.strip().lower() for h in (os.environ.get('PSNEST_LAN_HOSTS') or '').split(',') if h.strip())


def _allowed_nets(spec=None):
    """The networks in PSNEST_ALLOW_NET (or the given spec); entries that do not parse are ignored, never widened."""
    nets = []
    for part in (ALLOW_NET if spec is None else spec).split(','):
        part = part.strip()
        if not part: continue
        try: nets.append(ipaddress.ip_network(part, strict=False))
        except ValueError: pass
    return nets


def _client_allowed(ip, spec=None):
    """Loopback is always served; any other client must sit inside PSNEST_ALLOW_NET.  Unparseable addresses are refused."""
    try: a = ipaddress.ip_address(str(ip or '').split('%', 1)[0])
    except ValueError: return False
    if getattr(a, 'ipv4_mapped', None): a = a.ipv4_mapped
    if a.is_loopback: return True
    return any(a in net for net in _allowed_nets(spec))


def _is_loopback(ip):
    """True for a socket peer on this PC (127.0.0.0/8, ::1, ::ffff:127.x).  NAS routes are gated on this, the socket
    address, never on a Host or Origin header a LAN client can type."""
    try:
        a = ipaddress.ip_address(str(ip).split('%')[0])
        if getattr(a, 'ipv4_mapped', None): a = a.ipv4_mapped
        return a.is_loopback
    except ValueError: return False


def cutter_ids():
    """Valid ?machine= ids: every cutter in the product tables (CUTTERS plus any MACHINES entry of kind cutter), so a
    new cutter such as gunner is accepted as soon as products.py lists it; nothing is hard-coded here."""
    return tuple(dict.fromkeys(list(CUTTERS) + [k for k, v in MACHINES.items() if v.get('kind') == 'cutter']))


def machine_ids():
    """Valid ?machine= ids for a PC's page: every cutter, plus every printer (a printer PC such as the Colorado lists the
    products it prints)."""
    return tuple(dict.fromkeys(cutter_ids() + tuple(k for k, v in MACHINES.items() if v.get('kind') == 'printer')))


def is_printer(machine):
    return MACHINES.get(machine, {}).get('kind') == 'printer'


class MachineMismatch(ValueError):
    """A nest request from a PC bookmarked to machine X named a product that is cut (or, on a printer PC, printed) on another machine."""
    def __init__(self, machine, cutter, msg):
        super().__init__(msg); self.machine = machine; self.cutter = cutter


def _lan_address(host, spec=None):
    """True when host is an IP literal inside PSNEST_ALLOW_NET (not a name: a name that merely resolves to the LAN is
    the DNS-rebinding trick and is refused unless listed in PSNEST_LAN_HOSTS)."""
    try: a = ipaddress.ip_address(host)
    except ValueError: return False
    return not a.is_loopback and _client_allowed(host, spec)


def _new_run(): return {'stops': 0, 'progress': {}, 'started': time.time()}
OUTLINES = {}    # outline key -> shapes.parse_upload entry (uploaded DXF / SVG cut paths)
_FONTS = None    # cached importers.list_fonts()

def _ensure_dirs():
    for d in (JOBS_DIR, ART_DIR, OUT_DIR, ARCHIVE_DIR): os.makedirs(d, exist_ok=True)

def _housekeep():
    """Drop files older than KEEP_DAYS so the data folder does not grow forever.  Old jobs go first; an artwork or
    outline file that a surviving job still points at is kept whatever its age, so that job's downloads keep working."""
    cutoff = time.time() - KEEP_DAYS * 86400
    def drop_old(fp):
        try:
            if os.path.getmtime(fp) < cutoff: os.remove(fp)
        except OSError: pass
    for fn in os.listdir(JOBS_DIR): drop_old(os.path.join(JOBS_DIR, fn))
    keep = set()
    for fn in os.listdir(JOBS_DIR):
        if not fn.endswith('.json'): continue
        try: keep |= _referenced_keys(json.load(open(os.path.join(JOBS_DIR, fn))))
        except (OSError, ValueError): continue
    for d in (ART_DIR, OUT_DIR):
        for fn in os.listdir(d):
            if fn.rsplit('.', 1)[0] not in keep: drop_old(os.path.join(d, fn))

def _referenced_keys(obj):
    """Every artwork / outline key a saved job record mentions (parts[].artwork, shape {'key': ...})."""
    out = set()
    if isinstance(obj, dict):
        for k, v in obj.items():
            if k in ('artwork', 'artwork_back', 'key') and isinstance(v, str) and v: out.add(v)
            out |= _referenced_keys(v)
    elif isinstance(obj, list):
        for v in obj: out |= _referenced_keys(v)
    return out

def _job_source_keys(rec):
    """Return persisted artwork and outline keys without treating unrelated JSON ``key`` fields as files."""
    artworks, outlines = set(), set()
    for part in rec.get('parts') or []:
        if not isinstance(part, dict): continue
        for field in ('artwork', 'artwork_back'):
            artwork = part.get(field)
            if isinstance(artwork, str) and artwork: artworks.add(artwork)
        shape = part.get('shape')
        outline = shape.get('key') if isinstance(shape, dict) else None
        if isinstance(outline, str) and outline: outlines.add(outline)
    return {'artworks': artworks, 'outlines': outlines}

def _sha_file(path):
    digest = hashlib.sha256()
    with open(path, 'rb') as source:
        for block in iter(lambda: source.read(1024 * 1024), b''): digest.update(block)
    return digest.hexdigest()

def load_artworks():
    _ensure_dirs()
    for fn in os.listdir(ART_DIR):
        if not fn.endswith('.json'): continue
        key = fn[:-5]
        try:
            meta = json.load(open(os.path.join(ART_DIR, fn)))
            data = open(os.path.join(ART_DIR, key + '.pdf'), 'rb').read()
        except (OSError, ValueError): continue
        ARTWORKS[key] = {'name': meta['name'], 'bytes': data, 'w_mm': meta['w_mm'], 'h_mm': meta['h_mm'], 'cut': meta.get('cut'), 'pages': meta.get('pages', 1)}
        if meta.get('cut') is None:                      # stored before CutContour support: read it once now
            ARTWORKS[key]['cut'] = _analyse_cut(data)
            save_artwork(key, ARTWORKS[key])

def _analyse_cut(data):
    try: return pdfcut.analyse(data)
    except ValueError as e: return {'found': False, 'paths': [], 'error': str(e)}
    except Exception as e: return {'found': False, 'paths': [], 'error': f'could not read the PDF for a CutContour line ({type(e).__name__}: {e})'}

_NAME_QTY = (re.compile(r'\(\s*QTY\s*[-:]?\s*(\d{1,5})\s*\)', re.I), re.compile(r'(?:^|[\s_-])QTY\s*[-:]?\s*(\d{1,5})(?!\d)', re.I),
             re.compile(r'(?:^|[\s_-])(\d{1,5})\s*x\s*$', re.I), re.compile(r'(?:^|[\s_-])x\s*(\d{1,5})\s*$', re.I))

def name_qty(filename):
    """Quantity written in an artwork file name the way the shop names them: '..._420x245___36x.pdf',
    '... (QTY - 20).pdf', '1 - QTY2_print.pdf', 'Print x2.pdf'.  None when there is none: never guessed from a size."""
    stem = re.sub(r'\.pdf$', '', filename or '', flags=re.I).strip()
    for rx in _NAME_QTY:
        m = rx.search(stem)
        if m and int(m.group(1)) > 0: return int(m.group(1))
    return None

FIXES = [   # (what pdfcut reports, how the designer fixes it in Illustrator)
    ('not closed', 'Fix in Illustrator: select the cut line, Object > Path > Join (Cmd+J) so it becomes one closed path, or redraw it as a closed shape. Then Save As PDF again.'),
    ('encloses no area', 'Fix in Illustrator: the CutContour colour sits on a single line or a dot. Delete that object, draw the cut as a closed shape (rectangle, rounded rectangle, circle...) and give its STROKE the CutContour swatch. Then Save As PDF again.'),
    ('used but no cut path', 'Fix in Illustrator: the CutContour swatch is on a fill, text or a compound object, not on the stroke of a path. Draw the cut shape as a closed path, Fill none, Stroke = the CutContour spot swatch, then Save As PDF again.'),
    ('password', 'Fix in Illustrator: Save As PDF again without a document password (File > Save As > PDF > Security: no password).'),
    ('not a readable PDF', 'Fix: open the file in Illustrator or Acrobat and Save As PDF again (Illustrator default preset).'),
]
NO_CUT_FIX = ('No CutContour line: the part will be placed as a rectangle at page size and can be printed but not cut. '
              'To add it in Illustrator: Window > Swatches > New Swatch, name CutContour, type Spot Color; draw the cut shape as a closed path, '
              'Fill none, Stroke = CutContour; Save As PDF.')

def fix_for(error):
    """The Illustrator fix for a pdfcut error message, or None."""
    e = (error or '').lower()
    for key, fix in FIXES:
        if key in e: return fix
    return None

def artwork_summary(key, a):
    c = a.get('cut') or {}
    cut = {'found': bool(c.get('found')), 'error': c.get('error')}
    if c.get('error'): cut['fix'] = fix_for(c['error'])
    elif not c.get('found'): cut['fix'] = NO_CUT_FIX
    if c.get('found') and not c.get('error'):
        cut.update(w=round(c['w'], 1), h=round(c['h'], 1), paths=c['loops'], holes=c['holes'], islands=c['islands'])
    return {'key': key, 'name': a['name'], 'w_mm': a['w_mm'], 'h_mm': a['h_mm'], 'cut': cut, 'qty_hint': name_qty(a['name']), 'pages': a.get('pages', 1),
            'identity_candidate': artwork_identity.filename_candidate(a['name'])}

def artwork_checks(a, sheet_w=None, sheet_h=None, printed=True, bleed=None):
    """Warnings for one uploaded artwork, worded for the designer: bigger than the sheet, no bleed on a print job,
    page size far from the cut box.  sheet_w/h None -> the sheet check is skipped."""
    out = []
    c = a.get('cut') or {}
    pw, ph = float(a.get('w_mm') or 0), float(a.get('h_mm') or 0)
    if c.get('found') and not c.get('error'):
        w, h = float(c['w']), float(c['h'])
        what = 'cut line'
    else:
        w, h = pw, ph; what = 'page'
    if sheet_w and sheet_h and w > 0 and h > 0:
        fits = (w <= sheet_w and h <= sheet_h) or (h <= sheet_w and w <= sheet_h)
        if not fits:
            out.append(f'{a["name"]}: the {what} is {w:g} x {h:g} mm, bigger than the {sheet_w:g} x {sheet_h:g} mm sheet either way round. It cannot be nested: split the artwork or choose a bigger sheet.')
    if c.get('found') and not c.get('error'):
        try: over = outputs.contour_overhang(c)
        except Exception: over = None
        if printed and over is not None and over < 0.05:
            out.append(f'{a["name"]}: no bleed - the artwork stops exactly at the cut line. A hairline of white can show after cutting; extend the artwork {bleed or 3:g} mm past the CutContour line.')
        if pw > w + 60 or ph > h + 60:
            out.append(f'{a["name"]}: the PDF page is {pw:g} x {ph:g} mm but the cut line is {w:g} x {h:g} mm. The empty page around it is ignored, but check that the cut line is the whole part and not one piece of a multi-part page.')
        if pw < w - 0.5 or ph < h - 0.5:
            out.append(f'{a["name"]}: the cut line ({w:g} x {h:g} mm) runs past the PDF page ({pw:g} x {ph:g} mm): the part is clipped. Make the artboard at least as big as the cut line.')
    return out

def print_artwork(key, bleed_limit):
    """Bytes placed in the print PDF: the artwork itself, or for CutContour artwork a copy without the cut line and
    with its bleed clipped to bleed_limit mm around the line (half the gap, so neighbours cannot overprint)."""
    a = ARTWORKS[key]
    if not (a.get('cut') or {}).get('found'): return a['bytes']
    cache = a.setdefault('_print', {})
    if bleed_limit not in cache: cache[bleed_limit] = pdfcut.print_copy(a['bytes'], bleed_limit=bleed_limit)
    return cache[bleed_limit]

def save_artwork(key, art):
    _ensure_dirs()
    open(os.path.join(ART_DIR, key + '.pdf'), 'wb').write(art['bytes'])
    json.dump({'name': art['name'], 'w_mm': art['w_mm'], 'h_mm': art['h_mm'], 'cut': art.get('cut'), 'pages': art.get('pages', 1)}, open(os.path.join(ART_DIR, key + '.json'), 'w'))

def _loops_json(loops): return [[list(pt) for pt in o] for o in loops]
def _loops_tuple(loops): return tuple(tuple(tuple(pt) for pt in o) for o in (loops or ()))

def load_outlines():
    _ensure_dirs()
    for fn in os.listdir(OUT_DIR):
        if not fn.endswith('.json'): continue
        try: e = json.load(open(os.path.join(OUT_DIR, fn)))
        except (OSError, ValueError): continue
        for g in e['parts']:
            for k in ('outline',): g[k] = _loops_tuple([g[k]])[0]
            for k in ('holes', 'islands'): g[k] = _loops_tuple(g[k])
        OUTLINES[fn[:-5]] = e

def save_outline(key, e):
    _ensure_dirs()
    rec = dict(e); rec['parts'] = [dict(g, outline=_loops_json([g['outline']])[0], holes=_loops_json(g['holes']), islands=_loops_json(g['islands'])) for g in e['parts']]
    json.dump(rec, open(os.path.join(OUT_DIR, key + '.json'), 'w'))

def outline_summary(key, e):
    return {'key': key, 'name': e['name'], 'kind': e['kind'], 'summary': e['summary'], 'warnings': e.get('warnings', []),
            'parts': [{'index': i, 'w': round(g['w'], 2), 'h': round(g['h'], 2), 'holes': len(g['holes']), 'islands': len(g['islands']), 'area': g.get('area')} for i, g in enumerate(e['parts'])]}

_KEY_RX = re.compile(r'^[A-Za-z0-9_-]{1,64}$')

def _check_key(key):
    """Stored artworks and outlines are named by an 8-hex key; anything else (a path, a blank) never reaches the disk."""
    if not isinstance(key, str) or not _KEY_RX.match(key): raise ValueError('Not a stored file key.')
    return key

def delete_outline(key):
    _check_key(key)
    OUTLINES.pop(key, None)
    try: os.remove(os.path.join(OUT_DIR, key + '.json'))
    except OSError: pass

def register_artwork(name, data):
    """Store a one-page artwork PDF the way the upload box does and return its key.  The same bytes under the same
    name (a card fetched twice) reuse the stored copy instead of piling up duplicates."""
    import hashlib
    digest = hashlib.sha1(data).hexdigest()
    for k, a in ARTWORKS.items():
        if a['name'] == name and a.get('_sha1', hashlib.sha1(a['bytes']).hexdigest()) == digest:
            a['_sha1'] = digest; return k
    from pypdf import PdfReader; import io
    try:
        rd = PdfReader(io.BytesIO(data))
        if rd.is_encrypted and not rd.decrypt(''): raise ValueError('password-protected')
        pg = rd.pages[0]; n_pages = len(rd.pages)
    except Exception as e:
        why = 'it is password-protected' if 'password' in str(e).lower() or 'decrypt' in type(e).__name__.lower() else f'it is not a readable PDF ({type(e).__name__})'
        raise ValueError(f'{name}: {why}. Save it again from the design program.')
    unit = float(pg.get('/UserUnit', 1) or 1)          # Illustrator large-canvas files: the page is `unit` times its box
    key = uuid.uuid4().hex[:8]
    ARTWORKS[key] = {'name': name, 'bytes': data, 'pages': n_pages, '_sha1': digest,
                     'w_mm': round(float(pg.mediabox.width) * unit / outputs.MM, 1), 'h_mm': round(float(pg.mediabox.height) * unit / outputs.MM, 1),
                     'cut': _analyse_cut(data)}
    save_artwork(key, ARTWORKS[key])
    return key

def delete_artwork(key):
    _check_key(key)
    ARTWORKS.pop(key, None)
    for ext in ('.pdf', '.json'):
        try: os.remove(os.path.join(ART_DIR, key + ext))
        except OSError: pass

def save_job(jid, job):
    """Write the job to disk so downloads survive a restart of the server."""
    _ensure_dirs()
    r = job['rules']
    rec = {'job': job['job'], 'settings': job['settings'], 'print': job['print'], 'info': job['info'],
           'report': {k: v for k, v in job['report'].items() if k != 'svg'},
           'request': job.get('request'), 'created': job.get('created'), 'guard': job.get('guard'),
           'rules': {'sheet_w': r.sheet_w, 'sheet_h': r.sheet_h, 'edge': r.edge, 'gap': r.gap, 'clamp': r.clamp, 'min_offcut': r.min_offcut,
                     'rot_step': r.rot_step, 'grid': r.grid, 'roll': r.roll, 'trim_offcut': r.trim_offcut,
                     'edge_l': r.edge_l, 'edge_r': r.edge_r, 'edge_b': r.edge_b, 'edge_t': r.edge_t, 'offcut': r.offcut,
                     'pins': [list(p) for p in r.pins], 'stock': [list(s) for s in r.stock]},
           'custom_cuts': [s.custom_cuts for s in job['sheets']],
           'sheet_sizes': [list(s.size) if s.size else None for s in job['sheets']],
           'parts': [{'name': p.name, 'w': p.w, 'h': p.h, 'rotate': p.rotate, 'artwork': p.artwork, 'artwork_back': p.artwork_back, 'shape': p.shape,
                      'order_ref': p.order_ref, 'source_part_id': p.source_part_id,
                      'piece_id_base': p.piece_id_base, 'piece_id': p.piece_id,
                      'item_number': p.item_number, 'copy_number': p.copy_number, 'site_ref': p.site_ref,
                      'state': p.state, 'artwork_version': p.artwork_version,
                      'panel': p.panel,
                      'outline': _loops_json([p.outline])[0] if p.outline else None,
                      'holes': _loops_json(p.holes), 'islands': _loops_json(p.islands)} for p in job['parts']],
           'sheets': [[{'part': job['parts'].index(pl.part), 'x': pl.x, 'y': pl.y, 'w': pl.w, 'h': pl.h, 'rotated': pl.rotated, 'angle': pl.angle}
                       for pl in s.placed] for s in job['sheets']]}
    tmp = os.path.join(JOBS_DIR, jid + '.tmp')
    json.dump(rec, open(tmp, 'w'))
    os.replace(tmp, os.path.join(JOBS_DIR, jid + '.json'))

def load_job(jid):
    """Return the job from the cache or from its file on disk; None if it does not exist."""
    if jid in JOBS: return JOBS[jid]
    fp = os.path.join(JOBS_DIR, jid + '.json')
    if not os.path.exists(fp): return None
    from .engine import Placed, Sheet
    rec = json.load(open(fp))
    parts = [Part(p['name'], p['w'], p['h'], rotate=p['rotate'], artwork=p.get('artwork'), artwork_back=p.get('artwork_back'), shape=p.get('shape'),
                  order_ref=p.get('order_ref', ''), source_part_id=p.get('source_part_id', ''),
                  piece_id_base=p.get('piece_id_base', ''), piece_id=p.get('piece_id', ''),
                  item_number=p.get('item_number', ''), copy_number=p.get('copy_number', 0),
                  site_ref=p.get('site_ref', ''), state=p.get('state', ''), artwork_version=p.get('artwork_version', ''),
                  panel=p.get('panel', ''),
                  outline=_loops_tuple([p['outline']])[0] if p.get('outline') else None,
                  holes=_loops_tuple(p.get('holes')), islands=_loops_tuple(p.get('islands'))) for p in rec['parts']]
    sizes = rec.get('sheet_sizes') or [None] * len(rec['sheets'])
    sheets = [Sheet([Placed(parts[pl['part']], pl['x'], pl['y'], pl['w'], pl['h'], pl['rotated'], pl.get('angle', 0.0)) for pl in s],
                    size=tuple(sz) if sz else None) for s, sz in zip(rec['sheets'], sizes)]
    for s, cuts in zip(sheets, rec.get('custom_cuts') or []): s.custom_cuts = cuts
    rr = dict(rec['rules'])
    rr['pins'] = tuple(tuple(p) for p in rr.get('pins') or ())
    rr['stock'] = tuple(tuple(s) for s in rr.get('stock') or ())
    job = {'sheets': sheets, 'rules': Rules(**rr), 'parts': parts, 'info': rec['info'], 'settings': rec['settings'],
           'job': rec['job'], 'print': rec['print'], 'report': rec['report'], 'request': rec.get('request'), 'created': rec.get('created'),
           'guard': rec.get('guard')}
    if job['report'].get('orders'):
        previous = job['report'].get('packing_instruction')
        job['report']['packing_instruction'] = 'Read the small project reference beside each panel while it is still in its sheet position. Lift it straight into the correct project pile, then check the counts before bundling.'
        job['report']['notes'] = [job['report']['packing_instruction'] if note == previous else note
                                  for note in job['report'].get('notes', [])]
    JOBS[jid] = job
    return job

def list_jobs(limit=200):
    """Newest first: what the Projects list shows.  Read from the files so it survives a restart."""
    _ensure_dirs()
    rows = []
    for fn in os.listdir(JOBS_DIR):
        if not fn.endswith('.json'): continue
        fp = os.path.join(JOBS_DIR, fn)
        try:
            rec = json.load(open(fp)); rep = rec.get('report') or {}; st = rec.get('settings') or {}
        except (OSError, ValueError): continue
        rows.append({'id': fn[:-5], 'job': rec.get('job'), 'when': rec.get('created') or os.path.getmtime(fp),
                     'sheets': rep.get('sheet_count'), 'parts': rep.get('parts_total'), 'material': st.get('material'), 'cutter': st.get('cutter'),
                     'sheet_mm': rep.get('sheet_mm'), 'utilisation': rep.get('utilisation'), 'reopen': bool(rec.get('request'))})
    rows.sort(key=lambda r: -(r['when'] or 0))
    return rows[:limit]


def _test_label(label):
    return bool(re.match(r'^TEST(?:\s|[-_:])', str(label or '').strip(), re.I))


def _validate_disposable_test_orders(request_orders, report_orders):
    """The creation and archive routes share one exact manual TEST-order boundary."""
    if not request_orders or not isinstance(report_orders, list) or len(report_orders) != len(request_orders):
        raise ValueError('The disposable TEST job must retain its validated TEST order records.')
    for order in request_orders:
        if order.get('approved') is not True or any(not re.match(r'^TEST(?:\s|[-_:])', str(order.get(field) or ''), re.I)
                                                    for field in ('order_approval', 'artwork_approval', 'confirmed_by')):
            raise ValueError('Every saved order in a disposable TEST job must retain TEST-only approval fields.')
    for order in report_orders:
        if order.get('approval_basis') != 'operator_confirmation_of_existing_approval' or order.get('source_binding'):
            raise ValueError('Portal-bound production preparation cannot use the disposable TEST cleanup route.')
        if order.get('approved') is not True or any(not re.match(r'^TEST(?:\s|[-_:])', str(order.get(field) or ''), re.I)
                                                    for field in ('order_approval', 'artwork_approval', 'confirmed_by')):
            raise ValueError('The validated report does not retain TEST-only operator confirmation.')


def _creation_test_record(body, order_records):
    """Validate legacy provenance or issue a new immutable marker for a normal-UI creation intent."""
    intent, supplied = body.get('test_creation'), body.get('test_record')
    if intent is not None and supplied is not None:
        raise ValueError('Send either a TEST creation intent or an existing full TEST marker, not both.')
    marker = supplied if supplied is not None else intent
    if marker is None:
        return None
    if not isinstance(marker, dict) or marker.get('schema') != 1 or marker.get('disposable') is not True:
        raise ValueError('Disposable TEST creation requires a schema 1 marker with disposable true.')
    if marker.get('notifications_suppressed') is not True or marker.get('production_release') is not False:
        raise ValueError('Disposable TEST creation must suppress notifications and explicitly refuse production release.')
    label = str(body.get('job') or '').strip()
    if not _test_label(label):
        raise ValueError('A disposable TEST job name must begin with TEST followed by a space or separator.')
    actor = str(marker.get('created_by') or '').strip()
    if not actor or len(actor) > 200:
        raise ValueError('Give the TEST creator identity (200 characters maximum).')
    if supplied is not None and (marker.get('scope') or marker.get('creation_channel') == 'normal_ui'):
        raise ValueError('The normal_ui TEST creation channel and standalone scope are server-issued.')
    product = resolve_product(body.get('product'), body.get('custom_material'))
    standalone_roll = (intent is not None and bool(product.get('roll'))
                       and not body.get('orders') and not order_records)
    if standalone_roll:
        roll_test_lifecycle.validate_request(body)
    else:
        _validate_disposable_test_orders(body.get('orders') or [], order_records)
    if supplied is not None:
        if marker.get('creation_channel') == 'normal_ui':
            raise ValueError('The normal_ui TEST creation channel is server-issued and cannot be supplied by a caller.')
        test_id = str(marker.get('test_id') or '').strip()
        if not test_id or len(test_id) > 200:
            raise ValueError('The supplied TEST record identity is incomplete.')
        return copy.deepcopy(marker)
    expected = {'schema', 'disposable', 'notifications_suppressed', 'production_release', 'created_by'}
    if set(intent) != expected:
        raise ValueError('Normal TEST creation requires the exact intent fields and no client-supplied test_id.')
    issued = {'schema': 1, 'test_id': uuid.uuid4().hex, 'disposable': True,
            'notifications_suppressed': True, 'production_release': False, 'created_by': actor,
            'creation_channel': 'normal_ui'}
    if standalone_roll:
        issued.update(scope=roll_test_lifecycle.SCOPE,
                      sources=roll_test_lifecycle.source_inventory(body['parts'], ART_DIR))
    return issued


def _test_archive_identity(rec, body, archived_art_dir=None):
    """Require a saved, non-production TEST marker plus exact action-time identity echoes."""
    label = str(rec.get('job') or '').strip()
    if not _test_label(label):
        raise ValueError('Only a job whose saved name begins with TEST can be archived through this route.')
    marker = (rec.get('request') or {}).get('test_record')
    if not isinstance(marker, dict) or marker.get('schema') != 1 or marker.get('disposable') is not True:
        raise ValueError('The saved job has no exact disposable TEST record marker.')
    if marker.get('notifications_suppressed') is not True or marker.get('production_release') is not False:
        raise ValueError('The saved TEST record must suppress notifications and explicitly refuse production release.')
    test_id = str(marker.get('test_id') or '').strip()
    creator = str(marker.get('created_by') or '').strip()
    if not test_id or len(test_id) > 200 or not creator or len(creator) > 200:
        raise ValueError('The saved TEST record identity is incomplete.')
    normal_ui = marker.get('creation_channel') == 'normal_ui'
    archive_actor = creator
    if normal_ui:
        archive_actor = str(body.get('archive_actor') or '').strip()
        if not archive_actor or len(archive_actor) > 200:
            raise ValueError('Enter the operator performing this archive action (200 characters maximum).')
    if (rec.get('report') or {}).get('production_release') is not False:
        raise ValueError('A production-bearing job cannot be archived through the TEST cleanup route.')
    request_orders = (rec.get('request') or {}).get('orders') or []
    report_orders = (rec.get('report') or {}).get('orders') or []
    if marker.get('scope') == roll_test_lifecycle.SCOPE:
        if not normal_ui:
            raise ValueError('Standalone roll TEST provenance must be server-issued.')
        roll_test_lifecycle.validate_archive(rec, marker, ART_DIR, archived_art_dir)
    else:
        _validate_disposable_test_orders(request_orders, report_orders)
    if body.get('expected_job') != label or body.get('expected_test_id') != test_id:
        raise ValueError('The expected TEST identity does not exactly match the saved job.')
    try: expected_created = float(body.get('expected_created'))
    except (TypeError, ValueError): raise ValueError('The exact saved creation timestamp is required.')
    if expected_created != float(rec.get('created') or 0):
        raise ValueError('The expected creation timestamp does not exactly match the saved TEST job.')
    reason = str(body.get('reason') or '').strip()
    if not reason or len(reason) > 500: raise ValueError('Give the cleanup reason (500 characters maximum).')
    if body.get('confirmation') != 'ARCHIVE TEST JOB':
        raise ValueError('The exact confirmation phrase ARCHIVE TEST JOB is required.')
    return {'job': label, 'test_id': test_id, 'creator': creator, 'archive_actor': archive_actor,
            'reason': reason, 'normal_ui': normal_ui, 'retain_library_sources': normal_ui}

def archive_test_job(jid, body):
    """Retire one exact disposable TEST job after preserving a hash-addressed recoverable copy."""
    if not re.fullmatch(r'[0-9a-f]{10}', str(jid or '')): raise ValueError('Invalid job id.')
    with DATA_LOCK:
        _ensure_dirs()
        source = os.path.join(JOBS_DIR, jid + '.json')
        final = os.path.join(ARCHIVE_DIR, jid)
        archived_source = os.path.join(final, 'job.json')
        identity_source = source if os.path.isfile(source) else archived_source
        if not os.path.isfile(identity_source): return None
        with open(identity_source, 'rb') as source_file: raw = source_file.read()
        try: rec = json.loads(raw)
        except (TypeError, ValueError) as error: raise ValueError('The saved TEST job record is not readable.') from error
        identity = _test_archive_identity(rec, body, os.path.join(final, 'artworks'))
        referenced = _job_source_keys(rec)

        live_refs = {'artworks': set(), 'outlines': set()}
        for fn in os.listdir(JOBS_DIR):
            if fn == jid + '.json' or not fn.endswith('.json'): continue
            fp = os.path.join(JOBS_DIR, fn)
            try:
                with open(fp) as live_file: other = json.load(live_file)
            except (OSError, ValueError) as error:
                raise ValueError(f'Live job {fn} is unreadable; TEST cleanup stopped before changing files.') from error
            keys = _job_source_keys(other)
            for kind in live_refs: live_refs[kind] |= keys[kind]
        exclusive = {kind: sorted(keys - live_refs[kind]) for kind, keys in referenced.items()}
        shared = {kind: sorted(keys & live_refs[kind]) for kind, keys in referenced.items()}

        required = []
        for key in sorted(referenced['artworks']):
            required += [('artworks', key + '.pdf', os.path.join(ART_DIR, key + '.pdf')),
                         ('artworks', key + '.json', os.path.join(ART_DIR, key + '.json'))]
        for key in sorted(referenced['outlines']):
            required.append(('outlines', key + '.json', os.path.join(OUT_DIR, key + '.json')))
        missing = [f'{kind}/{name}' for kind, name, path in required if not os.path.isfile(path)]
        if missing and not os.path.isdir(final):
            raise ValueError('Saved TEST source custody is incomplete: ' + ', '.join(missing))

        stamp = time.time()
        manifest_path = os.path.join(final, 'archive.json')
        if not os.path.isdir(final):
            pending = os.path.join(ARCHIVE_DIR, '.' + jid + '-' + uuid.uuid4().hex[:8] + '.tmp')
            os.makedirs(pending)
            copied = []
            try:
                shutil.copy2(source, os.path.join(pending, 'job.json'))
                for kind in ('artworks', 'outlines'):
                    os.makedirs(os.path.join(pending, kind))
                for kind, name, path in required:
                    dst = os.path.join(pending, kind, name); shutil.copy2(path, dst)
                    copied.append({'kind': kind, 'file': name, 'sha256': _sha_file(dst)})
                sidecars = []
                job_files_dir = os.path.join(pending, 'job-files'); os.makedirs(job_files_dir)
                for fn in sorted(os.listdir(JOBS_DIR)):
                    fp = os.path.join(JOBS_DIR, fn)
                    if not fn.startswith(jid + '-') or not os.path.isfile(fp): continue
                    dst = os.path.join(job_files_dir, fn); shutil.copy2(fp, dst)
                    sidecars.append({'file': fn, 'sha256': _sha_file(dst)})
                manifest = {'schema': 1, 'archived_at': stamp, 'archived_by': identity['archive_actor'],
                            'created_by': identity['creator'],
                            'reason': identity['reason'], 'job_id': jid, 'job': identity['job'],
                            'test_id': identity['test_id'], 'created': rec.get('created'),
                            'original_sha256': hashlib.sha256(raw).hexdigest(), 'source_references':
                            {kind: sorted(keys) for kind, keys in referenced.items()},
                            'exclusive_references': exclusive, 'shared_references': shared,
                            'copied_files': copied, 'copied_job_files': sidecars,
                            'operational_cleanup': {'attempted': False, 'retained': []},
                            'cleanup_attempts': []}
                with open(os.path.join(pending, 'archive.json'), 'w') as manifest_file:
                    manifest_file.write(json.dumps(manifest, indent=2))
                os.replace(pending, final)
            except Exception:
                shutil.rmtree(pending, ignore_errors=True)
                raise
        else:
            with open(manifest_path) as manifest_file: manifest = json.load(manifest_file)
            if manifest.get('job_id') != jid or manifest.get('test_id') != identity['test_id']:
                raise ValueError('The existing archive does not match this exact TEST job.')

        if manifest.get('original_sha256') != _sha_file(archived_source):
            raise ValueError('The archived TEST job hash does not match its custody manifest.')
        for copied in manifest.get('copied_files') or []:
            kind, name = copied.get('kind'), copied.get('file')
            if kind not in ('artworks', 'outlines') or not isinstance(name, str) or os.path.basename(name) != name:
                raise ValueError('The TEST archive source manifest is invalid.')
            fp = os.path.join(final, kind, name)
            if not os.path.isfile(fp) or copied.get('sha256') != _sha_file(fp):
                raise ValueError(f'The archived TEST source hash is missing or changed: {kind}/{name}.')
        for copied in manifest.get('copied_job_files') or []:
            name = copied.get('file')
            if not isinstance(name, str) or os.path.basename(name) != name:
                raise ValueError('The TEST archive job-file manifest is invalid.')
            fp = os.path.join(final, 'job-files', name)
            if not os.path.isfile(fp) or copied.get('sha256') != _sha_file(fp):
                raise ValueError(f'The archived TEST job-file hash is missing or changed: {name}.')

        retry = identity_source == archived_source
        operational_job_files = [fn for fn in os.listdir(JOBS_DIR)
                                 if fn == jid + '.json' or fn.startswith(jid + '-')]
        operational_exclusive_sources = []
        if not identity['retain_library_sources']:
            for kind, folder in (('artworks', ART_DIR), ('outlines', OUT_DIR)):
                for key in exclusive[kind]:
                    operational_exclusive_sources += [os.path.join(folder, fn) for fn in os.listdir(folder)
                                                      if fn.rsplit('.', 1)[0] == key]
        if retry and not operational_job_files and not operational_exclusive_sources:
            retained = (manifest.get('operational_cleanup') or {}).get('retained') or []
            stale_failures = [row for row in retained if row.get('reason') == 'remove_failed']
            cleanup_actor = ((manifest.get('cleanup_attempts') or [{}])[-1].get('actor')
                             or manifest.get('archived_by'))
            if stale_failures:
                current_retained = [row for row in retained if row.get('reason') != 'remove_failed']
                completed_at = time.time()
                manifest['operational_cleanup'] = {'attempted': True, 'completed_at': completed_at,
                                                   'retained': current_retained}
                manifest.setdefault('resolved_cleanup_failures', []).append({
                    'resolved_at': completed_at, 'failures': copy.deepcopy(stale_failures)})
                if identity['normal_ui']:
                    manifest.setdefault('cleanup_attempts', []).append({
                        'at': completed_at, 'actor': identity['archive_actor'], 'outcome': 'reconciled_complete',
                        'retained': current_retained, 'previous_failures': stale_failures})
                tmp = manifest_path + '.tmp'
                with open(tmp, 'w') as manifest_file: manifest_file.write(json.dumps(manifest, indent=2))
                os.replace(tmp, manifest_path)
                retained = current_retained
                cleanup_actor = identity['archive_actor']
            return {'archived': True, 'idempotent': True, 'job_id': jid, 'job': identity['job'],
                    'test_id': identity['test_id'], 'archived_at': manifest['archived_at'],
                    'archive_sha256': _sha_file(manifest_path), 'operational_files_retained': retained,
                    'operational_cleanup_complete': True, 'archived_by': manifest.get('archived_by'),
                    'cleanup_actor': cleanup_actor,
                    'cleanup_attempts': copy.deepcopy(manifest.get('cleanup_attempts') or [])}

        retained = []
        for fn in [jid + '.json'] + [n for n in os.listdir(JOBS_DIR) if n.startswith(jid + '-')]:
            fp = os.path.join(JOBS_DIR, fn)
            if not os.path.isfile(fp): continue
            try: os.remove(fp)
            except OSError: retained.append({'kind': 'job-files', 'file': fn, 'reason': 'remove_failed'})
        for kind, folder, cache in (('artworks', ART_DIR, ARTWORKS), ('outlines', OUT_DIR, OUTLINES)):
            for key in sorted(referenced[kind]):
                if identity['retain_library_sources']:
                    retained.append({'kind': kind, 'key': key, 'reason': 'normal_ui_source_retained'})
                    continue
                if key in live_refs[kind]:
                    retained.append({'kind': kind, 'key': key, 'reason': 'shared_with_live_job'})
                    continue
                failed = False
                for fn in list(os.listdir(folder)):
                    if fn.rsplit('.', 1)[0] != key: continue
                    try: os.remove(os.path.join(folder, fn))
                    except OSError:
                        failed = True; retained.append({'kind': kind, 'file': fn, 'reason': 'remove_failed'})
                if not failed: cache.pop(key, None)
        JOBS.pop(jid, None)
        completed_at = time.time()
        cleanup_complete = not any(row.get('reason') == 'remove_failed' for row in retained)
        manifest['operational_cleanup'] = {'attempted': True, 'completed_at': completed_at, 'retained': retained}
        if identity['normal_ui']:
            manifest.setdefault('cleanup_attempts', []).append({
                'at': completed_at, 'actor': identity['archive_actor'],
                'outcome': 'complete' if cleanup_complete else 'incomplete', 'retained': copy.deepcopy(retained)})
        tmp = manifest_path + '.tmp'
        with open(tmp, 'w') as manifest_file: manifest_file.write(json.dumps(manifest, indent=2))
        os.replace(tmp, manifest_path)
        return {'archived': True, 'idempotent': retry,
                'job_id': jid, 'job': identity['job'], 'test_id': identity['test_id'],
                'archived_at': manifest['archived_at'], 'archive_sha256': _sha_file(manifest_path),
                'operational_files_retained': retained,
                'operational_cleanup_complete': cleanup_complete, 'archived_by': manifest.get('archived_by'),
                'cleanup_actor': identity['archive_actor'],
                'cleanup_attempts': copy.deepcopy(manifest.get('cleanup_attempts') or [])}

# ------------------------------------------------------------------ examples
EXAMPLES = [
    {'id': 'rate-boards', 'label': 'Rate boards: 9 x 500x1100 ACM, one size',
     'job': 'Rate boards', 'product': 'acm', 'sheet': {'w': 2440, 'h': 1220},
     'parts': [{'name': 'Rate board', 'w': 500, 'h': 1100, 'qty': 9, 'rotate': True}]},
    {'id': 'tc-boards', 'label': 'T&C boards: 8 x 500x1100 ACM, one size',
     'job': 'T&C boards', 'product': 'acm', 'sheet': {'w': 2440, 'h': 1220},
     'parts': [{'name': 'T&C board', 'w': 500, 'h': 1100, 'qty': 8, 'rotate': True}]},
    {'id': 'mixed', 'label': 'Mixed ACM order (six sizes, small quantities)',
     'job': 'Mixed ACM test', 'product': 'acm', 'sheet': {'w': 2440, 'h': 1220},
     'parts': [{'name': 'Rate board vertical', 'w': 590, 'h': 1340, 'qty': 4, 'rotate': True},
               {'name': 'Logo rate board', 'w': 850, 'h': 850, 'qty': 3, 'rotate': True},
               {'name': 'P1 rates promo', 'w': 960, 'h': 430, 'qty': 5, 'rotate': True},
               {'name': 'T&Cs small', 'w': 885, 'h': 430, 'qty': 6, 'rotate': True},
               {'name': 'STP QR', 'w': 400, 'h': 600, 'qty': 12, 'rotate': True},
               {'name': 'Level marker', 'w': 400, 'h': 500, 'qty': 8, 'rotate': True}]},
    {'id': 'shapes', 'label': 'Complex: circles, triangles, stars and hexagons at 45° steps (shape engine)',
     'job': 'Shape test', 'product': 'acm', 'sheet': {'w': 2440, 'h': 1220}, 'mode': 'complex', 'rot_step': 45,
     'parts': [{'name': 'Disc', 'w': 600, 'h': 600, 'qty': 3, 'rotate': True, 'shape': {'type': 'circle'}},
               {'name': 'Small disc', 'w': 250, 'h': 250, 'qty': 8, 'rotate': True, 'shape': {'type': 'circle'}},
               {'name': 'Arrow head', 'w': 500, 'h': 400, 'qty': 6, 'rotate': True, 'shape': {'type': 'triangle'}},
               {'name': 'Star', 'w': 450, 'h': 450, 'qty': 4, 'rotate': True, 'shape': {'type': 'star', 'n': 5, 'inner': 0.45}},
               {'name': 'Hex badge', 'w': 350, 'h': 350, 'qty': 6, 'rotate': True, 'shape': {'type': 'polygon', 'n': 6}},
               {'name': 'Panel', 'w': 900, 'h': 300, 'qty': 2, 'rotate': True}]},
    {'id': 'lettering', 'label': 'Complex: PLATINUM lettering 300 mm Arial Bold + two discs (shape engine)',
     'job': 'Lettering test', 'product': 'acm', 'sheet': {'w': 2440, 'h': 1220}, 'mode': 'complex', 'rot_step': 45,
     'parts': [{'name': 'Sign text', 'w': 0, 'h': 300, 'qty': 1, 'rotate': True, 'shape': {'type': 'text', 'text': 'PLATINUM', 'height': 300, 'font': 'Arial Bold'}},
               {'name': 'Disc', 'w': 400, 'h': 400, 'qty': 2, 'rotate': True, 'shape': {'type': 'circle'}}]},
]

# ------------------------------------------------------------------ Trello import (optional)
def _trello_creds():
    key = os.environ.get('TRELLO_API_KEY'); tok = os.environ.get('TRELLO_TOKEN')
    if key and tok: return key, tok
    for p in (os.path.expanduser('~/GitHub/platinum-shop/.env.production'), os.path.expanduser('~/GitHub/platinum-shop/.env.local')):
        if os.path.exists(p):
            env = {}
            for line in open(p):
                line = line.strip()
                if '=' in line and not line.startswith('#'):
                    k, v = line.split('=', 1); env[k.strip()] = v.strip().strip('"').strip("'")
            if env.get('TRELLO_API_KEY') and env.get('TRELLO_TOKEN'):
                return env['TRELLO_API_KEY'], env['TRELLO_TOKEN']
    return None, None

_DIM = re.compile(r'(\d{2,5}(?:\.\d+)?)\s*(?:mm)?\s*[xX×]\s*(\d{2,5}(?:\.\d+)?)\s*(?:mm)?')
_QTY = re.compile(r'(?:^|\b)(?:qty|quantity|x)\s*[:.]?\s*(\d{1,5})\b|(\d{1,5})\s*(?:x|pcs|pc|units?|off)\b', re.I)

# Material words as they appear on the shop's cards ("Material: SAV", "ACM panel ...").  First pattern that matches a
# line wins, so the clear-acrylic pattern sits above the plain acrylic one.  Plain "aluminium" is left out on purpose:
# it names ACM on some cards and sheet metal on others.
_MATERIAL_WORDS = [
    ('acrylic_clear', re.compile(r'clear\s+(?:acrylic|perspex)|(?:acrylic|perspex)\s+clear', re.I)),
    ('acrylic', re.compile(r'acrylic|perspex|plexi', re.I)),
    ('acm', re.compile(r'\bacm\b|composite|alupanel|dibond|alucobond', re.I)),
    ('corflute', re.compile(r'core?flute|corriboard|\bcorex\b|corrugated\s+plastic', re.I)),
    ('cardboard', re.compile(r'card\s*board|corrugated\s+(?:card|board)', re.I)),
    ('pvc', re.compile(r'foamex|\bforex\b|foam\s*pvc|\bpvc\b|palboard', re.I)),
    ('timber', re.compile(r'\bmdf\b|plywood|\bply\b|timber|\bwood', re.I)),
    ('metal', re.compile(r'stainless|mild\s+steel|\bsteel\b|corten|\bbrass\b|alumin(?:i)?um\s+sheet', re.I)),
    ('vinyl', re.compile(r'\bsav\b|vinyl|self[-\s]adhesive|sticker|decal|wall\s+graphic|floor\s+graphic|one[-\s]way\s+vision', re.I)),
]
_BLOCK_START = re.compile(r'^\W*item\s*[\d.]+\W*$|^[\W_]+$', re.I)          # "- **ITEM 3**", "ITEM 16.1", or a rule line (---, \_\_\_\_)
_STRUCK = re.compile(r'~~.*?~~')                                             # Markdown strikethrough: a cancelled item on the card
_QTY_LINE = re.compile(r'^\W*(?:qty|quantity)\W*(\d{1,5})\b', re.I)          # "**QTY: 7**" on a line of its own
_KEYVAL = re.compile(r'^\W*(?:material|lamination|laminate|printing|print|finish|finishing|size|colour|color|qty|quantity|item|artwork)\b', re.I)

def material_of(text):
    """The material a line names, by the shop's words, or None."""
    for mid, rx in _MATERIAL_WORDS:
        if rx.search(text): return mid
    return None

def parse_card_items(text):
    """Very plain parser: one item per line that carries a W x H.  The shop's cards write each item as a block
    ("ITEM n", "QTY: n", a few words, "Material: SAV", "Size:", "575mm x 560mm"), so a size line takes its quantity,
    name and material from the lines above it in the same block.  Returns candidate parts; the operator checks them."""
    items = []
    block = []                        # lines of the current block above the size line, oldest first
    for raw in text.splitlines():
        line = _STRUCK.sub('', raw).strip(' -*\t')          # struck-through text is cancelled: never a part, never a name
        if not line: continue
        if _BLOCK_START.match(line): block = []; continue
        m = _DIM.search(line)
        if not m: block.append(line); continue
        w, h = float(m.group(1)), float(m.group(2))
        rest = line[:m.start()] + ' ' + line[m.end():]
        q = _QTY.search(rest)
        qty = int(q.group(1) or q.group(2)) if q else 1
        if not q:
            for above in reversed(block):
                ql = _QTY_LINE.match(above)
                if ql: qty = int(ql.group(1)); break
        words = [b for b in block if not _QTY_LINE.match(b) and not _KEYVAL.match(b) and not b.startswith(('\\*', '*'))]
        name = re.sub(r'\s+', ' ', re.sub(_DIM, '', line)).strip(' -:,')
        name = re.sub(_QTY, '', name).strip(' -:,x')
        if not name: name = ' - '.join(words[:2]) or 'Part'
        mat = material_of(line) or next((mm for mm in (material_of(b) for b in reversed(block)) if mm), None)
        items.append({'name': name[:60], 'w': w, 'h': h, 'qty': qty, 'rotate': True, 'material': mat, 'acm': mat == 'acm', 'line': line})
        block = []
    return items

def card_material(items, text=''):
    """What the card is made of: the material named on most lines (ties go to the bigger quantity), else a word
    anywhere on the card, else None.  Also the mix, so the operator is told when a card carries two materials."""
    mix = {}
    for it in items:
        if it.get('material'):
            e = mix.setdefault(it['material'], {'material': it['material'], 'name': MATERIALS[it['material']]['name'], 'lines': 0, 'qty': 0})
            e['lines'] += 1; e['qty'] += it['qty']
    order = sorted(mix.values(), key=lambda e: (-e['lines'], -e['qty']))
    if order: return order[0]['material'], order
    mid = material_of(text)
    return mid, ([{'material': mid, 'name': MATERIALS[mid]['name'], 'lines': 0, 'qty': 0}] if mid else [])

def card_product(material_id, machine=None):
    """Where a card's material lands on this PC: (product id, warning).  `machine` is the page's ?machine= bookmark;
    the product is that machine's one for the material.  Only when the machine has no product for the material does
    it fall back to the material's first-listed cutter, and then the warning says so - that product is not in the
    bookmarked page's list, so the operator must open Show all machines or pick a material this PC cuts."""
    if not material_id: return None, None
    pid = default_product(material_id, machine)
    if not pid or not machine or _products.on_machine(PRODUCTS[pid], machine): return pid, None
    this = MACHINES.get(machine, {}).get('name', machine)
    if is_printer(machine):
        return pid, (f"This PC is the {this}, but {MATERIALS.get(material_id, {}).get('name', material_id)} is not printed on it, so this "
                     "page does not list it. Open Show all machines to nest it, or choose a material listed for this PC.")
    other = MACHINES.get(PRODUCTS[pid]['cutter'], {}).get('name', PRODUCTS[pid]['cutter'])
    mat = MATERIALS.get(material_id, {}).get('name', material_id)
    return pid, (f"This PC is the {this}, but {mat} is not cut on it: the card's material belongs to the {other}, which this page "
                 "does not list. Open Show all machines to nest it there, or choose a material listed for this PC.")

def trello_card(url_or_id, with_files=True, machine=None):
    key, tok = _trello_creds()
    if not key: raise RuntimeError('Trello credentials not found (TRELLO_API_KEY / TRELLO_TOKEN).')
    m = re.search(r'trello\.com/c/([A-Za-z0-9]+)', url_or_id or '')
    cid = m.group(1) if m else (url_or_id or '').strip()
    if not cid: raise ValueError('Paste the Trello card link (https://trello.com/c/...) or its id in the box, then press Fetch.')
    if not re.fullmatch(r'[A-Za-z0-9]{8,32}', cid): raise ValueError(f'"{cid}" is not a Trello card link or id. Copy the link from the card\'s Share button.')
    q = urllib.parse.urlencode({'key': key, 'token': tok, 'fields': 'name,desc,url', 'checklists': 'all'})
    try:
        with urllib.request.urlopen(f'https://api.trello.com/1/cards/{cid}?{q}', timeout=20) as r:
            card = json.loads(r.read())
    except urllib.error.HTTPError as e:
        if e.code in (400, 404): raise ValueError('Trello has no card at that link. Open the card in Trello and copy its link again.')
        if e.code in (401, 403): raise ValueError('Trello refused the shop token for that card (it may be on a board the token cannot see).')
        raise ValueError(f'Trello answered HTTP {e.code} for that card.')
    except (urllib.error.URLError, TimeoutError, OSError) as e:
        raise ValueError(f'Trello could not be reached from this Mac ({getattr(e, "reason", e)}). Check the internet connection.')
    text = card.get('name', '') + '\n' + card.get('desc', '')
    for cl in card.get('checklists', []) or []:
        for it in cl.get('checkItems', []): text += '\n' + it.get('name', '')
    items = parse_card_items(text)
    mid, mix = card_material(items, text)
    files, notes = card_files(cid, key, tok) if with_files else ([], [])
    pid, pwarn = card_product(mid, machine)
    return {'name': card.get('name'), 'url': card.get('url'), 'items': items,
            'material': mid, 'product': pid, 'product_fallback': bool(pwarn), 'product_warning': pwarn, 'mix': mix,
            'files': files, 'file_notes': notes, 'check': reconcile_files(items, files) if files else []}

_ATTACH_MAX = 40 * 1024 * 1024   # bytes per attachment; bigger ones are named, not fetched

def _trello_host(url):
    h = (urllib.parse.urlsplit(url).hostname or '').lower()
    return h == 'trello.com' or h.endswith('.trello.com')

class _TrelloRedirect(urllib.request.HTTPRedirectHandler):
    """Attachment downloads 302 to a signed storage link: the OAuth header must not follow them off trello.com."""
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        new = super().redirect_request(req, fp, code, msg, headers, newurl)
        if new is not None and not _trello_host(newurl): new.remove_header('Authorization')
        return new

def _trello_download(url, key, tok):
    """Fetch an attachment.  The Trello key + token go only to trello.com over https (an attachment link that points
    elsewhere, or a redirect that leaves trello.com, is fetched without them)."""
    if not str(url).lower().startswith('https://'): raise ValueError('Trello attachment link is not https.')
    headers = {'Authorization': f'OAuth oauth_consumer_key="{key}", oauth_token="{tok}"'} if _trello_host(url) else {}
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.build_opener(_TrelloRedirect).open(req, timeout=60) as r: return r.read()

_ATT_EXT = re.compile(r'\.(pdf|zip)(?=\W*$)', re.I)   # Trello names read 'NSW - KFC Fairfield.zip -' : the type sits before trailing junk

def attachment_kind(att):
    """'pdf', 'zip' or None for a Trello attachment, from its MIME type, then its name, then its URL."""
    mt = (att.get('mimeType') or '').lower()
    if 'pdf' in mt: return 'pdf'
    if 'zip' in mt: return 'zip'
    for text in (att.get('name') or '', urllib.parse.urlparse(att.get('url') or '').path):
        m = _ATT_EXT.search(text)
        if m: return m.group(1).lower()
    return None

def clean_name(name, kind):
    """'NSW - KFC Fairfield.zip -' -> 'NSW - KFC Fairfield.zip'; a name without the extension gets it back."""
    m = _ATT_EXT.search(name or '')
    base = (name or '')[:m.end()] if m else (name or '').strip(' -_')
    return base if base.lower().endswith('.' + kind) else f'{base or "attachment"}.{kind}'

def pdfs_in(name, data, kind=None):
    """(file name, bytes) for the artwork in one attachment: the PDF itself, or every PDF inside a zip
    (folders flattened, Finder's __MACOSX copies skipped).  Anything else gives nothing."""
    kind = kind or attachment_kind({'name': name})
    if kind == 'pdf': return [(clean_name(name, 'pdf'), data)]
    if kind != 'zip': return []
    import zipfile, io
    out = []
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            for info in z.infolist():
                n = info.filename
                if info.is_dir() or '__MACOSX' in n or os.path.basename(n).startswith('.') or not n.lower().endswith('.pdf'): continue
                out.append((os.path.basename(n), z.read(info)))
    except zipfile.BadZipFile:
        raise ValueError(f'{name} is not a zip file PS Nest can open.')
    return out

def card_files(cid, key, tok, fetch=None, attachments=None):
    """Pull the card's artwork: every PDF attached, loose or inside a zip, stored like an upload.
    Returns (artwork summaries in card order, notes about what was skipped).  `fetch`/`attachments` are for tests."""
    fetch = fetch or (lambda url: _trello_download(url, key, tok))
    if attachments is None:
        q = urllib.parse.urlencode({'key': key, 'token': tok, 'fields': 'name,url,bytes,mimeType,isUpload'})
        try:
            with urllib.request.urlopen(f'https://api.trello.com/1/cards/{cid}/attachments?{q}', timeout=20) as r:
                attachments = json.loads(r.read())
        except Exception as e:
            return [], [f'The card\'s attachments could not be listed ({getattr(e, "reason", e)}); the parts come from the card text only.']
    files, notes = [], []
    for att in attachments:
        kind = attachment_kind(att)
        if not kind: continue
        name = clean_name(att.get('name') or '', kind)
        if (att.get('bytes') or 0) > _ATTACH_MAX:
            notes.append(f'{name} is {(att.get("bytes") or 0) / 1e6:.0f} MB - too big to pull; add it by hand.'); continue
        try:
            data = fetch(att.get('url'))
            got = pdfs_in(name, data, kind)
        except ValueError as e:
            notes.append(str(e)); continue
        except Exception as e:
            notes.append(f'{name} could not be downloaded ({getattr(e, "reason", e)}).'); continue
        if kind == 'zip' and not got: notes.append(f'{name} has no PDF inside.')
        for fname, fdata in got:
            try:
                k = register_artwork(fname, fdata)
            except ValueError as e:
                notes.append(str(e)); continue
            summ = artwork_summary(k, ARTWORKS[k]); summ['from'] = name if kind == 'zip' else None
            files.append(summ)
    return files, notes

def _size_key(w, h):
    a, b = sorted((round(float(w)), round(float(h))))
    return (a, b)

def reconcile_files(items, files):
    """Card text vs artwork files, by part size (either way round).  One entry per size that disagrees:
    quantities that differ, sizes on the card with no file, files with no line on the card.  The operator
    reads these and decides; nothing is dropped or doubled by PS Nest."""
    text, art = {}, {}
    for it in items:
        try: k = _size_key(it['w'], it['h'])
        except (TypeError, ValueError, KeyError): continue
        text.setdefault(k, {'qty': 0, 'lines': 0}); text[k]['qty'] += int(it.get('qty') or 1); text[k]['lines'] += 1
    for f in files:
        c = f.get('cut') or {}
        w, h = (c.get('w'), c.get('h')) if c.get('found') else (f.get('w_mm'), f.get('h_mm'))
        if not w or not h: continue
        k = _size_key(w, h)
        art.setdefault(k, {'qty': 0, 'names': [], 'unknown': 0})
        if f.get('qty_hint'): art[k]['qty'] += f['qty_hint']
        else: art[k]['unknown'] += 1
        art[k]['names'].append(f['name'])
    out = []
    for k in sorted(set(text) | set(art), key=lambda k: (-k[0] * k[1], k)):
        size = f'{k[1]} x {k[0]}'
        t, a = text.get(k), art.get(k)
        if t and not a: out.append({'size': size, 'kind': 'no_file', 'text': f'the card lists {t["qty"]} x {size} but no file of that size came with it'})
        elif a and not t: out.append({'size': size, 'kind': 'no_line', 'text': f'{", ".join(a["names"])} ({size}) has no line on the card'})
        elif a['unknown']: out.append({'size': size, 'kind': 'qty_unknown', 'text': f'{size}: the card says {t["qty"]}; {a["unknown"]} file name{"s" if a["unknown"] > 1 else ""} of that size carr{"y" if a["unknown"] > 1 else "ies"} no quantity - set it on the row'})
        elif a['qty'] != t['qty']: out.append({'size': size, 'kind': 'qty', 'text': f'{size}: the card says {t["qty"]}, the files say {a["qty"]} ({len(a["names"])} file{"s" if len(a["names"]) > 1 else ""}: {", ".join(a["names"])})'})
    return out

# ------------------------------------------------------------------ nesting request
def _roll_panels(prod, rules, d, name, art, cut, g, rotate, notes):
    """A roll piece wider than the roll -> [(panel label, artwork key, cut)] or None when it fits as it is.
    Raises rollpanels.LeaveOut when the piece does not fit and PS Nest will not split it (a shape, or no split fits)."""
    from .engine import _turn_ok
    rotate = rotate and _turn_ok(rules)          # a 180-degree policy may not turn a panel sideways either
    given = d.get('panel_overlap')
    overlap = rollpanels.DEFAULT_OVERLAP_MM if given is None else float(given)
    roll = f'{rules.usable_h:g} mm roll'
    try:
        pl = rollpanels.plan(g['w'], g['h'], rules.usable_w, rules.usable_h, rotate, overlap, d.get('gap', 0))
    except ValueError as e:
        if 'overlap must' in str(e): raise
        raise rollpanels.LeaveOut(f'{name}: {e} Left out of this run.')
    if pl is None: return None
    if not rollpanels.is_rectangle(cut, g):
        raise rollpanels.LeaveOut(f'{name}: {g["w"]:g} x {g["h"]:g} mm is wider than the {roll} and not a plain rectangle - '
                                  'split it into panels in the design program, then nest it. Left out of this run.')
    pl['default_overlap'] = given is None
    bleed = max(float(d.get('bleed') or 0), 0.0)
    try:
        out = rollpanels.split(name, ARTWORKS[art], cut, g, pl, bleed, register_artwork, ARTWORKS.get)
    except ValueError as e:
        raise rollpanels.LeaveOut(f'{e} Left out of this run.')
    notes.append(rollpanels.note(name, g['w'], g['h'], pl))
    return out


def _sheet_panels(prod, rules, d, name, art, cut, g, rotate, notes):
    """A printed sheet piece bigger than every sheet -> [(panel label, artwork key, cut)] split at its colour edges, or None
    when it fits as it is (or the product is not printed).  Raises ValueError with the reason when it fits no sheet and
    PS Nest will not split it, so the run says why instead of the general "split it into panels first"."""
    if not prod.get('printer'): return None
    from .engine import _turn_ok
    rotate = rotate and _turn_ok(rules)
    sizes = sheetpanels.beds(rules)
    if sheetpanels.fits(g['w'], g['h'], sizes, rotate): return None
    step = rules.rot_step or 90.0
    if rotate and abs(step - 90.0) > 1e-9 and abs(step - 180.0) > 1e-9:
        # the shapes engine also tries the in-between angles (45 / 15 deg): a piece that fits whole at one of them
        # is nested whole, as before panels existed, never refused or split
        from types import SimpleNamespace
        from .shapenest import part_angles
        from .engine import FIT_TOL
        turns = part_angles(SimpleNamespace(rotate=True), step)
        if sheetpanels.fits_turned(g['outline'], sizes, turns, FIT_TOL): return None
    biggest = max(sizes, key=lambda s: s[0] * s[1])
    why = (f'{name}: {g["w"]:g} x {g["h"]:g} mm fits no usable sheet (largest {biggest[0]:g} x {biggest[1]:g} mm) and PS Nest '
           'could not split it at its colour edges')
    if not rollpanels.is_rectangle(cut, g):
        raise ValueError(f'{why}: the CutContour is not a plain rectangle. Split it into panels in the design program.')
    bleed = max(float(d.get('bleed') or 0), 0.0)
    try:
        pl = sheetpanels.plan(ARTWORKS[art]['bytes'], cut, sizes, rotate)
        out = sheetpanels.split(name, ARTWORKS[art], cut, pl, bleed, register_artwork, ARTWORKS.get)
    except sheetpanels.NoSplit as e:
        raise ValueError(f'{why}: {e}. Split it into panels in the design program.')
    notes.append(sheetpanels.note(name, g['w'], g['h'], pl))
    return out


def _left_out(part_name, w, h, qty, reason, identity):
    row = {'name': part_name, 'w': round(w, 1), 'h': round(h, 1), 'qty': qty, 'reason': reason}
    for k in ('order_ref', 'source_part_id', 'item_number'):
        if identity.get(k): row[k] = identity[k]
    return row


def run_nest(body):
    order_records = orders.validate(body, ARTWORKS)
    test_record = _creation_test_record(body, order_records)
    pid = body.get('product', 'acm')
    if not pid: raise ValueError('Choose the material first - the Material \u2192 cutter box at the top - then Nest.')
    prod = resolve_product(pid, body.get('custom_material'))
    machine = str(body.get('machine') or '').strip().lower()
    if machine:                 # the PC's bookmark (?machine=) travels with every nest request; the server is the gate
        if machine not in machine_ids(): raise ValueError(f'Unknown machine "{machine}". Bookmark ?machine=' + ', '.join(machine_ids()) + '.')
        refusal = getattr(_products, 'machine_material_refusal', None)   # owner-worded refusal (Gunner cuts vinyl only) comes first
        text = refusal(machine, prod) if refusal else None
        if text: raise ValueError(text)
        if is_printer(machine):        # a printer PC (Colorado) nests what it prints, on itself, for whichever cutter cuts it
            this = MACHINES[machine]['name']
            if not _products.on_machine(prod, machine):
                raise MachineMismatch(machine, prod.get('cutter'), f"This PC is the {this}, but {prod.get('material_name') or pid} is not "
                                      "printed on it. Choose a material listed for this PC, or open Show all machines.")
            if body.get('printer') not in (None, '', machine):
                raise MachineMismatch(machine, prod.get('cutter'), f"This PC is the {this}: the job prints here, not on the "
                                      f"{MACHINES.get(body.get('printer'), {}).get('name', body.get('printer'))}. Open Show all machines to print it there.")
            body = dict(body, printer=machine)
        elif prod.get('cutter') != machine:
            raise MachineMismatch(machine, prod.get('cutter'), f"This PC is the {MACHINES.get(machine, {}).get('name', machine)}, but "
                                  f"{prod.get('material_name') or pid} is cut on the {prod.get('cutter_name') or prod.get('cutter')}. "
                                  "Choose a material listed for this PC, or open Show all machines.")
    d = dict(prod['defaults']); d.update({k: float(v) for k, v in (body.get('rules') or {}).items() if v not in (None, '')})
    nums = {k: v for k, v in d.items() if isinstance(v, (int, float)) and not isinstance(v, bool)}
    bad = sorted(k for k, v in nums.items() if math.isnan(v) or math.isinf(v))
    if bad: raise ValueError('These rules are not numbers: ' + ', '.join(bad) + '. Use 0 or more (mm).')
    neg = sorted(k for k, v in nums.items() if v < 0)
    if neg: raise ValueError('These rules cannot be negative: ' + ', '.join(neg) + '. Use 0 or more (mm).')
    sheet = body.get('sheet') or prod['sheets'][0]
    sw, sh = float(sheet['w']), float(sheet['h'])
    if not math.isfinite(sw) or not math.isfinite(sh) or sw <= 0 or sh <= 0: raise ValueError('Sheet size must be positive.')
    roll_available_mm, roll_batch_mm = None, None
    if prod['roll']:
        roll_available_mm = sw
        roll_batch_mm, sw = roll_batches.nesting_limit(body, sw)
        body = dict(body, roll_batch_mm=roll_batch_mm)
    sh, roll_note = roll_nest_width(prod, sh)          # the Gunner: a 1600 mm roll fits, 1565 mm of it is cut
    complex_mode = body.get('mode') == 'complex'
    rot_step = float(body.get('rot_step') or (45 if complex_mode else 90))
    if rot_step <= 0 or rot_step > 180 or abs(360 / rot_step - round(360 / rot_step)) > 1e-6:
        raise ValueError('Rotation step must divide 360 (90, 45, 30, 15, 10 ...).')
    rot_step = rot_step if complex_mode else 90.0
    # turning policy (nest&cut style): none = parts stay as drawn, 90 = turned 0/90, 180 = upside down allowed but never
    # sideways (grain, top edge), free = any angle in 15 degree steps.  Absent -> the mode / step above decide.
    policy = str(body.get('policy') or '').strip().lower()
    if policy not in ('', 'none', '90', '180', 'free'): raise ValueError('Turning must be none, 90, 180 or free.')
    force_upright = policy == 'none'
    # nest guard: a reason for keeping a held layout is checked before any solving, so a refused reason costs no time
    turn_ack = guard.parse_ack(body.get('turn_lock'), 'turning')
    earlier_ack = guard.parse_ack(body.get('earlier_ack'), 'earlier')
    if policy == '180': rot_step = 180.0
    elif policy == 'free': rot_step = float(body.get('rot_step') or 15) if complex_mode else 15.0
    elif policy == '90': rot_step = 90.0
    # offcut shape: none / rect (one straight cut) / L (two cuts) / stairs; the tick box maps to rect
    offcut = str(body.get('offcut') or '').strip()
    if offcut:
        offcut = {'rectangle': 'rect', 'straight': 'rect', 'l': 'L', 'l-shaped': 'L', 'stair': 'stairs'}.get(offcut.lower(), offcut)
        if offcut not in ('none', 'rect', 'L', 'stairs'): raise ValueError('Offcut shape must be none, rect, L or stairs.')
        trim_offcut = offcut != 'none'
    else:
        offcut = 'auto'; trim_offcut = bool(d.get('trim_offcut'))
    # edge per side (mm); blank = the edge margin
    sides = body.get('edge_sides') or {}
    def side(k):
        v = sides.get(k) if isinstance(sides, dict) else None
        if v in (None, ''): return None
        try: v = float(v)
        except (TypeError, ValueError): raise ValueError('Edge per side must be numbers (mm).')
        if v < 0: raise ValueError('Edge per side cannot be negative.')
        return v
    edge_l, edge_r, edge_b, edge_t = side('l'), side('r'), side('b'), side('t')
    if prod['roll']:
        # Roll media uses exactly the nested job length.  Ignore stale saved settings and direct API overrides from
        # sheet jobs: ONYX owns the printable area, and there is no sheet edge, clamp/mark margin or reusable offcut.
        d['edge'] = d['clamp'] = d['min_offcut'] = 0.0
        d['trim_offcut'] = False
        edge_l = edge_r = edge_b = edge_t = 0.0
        offcut = 'none'; trim_offcut = False
    # remnant / extra stock sheets, used first in this order
    stock = []
    for i, s in enumerate(body.get('stock') or [], 1):
        try: w, h, q = float(s.get('w') or 0), float(s.get('h') or 0), int(s.get('qty') or 1)
        except (TypeError, ValueError, AttributeError): raise ValueError(f'Extra sheet {i}: width, height and quantity must be numbers.')
        if w <= 0 or h <= 0 or q <= 0: raise ValueError(f'Extra sheet {i}: width, height and quantity must be above zero.')
        stock.append((w, h, q))
    # locked parts: (part name, sheet index, x, y, angle) - the page sends them after a drag on the picture
    pins = []
    for i, p in enumerate(body.get('pins') or [], 1):
        try: pins.append((str(p['name']), int(p.get('sheet') or 0), float(p['x']), float(p['y']), float(p.get('angle') or 0)))
        except (KeyError, TypeError, ValueError): raise ValueError(f'Locked part {i}: needs a name, a sheet and x / y in mm.')
    try: time_budget = float(body.get('time') or os.environ.get('PSNEST_TIME_BUDGET') or 45.0)
    except (TypeError, ValueError): raise ValueError('Nesting time must be a number of seconds.')
    time_budget = min(300.0, max(3.0, time_budget))
    gap_note = None
    if order_records:
        # Printed panel references sit in the waste between neighbouring bleeds: widen a gap that is too narrow for them.
        overhang = float(d['bleed'] or 0)
        for p in body.get('parts') or []:
            cut = (ARTWORKS.get(p.get('artwork')) or {}).get('cut')
            if cut and cut.get('found'): overhang = max(overhang, outputs.contour_overhang(cut))
        need = order_labels.min_gap(overhang)
        if d['gap'] < need <= max(d['gap'], 25.0):
            gap_note = (f"Gap raised from {d['gap']:g} to {need:g} mm so each panel reference fits in the waste beside its own "
                        f"panel ({round(overhang, 1):g} mm bleed each side).")
            d['gap'] = need
    rules = Rules(sw, sh, edge=d['edge'], gap=d['gap'], clamp=d['clamp'], min_offcut=d['min_offcut'], rot_step=rot_step, roll=prod['roll'],
                  trim_offcut=trim_offcut, edge_l=edge_l, edge_r=edge_r, edge_b=edge_b, edge_t=edge_t, offcut=offcut,
                  pins=tuple(pins), stock=tuple(stock))
    if rules.usable_w <= 0 or rules.usable_h <= 0: raise ValueError('The edges leave no room on the sheet: reduce the edge margins.')
    warnings, notes = [], []
    if roll_note: notes.append(roll_note)
    if gap_note: notes.append(gap_note)
    if force_upright: notes.append('Turning: none. Every part is placed as drawn, even where a turn would save material.')
    elif policy == '180': notes.append('Turning: 180 degrees only. Parts may go upside down but never sideways.')
    if stock: notes.append('Extra sheets first: ' + ', '.join(f'{q} x {w:g} x {h:g} mm' for w, h, q in stock) + f', then {sw:g} x {sh:g} mm sheets as needed.')
    tool = prod['tool']['kind']                     # bit (router), kerf (lasers) or knife
    if d['gap'] < d['bit_diameter']:
        what = 'bit' if tool == 'bit' else 'kerf'
        warnings.append(f"Gap {d['gap']:g} mm is smaller than the {what} ({d['bit_diameter']:g} mm): neighbouring parts would share a cut. Set the gap to at least the {what} unless you intend a shared line.")
    if tool == 'bit' and 0 < d['corner_radius'] < d['bit_diameter'] / 2:
        warnings.append(f"Corner radius {d['corner_radius']:g} mm is smaller than half the bit; the router cannot cut it.")
    try: thickness = float(body['thickness']) if body.get('thickness') not in (None, '') else None
    except (TypeError, ValueError): raise ValueError('Thickness must be a number (mm).')
    if thickness is not None and (not math.isfinite(thickness) or thickness <= 0): raise ValueError('Thickness must be above zero.')
    printer = (body.get('printer') or prod['printer']) if prod['printer'] else None
    if printer and printer not in [x['id'] for x in prod['printers']]:
        raise ValueError(f'"{printer}" is not a printer for {prod["material_name"]}: choose one of ' + ', '.join(x['name'] for x in prod['printers']) + '.')
    warnings += machine_warnings(prod, sw, sh, thickness=thickness, gap=d['gap'], printer=printer, metal=body.get('metal'))
    blocks = machine_blocks(prod, thickness=thickness, printer=printer, metal=body.get('metal'), machine=body.get('machine'))
    if blocks: raise ValueError(' '.join(blocks))
    cut_process, cp_note = cut_process_for(prod, body.get('cut_process'), body.get('machine'))
    if cp_note: notes.append(cp_note)
    reg_note = registration_note(prod)                  # the Gunner: its CorelDRAW plugin adds the dots, PS Nest draws none
    if reg_note: notes.append(reg_note)
    corner_marks, cm_note = corner_marks_for(prod, body.get('corner_marks'))   # the Gunner's plugin makes the marks: PS Nest draws none
    if cm_note: notes.append(cm_note)
    # On a roll there is no edge margin (Danilo + owner, 20-Oct-2026); the Gunner's plugin dots are checked on the width the
    # job really uses, after nesting (roll_dots_warning), not on the edge.
    edge_w = None if prod['roll'] else plugin_edge_warning(prod, {'l': rules.ml - d['clamp'], 'r': rules.mr - d['clamp'], 'b': rules.mb - d['clamp'], 't': rules.mt - d['clamp']})
    if edge_w: warnings.append(edge_w)
    if prod['printer'] and d['gap'] < 2 * d['bleed'] - 1e-9:
        notes.append(f"Gap {d['gap']:g} mm is less than twice the {d['bleed']:g} mm bleed: the print PDF trims each part's bleed to {d['gap'] / 2:g} mm so neighbours cannot overprint.")
    mirror = bool(body.get('mirror', prod['mirror']))
    cut_line = body.get('cut_line') or 'cutcontour'
    if cut_line not in ('cutcontour', 'black'): raise ValueError('Cut PDF lines must be "cutcontour" or "black".')
    if d['edge'] == 0 and not prod['roll']:      # a roll has no edge margin by design: ONYX sets the printable area
        warnings.append('Edge is 0 mm: parts use the raw sheet edge as a finished edge. Only do this if the sheet is square to the datum and the edge is clean.')
    plist, left_out = [], []
    for i, p in enumerate(body.get('parts') or [], 1):
        spec = p.get('shape') or None
        stype = (spec or {}).get('type', 'rect')
        try:
            w, h, qty = float(p.get('w') or 0), float(p.get('h') or 0), int(p.get('qty', 1))
        except (ValueError, TypeError):
            raise ValueError(f'Part row {i}: width, height and quantity must be numbers.')
        if qty <= 0: raise ValueError(f'Part row {i}: quantity must be above zero.')
        if stype in ('rect', 'ellipse', 'triangle', 'right_triangle', 'rhombus') and (w <= 0 or h <= 0) and not ((ARTWORKS.get(p.get('artwork')) or {}).get('cut') or {}).get('found'):
            raise ValueError(f'Part row {i}: width and height must be above zero.')
        if stype in ('circle', 'polygon', 'star') and w <= 0: raise ValueError(f'Part row {i}: size must be above zero.')
        name = (p.get('name') or f'Part {i}').strip()
        identity = {}
        if order_records:
            order = next(o for o in order_records if o['ref'] == p['order_ref'])
            identity = {'order_ref': p['order_ref'], 'source_part_id': p['source_part_id'],
                        'item_number': p.get('item_number') or '', 'site_ref': p.get('site_ref') or order.get('site_ref') or '',
                        'state': order.get('state') or '', 'artwork_version': p.get('artwork_version') or ''}
            if (order.get('source_binding') or {}).get('schema') == 'portal-nest-preparation-2':
                identity['piece_id_base'] = p.get('piece_id_base') or ''
        if identity: name = f"{p['order_ref']} / {p['source_part_id']} / {name}"
        rotate, art = bool(p.get('rotate', True)) and not force_upright, p.get('artwork') or None
        cut = (ARTWORKS.get(art) or {}).get('cut') or {} if art else {}
        if stype == 'contour' and not cut.get('found'):
            raise ValueError(f'Part row {i} ({name}): shape is CutContour but ' + ('no artwork is attached.' if not art or art not in ARTWORKS else 'the artwork has no CutContour line.'))
        art_back = _back_art(i, name, art, p.get('artwork_back') or None, cut, prod['roll'], mirror,
                             carried=stype in ('rect', 'outline', 'contour') or bool(cut.get('found')))
        if cut.get('found'):
            # print & cut: the part is exactly the artwork's CutContour line; typed sizes and shapes do not apply
            if cut.get('error'):
                fix = fix_for(cut['error'])
                raise ValueError(f'Part row {i} ({name}): artwork "{ARTWORKS[art]["name"]}": {cut["error"]}' + (' ' + fix if fix else ''))
            g = pdfcut.geometry(cut)
            tl = shapes._tuple_loops
            try:
                panels = (_roll_panels if prod['roll'] else _sheet_panels)(prod, rules, d, name, art, cut, g, rotate, notes)
            except rollpanels.LeaveOut as e:
                left_out.append(_left_out(name, g['w'], g['h'], qty, str(e), identity)); notes.append(str(e)); continue
            if panels:
                if art_back: raise ValueError(f'Part row {i} ({name}): this piece is split over several sheets, and a split piece cannot carry a back print yet. Print the back as its own job.')
                for label, key, pc in panels:
                    pg = pdfcut.geometry(pc)
                    pident = dict(identity)
                    if pident.get('order_ref'):
                        k = label.split()[1]
                        pident['piece_id_base'] = (pident.get('piece_id_base') or f"{pident['order_ref']}:{pident.get('item_number') or pident['source_part_id']}") + f'-P{k}'
                    plist.append((Part(f'{name} {label}', pg['w'], pg['h'], rotate=rotate, artwork=key, outline=tl([pg['outline']])[0],
                                       holes=tl(pg['holes']), islands=tl(pg['islands']), shape={'type': 'contour'}, panel=label, **pident), qty))
                continue
            plist.append((Part(name, g['w'], g['h'], rotate=rotate, artwork=art, outline=tl([g['outline']])[0], holes=tl(g['holes']),
                               islands=tl(g['islands']), shape={'type': 'contour'}, artwork_back=art_back, **identity), qty))
            continue
        if stype == 'rect':
            plist.append((Part(name, w, h, rotate=rotate, artwork=art, artwork_back=art_back, **identity), qty)); continue
        try: geoms = shapes.build(spec, w, h, OUTLINES)
        except ValueError as e: raise ValueError(f'Part row {i} ({name}): {e}')
        if order_records and (len(geoms) != 1 or geoms[0].get('count', 1) != 1):
            raise ValueError(f'{name}: one source row must describe one intact printed part for order traceability.')
        for g in geoms:
            label = f"{name} {g['label']}" if g.get('label') else name
            plist.append((Part(label, g['w'], g['h'], rotate=rotate, artwork=art if stype == 'outline' else None,
                               artwork_back=art_back if stype == 'outline' else None,
                               outline=g['outline'], holes=g['holes'], islands=g['islands'], shape=dict(spec), **identity), qty * g.get('count', 1)))
    if prod['roll']:            # a typed part wider than the roll has no artwork to split: leave it out, nest the rest
        from .engine import _turn_ok
        keep = []
        for part, qty in plist:
            if rollpanels.fits(part.w, part.h, rules.usable_w, rules.usable_h, part.rotate and _turn_ok(rules)):
                keep.append((part, qty)); continue
            why = (f'{part.name}: {part.w:g} x {part.h:g} mm does not fit across the {rules.usable_h:g} mm roll and has no print & cut '
                   f'artwork PS Nest could split.{ROLL_NO_FIT} Left out of this run.')
            ident = {k: getattr(part, k, '') for k in ('order_ref', 'source_part_id', 'item_number')}
            left_out.append(_left_out(part.name, part.w, part.h, qty, why, ident)); notes.append(why)
        plist = keep
    if not plist and left_out:
        raise ValueError('Nothing left to nest: ' + ' '.join(r['reason'] for r in left_out))
    if not plist: raise ValueError('Add at least one part.')
    seen_names = {}
    for part, _ in plist: seen_names[part.name] = seen_names.get(part.name, 0) + 1
    dup = sorted(n for n, c in seen_names.items() if c > 1)
    if dup: warnings.append('Rows share the same name (' + ', '.join(dup) + '): each row still nests as its own part, but labels, '
                            'locks and the parts list cannot tell them apart. Give each row its own name.')
    if mirror:                                       # reverse print on clear material: every part as seen from the back
        plist = [(_mirrored(part), qty) for part, qty in plist]
        notes.append('Reverse print: every part is mirrored, artwork and cut line together, in the print PDF, the cut PDF and the DXF. Print on the back of the clear sheet and cut with the same face up.')
    for part, _ in plist:
        cut = (ARTWORKS.get(part.artwork) or {}).get('cut') if (part.shape or {}).get('type') == 'contour' else None
        over = outputs.contour_overhang(cut) if cut else 0.0
        if over > d['gap'] / 2 + 0.05:
            msg = (f'{part.name}: the artwork carries {over:.1f} mm of bleed past its CutContour line. The print PDF trims it to '
                   f'{d["gap"] / 2:g} mm (half the {d["gap"]:g} mm gap) so it cannot print onto a neighbouring part.')
            if msg not in notes: notes.append(msg)
    if any(part.artwork_back for part, _ in plist): notes.append(BACK_NOTE)
    parts = expand(plist)
    run_id = str(body.get('run_id') or '')[:40]
    run = (RUNS.pop(run_id, None) if run_id else None) or _new_run()
    if run_id: RUNS[run_id] = run          # a Stop that arrived before this line is already counted on the popped entry

    def progress(**fields):
        run['progress'].update(fields)
        if PROGRESS_HOOK: PROGRESS_HOOK(**fields)
    t0 = time.time()
    planning = body.get('production_plan')
    def solve(parts=parts, rules=rules):
        if planning is None:
            return nest(parts, rules, time_budget=time_budget, should_stop=lambda: run['stops'], progress=progress)
        from .production_planning import ProductionJob, plan_production
        if not isinstance(planning, dict) or planning.get('mode') != 'state_sequence':
            raise ValueError('Choose the supported state / job sequence production plan.')
        sequences = [o.get('sequence') for o in order_records]
        if any(isinstance(n, bool) or not isinstance(n, int) or n < 1 for n in sequences) or len(set(sequences)) != len(sequences):
            raise ValueError('Give every order its own positive production sequence, as scheduled by Danilo.')
        ordered = sorted(order_records, key=lambda o: o['sequence'])
        jobs = [ProductionJob(o['ref'], o.get('state', ''), 'current-setup',
                              tuple(p for p in parts if p.order_ref == o['ref'])) for o in ordered]
        plan = plan_production(jobs, {'current-setup': rules}, time_budget=time_budget,
                               should_stop=lambda: run['stops'], progress=progress,
                               tiny_parts_exception=planning.get('tiny_parts_exception', False))
        meta = {'mode': 'state_sequence', 'max_states_per_sheet': 2,
                'ordered_jobs': [ref for group in plan.compatibility_plans for ref in group.ordered_job_refs],
                'sheets': [{'job_refs': list(s.job_refs), 'states': list(s.states)}
                           for group in plan.compatibility_plans for s in group.sheets]}
        return list(plan.sheets), {'strategy': 'State / adjacent job sequence', 'production_plan': meta,
                                  'engine': 'shapes' if any(p.shaped for p in parts) else 'rect',
                                  'stopped': bool(run['stops'])}
    if pins:
        known = {p.name for p in parts} | {p.name.split(' #')[0] for p in parts}
        lost = [pn[0] for pn in pins if pn[0] not in known]
        if lost: warnings.append('Locked parts not in this list were ignored: ' + ', '.join(sorted(set(lost))) + '.')
    try:
        try:
            sheets, info = solve()
            problems = validate_shapes(sheets, parts, rules) if info.get('engine') == 'shapes' else validate(sheets, parts, rules)
        except Stopped: raise
        except Exception as e:
            if not pins or planning is not None: raise
            problems = [f'{type(e).__name__}: {e}']
        if problems and pins:       # a locked part that cannot sit where it was put: nest again free and say so
            warnings.append('The locked parts could not be kept where they were (' + '; '.join(problems)[:300] + '). This layout was nested without the locks.')
            rules = _replace(rules, pins=())
            sheets, info = nest(parts, rules, time_budget=time_budget, should_stop=lambda: run['stops'], progress=progress)
            problems = validate_shapes(sheets, parts, rules) if info.get('engine') == 'shapes' else validate(sheets, parts, rules)
        # nest guard: turning was switched off or held to half turns, so nest the same parts with it allowed and compare.
        # A comparison that cannot finish leaves the lock's cost unknown, and the machine files stay held (guard.py).
        turn_policy = '180' if abs(float(rules.rot_step or 90.0) - 180.0) < 1e-6 else policy     # half turns only, however it was asked
        locked_count, free_try = guard.turning_restricted(parts, turn_policy), None
        if locked_count and not problems:
            free_parts = [_replace(p, rotate=True) for p in parts]
            free_rules = _replace(rules, rot_step=90.0) if turn_policy == '180' else rules
            try:
                fs, fi = solve(free_parts, free_rules)
                bad = validate_shapes(fs, free_parts, free_rules) if fi.get('engine') == 'shapes' else validate(fs, free_parts, free_rules)
                if fi.get('stopped') or info.get('stopped'): free_try = ('failed', 'the search was stopped')
                elif bad: free_try = ('failed', 'its own check failed')
                else: free_try = ('ok', fs, free_rules, fi)
            except Stopped: free_try = ('failed', 'the search was stopped')
            except Exception as e: free_try = ('failed', f'{type(e).__name__}: {e}'[:160])
    except Stopped as e:
        raise ValueError(str(e))
    finally:
        if run_id: RUNS.pop(run_id, None)
    elapsed = time.time() - t0
    if info.get('stopped'):
        warnings.append(f"Stopped after {elapsed:.0f} s: this is the best of the {info.get('tried', 0)} layout"
                        f"{'s' if info.get('tried', 0) != 1 else ''} finished before Stop was pressed, not the full search.")
    if problems: raise RuntimeError('Internal check failed: ' + '; '.join(problems))
    if prod['roll']:
        warnings += roll_to_job_length(sheets, rules, prod, roll_available_mm)
    job_name = (body.get('job') or 'Untitled job').strip()
    settings = {'edge': d['edge'], 'gap': d['gap'], 'bleed': d['bleed'], 'clamp': d['clamp'], 'corner_radius': d['corner_radius'],
                'bit_diameter': d['bit_diameter'], 'min_offcut': d['min_offcut'], 'trim_offcut': bool(d.get('trim_offcut')), 'sheet_w': sw, 'sheet_h': sh, 'product': body.get('product', 'acm'),
                'mode': 'complex' if complex_mode else 'simple', 'rot_step': rules.rot_step, 'thickness': thickness, 'mirror': mirror, 'cut_line': cut_line,
                'custom_material': body.get('custom_material') if pid == 'custom' else None,
                'material': prod['material_name'], 'cutter': prod['cutter_name'], 'printer': MACHINES[printer]['name'] if printer else None, 'roll': prod['roll'],
                'policy': policy or ('free' if complex_mode else '90'), 'offcut': rules.offcut_shape, 'time': time_budget,
                'edge_sides': {'l': rules.ml - d['clamp'], 'r': rules.mr - d['clamp'], 'b': rules.mb - d['clamp'], 't': rules.mt - d['clamp']},
                'stock': [{'w': w, 'h': h, 'qty': q} for w, h, q in stock], 'pins': len(rules.pins), 'cut_process': cut_process}
    if prod['roll']:
        settings.update(roll_available_mm=roll_available_mm, roll_batch_mm=roll_batch_mm)
        notes.append(f'Whole pieces nested into batches at most {roll_batch_mm / 1000:g} m; '
                     f'Roll left is {roll_available_mm / 1000:g} m. Confirm ONYX registration space before production.')
    customcuts.apply(sheets, rules, body.get('custom_cuts') or {}, d['bit_diameter'], d['corner_radius'])
    planned_labels = order_labels.plan_labels(
        sheets, rules, label_bleed(parts, rules, d['bleed']), ccd_dots=_label_ccd_dots(prod)) if order_records else None
    rep = outputs.report(sheets, rules, info, job_name, settings)
    job_guard = _nest_guard(rep, parts, rules, prod, settings, job_name, turn_policy, locked_count, free_try, info,
                            turn_ack, earlier_ack, comparable=planning is None and test_record is None)
    if test_record is not None:
        rep['production_release'] = False
    if order_records:
        rep['orders'] = order_records
        if planning is not None: rep['production_plan'] = info['production_plan']
        rep['order_labels'] = planned_labels
        rep['production_release'] = False
        rep['packing_instruction'] = 'Read the small project reference beside each panel while it is still in its sheet position. Lift it straight into the correct project pile, then check the counts before bundling.'
        notes.append(rep['packing_instruction'])
    rep['seconds'] = round(elapsed, 2); rep['warnings'] = warnings; rep['notes'] = notes; rep['checks_passed'] = True
    rep['parts_total'] = len(parts)
    rep['unplaced'] = left_out          # pieces left out of this run with the reason; each one's note is in rep['notes']
    # Physical roll consumption is the sum of exported batch pages, including upward trim rounding.
    rep['media_used_mm'] = round(sum(e['sheet_mm'][0] if prod['roll'] else e['used_length_mm']
                                   for e in rep['sheets']), 1)
    if prod['roll']:                    # a machine's per-file limit is not a limit on the sum of separate batches
        for index, row in enumerate(rep['sheets'], 1):
            cap_w = length_cap_warning(prod, row['used_length_mm'], f'Roll batch {index}')
            if cap_w: warnings.append(cap_w)
    rep['process'] = {'id': pid, 'name': prod['name'], 'roll': prod['roll'], 'output': prod['output'], 'mirror': mirror}
    rep['mode'] = settings['mode']; rep['rot_step'] = rules.rot_step; rep['stopped'] = bool(info.get('stopped'))
    rep['cut_process'] = cut_process
    jid = uuid.uuid4().hex[:10]
    request = {k: v for k, v in body.items() if k not in ('run_id', 'test_creation')}  # what Projects can re-open
    if test_record is not None: request['test_record'] = test_record
    if not order_records: request['cut_process'] = cut_process           # combined requests retain the exact confirmed setup
    # A roll gets no frame and no marks from PS Nest: ONYX adds the registration marks, dots and QR code (Danilo + owner, 20-Oct-2026).
    JOBS[jid] = {'sheets': sheets, 'rules': rules, 'parts': parts, 'info': info, 'settings': settings, 'job': job_name,
                 'print': {'outlines': bool(body.get('print_outlines')), 'corner_marks': corner_marks and not prod['roll'],
                           'frame': bool(body.get('sheet_frame', True)) and not prod['roll'], 'cut_line': cut_line}, 'report': rep,
                 'request': request, 'created': time.time(), 'guard': job_guard}
    rep['job_id'] = jid; rep['created'] = JOBS[jid]['created']
    rep['words'] = result_words(rep, prod)
    if left_out:
        k = sum(r['qty'] for r in left_out)
        rep['words'] += f" {k} piece{'s' if k != 1 else ''} left out: see the notes."
    rep['file_label'] = file_label(job_name)
    rep['print_blocked'] = print_reason(JOBS[jid]); rep['back_print'] = _has_back(JOBS[jid])
    rep['cut_blocked'] = cut_reason(JOBS[jid]); rep['cut_parts'] = sum(1 for p in parts if _is_contour(p))
    _apply_guard(rep, JOBS[jid])
    for check in ('turning', 'earlier'):
        kept = job_guard.get(check)
        if kept and kept.get('ack'): guard.log(_guard_path('nest-guard-log.jsonl'), jid, job_name, check, kept)
    save_job(jid, JOBS[jid])
    rep['svg'] = [outputs.write_svg(s, rules, d['corner_radius']) for s in sheets]
    result = dict(rep)
    if test_record is not None: result['test_record'] = copy.deepcopy(test_record)
    return result

def _guard_path(name):
    """Nest-guard files sit beside the jobs folder, never inside it (every .json in there is a job)."""
    return os.path.join(os.path.dirname(JOBS_DIR), name)


def _nest_guard(rep, parts, rules, prod, settings, job_name, policy, locked_count, free_try, info, turn_ack, earlier_ack,
                comparable=True):
    """The nest-guard record of a fresh nest (guard.py): what a turning lock costs and whether the same parts were
    nested better before.  `free_try` is the comparison nest run_nest made with turning allowed."""
    roll, keep = bool(prod['roll']), rules.min_offcut
    now = guard.metrics(rep, roll=roll, min_offcut=keep)
    g = {'fp': None, 'turning': None, 'earlier': None, 'quantity_note': ''}
    if locked_count:
        free, why = None, 'not run'
        if free_try and free_try[0] == 'ok':
            free = guard.metrics(outputs.report(free_try[1], free_try[2], free_try[3], job_name, settings), roll=roll, min_offcut=keep)
        elif free_try: why = free_try[1]
        g['turning'] = guard.turning_check(locked_count, len(parts), policy, now, free, why_unchecked=why, ack=turn_ack)
    if comparable and not rules.pins and not rules.stock and not info.get('stopped'):
        g['fp'] = guard.fingerprint(guard.material_key(settings), rules.sheet_w, rules.sheet_h, parts)
        gone = guard.read_excluded(_guard_path('nest-guard-excluded.json'))
        t = g['turning']
        g['earlier'] = guard.earlier_check(guard.earlier_jobs(JOBS_DIR, g['fp'], exclude=gone), now,
                                           guard.setup(settings, locked_count), ack=earlier_ack,
                                           turn_free=t['free'] if t and t['costly'] and t['checked'] else None)
        g['quantity_note'] = guard.quantity_note(guard.same_name_jobs(job_name, parts, exclude=gone), len(parts))
    return g


def _apply_guard(rep, job):
    """Put the nest-guard record on a report: the hold sentence first, kept locks and their cost in the notes."""
    g = job.get('guard')
    rep['guard'] = guard.public(g)
    hold = rep['guard']['hold']
    rep['hold'] = hold or None
    old = rep.get('guard_notes') or []
    rep['guard_notes'] = guard.notes(g)
    rep['notes'] = [n for n in rep.get('notes') or [] if n not in old] + rep['guard_notes']
    words = rep.get('words') or ''
    if words.startswith(guard.HELD_WORD): words = words.split(guard.HELD_END, 1)[-1]
    rep['words'] = (guard.HELD_WORD + hold + guard.HELD_END + words) if hold else words
    rep['checks_passed'] = not hold
    if hold: rep['print_blocked'] = rep.get('print_blocked') or hold; rep['cut_blocked'] = rep.get('cut_blocked') or hold


def acknowledge_hold(jid, body):
    """Record why a held layout is kept (POST /api/job/<id>/acknowledge).  The geometry does not change, so the job
    keeps its id; the reason, the name and what the lock costs stay on the job and in the nest-guard log."""
    job = load_job(jid)
    if not job: return None
    check = str((body or {}).get('check') or '').strip().lower()
    rec = (job.get('guard') or {}).get(check) if check in guard.REASONS else None
    if not rec or not rec.get('costly'): raise ValueError('Nothing is held on this job for that check.')
    rec['ack'] = guard.parse_ack(body, check)
    guard.log(_guard_path('nest-guard-log.jsonl'), jid, job['job'], check, rec)
    if check == 'earlier' and rec['ack']['reason'] == 'earlier-wrong':
        guard.add_excluded(_guard_path('nest-guard-excluded.json'), rec['job_id'])
    _apply_guard(job['report'], job)
    save_job(jid, job)
    return job_result(jid, job)


def job_result(jid, job):
    rep = dict(job['report'])
    rep.update(outputs.report(job['sheets'],job['rules'],job['info'],job['job'],job['settings']))
    rep['words'] = result_words(rep,rep.get('process') or {})
    rep['job_id'] = jid
    rep['print_blocked'] = print_reason(job); rep['back_print'] = _has_back(job)
    rep['cut_blocked'] = cut_reason(job)
    _apply_guard(rep, job)
    rep['svg'] = [outputs.write_svg(s,job['rules'],job['settings'].get('corner_radius',0)) for s in job['sheets']]
    marker = (job.get('request') or {}).get('test_record')
    if isinstance(marker, dict): rep['test_record'] = copy.deepcopy(marker)
    return rep


def _safe(name):
    return re.sub(r'[^A-Za-z0-9._-]+', '-', name).strip('-') or 'job'

def _mm_label(v):
    return str(int(round(v))) if abs(v - round(v)) < 0.05 else ('%.1f' % v)

SHORT_MATERIAL = {'acm': 'ACM', 'acrylic': 'Acrylic', 'acrylic_clear': 'Clear acrylic', 'pvc': 'PVC', 'corflute': 'Corflute',
                  'cardboard': 'Cardboard', 'timber': 'Timber', 'metal': 'Metal', 'vinyl': 'Vinyl'}

def file_label(job_name):
    """The job's PL number when the name carries one (PL014508), else the name itself made safe for a file name."""
    m = re.search(r'\bPL\s?-?\s?(\d{5,6})\b', job_name or '', re.I)
    if m: return 'PL' + m.group(1)
    return re.sub(r'[\\/:*?"<>|]+', '-', (job_name or '').strip()).strip(' .-') or 'job'

def short_material(job):
    pid = (job.get('settings') or {}).get('product') or ''
    if pid == 'custom': return file_label(job['settings'].get('material') or 'Custom material')
    prod = PRODUCTS.get(pid) or {}
    return SHORT_MATERIAL.get(prod.get('material'), (prod.get('material_name') or 'material').split(' (')[0].split(',')[0])

def roll_to_job_length(sheets, rules, prod, available_mm=None):
    """Cut every roll page to the length its parts use (Danilo + owner, 20-Oct-2026: the file is exactly the job length,
    nothing extra, no offcut).  The length typed in (45 m by default) is the roll available, not the file.  Returns warnings."""
    out = []
    for s in sheets:
        rs = rules.for_sheet(s)
        if not s.placed: continue
        used = max(pl.x + pl.w for pl in s.placed) + rs.mr
        if used > rs.sheet_w + 1e-6:
            raise ValueError('A whole piece extends beyond the Maximum batch or available roll length. '
                             'Check the source dimensions and approved panel/seam plan; the page will not clip the artwork.')
        # Always round upwards; rounding the extent first can silently shorten a page.
        used = min(rs.sheet_w, math.ceil(used * 10 - 1e-8) / 10)
        s.size = (used, rs.sheet_h)
    shortage = roll_batches.supply_warning(sheets, rules.sheet_w if available_mm is None else available_mm)
    if shortage:
        out.append(shortage)
    reg = plugin_registration(prod) or {}
    need = reg.get('clear_per_side_mm'); rw = (MACHINES.get(prod.get('cutter')) or {}).get('roll_width')
    if need and rw:              # the Gunner: its plugin adds about 15 mm of dots each side, outside the artwork
        across = max((pl.y + pl.h for s in sheets for pl in s.placed), default=0.0)
        if across + 2 * need > rw + 1e-6:
            out.append(f"The job is {across:g} mm across the roll; the SignWorkPro dots add about {need:g} mm each side, "
                       f"{across + 2 * need:g} mm in all, more than the {rw:g} mm the {prod.get('cutter_name', 'cutter').split(' ')[0]} cuts. "
                       "Use a wider roll or a narrower layout, or check the dots in CorelDRAW before cutting.")
    return out

def result_words(rep, prod):
    """The result as one plain sentence for the team and for WhatsApp: sheets, parts, material used, what comes back to the rack."""
    n = rep['sheet_count']; roll = prod.get('roll')
    sheets = rep['sheets']
    if roll:                # the length used and nothing more (Danilo + owner, 20-Oct-2026)
        head = f"{rep['parts_total']} parts on {(rep['media_used_mm'] / 1000):.2f} m of {rep['sheet_mm'][1]:g} mm roll"
        return head + (f", in {n} lengths." if n > 1 else '.')
    else:
        sizes = {}
        for s in sheets: sizes[tuple(s['sheet_mm'])] = sizes.get(tuple(s['sheet_mm']), 0) + 1
        what = ', '.join(f'{c} x {w:g} x {h:g} mm' for (w, h), c in sizes.items())
        head = f"{rep['parts_total']} parts on {n} sheet{'s' if n != 1 else ''} ({what})"
    words = head + f", {rep['utilisation'] * 100:.0f}% of the material used."
    last = sheets[-1] if sheets else None
    if last and not roll:
        oc = last.get('offcut') or {}
        words += ' Last sheet: ' + (oc.get('words') or 'no offcut worth keeping') + '.'
    return words

def roll_file_name(job, kind):
    """'HARRY - Vinyl - print and cut 12840x1370.pdf': a roll job's file, named with the length it uses by the roll width."""
    rules, sheets = job['rules'], job['sheets']
    rs = rules.for_sheet(sheets[0]) if len(sheets) == 1 else rules
    size = f'{_mm_label(rs.sheet_w)}x{_mm_label(rs.sheet_h)}' if len(sheets) == 1 else f'{len(sheets)} lengths x{_mm_label(rs.sheet_h)}'
    return f'{file_label(job["job"])} - {short_material(job)} - {kind} {size}.pdf'

def per_sheet_files(job, kind, pdf, label=None, material=None):
    """Split a multi-page print or cut PDF into one single-page PDF per sheet, named the way the operator files them
    (Marcio, 18-Sep-2026): 'PL014508 - ACM - sheet 1 of 3 - cut 2440x1220.pdf'.  The number pairs print with cut,
    the size is the sheet (or roll pass) the page was nested on, so the printer sees the final size."""
    import io
    from pypdf import PdfReader, PdfWriter
    rules, sheets = job['rules'], job['sheets']
    label, mat = label or file_label(job['job']), material or short_material(job)
    files = {}
    reader = PdfReader(io.BytesIO(pdf)); pages = reader.pages
    if len(pages) != len(sheets):
        raise ValueError('The machine PDF page count does not match the physical sheet count.')
    for i, page in enumerate(pages, 1):
        rs = rules.for_sheet(sheets[i - 1]) if i <= len(sheets) else rules
        size = f'{_mm_label(rs.sheet_w)}x{_mm_label(rs.sheet_h)}'
        w = PdfWriter(); w.pdf_header = reader.pdf_header; w.add_page(page); buf = io.BytesIO(); w.write(buf)
        files[f'{label} - {mat} - sheet {i} of {len(pages)} - {kind} {size}.pdf'] = buf.getvalue()
    return files

def print_reason(job):
    """Why the 1:1 print PDF would be blank, or None when there is something to print.
    A print file with nothing on it looked like a broken download (16-Sep-2026), so it is never produced."""
    held = production_roll_hold(job) or guard.hold_reason(job.get('guard'))
    if held: return held
    gone = sorted({p.name.split(' #')[0] for p in job['parts'] if p.artwork and p.artwork not in ARTWORKS})
    if gone: return ('The artwork of these parts was removed from PS Nest, so their print image is gone: ' + ', '.join(gone) +
                     '. Upload it again and nest again.')
    if job['print']['outlines'] or job['print']['corner_marks']: return None
    if any(p.artwork and p.artwork in ARTWORKS for p in job['parts']): return None
    return ('Nothing to print: no part has artwork attached and cut outlines / corner marks are off, '
            'so the 1:1 print PDF would be blank pages. Attach artwork or tick an option under Print PDF, then nest again.')

def _is_contour(part): return (part.shape or {}).get('type') == 'contour'

def _mirrored(part):
    """The part as seen from the back (x -> w - x).  The flag travels in `shape`, so the writers mirror the artwork and
    the replayed cut line the same way and a stored job keeps it."""
    from . import geom
    from dataclasses import replace
    tl = shapes._tuple_loops
    shape = dict(part.shape or {'type': 'rect'}); shape['mirror'] = True
    if part.outline is None: return replace(part, shape=shape)
    return replace(part, shape=shape, outline=tl([geom.mirror_x(part.outline, part.w)])[0],
                   holes=tl([geom.mirror_x(h, part.w) for h in part.holes]), islands=tl([geom.mirror_x(o, part.w) for o in part.islands]))

BACK_NOTE = ('Double-sided: PS Nest writes the FRONT and the BACK print file from this one nest, so the parts may turn like on '
             'any other job. Print the FRONT, turn the sheet over left-to-right like a page (the edge nearest you stays nearest '
             'you), put it against the same stops and print the BACK. Cut once, front face up, with the normal cut file. '
             'The BACK file is right for a sheet of exactly the size nested: a wider or narrower sheet shifts the back print '
             'by the difference.')

def _has_back(job): return any(p.artwork_back for p in job['parts'])

def _face_loops(g, mirror=False):
    """Cut geometry (pdfcut.geometry) -> plain polygons of every loop, optionally as seen from the back."""
    from . import geom
    out = []
    for lp in [g['outline']] + list(g['holes']) + list(g['islands']):
        pts = [(v[0], v[1]) for v in geom.flatten(list(lp), 0.05)]
        if len(pts) > 200: pts = [(v[0], v[1]) for v in geom.simplify(pts, 0.1)]
        out.append([(g['w'] - x, y) if mirror else (x, y) for x, y in pts])
    return out

def _apart(a, b, tol):
    """True when some point on the lines of a lies more than tol mm from every line of b."""
    import math
    segs = [(lp[i], lp[(i + 1) % len(lp)]) for lp in b for i in range(len(lp))]
    edges = [(lp[i], lp[(i + 1) % len(lp)]) for lp in a for i in range(len(lp))]
    step = max(2.0, sum(math.hypot(q[0] - p[0], q[1] - p[1]) for p, q in edges) / 400.0)
    t2 = tol * tol
    for (x0, y0), (x1, y1) in edges:
        k = max(1, int(math.hypot(x1 - x0, y1 - y0) / step))
        for j in range(k):
            x, y = x0 + (x1 - x0) * j / k, y0 + (y1 - y0) * j / k
            for (ax, ay), (bx, by) in segs:
                dx, dy = bx - ax, by - ay; ll = dx * dx + dy * dy
                u = 0.0 if ll == 0 else max(0.0, min(1.0, ((x - ax) * dx + (y - ay) * dy) / ll))
                ex, ey = ax + u * dx - x, ay + u * dy - y
                if ex * ex + ey * ey <= t2: break
            else: return True
    return False

def _same_shape(a, b, tol=1.0): return not _apart(a, b, tol) and not _apart(b, a, tol)

def _back_art(i, name, art, back, front_cut, roll, mirror, carried=True):
    """A row's back artwork (double-sided print) -> its key, or None when the row has none.  Everything that would put
    the back print in the wrong place is refused here, in words the designer can act on: the two faces must be the
    same size, and a cut shape on the back must be the front shape seen from the back."""
    if not back: return None
    row = f'Part row {i} ({name})'
    if back not in ARTWORKS: raise ValueError(f'{row}: the back artwork is not in PS Nest any more. Attach it again.')
    if not art or art not in ARTWORKS: raise ValueError(f'{row}: a back artwork needs a front artwork on the same row.')
    if not carried:
        raise ValueError(f'{row}: a typed shape does not carry artwork, so it cannot carry a back print. Use a rectangle, an outline file, '
                         'or artwork with a CutContour line.')
    if roll: raise ValueError(f'{row}: a back print is for sheets on the flatbed. A roll job cannot carry one.')
    if mirror: raise ValueError(f'{row}: reverse print and a back print cannot be used together.')
    a, b = ARTWORKS[art], ARTWORKS[back]
    bc = b.get('cut') or {}
    if not front_cut.get('found'):
        if abs(a['w_mm'] - b['w_mm']) > 0.5 or abs(a['h_mm'] - b['h_mm']) > 0.5:
            raise ValueError(f'{row}: the front artwork is {a["w_mm"]:g} x {a["h_mm"]:g} mm but the back artwork "{b["name"]}" is '
                             f'{b["w_mm"]:g} x {b["h_mm"]:g} mm. Export both faces at the same page size.')
        return back
    if front_cut.get('error'): return back            # the front is refused a few lines on, with its own message
    if not bc.get('found'):
        raise ValueError(f'{row}: the front artwork has a CutContour line but the back artwork "{b["name"]}" has none. '
                         'Draw the back on the same shape as seen from the back, with its CutContour line, so PS Nest can line the two faces up.')
    if bc.get('error'): raise ValueError(f'{row}: back artwork "{b["name"]}": {bc["error"]}')
    front, rear = pdfcut.geometry(front_cut), pdfcut.geometry(bc)
    if abs(front['w'] - rear['w']) > 0.5 or abs(front['h'] - rear['h']) > 0.5:
        raise ValueError(f'{row}: the front cut shape is {front["w"]:.1f} x {front["h"]:.1f} mm but the cut shape on the back artwork '
                         f'"{b["name"]}" is {rear["w"]:.1f} x {rear["h"]:.1f} mm. Both faces must be the same size.')
    got = _face_loops(rear)
    if not _same_shape(_face_loops(front, mirror=True), got):
        if _same_shape(_face_loops(front), got):
            raise ValueError(f'{row}: the back artwork "{b["name"]}" has its cut shape the same way round as the front. Seen from the back '
                             'the shape is mirrored left-to-right. Redraw the back on the mirrored shape: the artwork stays readable, only the outline flips.')
        raise ValueError(f'{row}: the cut shape on the back artwork "{b["name"]}" is not the front shape seen from the back. Both faces must have the same outline.')
    return back

def _back_part(part):
    """The part as its back face shows it: the outline mirrored left-to-right, carrying the back artwork.  No mirror
    flag: the back artwork is already drawn the right way round for the back; only the shape is seen from behind."""
    from . import geom
    from dataclasses import replace
    tl = shapes._tuple_loops
    if part.outline is None: return replace(part, artwork=part.artwork_back)
    return replace(part, artwork=part.artwork_back, outline=tl([geom.mirror_x(part.outline, part.w)])[0],
                   holes=tl([geom.mirror_x(h, part.w) for h in part.holes]), islands=tl([geom.mirror_x(o, part.w) for o in part.islands]))

def back_sheets(job):
    """The same nest seen from the back: every sheet turned over left-to-right.  A piece whose box starts at x on the
    front starts at (sheet width - x - box width) on the back, and a turn to the left on the front is the same turn
    to the right on the back.  Only pieces with a back artwork are on these sheets."""
    from dataclasses import replace
    from .engine import Placed
    from . import geom
    rules, out, seen = job['rules'], [], {}
    for sheet in job['sheets']:
        sw = rules.for_sheet(sheet).sheet_w
        placed = []
        for pl in sheet.placed:
            if not pl.part.artwork_back: continue
            if id(pl.part) not in seen: seen[id(pl.part)] = _back_part(pl.part)
            x0, _, x1, _ = geom.bbox_loops([geom.rotate(o, pl.angle) if pl.angle else o for o in pl.part.shape_loops()])
            placed.append(Placed(seen[id(pl.part)], sw - (pl.x + (x1 - x0)), pl.y, pl.w, pl.h, pl.rotated, (-pl.angle) % 360.0))
        out.append(replace(sheet, placed=placed, custom_cuts=None))
    return out

def back_reason(job):
    """Why the BACK print file cannot be made, or None."""
    if not _has_back(job): return 'This job has no back artwork. Attach a back artwork to a part row, then nest again.'
    held = print_reason(job)
    if held: return held
    gone = sorted({p.name.split(' #')[0] for p in job['parts'] if p.artwork_back and p.artwork_back not in ARTWORKS})
    if gone: return ('The back artwork of these parts was removed from PS Nest, so their back print is gone: ' + ', '.join(gone) +
                     '. Attach it again and nest again.')
    return None

def _back_files(job, pdf):
    """Per-sheet BACK print files; a sheet with no double-sided piece gets no BACK file."""
    files = per_sheet_files(job, 'print BACK', pdf)
    keep = [bool(any(pl.part.artwork_back for pl in s.placed)) for s in job['sheets']]
    return {name: data for (name, data), k in zip(files.items(), keep) if k}

def cut_reason(job):
    """Why the CutContour cut PDF cannot be made, or None.  Cut lines only ever come from the artwork files,
    so every part must carry one: a part without it would silently not be cut."""
    held = production_roll_hold(job) or guard.hold_reason(job.get('guard'))
    if held: return held
    parts = job['parts']
    if not any(_is_contour(p) for p in parts): return 'No part has artwork with a CutContour line.'
    missing = sorted({p.name.split(' #')[0] for p in parts if not _is_contour(p)})
    if missing: return 'These parts have no CutContour line in their artwork, so the cutter would skip them: ' + ', '.join(missing) + '.'
    gone = sorted({p.name.split(' #')[0] for p in parts if p.artwork not in ARTWORKS})
    if gone: return 'The artwork of these parts was removed from PS Nest, so their cut line is gone: ' + ', '.join(gone) + '. Upload it again and nest again.'
    return None

def label_bleed(parts, rules, configured):
    """Conservatively protect actual printed contour overhang, which may exceed the configured bleed."""
    limit = max(0.0, rules.gap / 2)
    overhang = min(float(configured or 0), limit)
    for p in parts:
        cut = (ARTWORKS.get(p.artwork) or {}).get('cut')
        if cut and cut.get('found'):
            overhang = max(overhang, min(outputs.contour_overhang(cut), limit))
    return overhang


def _label_ccd_dots(product):
    """Active rigid-sheet camera dots that printed order references must avoid."""
    if not product or product.get('roll'):
        return None
    export = product.get('export') or {}
    profile = (CUTTERS.get(export.get('dxf')) or {}).get('export') or {}
    return profile.get('ccd_dots')


def _job_label_ccd_dots(job):
    settings = job.get('settings') or {}
    try:
        product = resolve_product(settings.get('product') or 'acm', settings.get('custom_material'))
    except ValueError:
        return None
    return _label_ccd_dots(product)


def check_approved_sources(job):
    """Require the source revision for both exports and saved layout edits."""
    import hashlib
    for record in job['report'].get('orders') or []:
        for source in record['sources']:
            art = ARTWORKS.get(source['artwork'])
            if not art or hashlib.sha256(art['bytes']).hexdigest() != source['artwork_sha256']:
                raise ValueError('An approved-order artwork is missing or changed. Recheck the source and nest again.')


def job_files(job, which):
    """Return (filename, bytes, content_type) for a download kind."""
    sheets, rules, st = job['sheets'], job['rules'], job['settings']
    combined = bool(job['report'].get('orders'))
    check_approved_sources(job)
    if which in guard.HELD_KINDS:           # nest guard: no machine file leaves while a costly lock is unexplained
        kept = guard.hold_reason(job.get('guard'))
        if kept: raise ValueError('Machine files held: ' + kept)
    if which in ('print', 'cut', 'corel-cut', 'print-files', 'cut-files', 'print-back', 'print-back-files', 'dxf', 'dxf-labels', 'all'):
        held = production_roll_hold(job)
        if held: raise ValueError('Machine export pending: ' + held)
    base = _safe(job['job']); r = st['corner_radius']
    if which in ('worksheet', 'production'):
        from .production_worksheet import batch_folder
        import io, zipfile
        package = production_package(job)
        folder = batch_folder(job)
        from .production_worksheet import WORKSHEET_RENDERER_VERSION
        suffix = f'-worksheet-v{WORKSHEET_RENDERER_VERSION}'
        if which == 'production': return folder + suffix + '.zip', package, 'application/zip'
        with zipfile.ZipFile(io.BytesIO(package)) as z:
            return folder + suffix + '.pdf', z.read(folder + '/production-worksheet.pdf'), 'application/pdf'
    if which == 'packing':
        if not combined: raise ValueError('The project sorting checklist requires an approved-order batch.')
        return f'{base}-sorting-checklist.pdf', outputs.write_packing_pdf(sheets, rules, job['job']), 'application/pdf'
    # The cutter's export profile (products.CUTTERS[<id>]['export']) shapes the files; a custom cutter has none and
    # gets the files exactly as before.  A job saved before profiles existed picks its profile up from its product id.
    try: prod = resolve_product(st.get('product') or 'acm', st.get('custom_material'))
    except ValueError: prod = {}
    export = prod.get('export') or {}
    profile = (CUTTERS.get(export.get('dxf')) or {}).get('export')
    planned_labels = order_labels.plan_labels(
        sheets, rules, label_bleed(job['parts'], rules, st['bleed']),
        ccd_dots=_label_ccd_dots(prod)) if combined else None
    kinds = export.get('kinds')
    front_kind = {'print-back': 'print', 'print-back-files': 'print-files'}.get(which, which)     # the back goes where the front goes
    if kinds is not None and front_kind not in kinds and which in ('dxf', 'dxf-labels', 'print', 'print-files', 'print-back', 'print-back-files', 'cut', 'cut-files', 'layout', 'report', 'all'):
        names = {'dxf-labels': 'labelled DXF', 'print': 'print PDF', 'print-files': 'print files', 'cut': 'cut PDF', 'cut-files': 'cut files',
                 'print-back': 'back print PDF', 'print-back-files': 'back print files'}
        raise ValueError(f"The {prod.get('cutter_name') or 'cutter'} does not use the {names.get(which, which)}: "
                         'it is not offered for this material. Use the DXF.')
    roll = bool(st.get('roll'))
    dots = None if roll else (profile or {}).get('ccd_dots')        # a roll: ONYX adds the marks (Danilo + owner, 20-Oct-2026)
    with_cut = roll and export.get('roll_files') == 'one'           # the Ameida: art and CutContour in ONE PDF
    corel = roll and export.get('dxf') == 'gunner' and export.get('roll_files') == 'two'
    if which == 'corel-cut':
        if not corel: raise ValueError('Corel cut EPS is offered for Gunner roll jobs only.')
        reason = cut_reason(job)
        if reason: raise ValueError(reason)
        cuts = {p.artwork: ARTWORKS[p.artwork]['cut'] for p in job['parts']}
        files = {}
        for i, sheet in enumerate(sheets, 1):
            rs = rules.for_sheet(sheet)
            name = (f'{file_label(job["job"])} - {short_material(job)} - Corel cut'
                    + (f' {i} of {len(sheets)}' if len(sheets) > 1 else '')
                    + f' {_mm_label(rs.sheet_w)}x{_mm_label(rs.sheet_h)}.eps')
            files[name] = outputs.write_cut_eps(sheet, rules, cuts, job['print'].get('cut_line', 'cutcontour'))
        if len(files) == 1:
            name, data = next(iter(files.items()))
            return name, data, 'application/postscript'
        return f'{base}-Corel-cut-files.zip', outputs.bundle(files), 'application/zip'
    if which == 'dxf':
        files = {f'{base}-sheet-{i}.dxf': outputs.write_dxf(s, rules, r, labels=False, profile=profile).encode() for i, s in enumerate(sheets, 1)}
        return f'{base}-dxf.zip', outputs.bundle(files), 'application/zip'
    if which == 'dxf-labels':
        files = {f'{base}-sheet-{i}-labelled.dxf': outputs.write_dxf(s, rules, r, labels=True, profile=profile).encode() for i, s in enumerate(sheets, 1)}
        return f'{base}-dxf-labelled.zip', outputs.bundle(files), 'application/zip'
    if which == 'print':
        reason = print_reason(job)
        if reason: raise ValueError(reason)
        used = {p.artwork for p in job['parts'] if p.artwork in ARTWORKS}
        arts = {k: print_artwork(k, rules.gap / 2) for k in used}
        cuts = {k: ARTWORKS[k]['cut'] for k in used if (ARTWORKS[k].get('cut') or {}).get('found')}
        pdf, warns = outputs.write_print_pdf(sheets, rules, arts, bleed=st['bleed'], outlines=job['print']['outlines'],
                                             corner_marks=job['print']['corner_marks'], corner_radius=r, cuts=cuts, frame=job['print'].get('frame', True), ccd_dots=dots,
                                             cut_line=job['print'].get('cut_line', 'cutcontour') if with_cut else None,
                                             order_labels=planned_labels)
        job['report']['print_warnings'] = warns
        if roll: return roll_file_name(job, 'print and cut' if with_cut else 'print'), pdf, 'application/pdf'
        return (f'{base}-print-FRONT-1to1.pdf' if _has_back(job) else f'{base}-print-1to1.pdf'), pdf, 'application/pdf'
    if which == 'print-back':
        # Double-sided: the same nest seen from the back.  No camera dots or corner marks: the sheet is cut once, front
        # face up, with the front's cut files, so nothing on the back may look like a registration mark.
        reason = back_reason(job)
        if reason: raise ValueError(reason)
        used = {p.artwork_back for p in job['parts'] if p.artwork_back}
        arts = {k: print_artwork(k, rules.gap / 2) for k in used}
        cuts = {k: ARTWORKS[k]['cut'] for k in used if (ARTWORKS[k].get('cut') or {}).get('found')}
        pdf, warns = outputs.write_print_pdf(back_sheets(job), rules, arts, bleed=st['bleed'], outlines=job['print']['outlines'],
                                             corner_radius=r, cuts=cuts, frame=job['print'].get('frame', True))
        job['report']['print_back_warnings'] = warns
        return f'{base}-print-BACK-1to1.pdf', pdf, 'application/pdf'
    if which == 'print-back-files':
        _, pdf, _ = job_files(job, 'print-back')
        return f'{base}-print-BACK-files.zip', outputs.bundle(_back_files(job, pdf)), 'application/zip'
    if which == 'cut':
        reason = cut_reason(job)
        if reason: raise ValueError(reason)
        cuts = {p.artwork: ARTWORKS[p.artwork]['cut'] for p in job['parts']}
        pdf = outputs.write_cut_pdf(sheets, rules, cuts, frame=job['print'].get('frame', True), style=job['print'].get('cut_line', 'cutcontour'), ccd_dots=dots)
        if roll: return roll_file_name(job, 'cut'), pdf, 'application/pdf'
        return f'{base}-cut-contour.pdf', pdf, 'application/pdf'
    if which in ('print-files', 'cut-files'):
        # One file per sheet / pass, named the way the design team hands files to the printer (Ingrid, 18-Sep-2026):
        # 1_print_2440x1220.pdf goes with 1_cut_2440x1220.pdf - the number pairs them, the size is the final sheet.
        kind = which.split('-')[0]
        _, pdf, _ = job_files(job, kind)
        face = 'print FRONT' if kind == 'print' and _has_back(job) else kind
        return f'{base}-{kind}-files.zip', outputs.bundle(per_sheet_files(job, face, pdf)), 'application/zip'
    if which == 'layout':
        return f'{base}-layout.pdf', outputs.write_layout_pdf(sheets, rules, job['job'], job['info'], r), 'application/pdf'
    if which == 'report':
        rep = {k: v for k, v in job['report'].items() if k != 'svg'}
        return f'{base}-report.json', json.dumps(rep, indent=2).encode(), 'application/json'
    if which == 'all':
        files = {}
        if combined:
            n, b, _ = job_files(job, 'packing'); files[n] = b
        for kind in ('dxf', 'print', 'cut', 'layout', 'report'):
            if kinds is not None and kind not in kinds: continue
            if kind == 'print' and print_reason(job): continue
            if kind == 'cut' and cut_reason(job): continue
            n, b, _ = job_files(job, kind)
            if kind == 'dxf':
                for i, s in enumerate(sheets, 1): files[f'{base}-sheet-{i}.dxf'] = outputs.write_dxf(s, rules, r, profile=profile).encode()
            elif kind in ('print', 'cut') and roll: files[n] = b                   # a roll: the one file per kind, as downloaded
            elif kind in ('print', 'cut'):
                files.update(per_sheet_files(job, 'print FRONT' if kind == 'print' and _has_back(job) else kind, b))
                if kind == 'print' and _has_back(job): files.update(_back_files(job, job_files(job, 'print-back')[1]))
            else: files[n] = b
        if corel and not cut_reason(job):
            n, b, ct = job_files(job, 'corel-cut')
            if ct == 'application/zip':
                import io, zipfile
                with zipfile.ZipFile(io.BytesIO(b)) as z:
                    files.update({name: z.read(name) for name in z.namelist()})
            else: files[n] = b
        return f'{base}-all.zip', outputs.bundle(files), 'application/zip'
    raise KeyError(which)


def production_package(job):
    """One immutable export per saved result and worksheet renderer.

    This is a local preparation artifact. Publishing its canonical folder to FA
    and linking portal orders remains the portal adapter's responsibility.
    """
    import hashlib, io, tempfile, zipfile
    from . import production_worksheet as worksheet
    if _has_back(job):                                  # never a package that silently leaves the back print out
        raise ValueError('Production package pending: this job has a back print, which the production package does not carry yet. '
                         'Download "Everything (zip)": it has the FRONT, BACK and cut files.')
    folder = worksheet.batch_folder(job)
    material = worksheet.material_folder(job)
    check_approved_sources(job)
    roll_hold = worksheet.production_roll_hold(job)
    if roll_hold:
        raise ValueError('Production package pending: ' + roll_hold)
    jid = job['report']['job_id']
    cache_path = worksheet.package_cache_path(job, JOBS_DIR)
    if os.path.exists(cache_path):
        with open(cache_path, 'rb') as cached:
            return worksheet.validate_cached_package(job, cached.read())
    files, entries = {}, []
    legacy_paths = [worksheet.package_cache_path(job, JOBS_DIR, version)
                    for version in worksheet.LEGACY_WORKSHEET_RENDERERS if version is not None]
    legacy_paths.append(os.path.join(JOBS_DIR, jid + '-production.zip'))
    legacy_path = next((path for path in legacy_paths if os.path.exists(path)), None)
    if legacy_path:
        # Upgrade only the human worksheet. Verify the historical source/layout
        # and machine-file hashes first, then retain its exact machine bytes.
        # Never remove, overwrite or silently repair a damaged legacy package.
        with open(legacy_path, 'rb') as cached:
            legacy = worksheet.validate_cached_package(job, cached.read(), allow_legacy_renderer=True)
        with zipfile.ZipFile(io.BytesIO(legacy)) as archive:
            old = json.loads(archive.read(folder + '/production-manifest.json'))
            entries = [entry for sheet in old['sheets'] for entry in sheet['files']]
            files = {entry['path']: archive.read(entry['path']) for entry in entries}
    label = f'NEST-{jid}-R1'
    reason = print_reason(job)
    if reason: raise ValueError('Production package pending: ' + reason)
    for kind in (() if entries else ('print', 'cut')):
        reason = cut_reason(job) if kind == 'cut' else None
        if reason:
            # A partial print-only package must not masquerade as print + cut.
            raise ValueError('Production package pending: ' + reason)
        pdf = job_files(job, kind)[1]
        split = per_sheet_files(job, kind.upper(), pdf, label=label, material=material)
        for i, (name, data) in enumerate(split.items(), 1):
            path = folder + '/' + material + '/' + worksheet.safe_component(name)
            if len(path.encode('utf-8')) > 240:
                raise ValueError('The production path is too long for workshop file handling. Shorten references without omitting orders.')
            files[path] = data
            entries.append({'name': name, 'path': path, 'sheet': i, 'operation': kind.upper(),
                            'sha256': hashlib.sha256(data).hexdigest(), 'print_passes': 1 if kind == 'print' else 0})
    data = worksheet.manifest(job, entries)
    files[folder + '/production-worksheet.pdf'] = worksheet.write_pdf(job, data)
    files[folder + '/production-manifest.json'] = json.dumps(data, indent=2, allow_nan=False).encode()
    package = outputs.bundle(files)
    # Publish atomically after every file has been produced. A concurrent retry
    # cannot replace the winning artifact or leave an incomplete zip visible.
    _ensure_dirs()
    fd, tmp = tempfile.mkstemp(prefix=jid + '-production-', suffix='.tmp', dir=JOBS_DIR)
    try:
        with os.fdopen(fd, 'wb') as f:
            f.write(package)
        try:
            os.link(tmp, cache_path)
        except FileExistsError:
            pass
    finally:
        os.unlink(tmp)
    with open(cache_path, 'rb') as f:
        return worksheet.validate_cached_package(job, f.read())

# ------------------------------------------------------------------ parts list from a spreadsheet
_COLS = {'name': ('name', 'part', 'item', 'description', 'title', 'file', 'filename', 'artwork'),
         'w': ('w', 'width', 'w mm', 'width mm', 'length', 'x'), 'h': ('h', 'height', 'h mm', 'height mm', 'y'),
         'qty': ('qty', 'quantity', 'q', 'count', 'pcs', 'pieces', 'no', 'number'), 'artwork': ('artwork', 'file', 'filename', 'pdf')}

def _sheet_rows(name, data):
    """CSV / XLSX / XLS-as-CSV -> list of rows (lists of strings)."""
    import io, csv
    if re.search(r'\.xlsx$', name or '', re.I):
        try: import openpyxl
        except ImportError: raise ValueError('Reading .xlsx needs the openpyxl package (pip install openpyxl). Save the list as CSV instead.')
        wb = openpyxl.load_workbook(io.BytesIO(data), read_only=True, data_only=True)
        ws = wb[wb.sheetnames[0]]
        return [['' if v is None else str(v) for v in row] for row in ws.iter_rows(values_only=True)]
    if re.search(r'\.xls$', name or '', re.I):
        raise ValueError('Old .xls files are not read. Save the list as .xlsx or CSV.')
    text = data.decode('utf-8-sig', errors='replace')
    dialect = csv.Sniffer().sniff(text[:2000], delimiters=',;\t') if text.strip() else csv.excel
    return [list(r) for r in csv.reader(io.StringIO(text), dialect)]

_UNIT_MM = {'mm': 1.0, 'cm': 10.0, 'm': 1000.0, 'in': 25.4, 'inch': 25.4, 'inches': 25.4, '"': 25.4, "''": 25.4}

def _size_mm(v):
    """A cell such as 1200, 1200mm, 120 cm, 1.2 m, 12in, 6" or 1,200 -> (mm, unit converted from or None).
    A comma between groups of three is a thousands separator (1,200); any other comma is a decimal point (1,5)."""
    s = re.sub(r'\s+', '', str(v or '')).lower()
    if not s: return None, None
    m = re.fullmatch(r"(-?[0-9][0-9.,]*)(mm|cm|m|in|inch|inches|\"|'')?", s)
    if not m: return None, None
    n, unit = m.group(1), m.group(2) or 'mm'
    n = n.replace(',', '') if re.fullmatch(r'-?\d{1,3}(,\d{3})+(\.\d+)?', n) else n.replace(',', '.')
    try: val = float(n)
    except ValueError: return None, None
    return val * _UNIT_MM[unit], (None if unit == 'mm' else unit)

def _qty(q):
    """Quantity cell -> whole number of 1 or more; blank -> 1; anything else -> None (the row is skipped)."""
    s = str(q or '').strip().replace(',', '.')
    if not s: return 1
    try: f = float(s)
    except ValueError: return None
    return int(round(f)) if abs(f - round(f)) < 1e-9 and f >= 1 else None

def parse_partslist(name, data):
    """Spreadsheet -> {'parts': [{'name','w','h','qty','artwork'}], 'notes': [...]}.  Header row is found by its words
    (name / width / height / qty / file); without one, the columns are name, W, H, qty.  Artwork file names are matched to
    the uploaded artworks (with or without .pdf, case does not matter)."""
    rows = [r for r in _sheet_rows(name, data) if any(str(c).strip() for c in r)]
    if not rows: raise ValueError(f'{name}: the file is empty.')
    notes = []; head = None
    for i, r in enumerate(rows[:5]):
        low = [str(c).strip().lower() for c in r]
        if sum(1 for c in low if any(c in v for v in _COLS.values())) >= 2: head = i; break
    if head is None:
        cols = {'name': 0, 'w': 1, 'h': 2, 'qty': 3}; body = rows
        notes.append('No header row found: the columns were read as name, W, H, quantity.')
    else:
        low = [str(c).strip().lower() for c in rows[head]]; cols = {}
        for key, names in _COLS.items():
            for j, c in enumerate(low):
                if c in names and key not in cols and (key != 'name' or c not in ('file', 'filename', 'artwork') or 'name' not in low):
                    cols[key] = j; break
        body = rows[head + 1:]
        if 'qty' not in cols: notes.append('No quantity column: every row is quantity 1.')
    by_name = {}
    for k, a in ARTWORKS.items():
        n = a['name'].lower(); by_name[n] = k; by_name[re.sub(r'\.pdf$', '', n)] = k
    out = []
    for i, r in enumerate(body, head + 2 if head is not None else 1):
        g = lambda key: str(r[cols[key]]).strip() if key in cols and cols[key] < len(r) else ''
        nm, w, h, q = g('name'), g('w'), g('h'), g('qty')
        art = g('artwork') or nm
        key = by_name.get(art.lower()) or by_name.get(re.sub(r'\.pdf$', '', art.lower()))
        (wv, wu), (hv, hu) = _size_mm(w), _size_mm(h)
        if not nm and wv is None and key is None: continue
        if wu or hu: notes.append(f'Row {i} ({nm or "no name"}): sizes given in {wu or hu} were converted to mm.')
        qv = _qty(q)
        if qv is None:
            notes.append(f'Row {i} ({nm or "no name"}): quantity "{q}" is not a whole number of 1 or more, row skipped.'); continue
        if key is None and (wv is None or hv is None):
            notes.append(f'Row {i} ({nm or "no name"}): no size and no matching artwork file, skipped.'); continue
        out.append({'name': nm or (ARTWORKS[key]['name'] if key else f'Part {i}'), 'w': wv, 'h': hv, 'qty': qv, 'artwork': key, 'rotate': True})
    if not out: raise ValueError(f'{name}: no usable rows (each row needs a name and W x H, or an artwork file name that was uploaded).')
    return {'parts': out, 'notes': notes, 'rows': len(out)}

# ------------------------------------------------------------------ NAS: the finished-art folder of a PL number
NAS_INDEX = os.path.expanduser('~/.cache/platinum-nas/index.tsv')
NAS_SETTINGS = nas_settings.NasSettings()

def _nas_creds():
    """Read at call time, never stored: NAS_TS_HOST (or NAS_HOST), NAS_USER, NAS_PASSWORD from the shop's .env.nas."""
    env = {k: os.environ.get(k) for k in ('NAS_TS_HOST', 'NAS_HOST', 'NAS_USER', 'NAS_PASSWORD')}
    p = os.path.expanduser('~/GitHub/platinum-shop/.env.nas')
    if os.path.exists(p):
        for line in open(p):
            line = line.strip()
            if '=' in line and not line.startswith('#'):
                k, v = line.split('=', 1); k = k.strip()
                if k in env and not env[k]: env[k] = v.strip().strip('"').strip("'")
    host = env['NAS_TS_HOST'] or env['NAS_HOST']
    if not (host and env['NAS_USER'] and env['NAS_PASSWORD']): return None
    return host.rstrip('/'), env['NAS_USER'], env['NAS_PASSWORD']

class _Nas:
    def __init__(self, host, user, pw):
        self.api = host + '/webapi/entry.cgi'; self.sid = None; self.user = user; self.pw = pw
    def _get(self, params, timeout=60, raw=False):
        # parameters travel in the POST body, never in the URL: the login password and the session id stay out of
        # every proxy, server and crash log that records request lines
        with _nas_open(self.api, urllib.parse.urlencode(params).encode(), timeout) as r:
            data = r.read()
        if raw: return data
        j = json.loads(data)
        if not j.get('success'): raise ValueError(f'NAS answered error {j.get("error", {}).get("code")}')
        return j.get('data', {})
    def login(self):
        d = self._get({'api': 'SYNO.API.Auth', 'version': '7', 'method': 'login', 'account': self.user, 'passwd': self.pw, 'session': 'FileStation', 'format': 'sid'})
        self.sid = d['sid']
    def list(self, folder):
        d = self._get({'api': 'SYNO.FileStation.List', 'version': '2', 'method': 'list', 'folder_path': folder, 'limit': '1000', '_sid': self.sid})
        return d.get('files', [])
    def download(self, path):
        return self._get({'api': 'SYNO.FileStation.Download', 'version': '2', 'method': 'download', 'mode': 'download', 'path': path, '_sid': self.sid}, timeout=600, raw=True)
    def logout(self):
        if self.sid:
            try: self._get({'api': 'SYNO.API.Auth', 'version': '7', 'method': 'logout', 'session': 'FileStation', '_sid': self.sid}, timeout=10)
            finally: self.sid = None


class _NoNasRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise ValueError('The NAS redirected the connection. Check its address.')


_NAS_OPENER = urllib.request.build_opener(urllib.request.ProxyHandler({}), _NoNasRedirect)


def _nas_open(url, data, timeout):
    return _NAS_OPENER.open(url, data=data, timeout=timeout)


def _nas_failure(error):
    if isinstance(error, (urllib.error.URLError, TimeoutError, OSError)): return 'The NAS could not be reached. Check its address and Tailscale connection.'
    return 'The NAS refused this request. Check the login and folder permissions.'


def _nas_test(details, password):
    nas_settings.require_tailnet_peer(details)
    nas = _Nas(details['host'], details['user'], password)
    try:
        nas.login()
        nas.list(details['root'])
    except Exception as e: raise nas_settings.SettingsError(_nas_failure(e)) from None
    finally:
        if nas.sid:
            try: nas.logout()
            except Exception: pass

def nas_find_job(pl, nas, root='/Platinum'):
    """Find a job under the selected root, using only matching local index paths."""
    rx = re.compile(r'\bPL\s?-?\s?0*' + re.escape(pl.lstrip('PL').lstrip('0')) + r'\b', re.I)
    hits = []
    if os.path.exists(NAS_INDEX):
        for line in open(NAS_INDEX, errors='replace'):
            parts = line.rstrip('\n').split('\t')
            if len(parts) >= 2 and parts[1] == 'dir' and parts[0].startswith(root + '/') and rx.search(os.path.basename(parts[0])): hits.append(parts[0])
    if not hits:
        for f in nas.list(root):
            if f.get('isdir') and isinstance(f.get('path'), str) and f['path'].startswith(root + '/') and rx.search(f['name']): hits.append(f['path'])
    # keep the top-most folder of each hit (a job folder, not its FA/MOCKUP children)
    hits = sorted(set(hits), key=len)
    tops = [h for h in hits if not any(h.startswith(o + '/') for o in hits if o != h)]
    return tops

def nas_job_files(pl):
    """Every PDF in the FA (finished art) folders of the job -> registered artworks + notes, like a Trello card fetch."""
    pl = (pl or '').strip().upper()
    m = re.search(r'(\d{4,6})', pl)
    if not m: raise ValueError('Type the PL number, e.g. PL014508.')
    pl = 'PL' + m.group(1).zfill(6)
    cfg = NAS_SETTINGS.current(_nas_creds())
    if not cfg: raise ValueError('Set up the NAS connection in this app, or copy the PDFs by hand.')
    if cfg['source'] != 'legacy': nas_settings.require_tailnet_peer(cfg)
    nas = _Nas(cfg['host'], cfg['user'], cfg['password'])
    try:
        try: nas.login()
        except Exception as e: raise ValueError(_nas_failure(e)) from None
        return _nas_job_files_logged_in(pl, nas, cfg['root'])
    finally:
        if nas.sid:
            try: nas.logout()
            except Exception: pass


def _nas_job_files_logged_in(pl, nas, root):
    try: tops = nas_find_job(pl, nas, root)
    except Exception as e: raise ValueError(_nas_failure(e)) from None
    if not tops: raise ValueError(f'No folder for {pl} under the selected NAS folder. Check the number, or copy the PDFs by hand.')
    files, notes, seen = [], [], set()
    def walk(folder, depth, fa):
        try: entries = nas.list(folder)
        except Exception as e: raise ValueError(_nas_failure(e)) from None
        for f in entries:
            if not isinstance(f.get('path'), str) or not f['path'].startswith(root + '/'): continue
            if f.get('isdir'):
                if depth < 3 and (fa or re.match(r'FA\b', f['name'], re.I) or f['name'].upper().startswith('FA')): walk(f['path'], depth + 1, True)
                elif depth < 2 and not fa: pass
            elif fa and f['name'].lower().endswith('.pdf') and f['path'] not in seen:
                seen.add(f['path'])
                size = int((f.get('additional') or {}).get('size') or 0)
                if size > _ATTACH_MAX: notes.append(f'{f["name"]} is over 40 MB and was not fetched.'); continue
                try:
                    data = nas.download(f['path'])
                    key = register_artwork(f['name'], data)
                    files.append(artwork_summary(key, ARTWORKS[key]))
                except Exception: notes.append('A NAS file could not be downloaded or read.')
    for top in tops: walk(top, 0, False)
    if not files:
        notes.append(f'{pl}: found ' + ', '.join(tops) + ' but no PDF in an FA folder inside it. Ask the designer to save the finished art there, or drop the PDFs in the box above.')
    return {'pl': pl, 'folders': tops, 'files': files, 'notes': notes, 'name': os.path.basename(tops[0])}

# ------------------------------------------------------------------ phone preview page
def preview_page(jid, job):
    """A one-file page of the result for a phone: the sentence, the numbers and the pictures.  Reached at /p/<id>
    from any device that can see this computer; the Copy-link button on the main page hands the address over."""
    rep = job['report']; sheets = job['sheets']; rules = job['rules']
    svgs = [outputs.write_svg(s, rules, job['settings'].get('corner_radius', 0)) for s in sheets]
    words = rep.get('words') or result_words(rep, PRODUCTS.get(job['settings'].get('product'), {}))
    h = lambda s: str(s).replace('&', '&amp;').replace('<', '&lt;')
    rows = ''.join(f'<div class="sheet"><b>Sheet {s["n"]} of {rep["sheet_count"]}</b> <span>{s["parts"]} part{"" if s["parts"] == 1 else "s"}, {s["utilisation"] * 100:.0f}% used, '
                   f'{h((s.get("offcut") or {}).get("words") or "")}</span>{svg}</div>' for s, svg in zip(rep['sheets'], svgs))
    return f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{h(job["job"])} - PS Nest</title><style>body{{margin:0;font-family:-apple-system,Helvetica,Arial,sans-serif;background:#f6f7f9;color:#1a1a1a;padding:16px}}
h1{{font-size:18px;margin:0 0 6px}}p{{font-size:15px;line-height:1.45;margin:0 0 14px}}.sheet{{background:#fff;border:1px solid #e4e7ec;border-radius:10px;padding:10px;margin-bottom:12px}}
.sheet b{{display:block;font-size:15px}}.sheet span{{font-size:13px;color:#667085;display:block;margin-bottom:6px}}svg{{width:100%;height:auto;display:block}}
.meta{{font-size:12px;color:#667085;margin-top:14px}}</style></head><body><h1>{h(job["job"])}</h1><p>{h(words)}</p>{rows}
<div class="meta">{h(job["settings"].get("material") or "")} on {h(job["settings"].get("cutter") or "")}. PS Nest job {jid}.</div></body></html>'''

# ------------------------------------------------------------------ HTTP
class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        sys.stderr.write('%s - %s\n' % (self.address_string(), fmt % args))

    def _send(self, code, body, ctype='application/json', filename=None):
        if isinstance(body, str): body = body.encode()
        self.send_response(code)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        if filename: self.send_header('Content-Disposition', f'attachment; filename="{filename}"')
        self.end_headers(); self.wfile.write(body)

    def do_GET(self):
        if not _client_allowed(self.client_address[0]):
            self._send(403, json.dumps({'error': 'Refused: this computer is not on the PS Nest network.'})); return
        if self.path.split('?', 1)[0].startswith('/api/nas') and not (_is_loopback(self.client_address[0]) and _nas_request_origin(self.headers)):
            self._send(403, json.dumps({'error': 'Refused NAS request origin.'})); return
        code, body, ctype, filename = dispatch('GET', self.path)
        self._send(code, body, ctype, filename=filename)

    def do_POST(self):
        if not _client_allowed(self.client_address[0]):
            self._send(403, json.dumps({'error': 'Refused: this computer is not on the PS Nest network.'})); return
        if not _local_origin(self.headers) or (self.path.split('?', 1)[0].startswith('/api/nas') and not (_is_loopback(self.client_address[0]) and _nas_request_origin(self.headers))):
            self._send(403, json.dumps({'error': 'Refused: this request did not come from the PS Nest page.'}).encode()); return
        n = int(self.headers.get('Content-Length') or 0)
        raw = self.rfile.read(n) if n else b''
        code, body, ctype, filename = dispatch('POST', self.path, raw)
        self._send(code, body, ctype, filename=filename)


def _local_origin(headers):
    """Only the PS Nest page may change things.  A browser stamps every POST with the page's Origin (or at least a
    Referer); a page on another site carries that site's, so it is refused.  A request with neither header (curl, a
    script, the launcher's own checks) is a local tool and passes.  On the LAN host the page is served from the host
    PC's own address, so an Origin that is this request's own Host and a LAN address inside PSNEST_ALLOW_NET passes,
    as does any name listed in PSNEST_LAN_HOSTS.  A loopback Origin passes only when it is exactly this request's own
    http host:port: the Box Maker on :8731 of the same PC, or any other page on another local port, is refused."""
    try:
        o = urllib.parse.urlsplit('http://' + headers.get('Host', '').strip())
        own = ((o.hostname or '').lower(), o.port if o.port is not None else 80)
    except ValueError: own = ('', None)
    for h in ('Origin', 'Referer'):
        v = headers.get(h)
        if not v: continue
        try:
            p = urllib.parse.urlsplit(v.strip()); host = (p.hostname or '').lower()
            port = p.port if p.port is not None else {'http': 80, 'https': 443}.get(p.scheme)
        except ValueError: return False
        if host in LOOPBACK: return p.scheme == 'http' and (host, port) == own   # the office app's own page only
        # the LAN page: scheme, host AND port must be this server's own (Box Maker on :8731 of the same PC is refused)
        return p.scheme == 'http' and (host, port) == own and (host in LAN_HOSTS or _lan_address(host))
    return True


def _nas_request_origin(headers):
    """NAS operations require a loopback Host and the exact page origin, including port."""
    host = headers.get('Host', '')
    try:
        h = urllib.parse.urlsplit('http://' + host)
        if h.hostname not in ('127.0.0.1', 'localhost', '::1') or h.username or h.password or h.path or h.query or h.fragment: return False
        port = h.port
    except ValueError: return False
    if port is None: return False
    expected = (h.hostname, port)
    for key in ('Origin', 'Referer'):
        value = headers.get(key)
        if not value: continue
        try:
            p = urllib.parse.urlsplit(value)
            if p.scheme != 'http' or (p.hostname, p.port) != expected or p.username or p.password: return False
        except ValueError: return False
    return True


def _reply(obj, code=200): return code, json.dumps(obj).encode(), 'application/json', None
def _error(msg, code=400): return _reply({'error': str(msg)}, code)


def dispatch(method, path, raw=b''):
    route = urllib.parse.urlparse(path).path
    if method == 'POST' and route.startswith('/api/update/'):
        if route == '/api/update/prepare':
            if not UPDATE_GUARD.prepare():
                return _error('A nesting or import operation is running. Finish it before updating.', 409)
            return _reply({'prepared': True})
        if route == '/api/update/cancel':
            UPDATE_GUARD.cancel()
            return _reply({'prepared': False})
        return _error('Not found', 404)
    if method == 'POST' and route == '/api/nest/stop':
        return _dispatch(method, path, raw)
    if method == 'POST' or route in ('/api/trello', '/api/nas') or route.startswith('/api/job/'):
        try:
            with UPDATE_GUARD.mutation():
                with DATA_LOCK: return _dispatch(method, path, raw)
        except ValueError as error:
            return _error(error, 409)
    if route in ('/api/jobs', '/api/artworks', '/api/outlines'):
        with DATA_LOCK: return _dispatch(method, path, raw)
    return _dispatch(method, path, raw)


def _dispatch(method, path, raw=b''):
    """Route one request without any HTTP machinery: (status, body bytes, content type, download
    filename or None).  Used by the local server above and by the browser build (nest/webapp.py),
    where the same call answers the UI from inside a web worker."""
    u = urllib.parse.urlparse(path); q = urllib.parse.parse_qs(u.query)
    if method == 'GET':
        try:
            if u.path in ('/', '/index.html'):
                return 200, open(os.path.join(HERE, 'ui.html'), 'rb').read(), 'text/html; charset=utf-8', None
            if u.path == '/api/nest/progress':
                run = RUNS.get((q.get('run') or [''])[0])
                if run is None: return _reply({'running': False})
                return _reply({'running': True, 'elapsed': round(time.time() - run['started'], 1), **run['progress']})
            if u.path == '/api/products':
                mq = (q.get('machine') or [''])[0].strip().lower()
                return _reply({'machine_preselect': mq if mq in machine_ids() else None, 'products': PRODUCTS, 'machines': MACHINES, 'cutters': CUTTERS, 'materials': MATERIALS, 'custom_templates': {k: custom_product({'name': 'Custom material', 'cutter': k}) for k in [*CUTTERS, 'custom']}, 'examples': EXAMPLES, 'trello': bool(_trello_creds()[0]), 'release': RELEASE, 'build': BUILD,
                               'guard': {'checks': sorted(guard.REASONS), 'back_print': True}})
            if u.path == '/api/artworks':
                return _reply({'artworks': [artwork_summary(k, v) for k, v in ARTWORKS.items()]})
            if u.path == '/api/outlines':
                return _reply({'outlines': [outline_summary(k, e) for k, e in OUTLINES.items()]})
            if u.path == '/api/fonts':
                global _FONTS
                if _FONTS is None: _FONTS = importers.list_fonts()
                return _reply({'fonts': _FONTS})
            if u.path == '/api/trello':
                mq = (q.get('machine') or [''])[0].strip().lower()   # the page's bookmark: the card lands on this machine's product
                try:
                    if mq and mq not in machine_ids(): raise ValueError(f'Unknown machine "{mq}". Bookmark ?machine=' + ', '.join(machine_ids()) + '.')
                    return _reply(trello_card(q.get('card', [''])[0], with_files=q.get('files', ['1'])[0] != '0', machine=mq or None))
                except ValueError as e: return _error(str(e), 400)
            if u.path == '/api/jobs':
                return _reply({'jobs': list_jobs()})
            if u.path == '/api/nas':
                try: return _reply(nas_job_files(q.get('pl', [''])[0]))
                except ValueError as e: return _error(str(e), 400)
                except Exception: return _error('Could not fetch NAS files.', 500)
            if u.path == '/api/nas/settings':
                if sys.platform == 'emscripten': return _error('NAS setup is available in the native app.', 404)
                try: return _reply(NAS_SETTINGS.status(_nas_creds()))
                except nas_settings.SettingsError as e: return _error(str(e), 400)
            m = re.match(r'^/api/job/([0-9a-f]+)/request$', u.path)
            if m:
                job = load_job(m.group(1))
                if not job: return _error('This job is no longer on the server.', 404)
                if not job.get('request'): return _error('This job was nested before Projects existed and cannot be re-opened. Nest it again.', 400)
                return _reply({'request': job['request'], 'job': job['job'], 'created': job.get('created'), 'result': job_result(m.group(1), job)})
            m = re.match(r'^/p/([0-9a-f]+)$', u.path)
            if m:
                job = load_job(m.group(1))
                if not job: return 404, b'This result is no longer on the server.', 'text/plain; charset=utf-8', None
                return 200, preview_page(m.group(1), job).encode(), 'text/html; charset=utf-8', None
            m = re.match(r'^/api/job/([0-9a-f]+)/(dxf|dxf-labels|print|cut|corel-cut|print-files|cut-files|print-back|print-back-files|layout|report|packing|worksheet|production|all)$', u.path)
            if m:
                job = load_job(m.group(1))
                if not job: return _error('This result is no longer on the server. Nest again and download the new file.', 404)
                try: name, data, ctype = job_files(job, m.group(2))
                except ValueError as e: return _error(str(e), 400)
                return 200, data, ctype, name
            return _error('Not found', 404)
        except Exception as e:
            return _error(e, 500)
    try:
        body = json.loads(raw or b'{}')
    except json.JSONDecodeError:
        return _error('Bad JSON')
    try:
        if u.path == '/api/nas':
            return _reply(nas_job_files(body.get('pl', '')))
        if u.path.startswith('/api/nas/settings/'):
            if sys.platform == 'emscripten': return _error('NAS setup is available in the native app.', 404)
            if u.path == '/api/nas/settings/clear':
                NAS_SETTINGS.clear(); return _reply(NAS_SETTINGS.status())
            if u.path not in ('/api/nas/settings/test', '/api/nas/settings/save'): return _error('Not found', 404)
            details, password = NAS_SETTINGS.candidate(body, _nas_creds())
            if u.path.endswith('/save') and (not isinstance(body.get('remember'), bool) or body['remember'] and not NAS_SETTINGS.secretstore):
                return _error('Choose session storage or macOS Keychain on a Mac.')
            _nas_test(details, password)
            if u.path.endswith('/test'): return _reply({'ok': True, 'message': 'NAS login and folder access succeeded.'})
            NAS_SETTINGS.save(details, password, body['remember'])
            return _reply(NAS_SETTINGS.status())
        m = re.match(r'^/api/job/([0-9a-f]+)/archive-test$', u.path)
        if m:
            result = archive_test_job(m.group(1), body)
            if result is None: return _error('This job is no longer on the server.', 404)
            return _reply(result)
        m = re.match(r'^/api/job/([0-9a-f]+)/acknowledge$', u.path)
        if m:
            try: result = acknowledge_hold(m.group(1), body)
            except ValueError as e: return _error(str(e), 400)
            if result is None: return _error('This job is no longer available. Nest again.', 404)
            return _reply(result)
        m = re.match(r'^/api/job/([0-9a-f]+)/separation-cuts$', u.path)
        if m:
            original = load_job(m.group(1))
            if not original: return _error('This job is no longer available. Nest again.', 404)
            check_approved_sources(original)
            draft = copy.deepcopy(original)
            customcuts.apply(draft['sheets'], draft['rules'], body.get('cuts'), draft['settings']['bit_diameter'], draft['settings']['corner_radius'])
            if draft['report'].get('orders'):
                draft['report']['order_labels'] = order_labels.plan_labels(
                    draft['sheets'], draft['rules'], label_bleed(draft['parts'], draft['rules'], draft['settings']['bleed']),
                    ccd_dots=_job_label_ccd_dots(draft))
            if body.get('validate_only'): return _reply({'valid': True})
            # Save a new immutable result so Undo and older download links retain
            # their original geometry. Failed validation never changes a job.
            jid = uuid.uuid4().hex[:10]
            draft['created'] = time.time()
            draft['request']['custom_cuts'] = {str(i): s.custom_cuts for i,s in enumerate(draft['sheets']) if s.custom_cuts is not None}
            fresh = outputs.report(draft['sheets'],draft['rules'],draft['info'],draft['job'],draft['settings'])
            draft['report'].update(fresh)
            draft['report']['created'] = draft['created']
            draft['report']['job_id'] = jid
            draft['report']['words'] = result_words(draft['report'], draft['report'].get('process') or {})
            JOBS[jid] = draft
            save_job(jid, draft)
            return _reply(job_result(jid, draft))
        if u.path == '/api/nest':
            mq = (urllib.parse.parse_qs(u.query).get('machine') or [''])[0].strip().lower()
            if mq and isinstance(body, dict) and not body.get('machine'): body['machine'] = mq
            try: return _reply(run_nest(body))
            except MachineMismatch as e: return _reply({'error': 'machine_mismatch', 'message': str(e), 'machine': e.machine, 'cutter': e.cutter}, 400)
        if u.path == '/api/nest/stop':
            rid = str(body.get('run_id') or '')[:40]
            if not rid: return _error('run_id missing')
            # The server is threaded, so this arrives while /api/nest is still inside the engine; if it somehow
            # arrives first, the pre-counted entry is picked up when the run registers.  First press: keep the
            # best finished layout (finishing the first if none has); second press: abandon (control.py).
            run = RUNS.setdefault(rid, _new_run()); run['stops'] += 1
            return _reply({'ok': True, 'presses': run['stops']})
        if u.path == '/api/artwork/identity':
            if set(body) - {'key', 'order_ref', 'item_number', 'site_ref', 'confirm'} or type(body.get('confirm', False)) is not bool:
                raise ValueError('Exact manual artwork identity fields are required.')
            key = body.get('key')
            if not isinstance(key, str) or key not in ARTWORKS:
                raise ValueError('Registered artwork is required to check its original identity.')
            return _reply(artwork_identity.resolve_manual_identity(key, ARTWORKS[key], body.get('order_ref', ''),
                          body.get('item_number', ''), body.get('site_ref', ''), body.get('confirm', False)))
        if u.path == '/api/artwork':
            key = register_artwork(body.get('name', 'artwork.pdf'), base64.b64decode(body['data']))
            summ = artwork_summary(key, ARTWORKS[key])
            sheet = body.get('sheet') or {}
            try: sw_, sh_ = float(sheet.get('w') or 0), float(sheet.get('h') or 0)
            except (TypeError, ValueError): sw_ = sh_ = 0
            prod = resolve_product('custom', body.get('custom_material')) if body.get('product') == 'custom' else PRODUCTS.get(body.get('product') or '') or {}
            summ['warnings'] = artwork_checks(ARTWORKS[key], sw_ or None, sh_ or None, printed=bool(prod.get('printer', True)),
                                              bleed=(prod.get('defaults') or {}).get('bleed'))
            return _reply(summ)
        if u.path == '/api/partslist':
            data = base64.b64decode(body['data'])
            if len(data) > 5_000_000: raise ValueError('The parts list is over 5 MB.')
            return _reply(parse_partslist(body.get('name') or 'parts.csv', data))
        if u.path == '/api/artwork/delete':
            delete_artwork(body.get('key')); return _reply({'ok': True})
        if u.path == '/api/outline':
            data = base64.b64decode(body['data'])
            if len(data) > 20_000_000: raise ValueError('Outline file is over 20 MB.')
            entry = shapes.parse_upload(body.get('name') or 'outline.dxf', data)
            key = uuid.uuid4().hex[:8]
            OUTLINES[key] = entry; save_outline(key, entry)
            return _reply(outline_summary(key, entry))
        if u.path == '/api/outline/delete':
            delete_outline(body.get('key')); return _reply({'ok': True})
        return _error('Not found', 404)
    except ValueError as e:
        if u.path.startswith('/api/nas/settings/'): return _error(str(e) if isinstance(e, nas_settings.SettingsError) else 'Could not update NAS settings.', 400)
        if u.path == '/api/nas': return _error(str(e), 400)
        return _error(e, 400)
    except Exception as e:
        if u.path.startswith('/api/nas/settings/'): return _error('Could not update NAS settings.', 500)
        if u.path == '/api/nas': return _error('Could not fetch NAS files.', 500)
        return _error(f'{type(e).__name__}: {e}', 500)


class _Server(ThreadingHTTPServer):
    # Windows lets a second program bind a port that is already listening when SO_REUSEADDR is set (HTTPServer sets
    # it), which is how two PS Nests could both answer on 8770.  There the socket is exclusive; on POSIX reuse stays
    # so a restart does not wait out TIME_WAIT.
    allow_reuse_address = os.name != 'nt'
    def server_bind(self):
        if os.name == 'nt' and hasattr(socket, 'SO_EXCLUSIVEADDRUSE'):
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        super().server_bind()


class _Server6(_Server): address_family = socket.AF_INET6


def _port_busy(bind, port):
    """True when something already answers on this port, so a second PS Nest is never started on top of the first."""
    probe = '127.0.0.1' if bind in ('0.0.0.0', '') else ('::1' if bind == '::' else bind)
    try:
        with socket.create_connection((probe, port), timeout=0.5): return True
    except OSError: return False


def bind_list(bind=None):
    """The addresses to listen on, each once: an explicit bind (comma list allowed) or PSNEST_BIND."""
    binds = tuple(dict.fromkeys(b.strip() for b in (bind or ','.join(BIND_LIST)).split(',') if b.strip())) or ('127.0.0.1',)
    return ('0.0.0.0',) if any(b in ('0.0.0.0', '') for b in binds) else binds


def launch_url(port, machine=None):
    """The page --open launches: on a cutter PC that sets PSNEST_MACHINE (or the given id) it is the bookmark form
    /?machine=<id>, so a normal start lands preselected; an unknown id is ignored and the plain page opens."""
    raw = machine if machine is not None else os.environ.get('PSNEST_MACHINE', '')
    source = 'machine id' if machine is not None else 'PSNEST_MACHINE'   # name where the bad value came from
    mid = raw.strip().strip('"\'').strip().lower()          # a launcher may pass the value with quotes around it
    if mid and mid not in cutter_ids():
        print(f'{source}={raw!r} is not a cutter id ({", ".join(cutter_ids())}); opening the plain page.', flush=True)
    return f'http://127.0.0.1:{port}/' + (f'?machine={mid}' if mid in cutter_ids() else '')

def main(port=None, open_browser=False, bind=None):
    port = port or PORT; binds = bind_list(bind)
    for b in binds:
        if _port_busy(b, port):
            print(f'PS Nest is already running on port {port} ({b}); not starting a second copy.', flush=True); sys.exit(3)
    _ensure_dirs(); _housekeep(); load_artworks(); load_outlines()
    servers = [(_Server6 if ':' in b else _Server)((b, port), Handler) for b in binds]
    url = launch_url(port)
    print(f'PS Nest running at {url}  (results kept in {DATA})', flush=True)
    for b in binds:
        if b not in LOOPBACK:
            where = "this PC's LAN address" if b in ('0.0.0.0', '::') else b
            print(f'Shared on the LAN at http://{where}:{port}/ for clients in {ALLOW_NET}; each cutter PC bookmarks /?machine=<' + '|'.join(cutter_ids()) + '>', flush=True)
    if open_browser:
        import webbrowser; webbrowser.open(url)
    for s in servers[1:]: threading.Thread(target=s.serve_forever, daemon=True).start()
    try: servers[0].serve_forever()
    except KeyboardInterrupt: pass

if __name__ == '__main__':
    port = next((int(a) for a in sys.argv[1:] if a.isdigit()), PORT)
    main(port, open_browser='--open' in sys.argv)
