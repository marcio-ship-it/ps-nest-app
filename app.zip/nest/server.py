"""PS Nest local server.  Standard library only for the HTTP side; reportlab + pypdf for the PDFs.

    python3 -m nest.server            # serves http://127.0.0.1:8765
"""
from __future__ import annotations
import base64, json, math, os, re, sys, time, uuid, urllib.request, urllib.parse, urllib.error
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler

from .engine import Part, Rules, expand, nest, validate, Stopped
from dataclasses import replace as _replace
from .shapenest import validate_shapes
from . import outputs, shapes, importers, pdfcut
from .products import PRODUCTS, MACHINES, MATERIALS, machine_warnings, machine_blocks, default_product, resolve_product, custom_product, CUTTERS
from . import nas_settings
from .version import RELEASE
from .update_guard import UpdateGuard
UPDATE_GUARD = UpdateGuard()

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.environ.get('PSNEST_DATA') or os.path.join(os.path.dirname(HERE), 'data')
JOBS_DIR = os.path.join(DATA, 'jobs'); ART_DIR = os.path.join(DATA, 'artworks'); OUT_DIR = os.path.join(DATA, 'outlines')
KEEP_DAYS = 60   # job and artwork files older than this are removed at start-up
JOBS = {}        # job id -> dict (cache; the file in JOBS_DIR is the record)
ARTWORKS = {}    # artwork key -> {'name', 'bytes', 'w_mm', 'h_mm', 'cut'}  (cut = pdfcut.analyse result)
RUNS = {}        # run id (chosen by the page) -> {'stops', 'progress', 'started'} while a nest runs
PROGRESS_HOOK = None   # the browser build sets a callable(**fields) that pushes live progress to the page


def _new_run(): return {'stops': 0, 'progress': {}, 'started': time.time()}
OUTLINES = {}    # outline key -> shapes.parse_upload entry (uploaded DXF / SVG cut paths)
_FONTS = None    # cached importers.list_fonts()

def _ensure_dirs():
    for d in (JOBS_DIR, ART_DIR, OUT_DIR): os.makedirs(d, exist_ok=True)

def _housekeep():
    """Drop files older than KEEP_DAYS so the data folder does not grow forever.  Old jobs go first; an artwork or
    outline file that a surviving job still points at is kept whatever its age, so that job's downloads keep working."""
    cutoff = time.time() - KEEP_DAYS * 86400
    def drop_old(fp):
        try:
            if os.path.getmtime(fp) < cutoff: os.remove(fp)
        except OSError: pass
    for fn in os.listdir(JOBS_DIR): drop_old(os.path.join(JOBS_DIR, fn))
    keep = set()
    for fn in os.listdir(JOBS_DIR):
        if not fn.endswith('.json'): continue
        try: keep |= _referenced_keys(json.load(open(os.path.join(JOBS_DIR, fn))))
        except (OSError, ValueError): continue
    for d in (ART_DIR, OUT_DIR):
        for fn in os.listdir(d):
            if fn.rsplit('.', 1)[0] not in keep: drop_old(os.path.join(d, fn))

def _referenced_keys(obj):
    """Every artwork / outline key a saved job record mentions (parts[].artwork, shape {'key': ...})."""
    out = set()
    if isinstance(obj, dict):
        for k, v in obj.items():
            if k in ('artwork', 'key') and isinstance(v, str) and v: out.add(v)
            out |= _referenced_keys(v)
    elif isinstance(obj, list):
        for v in obj: out |= _referenced_keys(v)
    return out

def load_artworks():
    _ensure_dirs()
    for fn in os.listdir(ART_DIR):
        if not fn.endswith('.json'): continue
        key = fn[:-5]
        try:
            meta = json.load(open(os.path.join(ART_DIR, fn)))
            data = open(os.path.join(ART_DIR, key + '.pdf'), 'rb').read()
        except (OSError, ValueError): continue
        ARTWORKS[key] = {'name': meta['name'], 'bytes': data, 'w_mm': meta['w_mm'], 'h_mm': meta['h_mm'], 'cut': meta.get('cut'), 'pages': meta.get('pages', 1)}
        if meta.get('cut') is None:                      # stored before CutContour support: read it once now
            ARTWORKS[key]['cut'] = _analyse_cut(data)
            save_artwork(key, ARTWORKS[key])

def _analyse_cut(data):
    try: return pdfcut.analyse(data)
    except ValueError as e: return {'found': False, 'paths': [], 'error': str(e)}
    except Exception as e: return {'found': False, 'paths': [], 'error': f'could not read the PDF for a CutContour line ({type(e).__name__}: {e})'}

_NAME_QTY = (re.compile(r'\(\s*QTY\s*[-:]?\s*(\d{1,5})\s*\)', re.I), re.compile(r'(?:^|[\s_-])QTY\s*[-:]?\s*(\d{1,5})(?!\d)', re.I),
             re.compile(r'(?:^|[\s_-])(\d{1,5})\s*x\s*$', re.I), re.compile(r'(?:^|[\s_-])x\s*(\d{1,5})\s*$', re.I))

def name_qty(filename):
    """Quantity written in an artwork file name the way the shop names them: '..._420x245___36x.pdf',
    '... (QTY - 20).pdf', '1 - QTY2_print.pdf', 'Print x2.pdf'.  None when there is none: never guessed from a size."""
    stem = re.sub(r'\.pdf$', '', filename or '', flags=re.I).strip()
    for rx in _NAME_QTY:
        m = rx.search(stem)
        if m and int(m.group(1)) > 0: return int(m.group(1))
    return None

FIXES = [   # (what pdfcut reports, how the designer fixes it in Illustrator)
    ('not closed', 'Fix in Illustrator: select the cut line, Object > Path > Join (Cmd+J) so it becomes one closed path, or redraw it as a closed shape. Then Save As PDF again.'),
    ('encloses no area', 'Fix in Illustrator: the CutContour colour sits on a single line or a dot. Delete that object, draw the cut as a closed shape (rectangle, rounded rectangle, circle...) and give its STROKE the CutContour swatch. Then Save As PDF again.'),
    ('used but no cut path', 'Fix in Illustrator: the CutContour swatch is on a fill, text or a compound object, not on the stroke of a path. Draw the cut shape as a closed path, Fill none, Stroke = the CutContour spot swatch, then Save As PDF again.'),
    ('password', 'Fix in Illustrator: Save As PDF again without a document password (File > Save As > PDF > Security: no password).'),
    ('not a readable PDF', 'Fix: open the file in Illustrator or Acrobat and Save As PDF again (Illustrator default preset).'),
]
NO_CUT_FIX = ('No CutContour line: the part will be placed as a rectangle at page size and can be printed but not cut. '
              'To add it in Illustrator: Window > Swatches > New Swatch, name CutContour, type Spot Color; draw the cut shape as a closed path, '
              'Fill none, Stroke = CutContour; Save As PDF.')

def fix_for(error):
    """The Illustrator fix for a pdfcut error message, or None."""
    e = (error or '').lower()
    for key, fix in FIXES:
        if key in e: return fix
    return None

def artwork_summary(key, a):
    c = a.get('cut') or {}
    cut = {'found': bool(c.get('found')), 'error': c.get('error')}
    if c.get('error'): cut['fix'] = fix_for(c['error'])
    elif not c.get('found'): cut['fix'] = NO_CUT_FIX
    if c.get('found') and not c.get('error'):
        cut.update(w=round(c['w'], 1), h=round(c['h'], 1), paths=c['loops'], holes=c['holes'], islands=c['islands'])
    return {'key': key, 'name': a['name'], 'w_mm': a['w_mm'], 'h_mm': a['h_mm'], 'cut': cut, 'qty_hint': name_qty(a['name']), 'pages': a.get('pages', 1)}

def artwork_checks(a, sheet_w=None, sheet_h=None, printed=True, bleed=None):
    """Warnings for one uploaded artwork, worded for the designer: bigger than the sheet, no bleed on a print job,
    page size far from the cut box.  sheet_w/h None -> the sheet check is skipped."""
    out = []
    c = a.get('cut') or {}
    pw, ph = float(a.get('w_mm') or 0), float(a.get('h_mm') or 0)
    if c.get('found') and not c.get('error'):
        w, h = float(c['w']), float(c['h'])
        what = 'cut line'
    else:
        w, h = pw, ph; what = 'page'
    if sheet_w and sheet_h and w > 0 and h > 0:
        fits = (w <= sheet_w and h <= sheet_h) or (h <= sheet_w and w <= sheet_h)
        if not fits:
            out.append(f'{a["name"]}: the {what} is {w:g} x {h:g} mm, bigger than the {sheet_w:g} x {sheet_h:g} mm sheet either way round. It cannot be nested: split the artwork or choose a bigger sheet.')
    if c.get('found') and not c.get('error'):
        try: over = outputs.contour_overhang(c)
        except Exception: over = None
        if printed and over is not None and over < 0.05:
            out.append(f'{a["name"]}: no bleed - the artwork stops exactly at the cut line. A hairline of white can show after cutting; extend the artwork {bleed or 3:g} mm past the CutContour line.')
        if pw > w + 60 or ph > h + 60:
            out.append(f'{a["name"]}: the PDF page is {pw:g} x {ph:g} mm but the cut line is {w:g} x {h:g} mm. The empty page around it is ignored, but check that the cut line is the whole part and not one piece of a multi-part page.')
        if pw < w - 0.5 or ph < h - 0.5:
            out.append(f'{a["name"]}: the cut line ({w:g} x {h:g} mm) runs past the PDF page ({pw:g} x {ph:g} mm): the part is clipped. Make the artboard at least as big as the cut line.')
    return out

def print_artwork(key, bleed_limit):
    """Bytes placed in the print PDF: the artwork itself, or for CutContour artwork a copy without the cut line and
    with its bleed clipped to bleed_limit mm around the line (half the gap, so neighbours cannot overprint)."""
    a = ARTWORKS[key]
    if not (a.get('cut') or {}).get('found'): return a['bytes']
    cache = a.setdefault('_print', {})
    if bleed_limit not in cache: cache[bleed_limit] = pdfcut.print_copy(a['bytes'], bleed_limit=bleed_limit)
    return cache[bleed_limit]

def save_artwork(key, art):
    _ensure_dirs()
    open(os.path.join(ART_DIR, key + '.pdf'), 'wb').write(art['bytes'])
    json.dump({'name': art['name'], 'w_mm': art['w_mm'], 'h_mm': art['h_mm'], 'cut': art.get('cut'), 'pages': art.get('pages', 1)}, open(os.path.join(ART_DIR, key + '.json'), 'w'))

def _loops_json(loops): return [[list(pt) for pt in o] for o in loops]
def _loops_tuple(loops): return tuple(tuple(tuple(pt) for pt in o) for o in (loops or ()))

def load_outlines():
    _ensure_dirs()
    for fn in os.listdir(OUT_DIR):
        if not fn.endswith('.json'): continue
        try: e = json.load(open(os.path.join(OUT_DIR, fn)))
        except (OSError, ValueError): continue
        for g in e['parts']:
            for k in ('outline',): g[k] = _loops_tuple([g[k]])[0]
            for k in ('holes', 'islands'): g[k] = _loops_tuple(g[k])
        OUTLINES[fn[:-5]] = e

def save_outline(key, e):
    _ensure_dirs()
    rec = dict(e); rec['parts'] = [dict(g, outline=_loops_json([g['outline']])[0], holes=_loops_json(g['holes']), islands=_loops_json(g['islands'])) for g in e['parts']]
    json.dump(rec, open(os.path.join(OUT_DIR, key + '.json'), 'w'))

def outline_summary(key, e):
    return {'key': key, 'name': e['name'], 'kind': e['kind'], 'summary': e['summary'], 'warnings': e.get('warnings', []),
            'parts': [{'index': i, 'w': round(g['w'], 2), 'h': round(g['h'], 2), 'holes': len(g['holes']), 'islands': len(g['islands']), 'area': g.get('area')} for i, g in enumerate(e['parts'])]}

_KEY_RX = re.compile(r'^[A-Za-z0-9_-]{1,64}$')

def _check_key(key):
    """Stored artworks and outlines are named by an 8-hex key; anything else (a path, a blank) never reaches the disk."""
    if not isinstance(key, str) or not _KEY_RX.match(key): raise ValueError('Not a stored file key.')
    return key

def delete_outline(key):
    _check_key(key)
    OUTLINES.pop(key, None)
    try: os.remove(os.path.join(OUT_DIR, key + '.json'))
    except OSError: pass

def register_artwork(name, data):
    """Store a one-page artwork PDF the way the upload box does and return its key.  The same bytes under the same
    name (a card fetched twice) reuse the stored copy instead of piling up duplicates."""
    import hashlib
    digest = hashlib.sha1(data).hexdigest()
    for k, a in ARTWORKS.items():
        if a['name'] == name and a.get('_sha1', hashlib.sha1(a['bytes']).hexdigest()) == digest:
            a['_sha1'] = digest; return k
    from pypdf import PdfReader; import io
    try:
        rd = PdfReader(io.BytesIO(data))
        if rd.is_encrypted and not rd.decrypt(''): raise ValueError('password-protected')
        pg = rd.pages[0]; n_pages = len(rd.pages)
    except Exception as e:
        why = 'it is password-protected' if 'password' in str(e).lower() or 'decrypt' in type(e).__name__.lower() else f'it is not a readable PDF ({type(e).__name__})'
        raise ValueError(f'{name}: {why}. Save it again from the design program.')
    unit = float(pg.get('/UserUnit', 1) or 1)          # Illustrator large-canvas files: the page is `unit` times its box
    key = uuid.uuid4().hex[:8]
    ARTWORKS[key] = {'name': name, 'bytes': data, 'pages': n_pages, '_sha1': digest,
                     'w_mm': round(float(pg.mediabox.width) * unit / outputs.MM, 1), 'h_mm': round(float(pg.mediabox.height) * unit / outputs.MM, 1),
                     'cut': _analyse_cut(data)}
    save_artwork(key, ARTWORKS[key])
    return key

def delete_artwork(key):
    _check_key(key)
    ARTWORKS.pop(key, None)
    for ext in ('.pdf', '.json'):
        try: os.remove(os.path.join(ART_DIR, key + ext))
        except OSError: pass

def save_job(jid, job):
    """Write the job to disk so downloads survive a restart of the server."""
    _ensure_dirs()
    r = job['rules']
    rec = {'job': job['job'], 'settings': job['settings'], 'print': job['print'], 'info': job['info'],
           'report': {k: v for k, v in job['report'].items() if k != 'svg'},
           'request': job.get('request'), 'created': job.get('created'),
           'rules': {'sheet_w': r.sheet_w, 'sheet_h': r.sheet_h, 'edge': r.edge, 'gap': r.gap, 'clamp': r.clamp, 'min_offcut': r.min_offcut,
                     'rot_step': r.rot_step, 'grid': r.grid, 'roll': r.roll, 'trim_offcut': r.trim_offcut,
                     'edge_l': r.edge_l, 'edge_r': r.edge_r, 'edge_b': r.edge_b, 'edge_t': r.edge_t, 'offcut': r.offcut,
                     'pins': [list(p) for p in r.pins], 'stock': [list(s) for s in r.stock]},
           'sheet_sizes': [list(s.size) if s.size else None for s in job['sheets']],
           'parts': [{'name': p.name, 'w': p.w, 'h': p.h, 'rotate': p.rotate, 'artwork': p.artwork, 'shape': p.shape,
                      'outline': _loops_json([p.outline])[0] if p.outline else None,
                      'holes': _loops_json(p.holes), 'islands': _loops_json(p.islands)} for p in job['parts']],
           'sheets': [[{'part': job['parts'].index(pl.part), 'x': pl.x, 'y': pl.y, 'w': pl.w, 'h': pl.h, 'rotated': pl.rotated, 'angle': pl.angle}
                       for pl in s.placed] for s in job['sheets']]}
    tmp = os.path.join(JOBS_DIR, jid + '.tmp')
    json.dump(rec, open(tmp, 'w'))
    os.replace(tmp, os.path.join(JOBS_DIR, jid + '.json'))

def load_job(jid):
    """Return the job from the cache or from its file on disk; None if it does not exist."""
    if jid in JOBS: return JOBS[jid]
    fp = os.path.join(JOBS_DIR, jid + '.json')
    if not os.path.exists(fp): return None
    from .engine import Placed, Sheet
    rec = json.load(open(fp))
    parts = [Part(p['name'], p['w'], p['h'], rotate=p['rotate'], artwork=p.get('artwork'), shape=p.get('shape'),
                  outline=_loops_tuple([p['outline']])[0] if p.get('outline') else None,
                  holes=_loops_tuple(p.get('holes')), islands=_loops_tuple(p.get('islands'))) for p in rec['parts']]
    sizes = rec.get('sheet_sizes') or [None] * len(rec['sheets'])
    sheets = [Sheet([Placed(parts[pl['part']], pl['x'], pl['y'], pl['w'], pl['h'], pl['rotated'], pl.get('angle', 0.0)) for pl in s],
                    size=tuple(sz) if sz else None) for s, sz in zip(rec['sheets'], sizes)]
    rr = dict(rec['rules'])
    rr['pins'] = tuple(tuple(p) for p in rr.get('pins') or ())
    rr['stock'] = tuple(tuple(s) for s in rr.get('stock') or ())
    job = {'sheets': sheets, 'rules': Rules(**rr), 'parts': parts, 'info': rec['info'], 'settings': rec['settings'],
           'job': rec['job'], 'print': rec['print'], 'report': rec['report'], 'request': rec.get('request'), 'created': rec.get('created')}
    JOBS[jid] = job
    return job

def list_jobs(limit=200):
    """Newest first: what the Projects list shows.  Read from the files so it survives a restart."""
    _ensure_dirs()
    rows = []
    for fn in os.listdir(JOBS_DIR):
        if not fn.endswith('.json'): continue
        fp = os.path.join(JOBS_DIR, fn)
        try:
            rec = json.load(open(fp)); rep = rec.get('report') or {}; st = rec.get('settings') or {}
        except (OSError, ValueError): continue
        rows.append({'id': fn[:-5], 'job': rec.get('job'), 'when': rec.get('created') or os.path.getmtime(fp),
                     'sheets': rep.get('sheet_count'), 'parts': rep.get('parts_total'), 'material': st.get('material'), 'cutter': st.get('cutter'),
                     'sheet_mm': rep.get('sheet_mm'), 'utilisation': rep.get('utilisation'), 'reopen': bool(rec.get('request'))})
    rows.sort(key=lambda r: -(r['when'] or 0))
    return rows[:limit]

# ------------------------------------------------------------------ examples
EXAMPLES = [
    {'id': 'rate-boards', 'label': 'Rate boards: 9 x 500x1100 ACM, one size',
     'job': 'Rate boards', 'product': 'acm', 'sheet': {'w': 2440, 'h': 1220},
     'parts': [{'name': 'Rate board', 'w': 500, 'h': 1100, 'qty': 9, 'rotate': True}]},
    {'id': 'tc-boards', 'label': 'T&C boards: 8 x 500x1100 ACM, one size',
     'job': 'T&C boards', 'product': 'acm', 'sheet': {'w': 2440, 'h': 1220},
     'parts': [{'name': 'T&C board', 'w': 500, 'h': 1100, 'qty': 8, 'rotate': True}]},
    {'id': 'mixed', 'label': 'Mixed ACM order (six sizes, small quantities)',
     'job': 'Mixed ACM test', 'product': 'acm', 'sheet': {'w': 2440, 'h': 1220},
     'parts': [{'name': 'Rate board vertical', 'w': 590, 'h': 1340, 'qty': 4, 'rotate': True},
               {'name': 'Logo rate board', 'w': 850, 'h': 850, 'qty': 3, 'rotate': True},
               {'name': 'P1 rates promo', 'w': 960, 'h': 430, 'qty': 5, 'rotate': True},
               {'name': 'T&Cs small', 'w': 885, 'h': 430, 'qty': 6, 'rotate': True},
               {'name': 'STP QR', 'w': 400, 'h': 600, 'qty': 12, 'rotate': True},
               {'name': 'Level marker', 'w': 400, 'h': 500, 'qty': 8, 'rotate': True}]},
    {'id': 'shapes', 'label': 'Complex: circles, triangles, stars and hexagons at 45° steps (shape engine)',
     'job': 'Shape test', 'product': 'acm', 'sheet': {'w': 2440, 'h': 1220}, 'mode': 'complex', 'rot_step': 45,
     'parts': [{'name': 'Disc', 'w': 600, 'h': 600, 'qty': 3, 'rotate': True, 'shape': {'type': 'circle'}},
               {'name': 'Small disc', 'w': 250, 'h': 250, 'qty': 8, 'rotate': True, 'shape': {'type': 'circle'}},
               {'name': 'Arrow head', 'w': 500, 'h': 400, 'qty': 6, 'rotate': True, 'shape': {'type': 'triangle'}},
               {'name': 'Star', 'w': 450, 'h': 450, 'qty': 4, 'rotate': True, 'shape': {'type': 'star', 'n': 5, 'inner': 0.45}},
               {'name': 'Hex badge', 'w': 350, 'h': 350, 'qty': 6, 'rotate': True, 'shape': {'type': 'polygon', 'n': 6}},
               {'name': 'Panel', 'w': 900, 'h': 300, 'qty': 2, 'rotate': True}]},
    {'id': 'lettering', 'label': 'Complex: PLATINUM lettering 300 mm Arial Bold + two discs (shape engine)',
     'job': 'Lettering test', 'product': 'acm', 'sheet': {'w': 2440, 'h': 1220}, 'mode': 'complex', 'rot_step': 45,
     'parts': [{'name': 'Sign text', 'w': 0, 'h': 300, 'qty': 1, 'rotate': True, 'shape': {'type': 'text', 'text': 'PLATINUM', 'height': 300, 'font': 'Arial Bold'}},
               {'name': 'Disc', 'w': 400, 'h': 400, 'qty': 2, 'rotate': True, 'shape': {'type': 'circle'}}]},
]

# ------------------------------------------------------------------ Trello import (optional)
def _trello_creds():
    key = os.environ.get('TRELLO_API_KEY'); tok = os.environ.get('TRELLO_TOKEN')
    if key and tok: return key, tok
    for p in (os.path.expanduser('~/GitHub/platinum-shop/.env.production'), os.path.expanduser('~/GitHub/platinum-shop/.env.local')):
        if os.path.exists(p):
            env = {}
            for line in open(p):
                line = line.strip()
                if '=' in line and not line.startswith('#'):
                    k, v = line.split('=', 1); env[k.strip()] = v.strip().strip('"').strip("'")
            if env.get('TRELLO_API_KEY') and env.get('TRELLO_TOKEN'):
                return env['TRELLO_API_KEY'], env['TRELLO_TOKEN']
    return None, None

_DIM = re.compile(r'(\d{2,5}(?:\.\d+)?)\s*(?:mm)?\s*[xX×]\s*(\d{2,5}(?:\.\d+)?)\s*(?:mm)?')
_QTY = re.compile(r'(?:^|\b)(?:qty|quantity|x)\s*[:.]?\s*(\d{1,5})\b|(\d{1,5})\s*(?:x|pcs|pc|units?|off)\b', re.I)

# Material words as they appear on the shop's cards ("Material: SAV", "ACM panel ...").  First pattern that matches a
# line wins, so the clear-acrylic pattern sits above the plain acrylic one.  Plain "aluminium" is left out on purpose:
# it names ACM on some cards and sheet metal on others.
_MATERIAL_WORDS = [
    ('acrylic_clear', re.compile(r'clear\s+(?:acrylic|perspex)|(?:acrylic|perspex)\s+clear', re.I)),
    ('acrylic', re.compile(r'acrylic|perspex|plexi', re.I)),
    ('acm', re.compile(r'\bacm\b|composite|alupanel|dibond|alucobond', re.I)),
    ('corflute', re.compile(r'core?flute|corriboard|\bcorex\b|corrugated\s+plastic', re.I)),
    ('cardboard', re.compile(r'card\s*board|corrugated\s+(?:card|board)', re.I)),
    ('pvc', re.compile(r'foamex|\bforex\b|foam\s*pvc|\bpvc\b|palboard', re.I)),
    ('timber', re.compile(r'\bmdf\b|plywood|\bply\b|timber|\bwood', re.I)),
    ('metal', re.compile(r'stainless|mild\s+steel|\bsteel\b|corten|\bbrass\b|alumin(?:i)?um\s+sheet', re.I)),
    ('vinyl', re.compile(r'\bsav\b|vinyl|self[-\s]adhesive|sticker|decal|wall\s+graphic|floor\s+graphic|one[-\s]way\s+vision', re.I)),
]
_BLOCK_START = re.compile(r'^\W*item\s*[\d.]+\W*$|^[\W_]+$', re.I)          # "- **ITEM 3**", "ITEM 16.1", or a rule line (---, \_\_\_\_)
_STRUCK = re.compile(r'~~.*?~~')                                             # Markdown strikethrough: a cancelled item on the card
_QTY_LINE = re.compile(r'^\W*(?:qty|quantity)\W*(\d{1,5})\b', re.I)          # "**QTY: 7**" on a line of its own
_KEYVAL = re.compile(r'^\W*(?:material|lamination|laminate|printing|print|finish|finishing|size|colour|color|qty|quantity|item|artwork)\b', re.I)

def material_of(text):
    """The material a line names, by the shop's words, or None."""
    for mid, rx in _MATERIAL_WORDS:
        if rx.search(text): return mid
    return None

def parse_card_items(text):
    """Very plain parser: one item per line that carries a W x H.  The shop's cards write each item as a block
    ("ITEM n", "QTY: n", a few words, "Material: SAV", "Size:", "575mm x 560mm"), so a size line takes its quantity,
    name and material from the lines above it in the same block.  Returns candidate parts; the operator checks them."""
    items = []
    block = []                        # lines of the current block above the size line, oldest first
    for raw in text.splitlines():
        line = _STRUCK.sub('', raw).strip(' -*\t')          # struck-through text is cancelled: never a part, never a name
        if not line: continue
        if _BLOCK_START.match(line): block = []; continue
        m = _DIM.search(line)
        if not m: block.append(line); continue
        w, h = float(m.group(1)), float(m.group(2))
        rest = line[:m.start()] + ' ' + line[m.end():]
        q = _QTY.search(rest)
        qty = int(q.group(1) or q.group(2)) if q else 1
        if not q:
            for above in reversed(block):
                ql = _QTY_LINE.match(above)
                if ql: qty = int(ql.group(1)); break
        words = [b for b in block if not _QTY_LINE.match(b) and not _KEYVAL.match(b) and not b.startswith(('\\*', '*'))]
        name = re.sub(r'\s+', ' ', re.sub(_DIM, '', line)).strip(' -:,')
        name = re.sub(_QTY, '', name).strip(' -:,x')
        if not name: name = ' - '.join(words[:2]) or 'Part'
        mat = material_of(line) or next((mm for mm in (material_of(b) for b in reversed(block)) if mm), None)
        items.append({'name': name[:60], 'w': w, 'h': h, 'qty': qty, 'rotate': True, 'material': mat, 'acm': mat == 'acm', 'line': line})
        block = []
    return items

def card_material(items, text=''):
    """What the card is made of: the material named on most lines (ties go to the bigger quantity), else a word
    anywhere on the card, else None.  Also the mix, so the operator is told when a card carries two materials."""
    mix = {}
    for it in items:
        if it.get('material'):
            e = mix.setdefault(it['material'], {'material': it['material'], 'name': MATERIALS[it['material']]['name'], 'lines': 0, 'qty': 0})
            e['lines'] += 1; e['qty'] += it['qty']
    order = sorted(mix.values(), key=lambda e: (-e['lines'], -e['qty']))
    if order: return order[0]['material'], order
    mid = material_of(text)
    return mid, ([{'material': mid, 'name': MATERIALS[mid]['name'], 'lines': 0, 'qty': 0}] if mid else [])

def trello_card(url_or_id, with_files=True):
    key, tok = _trello_creds()
    if not key: raise RuntimeError('Trello credentials not found (TRELLO_API_KEY / TRELLO_TOKEN).')
    m = re.search(r'trello\.com/c/([A-Za-z0-9]+)', url_or_id or '')
    cid = m.group(1) if m else (url_or_id or '').strip()
    if not cid: raise ValueError('Paste the Trello card link (https://trello.com/c/...) or its id in the box, then press Fetch.')
    if not re.fullmatch(r'[A-Za-z0-9]{8,32}', cid): raise ValueError(f'"{cid}" is not a Trello card link or id. Copy the link from the card\'s Share button.')
    q = urllib.parse.urlencode({'key': key, 'token': tok, 'fields': 'name,desc,url', 'checklists': 'all'})
    try:
        with urllib.request.urlopen(f'https://api.trello.com/1/cards/{cid}?{q}', timeout=20) as r:
            card = json.loads(r.read())
    except urllib.error.HTTPError as e:
        if e.code in (400, 404): raise ValueError('Trello has no card at that link. Open the card in Trello and copy its link again.')
        if e.code in (401, 403): raise ValueError('Trello refused the shop token for that card (it may be on a board the token cannot see).')
        raise ValueError(f'Trello answered HTTP {e.code} for that card.')
    except (urllib.error.URLError, TimeoutError, OSError) as e:
        raise ValueError(f'Trello could not be reached from this Mac ({getattr(e, "reason", e)}). Check the internet connection.')
    text = card.get('name', '') + '\n' + card.get('desc', '')
    for cl in card.get('checklists', []) or []:
        for it in cl.get('checkItems', []): text += '\n' + it.get('name', '')
    items = parse_card_items(text)
    mid, mix = card_material(items, text)
    files, notes = card_files(cid, key, tok) if with_files else ([], [])
    return {'name': card.get('name'), 'url': card.get('url'), 'items': items,
            'material': mid, 'product': default_product(mid) if mid else None, 'mix': mix,
            'files': files, 'file_notes': notes, 'check': reconcile_files(items, files) if files else []}

_ATTACH_MAX = 40 * 1024 * 1024   # bytes per attachment; bigger ones are named, not fetched

def _trello_host(url):
    h = (urllib.parse.urlsplit(url).hostname or '').lower()
    return h == 'trello.com' or h.endswith('.trello.com')

class _TrelloRedirect(urllib.request.HTTPRedirectHandler):
    """Attachment downloads 302 to a signed storage link: the OAuth header must not follow them off trello.com."""
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        new = super().redirect_request(req, fp, code, msg, headers, newurl)
        if new is not None and not _trello_host(newurl): new.remove_header('Authorization')
        return new

def _trello_download(url, key, tok):
    """Fetch an attachment.  The Trello key + token go only to trello.com over https (an attachment link that points
    elsewhere, or a redirect that leaves trello.com, is fetched without them)."""
    if not str(url).lower().startswith('https://'): raise ValueError('Trello attachment link is not https.')
    headers = {'Authorization': f'OAuth oauth_consumer_key="{key}", oauth_token="{tok}"'} if _trello_host(url) else {}
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.build_opener(_TrelloRedirect).open(req, timeout=60) as r: return r.read()

_ATT_EXT = re.compile(r'\.(pdf|zip)(?=\W*$)', re.I)   # Trello names read 'NSW - KFC Fairfield.zip -' : the type sits before trailing junk

def attachment_kind(att):
    """'pdf', 'zip' or None for a Trello attachment, from its MIME type, then its name, then its URL."""
    mt = (att.get('mimeType') or '').lower()
    if 'pdf' in mt: return 'pdf'
    if 'zip' in mt: return 'zip'
    for text in (att.get('name') or '', urllib.parse.urlparse(att.get('url') or '').path):
        m = _ATT_EXT.search(text)
        if m: return m.group(1).lower()
    return None

def clean_name(name, kind):
    """'NSW - KFC Fairfield.zip -' -> 'NSW - KFC Fairfield.zip'; a name without the extension gets it back."""
    m = _ATT_EXT.search(name or '')
    base = (name or '')[:m.end()] if m else (name or '').strip(' -_')
    return base if base.lower().endswith('.' + kind) else f'{base or "attachment"}.{kind}'

def pdfs_in(name, data, kind=None):
    """(file name, bytes) for the artwork in one attachment: the PDF itself, or every PDF inside a zip
    (folders flattened, Finder's __MACOSX copies skipped).  Anything else gives nothing."""
    kind = kind or attachment_kind({'name': name})
    if kind == 'pdf': return [(clean_name(name, 'pdf'), data)]
    if kind != 'zip': return []
    import zipfile, io
    out = []
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            for info in z.infolist():
                n = info.filename
                if info.is_dir() or '__MACOSX' in n or os.path.basename(n).startswith('.') or not n.lower().endswith('.pdf'): continue
                out.append((os.path.basename(n), z.read(info)))
    except zipfile.BadZipFile:
        raise ValueError(f'{name} is not a zip file PS Nest can open.')
    return out

def card_files(cid, key, tok, fetch=None, attachments=None):
    """Pull the card's artwork: every PDF attached, loose or inside a zip, stored like an upload.
    Returns (artwork summaries in card order, notes about what was skipped).  `fetch`/`attachments` are for tests."""
    fetch = fetch or (lambda url: _trello_download(url, key, tok))
    if attachments is None:
        q = urllib.parse.urlencode({'key': key, 'token': tok, 'fields': 'name,url,bytes,mimeType,isUpload'})
        try:
            with urllib.request.urlopen(f'https://api.trello.com/1/cards/{cid}/attachments?{q}', timeout=20) as r:
                attachments = json.loads(r.read())
        except Exception as e:
            return [], [f'The card\'s attachments could not be listed ({getattr(e, "reason", e)}); the parts come from the card text only.']
    files, notes = [], []
    for att in attachments:
        kind = attachment_kind(att)
        if not kind: continue
        name = clean_name(att.get('name') or '', kind)
        if (att.get('bytes') or 0) > _ATTACH_MAX:
            notes.append(f'{name} is {(att.get("bytes") or 0) / 1e6:.0f} MB - too big to pull; add it by hand.'); continue
        try:
            data = fetch(att.get('url'))
            got = pdfs_in(name, data, kind)
        except ValueError as e:
            notes.append(str(e)); continue
        except Exception as e:
            notes.append(f'{name} could not be downloaded ({getattr(e, "reason", e)}).'); continue
        if kind == 'zip' and not got: notes.append(f'{name} has no PDF inside.')
        for fname, fdata in got:
            try:
                k = register_artwork(fname, fdata)
            except ValueError as e:
                notes.append(str(e)); continue
            summ = artwork_summary(k, ARTWORKS[k]); summ['from'] = name if kind == 'zip' else None
            files.append(summ)
    return files, notes

def _size_key(w, h):
    a, b = sorted((round(float(w)), round(float(h))))
    return (a, b)

def reconcile_files(items, files):
    """Card text vs artwork files, by part size (either way round).  One entry per size that disagrees:
    quantities that differ, sizes on the card with no file, files with no line on the card.  The operator
    reads these and decides; nothing is dropped or doubled by PS Nest."""
    text, art = {}, {}
    for it in items:
        try: k = _size_key(it['w'], it['h'])
        except (TypeError, ValueError, KeyError): continue
        text.setdefault(k, {'qty': 0, 'lines': 0}); text[k]['qty'] += int(it.get('qty') or 1); text[k]['lines'] += 1
    for f in files:
        c = f.get('cut') or {}
        w, h = (c.get('w'), c.get('h')) if c.get('found') else (f.get('w_mm'), f.get('h_mm'))
        if not w or not h: continue
        k = _size_key(w, h)
        art.setdefault(k, {'qty': 0, 'names': [], 'unknown': 0})
        if f.get('qty_hint'): art[k]['qty'] += f['qty_hint']
        else: art[k]['unknown'] += 1
        art[k]['names'].append(f['name'])
    out = []
    for k in sorted(set(text) | set(art), key=lambda k: (-k[0] * k[1], k)):
        size = f'{k[1]} x {k[0]}'
        t, a = text.get(k), art.get(k)
        if t and not a: out.append({'size': size, 'kind': 'no_file', 'text': f'the card lists {t["qty"]} x {size} but no file of that size came with it'})
        elif a and not t: out.append({'size': size, 'kind': 'no_line', 'text': f'{", ".join(a["names"])} ({size}) has no line on the card'})
        elif a['unknown']: out.append({'size': size, 'kind': 'qty_unknown', 'text': f'{size}: the card says {t["qty"]}; {a["unknown"]} file name{"s" if a["unknown"] > 1 else ""} of that size carr{"y" if a["unknown"] > 1 else "ies"} no quantity - set it on the row'})
        elif a['qty'] != t['qty']: out.append({'size': size, 'kind': 'qty', 'text': f'{size}: the card says {t["qty"]}, the files say {a["qty"]} ({len(a["names"])} file{"s" if len(a["names"]) > 1 else ""}: {", ".join(a["names"])})'})
    return out

# ------------------------------------------------------------------ nesting request
def run_nest(body):
    pid = body.get('product', 'acm')
    if not pid: raise ValueError('Choose the material first - the Material \u2192 cutter box at the top - then Nest.')
    prod = resolve_product(pid, body.get('custom_material'))
    d = dict(prod['defaults']); d.update({k: float(v) for k, v in (body.get('rules') or {}).items() if v not in (None, '')})
    nums = {k: v for k, v in d.items() if isinstance(v, (int, float)) and not isinstance(v, bool)}
    bad = sorted(k for k, v in nums.items() if math.isnan(v) or math.isinf(v))
    if bad: raise ValueError('These rules are not numbers: ' + ', '.join(bad) + '. Use 0 or more (mm).')
    neg = sorted(k for k, v in nums.items() if v < 0)
    if neg: raise ValueError('These rules cannot be negative: ' + ', '.join(neg) + '. Use 0 or more (mm).')
    sheet = body.get('sheet') or prod['sheets'][0]
    sw, sh = float(sheet['w']), float(sheet['h'])
    if not math.isfinite(sw) or not math.isfinite(sh) or sw <= 0 or sh <= 0: raise ValueError('Sheet size must be positive.')
    complex_mode = body.get('mode') == 'complex'
    rot_step = float(body.get('rot_step') or (45 if complex_mode else 90))
    if rot_step <= 0 or rot_step > 180 or abs(360 / rot_step - round(360 / rot_step)) > 1e-6:
        raise ValueError('Rotation step must divide 360 (90, 45, 30, 15, 10 ...).')
    rot_step = rot_step if complex_mode else 90.0
    # turning policy (nest&cut style): none = parts stay as drawn, 90 = turned 0/90, 180 = upside down allowed but never
    # sideways (grain, top edge), free = any angle in 15 degree steps.  Absent -> the mode / step above decide.
    policy = str(body.get('policy') or '').strip().lower()
    if policy not in ('', 'none', '90', '180', 'free'): raise ValueError('Turning must be none, 90, 180 or free.')
    force_upright = policy == 'none'
    if policy == '180': rot_step = 180.0
    elif policy == 'free': rot_step = float(body.get('rot_step') or 15) if complex_mode else 15.0
    elif policy == '90': rot_step = 90.0
    # offcut shape: none / rect (one straight cut) / L (two cuts) / stairs; the tick box maps to rect
    offcut = str(body.get('offcut') or '').strip()
    if offcut:
        offcut = {'rectangle': 'rect', 'straight': 'rect', 'l': 'L', 'l-shaped': 'L', 'stair': 'stairs'}.get(offcut.lower(), offcut)
        if offcut not in ('none', 'rect', 'L', 'stairs'): raise ValueError('Offcut shape must be none, rect, L or stairs.')
        trim_offcut = offcut != 'none'
    else:
        offcut = 'auto'; trim_offcut = bool(d.get('trim_offcut'))
    # edge per side (mm); blank = the edge margin
    sides = body.get('edge_sides') or {}
    def side(k):
        v = sides.get(k) if isinstance(sides, dict) else None
        if v in (None, ''): return None
        try: v = float(v)
        except (TypeError, ValueError): raise ValueError('Edge per side must be numbers (mm).')
        if v < 0: raise ValueError('Edge per side cannot be negative.')
        return v
    edge_l, edge_r, edge_b, edge_t = side('l'), side('r'), side('b'), side('t')
    # remnant / extra stock sheets, used first in this order
    stock = []
    for i, s in enumerate(body.get('stock') or [], 1):
        try: w, h, q = float(s.get('w') or 0), float(s.get('h') or 0), int(s.get('qty') or 1)
        except (TypeError, ValueError, AttributeError): raise ValueError(f'Extra sheet {i}: width, height and quantity must be numbers.')
        if w <= 0 or h <= 0 or q <= 0: raise ValueError(f'Extra sheet {i}: width, height and quantity must be above zero.')
        stock.append((w, h, q))
    # locked parts: (part name, sheet index, x, y, angle) - the page sends them after a drag on the picture
    pins = []
    for i, p in enumerate(body.get('pins') or [], 1):
        try: pins.append((str(p['name']), int(p.get('sheet') or 0), float(p['x']), float(p['y']), float(p.get('angle') or 0)))
        except (KeyError, TypeError, ValueError): raise ValueError(f'Locked part {i}: needs a name, a sheet and x / y in mm.')
    try: time_budget = float(body.get('time') or os.environ.get('PSNEST_TIME_BUDGET') or 45.0)
    except (TypeError, ValueError): raise ValueError('Nesting time must be a number of seconds.')
    time_budget = min(300.0, max(3.0, time_budget))
    rules = Rules(sw, sh, edge=d['edge'], gap=d['gap'], clamp=d['clamp'], min_offcut=d['min_offcut'], rot_step=rot_step, roll=prod['roll'],
                  trim_offcut=trim_offcut, edge_l=edge_l, edge_r=edge_r, edge_b=edge_b, edge_t=edge_t, offcut=offcut,
                  pins=tuple(pins), stock=tuple(stock))
    if rules.usable_w <= 0 or rules.usable_h <= 0: raise ValueError('The edges leave no room on the sheet: reduce the edge margins.')
    warnings, notes = [], []
    if force_upright: notes.append('Turning: none. Every part is placed as drawn, even where a turn would save material.')
    elif policy == '180': notes.append('Turning: 180 degrees only. Parts may go upside down but never sideways.')
    if stock: notes.append('Extra sheets first: ' + ', '.join(f'{q} x {w:g} x {h:g} mm' for w, h, q in stock) + f', then {sw:g} x {sh:g} mm sheets as needed.')
    tool = prod['tool']['kind']                     # bit (router), kerf (lasers) or knife
    if d['gap'] < d['bit_diameter']:
        what = 'bit' if tool == 'bit' else 'kerf'
        warnings.append(f"Gap {d['gap']:g} mm is smaller than the {what} ({d['bit_diameter']:g} mm): neighbouring parts would share a cut. Set the gap to at least the {what} unless you intend a shared line.")
    if tool == 'bit' and 0 < d['corner_radius'] < d['bit_diameter'] / 2:
        warnings.append(f"Corner radius {d['corner_radius']:g} mm is smaller than half the bit; the router cannot cut it.")
    try: thickness = float(body['thickness']) if body.get('thickness') not in (None, '') else None
    except (TypeError, ValueError): raise ValueError('Thickness must be a number (mm).')
    if thickness is not None and (not math.isfinite(thickness) or thickness <= 0): raise ValueError('Thickness must be above zero.')
    printer = (body.get('printer') or prod['printer']) if prod['printer'] else None
    if printer and printer not in [x['id'] for x in prod['printers']]:
        raise ValueError(f'"{printer}" is not a printer for {prod["material_name"]}: choose one of ' + ', '.join(x['name'] for x in prod['printers']) + '.')
    warnings += machine_warnings(prod, sw, sh, thickness=thickness, gap=d['gap'], printer=printer)
    blocks = machine_blocks(prod, thickness=thickness, printer=printer)
    if blocks: raise ValueError(' '.join(blocks))
    if prod['printer'] and d['gap'] < 2 * d['bleed'] - 1e-9:
        notes.append(f"Gap {d['gap']:g} mm is less than twice the {d['bleed']:g} mm bleed: the print PDF trims each part's bleed to {d['gap'] / 2:g} mm so neighbours cannot overprint.")
    mirror = bool(body.get('mirror', prod['mirror']))
    cut_line = body.get('cut_line') or 'cutcontour'
    if cut_line not in ('cutcontour', 'black'): raise ValueError('Cut PDF lines must be "cutcontour" or "black".')
    if d['edge'] == 0:
        warnings.append('Edge is 0 mm: parts use the raw sheet edge as a finished edge. Only do this if the sheet is square to the datum and the edge is clean.')
    plist = []
    for i, p in enumerate(body.get('parts') or [], 1):
        spec = p.get('shape') or None
        stype = (spec or {}).get('type', 'rect')
        try:
            w, h, qty = float(p.get('w') or 0), float(p.get('h') or 0), int(p.get('qty', 1))
        except (ValueError, TypeError):
            raise ValueError(f'Part row {i}: width, height and quantity must be numbers.')
        if qty <= 0: raise ValueError(f'Part row {i}: quantity must be above zero.')
        if stype in ('rect', 'ellipse', 'triangle', 'right_triangle', 'rhombus') and (w <= 0 or h <= 0) and not ((ARTWORKS.get(p.get('artwork')) or {}).get('cut') or {}).get('found'):
            raise ValueError(f'Part row {i}: width and height must be above zero.')
        if stype in ('circle', 'polygon', 'star') and w <= 0: raise ValueError(f'Part row {i}: size must be above zero.')
        name = (p.get('name') or f'Part {i}').strip()
        rotate, art = bool(p.get('rotate', True)) and not force_upright, p.get('artwork') or None
        cut = (ARTWORKS.get(art) or {}).get('cut') or {} if art else {}
        if stype == 'contour' and not cut.get('found'):
            raise ValueError(f'Part row {i} ({name}): shape is CutContour but ' + ('no artwork is attached.' if not art or art not in ARTWORKS else 'the artwork has no CutContour line.'))
        if cut.get('found'):
            # print & cut: the part is exactly the artwork's CutContour line; typed sizes and shapes do not apply
            if cut.get('error'):
                fix = fix_for(cut['error'])
                raise ValueError(f'Part row {i} ({name}): artwork "{ARTWORKS[art]["name"]}": {cut["error"]}' + (' ' + fix if fix else ''))
            g = pdfcut.geometry(cut)
            tl = shapes._tuple_loops
            plist.append((Part(name, g['w'], g['h'], rotate=rotate, artwork=art, outline=tl([g['outline']])[0], holes=tl(g['holes']),
                               islands=tl(g['islands']), shape={'type': 'contour'}), qty))
            continue
        if stype == 'rect':
            plist.append((Part(name, w, h, rotate=rotate, artwork=art), qty)); continue
        try: geoms = shapes.build(spec, w, h, OUTLINES)
        except ValueError as e: raise ValueError(f'Part row {i} ({name}): {e}')
        for g in geoms:
            label = f"{name} {g['label']}" if g.get('label') else name
            plist.append((Part(label, g['w'], g['h'], rotate=rotate, artwork=art if stype == 'outline' else None,
                               outline=g['outline'], holes=g['holes'], islands=g['islands'], shape=dict(spec)), qty * g.get('count', 1)))
    if not plist: raise ValueError('Add at least one part.')
    seen_names = {}
    for part, _ in plist: seen_names[part.name] = seen_names.get(part.name, 0) + 1
    dup = sorted(n for n, c in seen_names.items() if c > 1)
    if dup: warnings.append('Rows share the same name (' + ', '.join(dup) + '): each row still nests as its own part, but labels, '
                            'locks and the parts list cannot tell them apart. Give each row its own name.')
    if mirror:                                       # reverse print on clear material: every part as seen from the back
        plist = [(_mirrored(part), qty) for part, qty in plist]
        notes.append('Reverse print: every part is mirrored, artwork and cut line together, in the print PDF, the cut PDF and the DXF. Print on the back of the clear sheet and cut with the same face up.')
    for part, _ in plist:
        cut = (ARTWORKS.get(part.artwork) or {}).get('cut') if (part.shape or {}).get('type') == 'contour' else None
        over = outputs.contour_overhang(cut) if cut else 0.0
        if over > d['gap'] / 2 + 0.05:
            msg = (f'{part.name}: the artwork carries {over:.1f} mm of bleed past its CutContour line. The print PDF trims it to '
                   f'{d["gap"] / 2:g} mm (half the {d["gap"]:g} mm gap) so it cannot print onto a neighbouring part.')
            if msg not in notes: notes.append(msg)
    parts = expand(plist)
    run_id = str(body.get('run_id') or '')[:40]
    run = (RUNS.pop(run_id, None) if run_id else None) or _new_run()
    if run_id: RUNS[run_id] = run          # a Stop that arrived before this line is already counted on the popped entry

    def progress(**fields):
        run['progress'].update(fields)
        if PROGRESS_HOOK: PROGRESS_HOOK(**fields)
    t0 = time.time()
    if pins:
        known = {p.name for p in parts} | {p.name.split(' #')[0] for p in parts}
        lost = [pn[0] for pn in pins if pn[0] not in known]
        if lost: warnings.append('Locked parts not in this list were ignored: ' + ', '.join(sorted(set(lost))) + '.')
    try:
        try:
            sheets, info = nest(parts, rules, time_budget=time_budget, should_stop=lambda: run['stops'], progress=progress)
            problems = validate_shapes(sheets, parts, rules) if info.get('engine') == 'shapes' else validate(sheets, parts, rules)
        except Stopped: raise
        except Exception as e:
            if not pins: raise
            problems = [f'{type(e).__name__}: {e}']
        if problems and pins:       # a locked part that cannot sit where it was put: nest again free and say so
            warnings.append('The locked parts could not be kept where they were (' + '; '.join(problems)[:300] + '). This layout was nested without the locks.')
            rules = _replace(rules, pins=())
            sheets, info = nest(parts, rules, time_budget=time_budget, should_stop=lambda: run['stops'], progress=progress)
            problems = validate_shapes(sheets, parts, rules) if info.get('engine') == 'shapes' else validate(sheets, parts, rules)
    except Stopped as e:
        raise ValueError(str(e))
    finally:
        if run_id: RUNS.pop(run_id, None)
    elapsed = time.time() - t0
    if info.get('stopped'):
        warnings.append(f"Stopped after {elapsed:.0f} s: this is the best of the {info.get('tried', 0)} layout"
                        f"{'s' if info.get('tried', 0) != 1 else ''} finished before Stop was pressed, not the full search.")
    if problems: raise RuntimeError('Internal check failed: ' + '; '.join(problems))
    job_name = (body.get('job') or 'Untitled job').strip()
    settings = {'edge': d['edge'], 'gap': d['gap'], 'bleed': d['bleed'], 'clamp': d['clamp'], 'corner_radius': d['corner_radius'],
                'bit_diameter': d['bit_diameter'], 'min_offcut': d['min_offcut'], 'trim_offcut': bool(d.get('trim_offcut')), 'sheet_w': sw, 'sheet_h': sh, 'product': body.get('product', 'acm'),
                'mode': 'complex' if complex_mode else 'simple', 'rot_step': rules.rot_step, 'thickness': thickness, 'mirror': mirror, 'cut_line': cut_line,
                'custom_material': body.get('custom_material') if pid == 'custom' else None,
                'material': prod['material_name'], 'cutter': prod['cutter_name'], 'printer': MACHINES[printer]['name'] if printer else None, 'roll': prod['roll'],
                'policy': policy or ('free' if complex_mode else '90'), 'offcut': rules.offcut_shape, 'time': time_budget,
                'edge_sides': {'l': rules.ml - d['clamp'], 'r': rules.mr - d['clamp'], 'b': rules.mb - d['clamp'], 't': rules.mt - d['clamp']},
                'stock': [{'w': w, 'h': h, 'qty': q} for w, h, q in stock], 'pins': len(rules.pins)}
    rep = outputs.report(sheets, rules, info, job_name, settings)
    rep['seconds'] = round(elapsed, 2); rep['warnings'] = warnings; rep['notes'] = notes; rep['checks_passed'] = True
    rep['parts_total'] = len(parts)
    rep['media_used_mm'] = round(sum(e['used_length_mm'] for e in rep['sheets']), 1)
    rep['process'] = {'id': pid, 'name': prod['name'], 'roll': prod['roll'], 'output': prod['output'], 'mirror': mirror}
    rep['mode'] = settings['mode']; rep['rot_step'] = rules.rot_step; rep['stopped'] = bool(info.get('stopped'))
    jid = uuid.uuid4().hex[:10]
    request = {k: v for k, v in body.items() if k not in ('run_id',)}     # what the page sent, so Projects can re-open the job
    JOBS[jid] = {'sheets': sheets, 'rules': rules, 'parts': parts, 'info': info, 'settings': settings, 'job': job_name,
                 'print': {'outlines': bool(body.get('print_outlines')), 'corner_marks': bool(body.get('corner_marks')),
                           'frame': bool(body.get('sheet_frame', True)), 'cut_line': cut_line}, 'report': rep,
                 'request': request, 'created': time.time()}
    rep['job_id'] = jid; rep['created'] = JOBS[jid]['created']
    rep['words'] = result_words(rep, prod)
    rep['file_label'] = file_label(job_name)
    rep['print_blocked'] = print_reason(JOBS[jid])
    rep['cut_blocked'] = cut_reason(JOBS[jid]); rep['cut_parts'] = sum(1 for p in parts if _is_contour(p))
    save_job(jid, JOBS[jid])
    rep['svg'] = [outputs.write_svg(s, rules, d['corner_radius']) for s in sheets]
    return rep

def _safe(name):
    return re.sub(r'[^A-Za-z0-9._-]+', '-', name).strip('-') or 'job'

def _mm_label(v):
    return str(int(round(v))) if abs(v - round(v)) < 0.05 else ('%.1f' % v)

SHORT_MATERIAL = {'acm': 'ACM', 'acrylic': 'Acrylic', 'acrylic_clear': 'Clear acrylic', 'pvc': 'PVC', 'corflute': 'Corflute',
                  'cardboard': 'Cardboard', 'timber': 'Timber', 'metal': 'Metal', 'vinyl': 'Vinyl'}

def file_label(job_name):
    """The job's PL number when the name carries one (PL014508), else the name itself made safe for a file name."""
    m = re.search(r'\bPL\s?-?\s?(\d{5,6})\b', job_name or '', re.I)
    if m: return 'PL' + m.group(1)
    return re.sub(r'[\\/:*?"<>|]+', '-', (job_name or '').strip()).strip(' .-') or 'job'

def short_material(job):
    pid = (job.get('settings') or {}).get('product') or ''
    if pid == 'custom': return file_label(job['settings'].get('material') or 'Custom material')
    prod = PRODUCTS.get(pid) or {}
    return SHORT_MATERIAL.get(prod.get('material'), (prod.get('material_name') or 'material').split(' (')[0].split(',')[0])

def result_words(rep, prod):
    """The result as one plain sentence for the team and for WhatsApp: sheets, parts, material used, what comes back to the rack."""
    n = rep['sheet_count']; roll = prod.get('roll')
    sheets = rep['sheets']
    if roll:
        head = f"{rep['parts_total']} parts on {(rep['media_used_mm'] / 1000):.2f} m of {rep['sheet_mm'][1]:g} mm roll, cut in {n} pass{'es' if n != 1 else ''}"
    else:
        sizes = {}
        for s in sheets: sizes[tuple(s['sheet_mm'])] = sizes.get(tuple(s['sheet_mm']), 0) + 1
        what = ', '.join(f'{c} x {w:g} x {h:g} mm' for (w, h), c in sizes.items())
        head = f"{rep['parts_total']} parts on {n} sheet{'s' if n != 1 else ''} ({what})"
    words = head + f", {rep['utilisation'] * 100:.0f}% of the material used."
    last = sheets[-1] if sheets else None
    if last and not roll:
        oc = last.get('offcut') or {}
        words += ' Last sheet: ' + (oc.get('words') or 'no offcut worth keeping') + '.'
    return words

def per_sheet_files(job, kind, pdf):
    """Split a multi-page print or cut PDF into one single-page PDF per sheet, named the way the operator files them
    (Marcio, 18-Sep-2026): 'PL014508 - ACM - sheet 1 of 3 - cut 2440x1220.pdf'.  The number pairs print with cut,
    the size is the sheet (or roll pass) the page was nested on, so the printer sees the final size."""
    import io
    from pypdf import PdfReader, PdfWriter
    rules, sheets = job['rules'], job['sheets']
    label, mat = file_label(job['job']), short_material(job)
    files = {}
    pages = PdfReader(io.BytesIO(pdf)).pages
    for i, page in enumerate(pages, 1):
        rs = rules.for_sheet(sheets[i - 1]) if i <= len(sheets) else rules
        size = f'{_mm_label(rs.sheet_w)}x{_mm_label(rs.sheet_h)}'
        w = PdfWriter(); w.add_page(page); buf = io.BytesIO(); w.write(buf)
        files[f'{label} - {mat} - sheet {i} of {len(pages)} - {kind} {size}.pdf'] = buf.getvalue()
    return files

def print_reason(job):
    """Why the 1:1 print PDF would be blank, or None when there is something to print.
    A print file with nothing on it looked like a broken download (16-Sep-2026), so it is never produced."""
    gone = sorted({p.name.split(' #')[0] for p in job['parts'] if p.artwork and p.artwork not in ARTWORKS})
    if gone: return ('The artwork of these parts was removed from PS Nest, so their print image is gone: ' + ', '.join(gone) +
                     '. Upload it again and nest again.')
    if job['print']['outlines'] or job['print']['corner_marks']: return None
    if any(p.artwork and p.artwork in ARTWORKS for p in job['parts']): return None
    return ('Nothing to print: no part has artwork attached and cut outlines / corner marks are off, '
            'so the 1:1 print PDF would be blank pages. Attach artwork or tick an option under Print PDF, then nest again.')

def _is_contour(part): return (part.shape or {}).get('type') == 'contour'

def _mirrored(part):
    """The part as seen from the back (x -> w - x).  The flag travels in `shape`, so the writers mirror the artwork and
    the replayed cut line the same way and a stored job keeps it."""
    from . import geom
    from dataclasses import replace
    tl = shapes._tuple_loops
    shape = dict(part.shape or {'type': 'rect'}); shape['mirror'] = True
    if part.outline is None: return replace(part, shape=shape)
    return replace(part, shape=shape, outline=tl([geom.mirror_x(part.outline, part.w)])[0],
                   holes=tl([geom.mirror_x(h, part.w) for h in part.holes]), islands=tl([geom.mirror_x(o, part.w) for o in part.islands]))

def cut_reason(job):
    """Why the CutContour cut PDF cannot be made, or None.  Cut lines only ever come from the artwork files,
    so every part must carry one: a part without it would silently not be cut."""
    parts = job['parts']
    if not any(_is_contour(p) for p in parts): return 'No part has artwork with a CutContour line.'
    missing = sorted({p.name.split(' #')[0] for p in parts if not _is_contour(p)})
    if missing: return 'These parts have no CutContour line in their artwork, so the cutter would skip them: ' + ', '.join(missing) + '.'
    gone = sorted({p.name.split(' #')[0] for p in parts if p.artwork not in ARTWORKS})
    if gone: return 'The artwork of these parts was removed from PS Nest, so their cut line is gone: ' + ', '.join(gone) + '. Upload it again and nest again.'
    return None

def job_files(job, which):
    """Return (filename, bytes, content_type) for a download kind."""
    sheets, rules, st = job['sheets'], job['rules'], job['settings']
    base = _safe(job['job']); r = st['corner_radius']
    if which == 'dxf':
        files = {f'{base}-sheet-{i}.dxf': outputs.write_dxf(s, rules, r, labels=False).encode() for i, s in enumerate(sheets, 1)}
        return f'{base}-dxf.zip', outputs.bundle(files), 'application/zip'
    if which == 'dxf-labels':
        files = {f'{base}-sheet-{i}-labelled.dxf': outputs.write_dxf(s, rules, r, labels=True).encode() for i, s in enumerate(sheets, 1)}
        return f'{base}-dxf-labelled.zip', outputs.bundle(files), 'application/zip'
    if which == 'print':
        reason = print_reason(job)
        if reason: raise ValueError(reason)
        used = {p.artwork for p in job['parts'] if p.artwork in ARTWORKS}
        arts = {k: print_artwork(k, rules.gap / 2) for k in used}
        cuts = {k: ARTWORKS[k]['cut'] for k in used if (ARTWORKS[k].get('cut') or {}).get('found')}
        pdf, warns = outputs.write_print_pdf(sheets, rules, arts, bleed=st['bleed'], outlines=job['print']['outlines'],
                                             corner_marks=job['print']['corner_marks'], corner_radius=r, cuts=cuts, frame=job['print'].get('frame', True))
        job['report']['print_warnings'] = warns
        return f'{base}-print-1to1.pdf', pdf, 'application/pdf'
    if which == 'cut':
        reason = cut_reason(job)
        if reason: raise ValueError(reason)
        cuts = {p.artwork: ARTWORKS[p.artwork]['cut'] for p in job['parts']}
        return f'{base}-cut-contour.pdf', outputs.write_cut_pdf(sheets, rules, cuts, frame=job['print'].get('frame', True), style=job['print'].get('cut_line', 'cutcontour')), 'application/pdf'
    if which in ('print-files', 'cut-files'):
        # One file per sheet / pass, named the way the design team hands files to the printer (Ingrid, 18-Sep-2026):
        # 1_print_2440x1220.pdf goes with 1_cut_2440x1220.pdf - the number pairs them, the size is the final sheet.
        kind = which.split('-')[0]
        _, pdf, _ = job_files(job, kind)
        return f'{base}-{kind}-files.zip', outputs.bundle(per_sheet_files(job, kind, pdf)), 'application/zip'
    if which == 'layout':
        return f'{base}-layout.pdf', outputs.write_layout_pdf(sheets, rules, job['job'], job['info'], r), 'application/pdf'
    if which == 'report':
        rep = {k: v for k, v in job['report'].items() if k != 'svg'}
        return f'{base}-report.json', json.dumps(rep, indent=2).encode(), 'application/json'
    if which == 'all':
        files = {}
        for kind in ('dxf', 'print', 'cut', 'layout', 'report'):
            if kind == 'print' and print_reason(job): continue
            if kind == 'cut' and cut_reason(job): continue
            n, b, _ = job_files(job, kind)
            if kind == 'dxf':
                for i, s in enumerate(sheets, 1): files[f'{base}-sheet-{i}.dxf'] = outputs.write_dxf(s, rules, r).encode()
            elif kind in ('print', 'cut'): files.update(per_sheet_files(job, kind, b))
            else: files[n] = b
        return f'{base}-all.zip', outputs.bundle(files), 'application/zip'
    raise KeyError(which)

# ------------------------------------------------------------------ parts list from a spreadsheet
_COLS = {'name': ('name', 'part', 'item', 'description', 'title', 'file', 'filename', 'artwork'),
         'w': ('w', 'width', 'w mm', 'width mm', 'length', 'x'), 'h': ('h', 'height', 'h mm', 'height mm', 'y'),
         'qty': ('qty', 'quantity', 'q', 'count', 'pcs', 'pieces', 'no', 'number'), 'artwork': ('artwork', 'file', 'filename', 'pdf')}

def _sheet_rows(name, data):
    """CSV / XLSX / XLS-as-CSV -> list of rows (lists of strings)."""
    import io, csv
    if re.search(r'\.xlsx$', name or '', re.I):
        try: import openpyxl
        except ImportError: raise ValueError('Reading .xlsx needs the openpyxl package (pip install openpyxl). Save the list as CSV instead.')
        wb = openpyxl.load_workbook(io.BytesIO(data), read_only=True, data_only=True)
        ws = wb[wb.sheetnames[0]]
        return [['' if v is None else str(v) for v in row] for row in ws.iter_rows(values_only=True)]
    if re.search(r'\.xls$', name or '', re.I):
        raise ValueError('Old .xls files are not read. Save the list as .xlsx or CSV.')
    text = data.decode('utf-8-sig', errors='replace')
    dialect = csv.Sniffer().sniff(text[:2000], delimiters=',;\t') if text.strip() else csv.excel
    return [list(r) for r in csv.reader(io.StringIO(text), dialect)]

_UNIT_MM = {'mm': 1.0, 'cm': 10.0, 'm': 1000.0, 'in': 25.4, 'inch': 25.4, 'inches': 25.4, '"': 25.4, "''": 25.4}

def _size_mm(v):
    """A cell such as 1200, 1200mm, 120 cm, 1.2 m, 12in, 6" or 1,200 -> (mm, unit converted from or None).
    A comma between groups of three is a thousands separator (1,200); any other comma is a decimal point (1,5)."""
    s = re.sub(r'\s+', '', str(v or '')).lower()
    if not s: return None, None
    m = re.fullmatch(r"(-?[0-9][0-9.,]*)(mm|cm|m|in|inch|inches|\"|'')?", s)
    if not m: return None, None
    n, unit = m.group(1), m.group(2) or 'mm'
    n = n.replace(',', '') if re.fullmatch(r'-?\d{1,3}(,\d{3})+(\.\d+)?', n) else n.replace(',', '.')
    try: val = float(n)
    except ValueError: return None, None
    return val * _UNIT_MM[unit], (None if unit == 'mm' else unit)

def _qty(q):
    """Quantity cell -> whole number of 1 or more; blank -> 1; anything else -> None (the row is skipped)."""
    s = str(q or '').strip().replace(',', '.')
    if not s: return 1
    try: f = float(s)
    except ValueError: return None
    return int(round(f)) if abs(f - round(f)) < 1e-9 and f >= 1 else None

def parse_partslist(name, data):
    """Spreadsheet -> {'parts': [{'name','w','h','qty','artwork'}], 'notes': [...]}.  Header row is found by its words
    (name / width / height / qty / file); without one, the columns are name, W, H, qty.  Artwork file names are matched to
    the uploaded artworks (with or without .pdf, case does not matter)."""
    rows = [r for r in _sheet_rows(name, data) if any(str(c).strip() for c in r)]
    if not rows: raise ValueError(f'{name}: the file is empty.')
    notes = []; head = None
    for i, r in enumerate(rows[:5]):
        low = [str(c).strip().lower() for c in r]
        if sum(1 for c in low if any(c in v for v in _COLS.values())) >= 2: head = i; break
    if head is None:
        cols = {'name': 0, 'w': 1, 'h': 2, 'qty': 3}; body = rows
        notes.append('No header row found: the columns were read as name, W, H, quantity.')
    else:
        low = [str(c).strip().lower() for c in rows[head]]; cols = {}
        for key, names in _COLS.items():
            for j, c in enumerate(low):
                if c in names and key not in cols and (key != 'name' or c not in ('file', 'filename', 'artwork') or 'name' not in low):
                    cols[key] = j; break
        body = rows[head + 1:]
        if 'qty' not in cols: notes.append('No quantity column: every row is quantity 1.')
    by_name = {}
    for k, a in ARTWORKS.items():
        n = a['name'].lower(); by_name[n] = k; by_name[re.sub(r'\.pdf$', '', n)] = k
    out = []
    for i, r in enumerate(body, head + 2 if head is not None else 1):
        g = lambda key: str(r[cols[key]]).strip() if key in cols and cols[key] < len(r) else ''
        nm, w, h, q = g('name'), g('w'), g('h'), g('qty')
        art = g('artwork') or nm
        key = by_name.get(art.lower()) or by_name.get(re.sub(r'\.pdf$', '', art.lower()))
        (wv, wu), (hv, hu) = _size_mm(w), _size_mm(h)
        if not nm and wv is None and key is None: continue
        if wu or hu: notes.append(f'Row {i} ({nm or "no name"}): sizes given in {wu or hu} were converted to mm.')
        qv = _qty(q)
        if qv is None:
            notes.append(f'Row {i} ({nm or "no name"}): quantity "{q}" is not a whole number of 1 or more, row skipped.'); continue
        if key is None and (wv is None or hv is None):
            notes.append(f'Row {i} ({nm or "no name"}): no size and no matching artwork file, skipped.'); continue
        out.append({'name': nm or (ARTWORKS[key]['name'] if key else f'Part {i}'), 'w': wv, 'h': hv, 'qty': qv, 'artwork': key, 'rotate': True})
    if not out: raise ValueError(f'{name}: no usable rows (each row needs a name and W x H, or an artwork file name that was uploaded).')
    return {'parts': out, 'notes': notes, 'rows': len(out)}

# ------------------------------------------------------------------ NAS: the finished-art folder of a PL number
NAS_INDEX = os.path.expanduser('~/.cache/platinum-nas/index.tsv')
NAS_SETTINGS = nas_settings.NasSettings()

def _nas_creds():
    """Read at call time, never stored: NAS_TS_HOST (or NAS_HOST), NAS_USER, NAS_PASSWORD from the shop's .env.nas."""
    env = {k: os.environ.get(k) for k in ('NAS_TS_HOST', 'NAS_HOST', 'NAS_USER', 'NAS_PASSWORD')}
    p = os.path.expanduser('~/GitHub/platinum-shop/.env.nas')
    if os.path.exists(p):
        for line in open(p):
            line = line.strip()
            if '=' in line and not line.startswith('#'):
                k, v = line.split('=', 1); k = k.strip()
                if k in env and not env[k]: env[k] = v.strip().strip('"').strip("'")
    host = env['NAS_TS_HOST'] or env['NAS_HOST']
    if not (host and env['NAS_USER'] and env['NAS_PASSWORD']): return None
    return host.rstrip('/'), env['NAS_USER'], env['NAS_PASSWORD']

class _Nas:
    def __init__(self, host, user, pw):
        self.api = host + '/webapi/entry.cgi'; self.sid = None; self.user = user; self.pw = pw
    def _get(self, params, timeout=60, raw=False):
        # parameters travel in the POST body, never in the URL: the login password and the session id stay out of
        # every proxy, server and crash log that records request lines
        with _nas_open(self.api, urllib.parse.urlencode(params).encode(), timeout) as r:
            data = r.read()
        if raw: return data
        j = json.loads(data)
        if not j.get('success'): raise ValueError(f'NAS answered error {j.get("error", {}).get("code")}')
        return j.get('data', {})
    def login(self):
        d = self._get({'api': 'SYNO.API.Auth', 'version': '7', 'method': 'login', 'account': self.user, 'passwd': self.pw, 'session': 'FileStation', 'format': 'sid'})
        self.sid = d['sid']
    def list(self, folder):
        d = self._get({'api': 'SYNO.FileStation.List', 'version': '2', 'method': 'list', 'folder_path': folder, 'limit': '1000', '_sid': self.sid})
        return d.get('files', [])
    def download(self, path):
        return self._get({'api': 'SYNO.FileStation.Download', 'version': '2', 'method': 'download', 'mode': 'download', 'path': path, '_sid': self.sid}, timeout=600, raw=True)
    def logout(self):
        if self.sid:
            try: self._get({'api': 'SYNO.API.Auth', 'version': '7', 'method': 'logout', 'session': 'FileStation', '_sid': self.sid}, timeout=10)
            finally: self.sid = None


class _NoNasRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise ValueError('The NAS redirected the connection. Check its address.')


_NAS_OPENER = urllib.request.build_opener(urllib.request.ProxyHandler({}), _NoNasRedirect)


def _nas_open(url, data, timeout):
    return _NAS_OPENER.open(url, data=data, timeout=timeout)


def _nas_failure(error):
    if isinstance(error, (urllib.error.URLError, TimeoutError, OSError)): return 'The NAS could not be reached. Check its address and Tailscale connection.'
    return 'The NAS refused this request. Check the login and folder permissions.'


def _nas_test(details, password):
    nas_settings.require_tailnet_peer(details)
    nas = _Nas(details['host'], details['user'], password)
    try:
        nas.login()
        nas.list(details['root'])
    except Exception as e: raise nas_settings.SettingsError(_nas_failure(e)) from None
    finally:
        if nas.sid:
            try: nas.logout()
            except Exception: pass

def nas_find_job(pl, nas, root='/Platinum'):
    """Find a job under the selected root, using only matching local index paths."""
    rx = re.compile(r'\bPL\s?-?\s?0*' + re.escape(pl.lstrip('PL').lstrip('0')) + r'\b', re.I)
    hits = []
    if os.path.exists(NAS_INDEX):
        for line in open(NAS_INDEX, errors='replace'):
            parts = line.rstrip('\n').split('\t')
            if len(parts) >= 2 and parts[1] == 'dir' and parts[0].startswith(root + '/') and rx.search(os.path.basename(parts[0])): hits.append(parts[0])
    if not hits:
        for f in nas.list(root):
            if f.get('isdir') and isinstance(f.get('path'), str) and f['path'].startswith(root + '/') and rx.search(f['name']): hits.append(f['path'])
    # keep the top-most folder of each hit (a job folder, not its FA/MOCKUP children)
    hits = sorted(set(hits), key=len)
    tops = [h for h in hits if not any(h.startswith(o + '/') for o in hits if o != h)]
    return tops

def nas_job_files(pl):
    """Every PDF in the FA (finished art) folders of the job -> registered artworks + notes, like a Trello card fetch."""
    pl = (pl or '').strip().upper()
    m = re.search(r'(\d{4,6})', pl)
    if not m: raise ValueError('Type the PL number, e.g. PL014508.')
    pl = 'PL' + m.group(1).zfill(6)
    cfg = NAS_SETTINGS.current(_nas_creds())
    if not cfg: raise ValueError('Set up the NAS connection in this app, or copy the PDFs by hand.')
    if cfg['source'] != 'legacy': nas_settings.require_tailnet_peer(cfg)
    nas = _Nas(cfg['host'], cfg['user'], cfg['password'])
    try:
        try: nas.login()
        except Exception as e: raise ValueError(_nas_failure(e)) from None
        return _nas_job_files_logged_in(pl, nas, cfg['root'])
    finally:
        if nas.sid:
            try: nas.logout()
            except Exception: pass


def _nas_job_files_logged_in(pl, nas, root):
    try: tops = nas_find_job(pl, nas, root)
    except Exception as e: raise ValueError(_nas_failure(e)) from None
    if not tops: raise ValueError(f'No folder for {pl} under the selected NAS folder. Check the number, or copy the PDFs by hand.')
    files, notes, seen = [], [], set()
    def walk(folder, depth, fa):
        try: entries = nas.list(folder)
        except Exception as e: raise ValueError(_nas_failure(e)) from None
        for f in entries:
            if not isinstance(f.get('path'), str) or not f['path'].startswith(root + '/'): continue
            if f.get('isdir'):
                if depth < 3 and (fa or re.match(r'FA\b', f['name'], re.I) or f['name'].upper().startswith('FA')): walk(f['path'], depth + 1, True)
                elif depth < 2 and not fa: pass
            elif fa and f['name'].lower().endswith('.pdf') and f['path'] not in seen:
                seen.add(f['path'])
                size = int((f.get('additional') or {}).get('size') or 0)
                if size > _ATTACH_MAX: notes.append(f'{f["name"]} is over 40 MB and was not fetched.'); continue
                try:
                    data = nas.download(f['path'])
                    key = register_artwork(f['name'], data)
                    files.append(artwork_summary(key, ARTWORKS[key]))
                except Exception: notes.append('A NAS file could not be downloaded or read.')
    for top in tops: walk(top, 0, False)
    if not files:
        notes.append(f'{pl}: found ' + ', '.join(tops) + ' but no PDF in an FA folder inside it. Ask the designer to save the finished art there, or drop the PDFs in the box above.')
    return {'pl': pl, 'folders': tops, 'files': files, 'notes': notes, 'name': os.path.basename(tops[0])}

# ------------------------------------------------------------------ phone preview page
def preview_page(jid, job):
    """A one-file page of the result for a phone: the sentence, the numbers and the pictures.  Reached at /p/<id>
    from any device that can see this computer; the Copy-link button on the main page hands the address over."""
    rep = job['report']; sheets = job['sheets']; rules = job['rules']
    svgs = [outputs.write_svg(s, rules, job['settings'].get('corner_radius', 0)) for s in sheets]
    words = rep.get('words') or result_words(rep, PRODUCTS.get(job['settings'].get('product'), {}))
    h = lambda s: str(s).replace('&', '&amp;').replace('<', '&lt;')
    rows = ''.join(f'<div class="sheet"><b>Sheet {s["n"]} of {rep["sheet_count"]}</b> <span>{s["parts"]} part{"" if s["parts"] == 1 else "s"}, {s["utilisation"] * 100:.0f}% used, '
                   f'{h((s.get("offcut") or {}).get("words") or "")}</span>{svg}</div>' for s, svg in zip(rep['sheets'], svgs))
    return f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{h(job["job"])} - PS Nest</title><style>body{{margin:0;font-family:-apple-system,Helvetica,Arial,sans-serif;background:#f6f7f9;color:#1a1a1a;padding:16px}}
h1{{font-size:18px;margin:0 0 6px}}p{{font-size:15px;line-height:1.45;margin:0 0 14px}}.sheet{{background:#fff;border:1px solid #e4e7ec;border-radius:10px;padding:10px;margin-bottom:12px}}
.sheet b{{display:block;font-size:15px}}.sheet span{{font-size:13px;color:#667085;display:block;margin-bottom:6px}}svg{{width:100%;height:auto;display:block}}
.meta{{font-size:12px;color:#667085;margin-top:14px}}</style></head><body><h1>{h(job["job"])}</h1><p>{h(words)}</p>{rows}
<div class="meta">{h(job["settings"].get("material") or "")} on {h(job["settings"].get("cutter") or "")}. PS Nest job {jid}.</div></body></html>'''

# ------------------------------------------------------------------ HTTP
class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        sys.stderr.write('%s - %s\n' % (self.address_string(), fmt % args))

    def _send(self, code, body, ctype='application/json', filename=None):
        if isinstance(body, str): body = body.encode()
        self.send_response(code)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        if filename: self.send_header('Content-Disposition', f'attachment; filename="{filename}"')
        self.end_headers(); self.wfile.write(body)

    def do_GET(self):
        if self.path.split('?', 1)[0].startswith('/api/nas') and not _nas_request_origin(self.headers):
            self._send(403, json.dumps({'error': 'Refused NAS request origin.'})); return
        code, body, ctype, filename = dispatch('GET', self.path)
        self._send(code, body, ctype, filename=filename)

    def do_POST(self):
        if not _local_origin(self.headers) or (self.path.split('?', 1)[0].startswith('/api/nas') and not _nas_request_origin(self.headers)):
            self._send(403, json.dumps({'error': 'Refused: this request did not come from the PS Nest page.'}).encode()); return
        n = int(self.headers.get('Content-Length') or 0)
        raw = self.rfile.read(n) if n else b''
        code, body, ctype, filename = dispatch('POST', self.path, raw)
        self._send(code, body, ctype, filename=filename)


def _local_origin(headers):
    """Only the PS Nest page may change things.  A browser stamps every POST with the page's Origin (or at least a
    Referer); a page on another site carries that site's, so it is refused.  A request with neither header (curl, a
    script, the launcher's own checks) is a local tool and passes."""
    for h in ('Origin', 'Referer'):
        v = headers.get(h)
        if not v: continue
        host = (urllib.parse.urlsplit(v.strip()).hostname or '').lower()
        return host in ('127.0.0.1', 'localhost', '::1')
    return True


def _nas_request_origin(headers):
    """NAS operations require a loopback Host and the exact page origin, including port."""
    host = headers.get('Host', '')
    try:
        h = urllib.parse.urlsplit('http://' + host)
        if h.hostname not in ('127.0.0.1', 'localhost', '::1') or h.username or h.password or h.path or h.query or h.fragment: return False
        port = h.port
    except ValueError: return False
    if port is None: return False
    expected = (h.hostname, port)
    for key in ('Origin', 'Referer'):
        value = headers.get(key)
        if not value: continue
        try:
            p = urllib.parse.urlsplit(value)
            if p.scheme != 'http' or (p.hostname, p.port) != expected or p.username or p.password: return False
        except ValueError: return False
    return True


def _reply(obj, code=200): return code, json.dumps(obj).encode(), 'application/json', None
def _error(msg, code=400): return _reply({'error': str(msg)}, code)


def dispatch(method, path, raw=b''):
    route = urllib.parse.urlparse(path).path
    if method == 'POST' and route.startswith('/api/update/'):
        if route == '/api/update/prepare':
            if not UPDATE_GUARD.prepare():
                return _error('A nesting or import operation is running. Finish it before updating.', 409)
            return _reply({'prepared': True})
        if route == '/api/update/cancel':
            UPDATE_GUARD.cancel()
            return _reply({'prepared': False})
        return _error('Not found', 404)
    if method == 'POST' or route in ('/api/trello', '/api/nas') or route.startswith('/api/job/'):
        try:
            with UPDATE_GUARD.mutation():
                return _dispatch(method, path, raw)
        except ValueError as error:
            return _error(error, 409)
    return _dispatch(method, path, raw)


def _dispatch(method, path, raw=b''):
    """Route one request without any HTTP machinery: (status, body bytes, content type, download
    filename or None).  Used by the local server above and by the browser build (nest/webapp.py),
    where the same call answers the UI from inside a web worker."""
    u = urllib.parse.urlparse(path); q = urllib.parse.parse_qs(u.query)
    if method == 'GET':
        try:
            if u.path in ('/', '/index.html'):
                return 200, open(os.path.join(HERE, 'ui.html'), 'rb').read(), 'text/html; charset=utf-8', None
            if u.path == '/api/nest/progress':
                run = RUNS.get((q.get('run') or [''])[0])
                if run is None: return _reply({'running': False})
                return _reply({'running': True, 'elapsed': round(time.time() - run['started'], 1), **run['progress']})
            if u.path == '/api/products':
                return _reply({'products': PRODUCTS, 'machines': MACHINES, 'cutters': CUTTERS, 'materials': MATERIALS, 'custom_templates': {k: custom_product({'name': 'Custom material', 'cutter': k}) for k in [*CUTTERS, 'custom']}, 'examples': EXAMPLES, 'trello': bool(_trello_creds()[0]), 'release': RELEASE})
            if u.path == '/api/artworks':
                return _reply({'artworks': [artwork_summary(k, v) for k, v in ARTWORKS.items()]})
            if u.path == '/api/outlines':
                return _reply({'outlines': [outline_summary(k, e) for k, e in OUTLINES.items()]})
            if u.path == '/api/fonts':
                global _FONTS
                if _FONTS is None: _FONTS = importers.list_fonts()
                return _reply({'fonts': _FONTS})
            if u.path == '/api/trello':
                try: return _reply(trello_card(q.get('card', [''])[0], with_files=q.get('files', ['1'])[0] != '0'))
                except ValueError as e: return _error(str(e), 400)
            if u.path == '/api/jobs':
                return _reply({'jobs': list_jobs()})
            if u.path == '/api/nas':
                try: return _reply(nas_job_files(q.get('pl', [''])[0]))
                except ValueError as e: return _error(str(e), 400)
                except Exception: return _error('Could not fetch NAS files.', 500)
            if u.path == '/api/nas/settings':
                if sys.platform == 'emscripten': return _error('NAS setup is available in the native app.', 404)
                try: return _reply(NAS_SETTINGS.status(_nas_creds()))
                except nas_settings.SettingsError as e: return _error(str(e), 400)
            m = re.match(r'^/api/job/([0-9a-f]+)/request$', u.path)
            if m:
                job = load_job(m.group(1))
                if not job: return _error('This job is no longer on the server.', 404)
                if not job.get('request'): return _error('This job was nested before Projects existed and cannot be re-opened. Nest it again.', 400)
                return _reply({'request': job['request'], 'job': job['job'], 'created': job.get('created')})
            m = re.match(r'^/p/([0-9a-f]+)$', u.path)
            if m:
                job = load_job(m.group(1))
                if not job: return 404, b'This result is no longer on the server.', 'text/plain; charset=utf-8', None
                return 200, preview_page(m.group(1), job).encode(), 'text/html; charset=utf-8', None
            m = re.match(r'^/api/job/([0-9a-f]+)/(dxf|dxf-labels|print|cut|print-files|cut-files|layout|report|all)$', u.path)
            if m:
                job = load_job(m.group(1))
                if not job: return _error('This result is no longer on the server. Nest again and download the new file.', 404)
                try: name, data, ctype = job_files(job, m.group(2))
                except ValueError as e: return _error(str(e), 400)
                return 200, data, ctype, name
            return _error('Not found', 404)
        except Exception as e:
            return _error(e, 500)
    try:
        body = json.loads(raw or b'{}')
    except json.JSONDecodeError:
        return _error('Bad JSON')
    try:
        if u.path == '/api/nas':
            return _reply(nas_job_files(body.get('pl', '')))
        if u.path.startswith('/api/nas/settings/'):
            if sys.platform == 'emscripten': return _error('NAS setup is available in the native app.', 404)
            if u.path == '/api/nas/settings/clear':
                NAS_SETTINGS.clear(); return _reply(NAS_SETTINGS.status())
            if u.path not in ('/api/nas/settings/test', '/api/nas/settings/save'): return _error('Not found', 404)
            details, password = NAS_SETTINGS.candidate(body, _nas_creds())
            if u.path.endswith('/save') and (not isinstance(body.get('remember'), bool) or body['remember'] and not NAS_SETTINGS.secretstore):
                return _error('Choose session storage or macOS Keychain on a Mac.')
            _nas_test(details, password)
            if u.path.endswith('/test'): return _reply({'ok': True, 'message': 'NAS login and folder access succeeded.'})
            NAS_SETTINGS.save(details, password, body['remember'])
            return _reply(NAS_SETTINGS.status())
        if u.path == '/api/nest':
            return _reply(run_nest(body))
        if u.path == '/api/nest/stop':
            rid = str(body.get('run_id') or '')[:40]
            if not rid: return _error('run_id missing')
            # The server is threaded, so this arrives while /api/nest is still inside the engine; if it somehow
            # arrives first, the pre-counted entry is picked up when the run registers.  First press: keep the
            # best finished layout (finishing the first if none has); second press: abandon (control.py).
            run = RUNS.setdefault(rid, _new_run()); run['stops'] += 1
            return _reply({'ok': True, 'presses': run['stops']})
        if u.path == '/api/artwork':
            key = register_artwork(body.get('name', 'artwork.pdf'), base64.b64decode(body['data']))
            summ = artwork_summary(key, ARTWORKS[key])
            sheet = body.get('sheet') or {}
            try: sw_, sh_ = float(sheet.get('w') or 0), float(sheet.get('h') or 0)
            except (TypeError, ValueError): sw_ = sh_ = 0
            prod = resolve_product('custom', body.get('custom_material')) if body.get('product') == 'custom' else PRODUCTS.get(body.get('product') or '') or {}
            summ['warnings'] = artwork_checks(ARTWORKS[key], sw_ or None, sh_ or None, printed=bool(prod.get('printer', True)),
                                              bleed=(prod.get('defaults') or {}).get('bleed'))
            return _reply(summ)
        if u.path == '/api/partslist':
            data = base64.b64decode(body['data'])
            if len(data) > 5_000_000: raise ValueError('The parts list is over 5 MB.')
            return _reply(parse_partslist(body.get('name') or 'parts.csv', data))
        if u.path == '/api/artwork/delete':
            delete_artwork(body.get('key')); return _reply({'ok': True})
        if u.path == '/api/outline':
            data = base64.b64decode(body['data'])
            if len(data) > 20_000_000: raise ValueError('Outline file is over 20 MB.')
            entry = shapes.parse_upload(body.get('name') or 'outline.dxf', data)
            key = uuid.uuid4().hex[:8]
            OUTLINES[key] = entry; save_outline(key, entry)
            return _reply(outline_summary(key, entry))
        if u.path == '/api/outline/delete':
            delete_outline(body.get('key')); return _reply({'ok': True})
        return _error('Not found', 404)
    except ValueError as e:
        if u.path.startswith('/api/nas/settings/'): return _error(str(e) if isinstance(e, nas_settings.SettingsError) else 'Could not update NAS settings.', 400)
        if u.path == '/api/nas': return _error(str(e), 400)
        return _error(e, 400)
    except Exception as e:
        if u.path.startswith('/api/nas/settings/'): return _error('Could not update NAS settings.', 500)
        if u.path == '/api/nas': return _error('Could not fetch NAS files.', 500)
        return _error(f'{type(e).__name__}: {e}', 500)


def main(port=8765, open_browser=False):
    _ensure_dirs(); _housekeep(); load_artworks(); load_outlines()
    srv = ThreadingHTTPServer(('127.0.0.1', port), Handler)
    url = f'http://127.0.0.1:{port}/'
    print(f'PS Nest running at {url}  (results kept in {DATA})', flush=True)
    if open_browser:
        import webbrowser; webbrowser.open(url)
    try: srv.serve_forever()
    except KeyboardInterrupt: pass

if __name__ == '__main__':
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8765
    main(port, open_browser='--open' in sys.argv)
