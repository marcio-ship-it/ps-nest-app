"""PS Nest local server.  Standard library only for the HTTP side; reportlab + pypdf for the PDFs.

    python3 -m nest.server            # serves http://127.0.0.1:8765
"""
from __future__ import annotations
import base64, json, os, re, sys, time, uuid, urllib.request, urllib.parse
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler

from .engine import Part, Rules, expand, nest, validate
from .shapenest import validate_shapes
from . import outputs, shapes, importers
from .products import PRODUCTS

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.environ.get('PSNEST_DATA') or os.path.join(os.path.dirname(HERE), 'data')
JOBS_DIR = os.path.join(DATA, 'jobs'); ART_DIR = os.path.join(DATA, 'artworks'); OUT_DIR = os.path.join(DATA, 'outlines')
KEEP_DAYS = 60   # job and artwork files older than this are removed at start-up
JOBS = {}        # job id -> dict (cache; the file in JOBS_DIR is the record)
ARTWORKS = {}    # artwork key -> {'name', 'bytes', 'w_mm', 'h_mm'}
OUTLINES = {}    # outline key -> shapes.parse_upload entry (uploaded DXF / SVG cut paths)
_FONTS = None    # cached importers.list_fonts()

def _ensure_dirs():
    for d in (JOBS_DIR, ART_DIR, OUT_DIR): os.makedirs(d, exist_ok=True)

def _housekeep():
    """Drop files older than KEEP_DAYS so the data folder does not grow forever."""
    cutoff = time.time() - KEEP_DAYS * 86400
    for d in (JOBS_DIR, ART_DIR, OUT_DIR):
        for fn in os.listdir(d):
            fp = os.path.join(d, fn)
            try:
                if os.path.getmtime(fp) < cutoff: os.remove(fp)
            except OSError: pass

def load_artworks():
    _ensure_dirs()
    for fn in os.listdir(ART_DIR):
        if not fn.endswith('.json'): continue
        key = fn[:-5]
        try:
            meta = json.load(open(os.path.join(ART_DIR, fn)))
            data = open(os.path.join(ART_DIR, key + '.pdf'), 'rb').read()
        except (OSError, ValueError): continue
        ARTWORKS[key] = {'name': meta['name'], 'bytes': data, 'w_mm': meta['w_mm'], 'h_mm': meta['h_mm']}

def save_artwork(key, art):
    _ensure_dirs()
    open(os.path.join(ART_DIR, key + '.pdf'), 'wb').write(art['bytes'])
    json.dump({'name': art['name'], 'w_mm': art['w_mm'], 'h_mm': art['h_mm']}, open(os.path.join(ART_DIR, key + '.json'), 'w'))

def _loops_json(loops): return [[list(pt) for pt in o] for o in loops]
def _loops_tuple(loops): return tuple(tuple(tuple(pt) for pt in o) for o in (loops or ()))

def load_outlines():
    _ensure_dirs()
    for fn in os.listdir(OUT_DIR):
        if not fn.endswith('.json'): continue
        try: e = json.load(open(os.path.join(OUT_DIR, fn)))
        except (OSError, ValueError): continue
        for g in e['parts']:
            for k in ('outline',): g[k] = _loops_tuple([g[k]])[0]
            for k in ('holes', 'islands'): g[k] = _loops_tuple(g[k])
        OUTLINES[fn[:-5]] = e

def save_outline(key, e):
    _ensure_dirs()
    rec = dict(e); rec['parts'] = [dict(g, outline=_loops_json([g['outline']])[0], holes=_loops_json(g['holes']), islands=_loops_json(g['islands'])) for g in e['parts']]
    json.dump(rec, open(os.path.join(OUT_DIR, key + '.json'), 'w'))

def outline_summary(key, e):
    return {'key': key, 'name': e['name'], 'kind': e['kind'], 'summary': e['summary'], 'warnings': e.get('warnings', []),
            'parts': [{'index': i, 'w': round(g['w'], 2), 'h': round(g['h'], 2), 'holes': len(g['holes']), 'islands': len(g['islands']), 'area': g.get('area')} for i, g in enumerate(e['parts'])]}

def delete_outline(key):
    OUTLINES.pop(key, None)
    try: os.remove(os.path.join(OUT_DIR, key + '.json'))
    except OSError: pass

def delete_artwork(key):
    ARTWORKS.pop(key, None)
    for ext in ('.pdf', '.json'):
        try: os.remove(os.path.join(ART_DIR, key + ext))
        except OSError: pass

def save_job(jid, job):
    """Write the job to disk so downloads survive a restart of the server."""
    _ensure_dirs()
    r = job['rules']
    rec = {'job': job['job'], 'settings': job['settings'], 'print': job['print'], 'info': job['info'],
           'report': {k: v for k, v in job['report'].items() if k != 'svg'},
           'rules': {'sheet_w': r.sheet_w, 'sheet_h': r.sheet_h, 'edge': r.edge, 'gap': r.gap, 'clamp': r.clamp, 'min_offcut': r.min_offcut,
                     'rot_step': r.rot_step, 'grid': r.grid},
           'parts': [{'name': p.name, 'w': p.w, 'h': p.h, 'rotate': p.rotate, 'artwork': p.artwork, 'shape': p.shape,
                      'outline': _loops_json([p.outline])[0] if p.outline else None,
                      'holes': _loops_json(p.holes), 'islands': _loops_json(p.islands)} for p in job['parts']],
           'sheets': [[{'part': job['parts'].index(pl.part), 'x': pl.x, 'y': pl.y, 'w': pl.w, 'h': pl.h, 'rotated': pl.rotated, 'angle': pl.angle}
                       for pl in s.placed] for s in job['sheets']]}
    tmp = os.path.join(JOBS_DIR, jid + '.tmp')
    json.dump(rec, open(tmp, 'w'))
    os.replace(tmp, os.path.join(JOBS_DIR, jid + '.json'))

def load_job(jid):
    """Return the job from the cache or from its file on disk; None if it does not exist."""
    if jid in JOBS: return JOBS[jid]
    fp = os.path.join(JOBS_DIR, jid + '.json')
    if not os.path.exists(fp): return None
    from .engine import Placed, Sheet
    rec = json.load(open(fp))
    parts = [Part(p['name'], p['w'], p['h'], rotate=p['rotate'], artwork=p.get('artwork'), shape=p.get('shape'),
                  outline=_loops_tuple([p['outline']])[0] if p.get('outline') else None,
                  holes=_loops_tuple(p.get('holes')), islands=_loops_tuple(p.get('islands'))) for p in rec['parts']]
    sheets = [Sheet([Placed(parts[pl['part']], pl['x'], pl['y'], pl['w'], pl['h'], pl['rotated'], pl.get('angle', 0.0)) for pl in s]) for s in rec['sheets']]
    job = {'sheets': sheets, 'rules': Rules(**rec['rules']), 'parts': parts, 'info': rec['info'], 'settings': rec['settings'],
           'job': rec['job'], 'print': rec['print'], 'report': rec['report']}
    JOBS[jid] = job
    return job

# ------------------------------------------------------------------ examples
EXAMPLES = [
    {'id': 'inv-15102', 'label': 'INV-15102 Secure Parking, 9 x 500x1100 ACM (Trello DisWiOoC)',
     'job': 'INV-15102 Secure Parking', 'product': 'acm', 'sheet': {'w': 2440, 'h': 1220},
     'parts': [{'name': 'Rate board', 'w': 500, 'h': 1100, 'qty': 9, 'rotate': True}]},
    {'id': 'inv-15136', 'label': 'INV-15136 Secure Parking, 8 x 500x1100 ACM T&C (Trello SuWSCjgQ)',
     'job': 'INV-15136 Secure Parking', 'product': 'acm', 'sheet': {'w': 2440, 'h': 1220},
     'parts': [{'name': 'T&C board', 'w': 500, 'h': 1100, 'qty': 8, 'rotate': True}]},
    {'id': 'mixed', 'label': 'Mixed ACM order (sizes from the Secure Parking 15-Sep schedule, small quantities)',
     'job': 'Mixed ACM test', 'product': 'acm', 'sheet': {'w': 2440, 'h': 1220},
     'parts': [{'name': 'Rate board vertical', 'w': 590, 'h': 1340, 'qty': 4, 'rotate': True},
               {'name': 'Logo rate board', 'w': 850, 'h': 850, 'qty': 3, 'rotate': True},
               {'name': 'P1 rates promo', 'w': 960, 'h': 430, 'qty': 5, 'rotate': True},
               {'name': 'T&Cs small', 'w': 885, 'h': 430, 'qty': 6, 'rotate': True},
               {'name': 'STP QR', 'w': 400, 'h': 600, 'qty': 12, 'rotate': True},
               {'name': 'Level marker', 'w': 400, 'h': 500, 'qty': 8, 'rotate': True}]},
    {'id': 'shapes', 'label': 'Complex: circles, triangles, stars and hexagons at 45° steps (shape engine)',
     'job': 'Shape test', 'product': 'acm', 'sheet': {'w': 2440, 'h': 1220}, 'mode': 'complex', 'rot_step': 45,
     'parts': [{'name': 'Disc', 'w': 600, 'h': 600, 'qty': 3, 'rotate': True, 'shape': {'type': 'circle'}},
               {'name': 'Small disc', 'w': 250, 'h': 250, 'qty': 8, 'rotate': True, 'shape': {'type': 'circle'}},
               {'name': 'Arrow head', 'w': 500, 'h': 400, 'qty': 6, 'rotate': True, 'shape': {'type': 'triangle'}},
               {'name': 'Star', 'w': 450, 'h': 450, 'qty': 4, 'rotate': True, 'shape': {'type': 'star', 'n': 5, 'inner': 0.45}},
               {'name': 'Hex badge', 'w': 350, 'h': 350, 'qty': 6, 'rotate': True, 'shape': {'type': 'polygon', 'n': 6}},
               {'name': 'Panel', 'w': 900, 'h': 300, 'qty': 2, 'rotate': True}]},
    {'id': 'lettering', 'label': 'Complex: PLATINUM lettering 300 mm Arial Bold + two discs (shape engine)',
     'job': 'Lettering test', 'product': 'acm', 'sheet': {'w': 2440, 'h': 1220}, 'mode': 'complex', 'rot_step': 45,
     'parts': [{'name': 'Sign text', 'w': 0, 'h': 300, 'qty': 1, 'rotate': True, 'shape': {'type': 'text', 'text': 'PLATINUM', 'height': 300, 'font': 'Arial Bold'}},
               {'name': 'Disc', 'w': 400, 'h': 400, 'qty': 2, 'rotate': True, 'shape': {'type': 'circle'}}]},
]

# ------------------------------------------------------------------ Trello import (optional)
def _trello_creds():
    key = os.environ.get('TRELLO_API_KEY'); tok = os.environ.get('TRELLO_TOKEN')
    if key and tok: return key, tok
    for p in (os.path.expanduser('~/GitHub/platinum-shop/.env.production'), os.path.expanduser('~/GitHub/platinum-shop/.env.local')):
        if os.path.exists(p):
            env = {}
            for line in open(p):
                line = line.strip()
                if '=' in line and not line.startswith('#'):
                    k, v = line.split('=', 1); env[k.strip()] = v.strip().strip('"').strip("'")
            if env.get('TRELLO_API_KEY') and env.get('TRELLO_TOKEN'):
                return env['TRELLO_API_KEY'], env['TRELLO_TOKEN']
    return None, None

_DIM = re.compile(r'(\d{2,5}(?:\.\d+)?)\s*(?:mm)?\s*[xX×]\s*(\d{2,5}(?:\.\d+)?)\s*(?:mm)?')
_QTY = re.compile(r'(?:^|\b)(?:qty|quantity|x)\s*[:.]?\s*(\d{1,5})\b|(\d{1,5})\s*(?:x|pcs|pc|units?|off)\b', re.I)

def parse_card_items(text):
    """Very plain parser: one item per line that carries a W x H.  Returns candidate parts; the operator checks them."""
    items = []
    for raw in text.splitlines():
        line = raw.strip(' -*\t')
        if not line: continue
        m = _DIM.search(line)
        if not m: continue
        w, h = float(m.group(1)), float(m.group(2))
        qty = 1
        rest = line[:m.start()] + ' ' + line[m.end():]
        q = _QTY.search(rest)
        if q:
            qty = int(q.group(1) or q.group(2))
        name = re.sub(r'\s+', ' ', re.sub(_DIM, '', line)).strip(' -:,') or 'Part'
        name = re.sub(_QTY, '', name).strip(' -:,x') or 'Part'
        is_acm = 'acm' in line.lower() or 'composite' in line.lower()
        items.append({'name': name[:60], 'w': w, 'h': h, 'qty': qty, 'rotate': True, 'acm': is_acm, 'line': line})
    return items

def trello_card(url_or_id):
    key, tok = _trello_creds()
    if not key: raise RuntimeError('Trello credentials not found (TRELLO_API_KEY / TRELLO_TOKEN).')
    m = re.search(r'trello\.com/c/([A-Za-z0-9]+)', url_or_id)
    cid = m.group(1) if m else url_or_id.strip()
    q = urllib.parse.urlencode({'key': key, 'token': tok, 'fields': 'name,desc,url', 'checklists': 'all'})
    with urllib.request.urlopen(f'https://api.trello.com/1/cards/{cid}?{q}', timeout=20) as r:
        card = json.loads(r.read())
    text = card.get('name', '') + '\n' + card.get('desc', '')
    for cl in card.get('checklists', []) or []:
        for it in cl.get('checkItems', []): text += '\n' + it.get('name', '')
    return {'name': card.get('name'), 'url': card.get('url'), 'items': parse_card_items(text)}

# ------------------------------------------------------------------ nesting request
def run_nest(body):
    prod = PRODUCTS[body.get('product', 'acm')]
    d = dict(prod['defaults']); d.update({k: float(v) for k, v in (body.get('rules') or {}).items() if v not in (None, '')})
    sheet = body.get('sheet') or prod['sheets'][0]
    sw, sh = float(sheet['w']), float(sheet['h'])
    if sw <= 0 or sh <= 0: raise ValueError('Sheet size must be positive.')
    complex_mode = body.get('mode') == 'complex'
    rot_step = float(body.get('rot_step') or (45 if complex_mode else 90))
    if rot_step <= 0 or rot_step > 180 or abs(360 / rot_step - round(360 / rot_step)) > 1e-6:
        raise ValueError('Rotation step must divide 360 (90, 45, 30, 15, 10 ...).')
    rules = Rules(sw, sh, edge=d['edge'], gap=d['gap'], clamp=d['clamp'], min_offcut=d['min_offcut'], rot_step=rot_step if complex_mode else 90.0)
    warnings = []
    if d['gap'] < d['bit_diameter']:
        warnings.append(f"Gap {d['gap']:g} mm is smaller than the bit ({d['bit_diameter']:g} mm): neighbouring parts would share a cut. Set the gap to at least the bit diameter unless you intend a shared line.")
    if 0 < d['corner_radius'] < d['bit_diameter'] / 2:
        warnings.append(f"Corner radius {d['corner_radius']:g} mm is smaller than half the bit; the router cannot cut it.")
    if d['edge'] == 0:
        warnings.append('Edge is 0 mm: parts use the raw sheet edge as a finished edge. Only do this if the sheet is square to the datum and the edge is clean.')
    plist = []
    for i, p in enumerate(body.get('parts') or [], 1):
        spec = p.get('shape') or None
        stype = (spec or {}).get('type', 'rect')
        try:
            w, h, qty = float(p.get('w') or 0), float(p.get('h') or 0), int(p.get('qty', 1))
        except (ValueError, TypeError):
            raise ValueError(f'Part row {i}: width, height and quantity must be numbers.')
        if qty <= 0: raise ValueError(f'Part row {i}: quantity must be above zero.')
        if stype in ('rect', 'ellipse', 'triangle', 'right_triangle', 'rhombus') and (w <= 0 or h <= 0):
            raise ValueError(f'Part row {i}: width and height must be above zero.')
        if stype in ('circle', 'polygon', 'star') and w <= 0: raise ValueError(f'Part row {i}: size must be above zero.')
        name = (p.get('name') or f'Part {i}').strip()
        rotate, art = bool(p.get('rotate', True)), p.get('artwork') or None
        if stype == 'rect':
            plist.append((Part(name, w, h, rotate=rotate, artwork=art), qty)); continue
        try: geoms = shapes.build(spec, w, h, OUTLINES)
        except ValueError as e: raise ValueError(f'Part row {i} ({name}): {e}')
        for g in geoms:
            label = f"{name} {g['label']}" if g.get('label') else name
            plist.append((Part(label, g['w'], g['h'], rotate=rotate, artwork=art if stype == 'outline' else None,
                               outline=g['outline'], holes=g['holes'], islands=g['islands'], shape=dict(spec)), qty * g.get('count', 1)))
    if not plist: raise ValueError('Add at least one part.')
    parts = expand(plist)
    t0 = time.time()
    sheets, info = nest(parts, rules, time_budget=float(os.environ.get('PSNEST_TIME_BUDGET') or 45.0))
    elapsed = time.time() - t0
    problems = validate_shapes(sheets, parts, rules) if info.get('engine') == 'shapes' else validate(sheets, parts, rules)
    if problems: raise RuntimeError('Internal check failed: ' + '; '.join(problems))
    job_name = (body.get('job') or 'Untitled job').strip()
    settings = {'edge': d['edge'], 'gap': d['gap'], 'bleed': d['bleed'], 'clamp': d['clamp'], 'corner_radius': d['corner_radius'],
                'bit_diameter': d['bit_diameter'], 'min_offcut': d['min_offcut'], 'sheet_w': sw, 'sheet_h': sh, 'product': body.get('product', 'acm'),
                'mode': 'complex' if complex_mode else 'simple', 'rot_step': rules.rot_step}
    rep = outputs.report(sheets, rules, info, job_name, settings)
    rep['seconds'] = round(elapsed, 2); rep['warnings'] = warnings; rep['checks_passed'] = True
    rep['parts_total'] = len(parts)
    rep['mode'] = settings['mode']; rep['rot_step'] = rules.rot_step
    jid = uuid.uuid4().hex[:10]
    JOBS[jid] = {'sheets': sheets, 'rules': rules, 'parts': parts, 'info': info, 'settings': settings, 'job': job_name,
                 'print': {'outlines': bool(body.get('print_outlines')), 'corner_marks': bool(body.get('corner_marks'))}, 'report': rep}
    rep['job_id'] = jid
    rep['print_blocked'] = print_reason(JOBS[jid])
    save_job(jid, JOBS[jid])
    rep['svg'] = [outputs.write_svg(s, rules, d['corner_radius']) for s in sheets]
    return rep

def _safe(name):
    return re.sub(r'[^A-Za-z0-9._-]+', '-', name).strip('-') or 'job'

def print_reason(job):
    """Why the 1:1 print PDF would be blank, or None when there is something to print.
    A print file with nothing on it looked like a broken download (16-Sep-2026), so it is never produced."""
    if job['print']['outlines'] or job['print']['corner_marks']: return None
    if any(p.artwork and p.artwork in ARTWORKS for p in job['parts']): return None
    return ('Nothing to print: no part has artwork attached and cut outlines / corner marks are off, '
            'so the 1:1 print PDF would be blank pages. Attach artwork or tick an option under Print PDF, then nest again.')

def job_files(job, which):
    """Return (filename, bytes, content_type) for a download kind."""
    sheets, rules, st = job['sheets'], job['rules'], job['settings']
    base = _safe(job['job']); r = st['corner_radius']
    if which == 'dxf':
        files = {f'{base}-sheet-{i}.dxf': outputs.write_dxf(s, rules, r, labels=False).encode() for i, s in enumerate(sheets, 1)}
        return f'{base}-dxf.zip', outputs.bundle(files), 'application/zip'
    if which == 'dxf-labels':
        files = {f'{base}-sheet-{i}-labelled.dxf': outputs.write_dxf(s, rules, r, labels=True).encode() for i, s in enumerate(sheets, 1)}
        return f'{base}-dxf-labelled.zip', outputs.bundle(files), 'application/zip'
    if which == 'print':
        reason = print_reason(job)
        if reason: raise ValueError(reason)
        arts = {k: v['bytes'] for k, v in ARTWORKS.items()}
        pdf, warns = outputs.write_print_pdf(sheets, rules, arts, bleed=st['bleed'], outlines=job['print']['outlines'],
                                             corner_marks=job['print']['corner_marks'], corner_radius=r)
        job['report']['print_warnings'] = warns
        return f'{base}-print-1to1.pdf', pdf, 'application/pdf'
    if which == 'layout':
        return f'{base}-layout.pdf', outputs.write_layout_pdf(sheets, rules, job['job'], job['info'], r), 'application/pdf'
    if which == 'report':
        rep = {k: v for k, v in job['report'].items() if k != 'svg'}
        return f'{base}-report.json', json.dumps(rep, indent=2).encode(), 'application/json'
    if which == 'all':
        files = {}
        for kind in ('dxf', 'print', 'layout', 'report'):
            if kind == 'print' and print_reason(job): continue
            n, b, _ = job_files(job, kind)
            if kind == 'dxf':
                for i, s in enumerate(sheets, 1): files[f'{base}-sheet-{i}.dxf'] = outputs.write_dxf(s, rules, r).encode()
            else: files[n] = b
        return f'{base}-all.zip', outputs.bundle(files), 'application/zip'
    raise KeyError(which)

# ------------------------------------------------------------------ HTTP
class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        sys.stderr.write('%s - %s\n' % (self.address_string(), fmt % args))

    def _send(self, code, body, ctype='application/json', filename=None):
        if isinstance(body, str): body = body.encode()
        self.send_response(code)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        if filename: self.send_header('Content-Disposition', f'attachment; filename="{filename}"')
        self.end_headers(); self.wfile.write(body)

    def do_GET(self):
        code, body, ctype, filename = dispatch('GET', self.path)
        self._send(code, body, ctype, filename=filename)

    def do_POST(self):
        n = int(self.headers.get('Content-Length') or 0)
        raw = self.rfile.read(n) if n else b''
        code, body, ctype, filename = dispatch('POST', self.path, raw)
        self._send(code, body, ctype, filename=filename)


def _reply(obj, code=200): return code, json.dumps(obj).encode(), 'application/json', None
def _error(msg, code=400): return _reply({'error': str(msg)}, code)


def dispatch(method, path, raw=b''):
    """Route one request without any HTTP machinery: (status, body bytes, content type, download
    filename or None).  Used by the local server above and by the browser build (nest/webapp.py),
    where the same call answers the UI from inside a web worker."""
    u = urllib.parse.urlparse(path); q = urllib.parse.parse_qs(u.query)
    if method == 'GET':
        try:
            if u.path in ('/', '/index.html'):
                return 200, open(os.path.join(HERE, 'ui.html'), 'rb').read(), 'text/html; charset=utf-8', None
            if u.path == '/api/products':
                return _reply({'products': PRODUCTS, 'examples': EXAMPLES, 'trello': bool(_trello_creds()[0])})
            if u.path == '/api/artworks':
                return _reply({'artworks': [{'key': k, 'name': v['name'], 'w_mm': v['w_mm'], 'h_mm': v['h_mm']} for k, v in ARTWORKS.items()]})
            if u.path == '/api/outlines':
                return _reply({'outlines': [outline_summary(k, e) for k, e in OUTLINES.items()]})
            if u.path == '/api/fonts':
                global _FONTS
                if _FONTS is None: _FONTS = importers.list_fonts()
                return _reply({'fonts': _FONTS})
            if u.path == '/api/trello':
                return _reply(trello_card(q.get('card', [''])[0]))
            m = re.match(r'^/api/job/([0-9a-f]+)/(dxf|dxf-labels|print|layout|report|all)$', u.path)
            if m:
                job = load_job(m.group(1))
                if not job: return _error('This result is no longer on the server. Nest again and download the new file.', 404)
                try: name, data, ctype = job_files(job, m.group(2))
                except ValueError as e: return _error(str(e), 400)
                return 200, data, ctype, name
            return _error('Not found', 404)
        except Exception as e:
            return _error(e, 500)
    try:
        body = json.loads(raw or b'{}')
    except json.JSONDecodeError:
        return _error('Bad JSON')
    try:
        if u.path == '/api/nest':
            return _reply(run_nest(body))
        if u.path == '/api/artwork':
            data = base64.b64decode(body['data'])
            from pypdf import PdfReader; import io
            pg = PdfReader(io.BytesIO(data)).pages[0]
            key = uuid.uuid4().hex[:8]
            ARTWORKS[key] = {'name': body.get('name', 'artwork.pdf'), 'bytes': data,
                             'w_mm': round(float(pg.mediabox.width) / outputs.MM, 1), 'h_mm': round(float(pg.mediabox.height) / outputs.MM, 1)}
            save_artwork(key, ARTWORKS[key])
            return _reply({'key': key, 'name': ARTWORKS[key]['name'], 'w_mm': ARTWORKS[key]['w_mm'], 'h_mm': ARTWORKS[key]['h_mm']})
        if u.path == '/api/artwork/delete':
            delete_artwork(body.get('key')); return _reply({'ok': True})
        if u.path == '/api/outline':
            data = base64.b64decode(body['data'])
            if len(data) > 20_000_000: raise ValueError('Outline file is over 20 MB.')
            entry = shapes.parse_upload(body.get('name') or 'outline.dxf', data)
            key = uuid.uuid4().hex[:8]
            OUTLINES[key] = entry; save_outline(key, entry)
            return _reply(outline_summary(key, entry))
        if u.path == '/api/outline/delete':
            delete_outline(body.get('key')); return _reply({'ok': True})
        return _error('Not found', 404)
    except ValueError as e:
        return _error(e, 400)
    except Exception as e:
        return _error(f'{type(e).__name__}: {e}', 500)


def main(port=8765, open_browser=False):
    _ensure_dirs(); _housekeep(); load_artworks(); load_outlines()
    srv = ThreadingHTTPServer(('127.0.0.1', port), Handler)
    url = f'http://127.0.0.1:{port}/'
    print(f'PS Nest running at {url}  (results kept in {DATA})', flush=True)
    if open_browser:
        import webbrowser; webbrowser.open(url)
    try: srv.serve_forever()
    except KeyboardInterrupt: pass

if __name__ == '__main__':
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8765
    main(port, open_browser='--open' in sys.argv)
