"""Whole-piece production batches are distinct from the stock left on a roll."""
import math

from .production_worksheet import ROLL_PRODUCTION_BATCH_MAX_MM


def nesting_limit(body, available_mm):
    """Return the requested production cap and the bin length used by the solver.

    Extra sheet allocations belong to the sheet workflow. In particular, an old
    15 m allocation must never bypass the production batch limit on re-nesting.
    Existing saved layouts remain immutable and are checked again at export.
    """
    value = body.get('roll_batch_mm', ROLL_PRODUCTION_BATCH_MAX_MM)
    try:
        if isinstance(value, bool):
            raise ValueError
        cap = float(value)
    except (TypeError, ValueError):
        raise ValueError('Maximum roll batch must be a number above 0 and at most 10,000 mm.')
    if not math.isfinite(cap) or not 0 < cap <= ROLL_PRODUCTION_BATCH_MAX_MM:
        raise ValueError('Maximum roll batch must be above 0 and at most 10,000 mm.')
    if body.get('stock'):
        raise ValueError('Remove extra sheet allocations from this roll job. Enter the actual Roll left and '
                         'Maximum batch instead; existing pieces will be nested whole into separate batches.')
    return cap, min(available_mm, cap)


def supply_warning(sheets, available_mm):
    """A multi-batch layout alone is not evidence that the roll is too short."""
    need = sum(sheet.size[0] for sheet in sheets if sheet.placed and sheet.size)
    if need <= available_mm + 1e-6:
        return None
    return (f'Not enough roll: these batches need {need / 1000:.3f} m but Roll left is '
            f'{available_mm / 1000:g} m. Confirm sufficient stock before production; '
            'the batch limit does not add stock.')
