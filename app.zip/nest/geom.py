"""Outline geometry for PS Nest shapes (Phase 2, 17-Sep-2026).

An *outline* is a closed list of (x, y, bulge) vertices in mm, exactly like a DXF
LWPOLYLINE: the segment from vertex i to vertex i+1 (wrapping) is a straight line when
bulge is 0 and a circular arc otherwise, bulge = tan(included angle / 4), positive =
counter-clockwise.  A *polygon* is a closed list of (x, y) points: the flattened outline.

Part-local outlines are normalised: counter-clockwise, bounding box with its bottom-left
corner at (0, 0).  Everything here is pure Python.
"""
from __future__ import annotations
import math

EPS = 1e-9


# ------------------------------------------------------------------ bulge arcs
def arc_from_bulge(p1, p2, b):
    """(centre, radius, start angle, signed sweep) of the arc p1 -> p2 with bulge b, or None if degenerate."""
    x1, y1 = p1[0], p1[1]; x2, y2 = p2[0], p2[1]
    theta = 4.0 * math.atan(b)                              # included angle, CCW positive
    c = math.hypot(x2 - x1, y2 - y1)
    if c < EPS or abs(theta) < 1e-12: return None
    r = c / (2.0 * math.sin(abs(theta) / 2.0))
    mx, my = (x1 + x2) / 2.0, (y1 + y2) / 2.0
    d = math.sqrt(max(r * r - (c / 2.0) ** 2, 0.0))       # chord midpoint -> centre
    nx, ny = -(y2 - y1) / c, (x2 - x1) / c                  # left normal of the chord
    sgn = 1.0 if b > 0 else -1.0
    # CCW minor arc: centre on the left of the chord; CCW major arc: on the right (mirrored for CW)
    if abs(theta) <= math.pi: cx, cy = mx + sgn * nx * d, my + sgn * ny * d
    else: cx, cy = mx - sgn * nx * d, my - sgn * ny * d
    return (cx, cy), r, math.atan2(y1 - cy, x1 - cx), theta


def flatten(outline, tol=0.1):
    """Outline -> polygon; arcs become chords with sagitta error <= tol mm."""
    pts = []
    n = len(outline)
    for i in range(n):
        v = outline[i]; w = outline[(i + 1) % n]
        pts.append((v[0], v[1]))
        b = v[2] if len(v) > 2 else 0.0
        if abs(b) < 1e-12: continue
        arc = arc_from_bulge(v, w, b)
        if arc is None: continue
        (cx, cy), r, a1, theta = arc
        if r <= tol: k = 4
        else: k = max(1, math.ceil(abs(theta) / (2.0 * math.acos(max(-1.0, 1.0 - tol / r)))))
        for j in range(1, k):
            a = a1 + theta * j / k
            pts.append((cx + r * math.cos(a), cy + r * math.sin(a)))
    return pts


def signed_area(poly):
    s = 0.0; n = len(poly)
    for i in range(n):
        x1, y1 = poly[i][0], poly[i][1]; x2, y2 = poly[(i + 1) % n][0], poly[(i + 1) % n][1]
        s += x1 * y2 - x2 * y1
    return s / 2.0


def area(outline, tol=0.02):
    return abs(signed_area(flatten(outline, tol)))


def centroid(poly):
    a = signed_area(poly)
    if abs(a) < EPS:
        return (sum(p[0] for p in poly) / len(poly), sum(p[1] for p in poly) / len(poly))
    cx = cy = 0.0; n = len(poly)
    for i in range(n):
        x1, y1 = poly[i][0], poly[i][1]; x2, y2 = poly[(i + 1) % n][0], poly[(i + 1) % n][1]
        f = x1 * y2 - x2 * y1
        cx += (x1 + x2) * f; cy += (y1 + y2) * f
    return (cx / (6.0 * a), cy / (6.0 * a))


def bbox_outline(outline):
    """Exact bounding box (x0, y0, x1, y1) including arc extremes."""
    xs = [v[0] for v in outline]; ys = [v[1] for v in outline]
    x0, y0, x1, y1 = min(xs), min(ys), max(xs), max(ys)
    n = len(outline)
    for i in range(n):
        v = outline[i]
        b = v[2] if len(v) > 2 else 0.0
        if abs(b) < 1e-12: continue
        arc = arc_from_bulge(v, outline[(i + 1) % n], b)
        if arc is None: continue
        (cx, cy), r, a1, theta = arc
        for q, (dx, dy) in enumerate(((1, 0), (0, 1), (-1, 0), (0, -1))):
            aq = q * math.pi / 2.0
            # is angle aq inside the sweep from a1 over theta?
            t = (aq - a1) % (2 * math.pi) if theta > 0 else (a1 - aq) % (2 * math.pi)
            if t <= abs(theta) + 1e-12:
                x0, y0, x1, y1 = min(x0, cx + r * dx), min(y0, cy + r * dy), max(x1, cx + r * dx), max(y1, cy + r * dy)
    return (x0, y0, x1, y1)


def bbox_poly(poly):
    xs = [p[0] for p in poly]; ys = [p[1] for p in poly]
    return (min(xs), min(ys), max(xs), max(ys))


def translate(outline, dx, dy):
    return [(v[0] + dx, v[1] + dy, v[2] if len(v) > 2 else 0.0) for v in outline]


def rotate(outline, deg, ox=0.0, oy=0.0):
    """Rotate counter-clockwise by deg about (ox, oy).  Bulges are unchanged."""
    a = math.radians(deg); c, s = math.cos(a), math.sin(a)
    out = []
    for v in outline:
        x, y = v[0] - ox, v[1] - oy
        out.append((ox + x * c - y * s, oy + x * s + y * c, v[2] if len(v) > 2 else 0.0))
    return out


def reverse(outline):
    """Same closed path traversed the other way (bulges negated and re-attached to their new start vertex)."""
    n = len(outline)
    out = []
    for i in range(n):
        v = outline[n - 1 - i]
        b = outline[(n - 2 - i) % n]
        out.append((v[0], v[1], -(b[2] if len(b) > 2 else 0.0)))
    return out


def normalise(outline):
    """Counter-clockwise, bounding box at the origin.  Returns (outline, w, h)."""
    out = [(float(v[0]), float(v[1]), float(v[2]) if len(v) > 2 else 0.0) for v in outline]
    # drop repeated consecutive points (and a closing point equal to the first)
    clean = []
    for v in out:
        if clean and abs(v[0] - clean[-1][0]) < 1e-7 and abs(v[1] - clean[-1][1]) < 1e-7:
            clean[-1] = (clean[-1][0], clean[-1][1], clean[-1][2] or v[2]); continue
        clean.append(v)
    if len(clean) > 1 and abs(clean[0][0] - clean[-1][0]) < 1e-7 and abs(clean[0][1] - clean[-1][1]) < 1e-7:
        last = clean.pop()
        if last[2] and not clean[-1][2]: clean[-1] = (clean[-1][0], clean[-1][1], last[2])
    if len(clean) < 2 or (len(clean) == 2 and not (clean[0][2] or clean[1][2])):
        raise ValueError('outline needs at least three points (or two points with arcs)')
    if signed_area(flatten(clean, 0.05)) < 0: clean = reverse(clean)
    x0, y0, x1, y1 = bbox_outline(clean)
    clean = translate(clean, -x0, -y0)
    return clean, x1 - x0, y1 - y0


def simplify(poly, tol):
    """Douglas-Peucker on a closed polygon.  Keeps at least a triangle."""
    if len(poly) <= 4 or tol <= 0: return list(poly)
    # split at the two farthest-apart points so the closed ring becomes two open chains
    n = len(poly)
    i0 = 0
    i1 = max(range(n), key=lambda i: (poly[i][0] - poly[0][0]) ** 2 + (poly[i][1] - poly[0][1]) ** 2)
    if i1 == 0: return list(poly)
    def dp(pts):
        if len(pts) < 3: return list(pts)
        ax, ay = pts[0]; bx, by = pts[-1]
        dx, dy = bx - ax, by - ay
        L = math.hypot(dx, dy)
        best, bi = -1.0, -1
        for i in range(1, len(pts) - 1):
            px, py = pts[i]
            d = abs(dx * (py - ay) - dy * (px - ax)) / L if L > EPS else math.hypot(px - ax, py - ay)
            if d > best: best, bi = d, i
        if best <= tol: return [pts[0], pts[-1]]
        left = dp(pts[:bi + 1]); right = dp(pts[bi:])
        return left[:-1] + right
    a = dp([(p[0], p[1]) for p in poly[i0:i1 + 1]])
    b = dp([(p[0], p[1]) for p in poly[i1:] + poly[:1]])
    out = a[:-1] + b[:-1]
    return out if len(out) >= 3 else list(poly)


# ------------------------------------------------------------------ predicates and distances
def point_in_poly(x, y, poly):
    inside = False; n = len(poly)
    for i in range(n):
        x1, y1 = poly[i][0], poly[i][1]; x2, y2 = poly[(i + 1) % n][0], poly[(i + 1) % n][1]
        if (y1 > y) != (y2 > y):
            xi = x1 + (y - y1) * (x2 - x1) / (y2 - y1)
            if x < xi: inside = not inside
    return inside


def _orient(ax, ay, bx, by, cx, cy):
    return (bx - ax) * (cy - ay) - (by - ay) * (cx - ax)


def segments_intersect(a, b, c, d):
    """Proper or touching intersection of segments ab and cd."""
    o1 = _orient(a[0], a[1], b[0], b[1], c[0], c[1]); o2 = _orient(a[0], a[1], b[0], b[1], d[0], d[1])
    o3 = _orient(c[0], c[1], d[0], d[1], a[0], a[1]); o4 = _orient(c[0], c[1], d[0], d[1], b[0], b[1])
    if ((o1 > EPS and o2 < -EPS) or (o1 < -EPS and o2 > EPS)) and ((o3 > EPS and o4 < -EPS) or (o3 < -EPS and o4 > EPS)):
        return True
    def on_seg(p, q, r):
        return (min(p[0], q[0]) - EPS <= r[0] <= max(p[0], q[0]) + EPS and min(p[1], q[1]) - EPS <= r[1] <= max(p[1], q[1]) + EPS)
    if abs(o1) <= EPS and on_seg(a, b, c): return True
    if abs(o2) <= EPS and on_seg(a, b, d): return True
    if abs(o3) <= EPS and on_seg(c, d, a): return True
    if abs(o4) <= EPS and on_seg(c, d, b): return True
    return False


def point_seg_dist(px, py, ax, ay, bx, by):
    dx, dy = bx - ax, by - ay
    L2 = dx * dx + dy * dy
    if L2 < EPS: return math.hypot(px - ax, py - ay)
    t = max(0.0, min(1.0, ((px - ax) * dx + (py - ay) * dy) / L2))
    return math.hypot(px - (ax + t * dx), py - (ay + t * dy))


def seg_seg_dist(a, b, c, d):
    if segments_intersect(a, b, c, d): return 0.0
    return min(point_seg_dist(a[0], a[1], c[0], c[1], d[0], d[1]), point_seg_dist(b[0], b[1], c[0], c[1], d[0], d[1]),
               point_seg_dist(c[0], c[1], a[0], a[1], b[0], b[1]), point_seg_dist(d[0], d[1], a[0], a[1], b[0], b[1]))


def poly_distance(p, q, stop_at=None):
    """Minimum distance between two polygons (0 if they touch, cross or one contains the other).
    stop_at: return early once a distance <= stop_at is found (the caller only needs to know it is too close)."""
    if point_in_poly(p[0][0], p[0][1], q) or point_in_poly(q[0][0], q[0][1], p): return 0.0
    best = float('inf')
    n, m = len(p), len(q)
    qb = [(min(q[j][0], q[(j + 1) % m][0]), min(q[j][1], q[(j + 1) % m][1]), max(q[j][0], q[(j + 1) % m][0]), max(q[j][1], q[(j + 1) % m][1])) for j in range(m)]
    for i in range(n):
        a = p[i]; b = p[(i + 1) % n]
        ax0, ay0, ax1, ay1 = min(a[0], b[0]), min(a[1], b[1]), max(a[0], b[0]), max(a[1], b[1])
        for j in range(m):
            bb = qb[j]
            # segment boxes further apart than the current best cannot improve it
            gap = max(bb[0] - ax1, ax0 - bb[2], bb[1] - ay1, ay0 - bb[3], 0.0)
            if gap >= best: continue
            d = seg_seg_dist(a, b, q[j], q[(j + 1) % m])
            if d < best:
                best = d
                if best <= EPS or (stop_at is not None and best <= stop_at): return best
    return best


def self_intersects(poly):
    n = len(poly)
    if n < 4: return False
    segs = [(poly[i], poly[(i + 1) % n]) for i in range(n)]
    boxes = [(min(a[0], b[0]), min(a[1], b[1]), max(a[0], b[0]), max(a[1], b[1])) for a, b in segs]
    for i in range(n):
        bi = boxes[i]
        for j in range(i + 2, n):
            if i == 0 and j == n - 1: continue
            bj = boxes[j]
            if bj[0] > bi[2] or bj[2] < bi[0] or bj[1] > bi[3] or bj[3] < bi[1]: continue
            if segments_intersect(segs[i][0], segs[i][1], segs[j][0], segs[j][1]): return True
    return False


# ------------------------------------------------------------------ primitives (all return normalised outlines)
def rect(w, h, r=0.0):
    r = min(r, w / 2.0, h / 2.0)
    if r <= 0: return [(0.0, 0.0, 0.0), (w, 0.0, 0.0), (w, h, 0.0), (0.0, h, 0.0)]
    b = math.tan(math.pi / 8.0)
    return [(w - r, 0.0, b), (w, r, 0.0), (w, h - r, b), (w - r, h, 0.0), (r, h, b), (0.0, h - r, 0.0), (0.0, r, b), (r, 0.0, 0.0)]


def circle(d):
    r = d / 2.0
    return [(0.0, r, 1.0), (2 * r, r, 1.0)]


def ellipse(w, h, n=72):
    a, b = w / 2.0, h / 2.0
    return [(a + a * math.cos(2 * math.pi * i / n), b + b * math.sin(2 * math.pi * i / n), 0.0) for i in range(n)]


def triangle(w, h):
    return [(0.0, 0.0, 0.0), (w, 0.0, 0.0), (w / 2.0, h, 0.0)]


def right_triangle(w, h):
    return [(0.0, 0.0, 0.0), (w, 0.0, 0.0), (0.0, h, 0.0)]


def rhombus(w, h):
    return [(w / 2.0, 0.0, 0.0), (w, h / 2.0, 0.0), (w / 2.0, h, 0.0), (0.0, h / 2.0, 0.0)]


def regular_polygon(n, d):
    r = d / 2.0; n = max(3, int(n))
    pts = [(r * math.cos(math.pi / 2 + 2 * math.pi * i / n), r * math.sin(math.pi / 2 + 2 * math.pi * i / n), 0.0) for i in range(n)]
    return normalise(pts)[0]


def star(n, d, inner=0.5):
    """n-pointed star, outer diameter d, inner radius = inner * outer radius, one point straight up."""
    n = max(3, int(n)); R = d / 2.0; r = max(0.05, min(0.95, float(inner))) * R
    pts = []
    for i in range(2 * n):
        a = math.pi / 2 + math.pi * i / n
        rr = R if i % 2 == 0 else r
        pts.append((rr * math.cos(a), rr * math.sin(a), 0.0))
    return normalise(pts)[0]


def scale(outline, k):
    return [(v[0] * k, v[1] * k, v[2] if len(v) > 2 else 0.0) for v in outline]


def fit_width(outline, w):
    """Uniformly scale a normalised outline so its bounding-box width is w."""
    x0, y0, x1, y1 = bbox_outline(outline)
    if x1 - x0 < EPS: raise ValueError('outline has no width')
    return normalise(scale(outline, w / (x1 - x0)))[0]


def world_outline(outline, angle, x, y):
    """Place a normalised outline: rotate by angle (deg CCW) then move its bounding box's bottom-left to (x, y)."""
    o = rotate(outline, angle) if angle else [(v[0], v[1], v[2] if len(v) > 2 else 0.0) for v in outline]
    x0, y0, _, _ = bbox_outline(o)
    return translate(o, x - x0, y - y0)


# ------------------------------------------------------------------ multi-loop parts (outline + islands)
def bbox_loops(loops):
    """Union of the loops' bounding boxes.  Each loop is measured on its own: concatenating the vertex
    lists would turn the closing bulge of one loop into a phantom arc to the next loop's first vertex."""
    bs = [bbox_outline(o) for o in loops if o]
    if not bs: return 0.0, 0.0, 0.0, 0.0
    return min(b[0] for b in bs), min(b[1] for b in bs), max(b[2] for b in bs), max(b[3] for b in bs)


def normalise_loops(loops):
    """Every loop CCW, the union's bounding box at the origin.  Returns (loops, w, h)."""
    out = []
    for o in loops:
        c, _, _ = normalise(o)
        x0, y0, _, _ = bbox_outline(o)
        out.append(translate(c, x0, y0))          # normalise() moved it to the origin: put it back
    x0, y0, x1, y1 = bbox_loops(out)
    return [translate(o, -x0, -y0) for o in out], x1 - x0, y1 - y0


def world_loops(loops, angle, x, y):
    """Rotate every loop by `angle` and translate so the union's bbox min corner sits at (x, y)."""
    outs = [rotate(o, angle) if angle else [(v[0], v[1], v[2] if len(v) > 2 else 0.0) for v in o] for o in loops]
    x0, y0, _, _ = bbox_loops(outs)
    return [translate(o, x - x0, y - y0) for o in outs]
