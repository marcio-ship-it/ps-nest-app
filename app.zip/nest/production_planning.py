"""Deterministic production-order planning above the existing nesting engine.

The module decides *which adjacent jobs may share a sheet*.  It deliberately
does not place geometry: every candidate is produced by :func:`engine.nest`
and checked by :func:`engine.validate` before it can enter the plan.

This first integration keeps global-sheet features honest.  Pins, ordered
stock/remnant sheets and roll media need a single global solver run, while the
adjacency policy uses bounded sub-runs.  They are therefore rejected here
rather than silently being reset for each sub-run.
"""
from __future__ import annotations

from collections import OrderedDict
from dataclasses import dataclass
from typing import Callable, Iterable, Mapping

from .engine import Part, Rules, Sheet, nest, validate


AU_STATES = frozenset({"ACT", "NSW", "NT", "QLD", "SA", "TAS", "VIC", "WA"})


class ProductionPlanningError(ValueError):
    """Input or solver output cannot produce a safe automatic plan."""


class UnsupportedPlanningFeature(ProductionPlanningError):
    """A feature cannot yet retain its semantics in bounded planning runs."""


@dataclass(frozen=True)
class ProductionJob:
    """One ordered job with explicit dispatch state and compatibility recipe."""

    job_ref: str
    state: str
    compatibility_key: str
    parts: tuple[Part, ...]

    def __post_init__(self):
        object.__setattr__(self, "parts", tuple(self.parts))


@dataclass(frozen=True)
class PlannedSheet:
    """An existing engine Sheet plus the policy identity needed downstream."""

    sheet: Sheet
    job_refs: tuple[str, ...]
    states: tuple[str, ...]


@dataclass(frozen=True)
class CompatibilityPlan:
    compatibility_key: str
    ordered_job_refs: tuple[str, ...]
    sheets: tuple[PlannedSheet, ...]


@dataclass(frozen=True)
class ProductionPlan:
    compatibility_plans: tuple[CompatibilityPlan, ...]

    @property
    def sheets(self) -> tuple[Sheet, ...]:
        """Flattened existing Sheet structures, in production-plan order."""
        return tuple(ps.sheet for group in self.compatibility_plans for ps in group.sheets)


NestCall = Callable[..., tuple[list[Sheet], dict]]


def plan_production(
    jobs: Iterable[ProductionJob],
    rules_by_compatibility: Mapping[str, Rules],
    *,
    nest_call: NestCall = nest,
    seed: int = 20260916,
    time_budget: float = 45.0,
    attempts: int | None = None,
    should_stop=None,
    progress=None,
    tiny_parts_exception: bool = False,
) -> ProductionPlan:
    """Plan compatible jobs with state-first, stable job ordering.

    At most the final sheet is reconsidered with the next job in sequence. A
    shared layout must save stock and retain every earlier carry piece on the
    first candidate sheet. Consecutive small jobs may share that remainder;
    the limit is two states, not two jobs. Finished earlier sheets stay fixed.

    ``time_budget`` is divided over the bounded solver calls. Callers retain
    the engine stop protocol through ``should_stop``; minimum layout work may
    exceed a very short requested budget, as in the existing engine.
    """
    source_jobs = tuple(jobs)
    if not source_jobs:
        return ProductionPlan(())
    if tiny_parts_exception:
        raise UnsupportedPlanningFeature(
            "tiny-parts state exception needs an explicit configured threshold; it is disabled"
        )

    normalised = tuple(_normalise_job(job) for job in source_jobs)
    seen_refs: set[str] = set()
    for job in normalised:
        if job.job_ref in seen_refs:
            raise ProductionPlanningError(f"duplicate job_ref: {job.job_ref}")
        seen_refs.add(job.job_ref)

    by_compatibility: OrderedDict[str, list[ProductionJob]] = OrderedDict()
    for job in normalised:
        by_compatibility.setdefault(job.compatibility_key, []).append(job)

    plans = []
    run_budget = time_budget / max(1, 2 * len(normalised) - len(by_compatibility))
    for compatibility_key, compatible_jobs in by_compatibility.items():
        if compatibility_key not in rules_by_compatibility:
            raise ProductionPlanningError(f"missing rules for compatibility {compatibility_key!r}")
        rules = rules_by_compatibility[compatibility_key]
        _require_supported_rules(rules)
        ordered_jobs = _state_first(compatible_jobs)
        plans.append(_plan_compatible_jobs(
            compatibility_key,
            ordered_jobs,
            rules,
            nest_call=nest_call,
            seed=seed,
            time_budget=run_budget,
            attempts=attempts,
            should_stop=should_stop,
            progress=progress,
        ))
    return ProductionPlan(tuple(plans))


def _normalise_job(job: ProductionJob) -> ProductionJob:
    ref = str(job.job_ref).strip()
    state = str(job.state).strip().upper()
    compatibility = str(job.compatibility_key).strip()
    if not ref:
        raise ProductionPlanningError("job_ref is required")
    if state not in AU_STATES:
        shown = state or "missing"
        raise ProductionPlanningError(
            f"job {ref}: state must be one unambiguous Australian state/territory code; got {shown!r}"
        )
    if not compatibility:
        raise ProductionPlanningError(f"job {ref}: compatibility_key is required")
    if not job.parts:
        raise ProductionPlanningError(f"job {ref}: at least one expanded part is required")
    for part in job.parts:
        if not isinstance(part, Part):
            raise ProductionPlanningError(f"job {ref}: all parts must be engine.Part instances")
        if part.order_ref != ref:
            raise ProductionPlanningError(
                f"job {ref}: part {part.name!r} has order_ref {part.order_ref!r}; exact provenance is required"
            )
    return ProductionJob(ref, state, compatibility, job.parts)


def _require_supported_rules(rules: Rules) -> None:
    if rules.pins:
        raise UnsupportedPlanningFeature(
            "pinned placements use global sheet indexes and are not supported by bounded production planning"
        )
    if rules.stock:
        raise UnsupportedPlanningFeature(
            "ordered stock/remnant sheets require one global solver run and are not supported by bounded production planning"
        )
    if rules.roll:
        raise UnsupportedPlanningFeature(
            "roll media uses continuous length rather than physical-sheet adjacency and is not supported here"
        )


def _state_first(jobs: list[ProductionJob]) -> list[ProductionJob]:
    by_state: OrderedDict[str, list[ProductionJob]] = OrderedDict()
    for job in jobs:
        by_state.setdefault(job.state, []).append(job)
    return [job for state_jobs in by_state.values() for job in state_jobs]


def _plan_compatible_jobs(
    compatibility_key: str,
    jobs: list[ProductionJob],
    rules: Rules,
    **solver_options,
) -> CompatibilityPlan:
    final: list[Sheet] = []
    carry: Sheet | None = None
    state_by_ref = {job.job_ref: job.state for job in jobs}

    for job in jobs:
        standalone = _solve(job.parts, rules, **solver_options)
        if carry is None:
            final.extend(standalone[:-1])
            carry = standalone[-1]
            continue

        combined_parts = tuple(pl.part for pl in carry.placed) + job.parts
        previous_refs = _sheet_refs(carry)
        states = {state_by_ref[ref] for ref in previous_refs} | {job.state}
        candidate = _solve(combined_parts, rules, **solver_options) if len(states) <= 2 else None
        if candidate and _use_shared_candidate(candidate, previous_refs, job, len(standalone)):
            final.extend(candidate[:-1])
            carry = candidate[-1]
        else:
            final.append(carry)
            final.extend(standalone[:-1])
            carry = standalone[-1]

    if carry is not None:
        final.append(carry)

    all_parts = tuple(part for job in jobs for part in job.parts)
    issues = validate(final, all_parts, rules)
    if issues:
        raise ProductionPlanningError("final geometry validation failed: " + "; ".join(issues))

    planned = []
    for sheet in final:
        refs = _sheet_refs(sheet)
        states = tuple(dict.fromkeys(state_by_ref[ref] for ref in refs))
        if len(states) > 2:
            raise ProductionPlanningError(
                f"sheet contains {len(states)} states ({', '.join(states)}); normal maximum is two"
            )
        planned.append(PlannedSheet(sheet, refs, states))
    return CompatibilityPlan(
        compatibility_key,
        tuple(job.job_ref for job in jobs),
        tuple(planned),
    )


def _solve(parts: tuple[Part, ...], rules: Rules, *, nest_call: NestCall, **options) -> list[Sheet]:
    call_options = dict(options)
    if call_options.get("attempts") is None:
        call_options.pop("attempts", None)
    sheets, _info = nest_call(list(parts), rules, **call_options)
    if not sheets:
        raise ProductionPlanningError("nesting engine returned no sheets for a non-empty job")
    issues = validate(sheets, list(parts), rules)
    if issues:
        raise ProductionPlanningError("candidate geometry validation failed: " + "; ".join(issues))
    return sheets


def _sheet_refs(sheet: Sheet) -> tuple[str, ...]:
    return tuple(dict.fromkeys(pl.part.order_ref for pl in sheet.placed))


def _use_shared_candidate(
    sheets: list[Sheet],
    previous_refs: tuple[str, ...],
    current: ProductionJob,
    current_standalone_count: int,
) -> bool:
    # Finalising the carry plus the standalone job costs 1 + N sheets.  Equal
    # count adds sorting without saving stock, so it is deliberately rejected.
    if len(sheets) >= 1 + current_standalone_count:
        return False
    refs_by_sheet = [_sheet_refs(sheet) for sheet in sheets]
    previous_indexes = [i for i, refs in enumerate(refs_by_sheet) if set(previous_refs) & set(refs)]
    if previous_indexes != [0]:
        return False
    if current.job_ref not in refs_by_sheet[0]:
        return False
    allowed = {*previous_refs, current.job_ref}
    return all(set(refs) <= allowed for refs in refs_by_sheet)
