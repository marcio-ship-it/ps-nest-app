"""Provenance for a newly created standalone roll export test, never a real job."""
import hashlib
import re
from pathlib import Path

from .products import resolve_product

SCOPE = 'standalone_roll'
_KEY = re.compile(r'^[A-Za-z0-9_-]{1,64}$')
_APPROVAL_FIELDS = {'order_ref', 'source_binding', 'order_approval', 'artwork_approval',
                    'confirmed_by', 'approved', 'approval_basis'}


def _has_approval(value):
    if isinstance(value, dict):
        return any((key in _APPROVAL_FIELDS and bool(item)) or _has_approval(item)
                   for key, item in value.items())
    if isinstance(value, list):
        return any(_has_approval(item) for item in value)
    return False


def validate_request(request):
    product = resolve_product(request.get('product'), request.get('custom_material'))
    if not product.get('roll') or request.get('orders') or request.get('production_plan') or _has_approval(request):
        raise ValueError('A standalone roll TEST must be a new roll job without orders, approvals or portal bindings.')
    parts = request.get('parts')
    if not isinstance(parts, list) or not parts:
        raise ValueError('A standalone roll TEST needs retained artwork parts.')
    for part in parts:
        key = part.get('artwork') if isinstance(part, dict) else None
        if not isinstance(key, str) or not _KEY.fullmatch(key) or (part.get('shape') or {}).get('key'):
            raise ValueError('Each standalone roll TEST part must use a retained artwork key, without a separate outline.')


def source_inventory(parts, art_dir, archived_art_dir=None):
    """Bind both PDF bytes and analysis metadata, retaining shared library files."""
    keys = {part.get('artwork') if isinstance(part, dict) else None for part in parts}
    if not keys or any(not isinstance(key, str) or not _KEY.fullmatch(key) for key in keys):
        raise ValueError('Standalone roll TEST source key is invalid.')
    result = []
    for key in sorted(keys):
        if not isinstance(key, str) or not _KEY.fullmatch(key):
            raise ValueError('Standalone roll TEST source key is invalid.')
        for suffix in ('.pdf', '.json'):
            name = key + suffix
            path = Path(art_dir) / name
            if not path.is_file() and archived_art_dir is not None:
                path = Path(archived_art_dir) / name
            if not path.is_file():
                raise ValueError('Standalone roll TEST source custody is incomplete: ' + name)
            data = path.read_bytes()
            result.append({'file': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
    return result


def validate_archive(rec, marker, art_dir, archived_art_dir=None):
    request = rec.get('request') or {}
    validate_request(request)
    report = rec.get('report') or {}
    if report.get('orders') or report.get('production_plan') or _has_approval(rec.get('parts') or []):
        raise ValueError('A standalone roll TEST cannot acquire order approval or production bindings.')
    if not (rec.get('settings') or {}).get('roll'):
        raise ValueError('The saved standalone roll TEST no longer has a roll configuration.')
    expected = marker.get('sources')
    if not expected or expected != source_inventory(request['parts'], art_dir, archived_art_dir):
        raise ValueError('Standalone roll TEST source bytes changed after creation; cleanup is held.')
    if expected != source_inventory(rec.get('parts') or [], art_dir, archived_art_dir):
        raise ValueError('Standalone roll TEST saved pieces differ from its source inventory.')
