"""PS Nest - rectangle nesting engine.

Objective, in priority order (agreed with Marcio, 16-Sep-2026):
  1. fewest sheets
  2. largest clean offcut on the last sheet (a full-length strip that one
     straight cut removes), then the largest empty rectangle anywhere
  3. highest utilisation
subject to: edge margin, gap between parts, no-rotate parts.

Method: maximal-rectangles bin packing (Jylanki 2010) run under several
placement heuristics, several part orderings and three orientation modes
(free, all upright, all turned: the last two give the clean grids an operator
would cut by hand), plus deterministic seeded shuffles; the best layout by the
objective wins.  Deterministic: the same
input always gives the same output.

All dimensions in mm.  Sheet origin bottom-left, x to the right, y up
(matches DXF and PDF).  A part is placed by its bounding rectangle; corner
radius is a cut-path detail handled in outputs, not here.
"""
from __future__ import annotations
import random
import time
from dataclasses import dataclass, field
from .control import Progress, Stopped     # noqa: F401  (re-exported: server.py catches Stopped from here)

EPS = 1e-6

@dataclass(frozen=True)
class Part:
    name: str
    w: float
    h: float
    rotate: bool = True          # may turn (90 degrees, or rules.rot_step in shape mode)
    artwork: str | None = None   # key into the artwork store, if any
    outline: tuple | None = None # Phase 2: normalised CCW outline ((x, y, bulge), ...) with bbox = w x h; None = rectangle
    holes: tuple = ()            # Phase 2: inner loops (same form) cut out of the part
    shape: str | None = None     # Phase 2: JSON of the shape spec the outline was built from (for save/load and the UI)
    islands: tuple = ()          # Phase 2: further outer loops that belong to this part (the dot of an "i")
    # outline, islands and holes share one frame: the bbox of outline+islands has its min corner at (0, 0) and is w x h

    @property
    def shaped(self): return self.outline is not None

    def shape_outline(self):
        """Primary outline used for nesting: the real outline, or the w x h rectangle."""
        if self.outline is not None: return list(self.outline)
        return [(0.0, 0.0, 0.0), (self.w, 0.0, 0.0), (self.w, self.h, 0.0), (0.0, self.h, 0.0)]

    def shape_loops(self):
        """All outer loops (outline + islands) used for nesting and validation."""
        return [self.shape_outline()] + [list(o) for o in self.islands]

    def shape_outline_key(self):
        return (self.outline, self.islands) if self.outline is not None else ('rect', self.w, self.h)

    def true_area(self):
        if self.outline is None: return self.w * self.h
        from . import geom
        return geom.area(self.outline) + sum(geom.area(o) for o in self.islands) - sum(geom.area(h) for h in self.holes)

@dataclass(frozen=True)
class Rules:
    sheet_w: float
    sheet_h: float
    edge: float = 10.0           # margin from every sheet edge to any cut
    gap: float = 10.0            # clear space between neighbouring parts
    clamp: float = 0.0           # extra margin on every edge for clamps/marks
    min_offcut: float = 0.0      # a strip narrower than this does not count
    rot_step: float = 90.0       # Phase 2: allowed rotation step in degrees (90 = rectangles' turn)
    grid: float = 2.0            # Phase 2: raster cell size in mm for true-shape nesting
    roll: bool = False           # roll media: sheet_w runs along the roll; only unused LENGTH is worth keeping (it stays on the roll)

    @property
    def margin(self): return self.edge + self.clamp
    @property
    def usable_w(self): return self.sheet_w - 2 * self.margin
    @property
    def usable_h(self): return self.sheet_h - 2 * self.margin

@dataclass
class Placed:
    part: Part
    x: float
    y: float
    w: float      # placed width (after rotation)
    h: float
    rotated: bool
    angle: float = 0.0    # degrees counter-clockwise (Phase 2); 90 when rotated in rectangle mode

    def __post_init__(self):
        if self.rotated and not self.angle: self.angle = 90.0

@dataclass
class Sheet:
    placed: list[Placed] = field(default_factory=list)

    def used_area(self): return sum(p.part.true_area() for p in self.placed)


class _MaxRects:
    """One sheet, maximal free-rectangle bookkeeping in the *inflated* space:
    every part is (w+gap, h+gap) and the bin is (usable+gap) so that the gap
    rule holds between parts while the margin rule holds at the sheet edge."""

    def __init__(self, W, H):
        self.W, self.H = W, H
        self.free = [(0.0, 0.0, W, H)]     # x, y, w, h
        self.used = []                      # (x, y, w, h)

    def find(self, w, h, rotate, heuristic, orient='free'):
        best = None
        if rotate and abs(w - h) > EPS:
            opts = ((w, h, False), (h, w, True)) if orient == 'free' else (((h, w, True),) if orient == 'turned' else ((w, h, False),))
        else:
            opts = ((w, h, False),)
        for (fx, fy, fw, fh) in self.free:
            for (pw, ph, rot) in opts:
                if pw <= fw + EPS and ph <= fh + EPS:
                    score = self._score(fx, fy, fw, fh, pw, ph, heuristic)
                    if best is None or score < best[0]:
                        best = (score, fx, fy, pw, ph, rot)
        return best

    def _score(self, fx, fy, fw, fh, pw, ph, heuristic):
        if heuristic == 'bssf':      # best short side fit
            a, b = fw - pw, fh - ph; return (min(a, b), max(a, b))
        if heuristic == 'blsf':      # best long side fit
            a, b = fw - pw, fh - ph; return (max(a, b), min(a, b))
        if heuristic == 'baf':       # best area fit
            a, b = fw - pw, fh - ph; return (fw * fh - pw * ph, min(a, b))
        if heuristic == 'bl':        # bottom-left, then left (fills rows; leaves a strip along the top)
            return (fy + ph, fx)
        if heuristic == 'lb':        # left-bottom (fills columns; leaves a strip along the right)
            return (fx + pw, fy)
        if heuristic == 'cp':        # contact point (most touching edges)
            return (-self._contact(fx, fy, pw, ph), fy + ph, fx)
        raise ValueError(heuristic)

    def _contact(self, x, y, w, h):
        s = 0.0
        if x <= EPS: s += h
        if y <= EPS: s += w
        if abs(x + w - self.W) <= EPS: s += h
        if abs(y + h - self.H) <= EPS: s += w
        for (ux, uy, uw, uh) in self.used:
            if abs(ux + uw - x) <= EPS or abs(ux - (x + w)) <= EPS:
                s += max(0.0, min(uy + uh, y + h) - max(uy, y))
            if abs(uy + uh - y) <= EPS or abs(uy - (y + h)) <= EPS:
                s += max(0.0, min(ux + uw, x + w) - max(ux, x))
        return s

    def place(self, x, y, w, h):
        self.used.append((x, y, w, h))
        new = []
        for (fx, fy, fw, fh) in self.free:
            if x >= fx + fw - EPS or x + w <= fx + EPS or y >= fy + fh - EPS or y + h <= fy + EPS:
                new.append((fx, fy, fw, fh)); continue
            if x > fx + EPS:            new.append((fx, fy, x - fx, fh))
            if x + w < fx + fw - EPS:   new.append((x + w, fy, fx + fw - (x + w), fh))
            if y > fy + EPS:            new.append((fx, fy, fw, y - fy))
            if y + h < fy + fh - EPS:   new.append((fx, y + h, fw, fy + fh - (y + h)))
        # prune rectangles contained in others
        new = [r for r in new if r[2] > EPS and r[3] > EPS]
        keep = []
        for i, a in enumerate(new):
            contained = False
            for j, b in enumerate(new):
                if i != j and _contains(b, a) and (not _contains(a, b) or j < i):
                    contained = True; break
            if not contained: keep.append(a)
        self.free = keep


def _contains(b, a):
    return (a[0] >= b[0] - EPS and a[1] >= b[1] - EPS and
            a[0] + a[2] <= b[0] + b[2] + EPS and a[1] + a[3] <= b[1] + b[3] + EPS)


HEURISTICS = ('bssf', 'baf', 'blsf', 'bl', 'lb', 'cp')
ORIENTS = ('free', 'upright', 'turned')

def _orders(parts):
    yield 'area desc',    sorted(parts, key=lambda p: (-p.w * p.h, -max(p.w, p.h), p.name))
    yield 'long side',    sorted(parts, key=lambda p: (-max(p.w, p.h), -min(p.w, p.h), p.name))
    yield 'short side',   sorted(parts, key=lambda p: (-min(p.w, p.h), -max(p.w, p.h), p.name))
    yield 'height desc',  sorted(parts, key=lambda p: (-p.h, -p.w, p.name))
    yield 'width desc',   sorted(parts, key=lambda p: (-p.w, -p.h, p.name))
    yield 'perimeter',    sorted(parts, key=lambda p: (-(p.w + p.h), p.name))


def _pack_sheet(order, rules, heuristic, global_best, orient='free'):
    """Fill one sheet from `order` (list of Part); returns (Sheet, leftovers)."""
    g = rules.gap
    bin_ = _MaxRects(rules.usable_w + g, rules.usable_h + g)
    sheet, left = Sheet(), []
    remaining = list(order)
    if global_best:
        # each step: try every remaining part, take the best-scoring placement
        while remaining:
            cand = None
            for idx, p in enumerate(remaining):
                f = bin_.find(p.w + g, p.h + g, p.rotate, heuristic, orient)
                if f and (cand is None or f[0] < cand[0][0]): cand = (f, idx)
            if cand is None: break
            (score, fx, fy, pw, ph, rot), idx = cand
            p = remaining.pop(idx)
            bin_.place(fx, fy, pw, ph)
            sheet.placed.append(Placed(p, fx + rules.margin, fy + rules.margin, pw - g, ph - g, rot))
        left = remaining
    else:
        for p in remaining:
            f = bin_.find(p.w + g, p.h + g, p.rotate, heuristic, orient)
            if f is None: left.append(p); continue
            score, fx, fy, pw, ph, rot = f
            bin_.place(fx, fy, pw, ph)
            sheet.placed.append(Placed(p, fx + rules.margin, fy + rules.margin, pw - g, ph - g, rot))
    return sheet, left


def _pack_all(order, rules, heuristic, global_best, orient='free'):
    sheets, left = [], list(order)
    while left:
        s, nleft = _pack_sheet(left, rules, heuristic, global_best, orient)
        if not s.placed:
            raise ValueError('part does not fit on the sheet: %s %gx%g' % (left[0].name, left[0].w, left[0].h))
        sheets.append(s); left = nleft
    return sheets


def strip_offcut(sheet, rules):
    """Largest full-length strip on the sheet that one straight cut frees.
    Returns (area, w, h, where)."""
    if not sheet.placed: return (rules.sheet_w * rules.sheet_h, rules.sheet_w, rules.sheet_h, 'whole sheet')
    x_max = max(p.x + p.w for p in sheet.placed)
    y_max = max(p.y + p.h for p in sheet.placed)
    right = (rules.sheet_w - x_max, rules.sheet_h)     # strip along the right edge
    top = (rules.sheet_w, rules.sheet_h - y_max)       # strip along the top edge
    if rules.roll:
        # A strip along the top of a frame is a strip off the side of the roll: waste.  What counts is the length
        # not printed, however short, because it never leaves the roll.
        return (right[0] * right[1], right[0], right[1], 'right') if right[0] > EPS else (0.0, 0.0, 0.0, 'none')
    cands = []
    for (w, h, where) in ((right[0], right[1], 'right'), (top[0], top[1], 'top')):
        if min(w, h) >= max(rules.min_offcut, EPS): cands.append((w * h, w, h, where))
    return max(cands) if cands else (0.0, 0.0, 0.0, 'none')


def largest_empty_rect(sheet, rules):
    """Largest axis-aligned empty rectangle inside the sheet (any position).
    Coordinate-compressed occupancy grid + largest-rectangle-in-histogram: O(cells)."""
    from bisect import bisect_left
    xs = sorted({0.0, rules.sheet_w} | {p.x for p in sheet.placed} | {p.x + p.w for p in sheet.placed})
    ys = sorted({0.0, rules.sheet_h} | {p.y for p in sheet.placed} | {p.y + p.h for p in sheet.placed})
    nx, ny = len(xs) - 1, len(ys) - 1
    occ = [[False] * nx for _ in range(ny)]          # occ[row j][col i]
    for p in sheet.placed:
        i0, i1 = bisect_left(xs, p.x - EPS), bisect_left(xs, p.x + p.w - EPS)
        j0, j1 = bisect_left(ys, p.y - EPS), bisect_left(ys, p.y + p.h - EPS)
        for j in range(j0, j1):
            row = occ[j]
            for i in range(i0, i1): row[i] = True
    best = (0.0, 0.0, 0.0, 0.0, 0.0)
    start = [0] * nx                                  # row index where the current free run of column i began
    for j in range(ny):
        row = occ[j]
        for i in range(nx):
            if row[i]: start[i] = j + 1
        top = ys[j + 1]
        stack = []                                    # (column index, run start row)
        for i in range(nx + 1):
            cur = start[i] if i < nx else j + 1       # sentinel: height 0 flushes the stack
            hgt = top - ys[cur] if cur <= j else 0.0
            left = i
            while stack and (top - ys[stack[-1][1]]) >= hgt - EPS:
                k, st = stack.pop()
                h = top - ys[st]
                if h > EPS:
                    w = xs[i] - xs[k]
                    if w * h > best[0]: best = (w * h, xs[k], ys[st], w, h)
                left = k
            if hgt > EPS: stack.append((left, cur))
    return best


def score(sheets, rules):
    """Lower is better: (sheet count, -strip offcut, -largest empty rect, -utilisation)."""
    last = sheets[-1]
    strip = strip_offcut(last, rules)[0]
    ler = largest_empty_rect(last, rules)[0]
    util = sum(s.used_area() for s in sheets) / (len(sheets) * rules.sheet_w * rules.sheet_h)
    return (len(sheets), -round(strip), -round(ler), -round(util, 6))


def expand(parts_with_qty):
    """[(Part, qty)] -> [Part, ...] with numbered names."""
    out = []
    for p, q in parts_with_qty:
        for i in range(int(q)):
            out.append(Part(f'{p.name} #{i + 1}' if q > 1 else p.name, p.w, p.h, p.rotate, p.artwork, p.outline, p.holes, p.shape, p.islands))
    return out


def needs_shapes(parts, rules):
    """True when the true-shape engine must run: any non-rectangular part, or a rotation step that is not 90."""
    return any(p.shaped for p in parts) or abs((rules.rot_step or 90.0) - 90.0) > EPS


def nest(parts, rules, attempts=None, seed=20260916, time_budget=45.0, should_stop=None, progress=None):
    """parts: list[Part] (already expanded).  Returns (sheets, info).
    should_stop: optional callable (protocol in control.py): 1 = return the best finished layout, finishing the
    first one if none has; 2 = abandon at once (raises Stopped when nothing had finished).  info['stopped'] = True.
    progress: optional callable(**fields) fed stage / tried / best_sheets / placed / total as the search goes."""
    stop = should_stop or (lambda: False)
    prog = progress if isinstance(progress, Progress) else Progress(progress)
    if parts and needs_shapes(parts, rules):
        from .shapenest import nest_shapes, validate_shapes
        extra = {}
        sheets = nest_shapes(parts, rules, time_budget=time_budget, seed=seed, info=extra, should_stop=stop, progress=prog)
        if sheets is None: raise Stopped('Stopped before any layout was finished, so there is nothing to show.')
        info = {'tried': len(extra.get('passes', [])), 'strategy': 'true-shape raster BLF', 'engine': 'shapes',
                'score': score(sheets, rules), 'pairs': extra.get('pairs', []), 'grid': extra.get('grid'),
                'seconds': extra.get('seconds'), 'stopped': bool(extra.get('stopped'))}
        # A bounding-box layout is a valid shape layout too (rectangles `gap` apart keep their outlines `gap`
        # apart; 0 and 90 degrees belong to every rotation step the app offers), so it competes on score: near-
        # rectangular parts never nest worse in complex mode than they did in Phase 1.  Validated before use.
        try: rs, rinfo = _nest_rects(parts, rules, attempts, seed, time_budget=min(10.0, time_budget * 0.25),
                                     should_stop=stop, progress=prog)
        except ValueError: rs = None
        if rs is not None and score(rs, rules) < info['score'] and not validate_shapes(rs, parts, rules):
            info.update(strategy='bounding boxes / ' + rinfo['strategy'], score=score(rs, rules),
                        tried=info['tried'] + rinfo['tried'], pairs=[])
            sheets = rs
        return sheets, info
    return _nest_rects(parts, rules, attempts, seed, should_stop=stop, progress=prog)


def _nest_rects(parts, rules, attempts=None, seed=20260916, time_budget=None, should_stop=None, progress=None):
    """Phase 1 engine: MaxRects on the parts' bounding boxes, every heuristic x order x orientation, then random
    orders up to `attempts`.  `time_budget` (seconds) stops the search early once every candidate has had a turn
    or the clock runs out, whichever is later than the first two candidates."""
    t0 = time.monotonic()
    for p in parts:
        fits = (p.w <= rules.usable_w + EPS and p.h <= rules.usable_h + EPS) or \
               (p.rotate and p.h <= rules.usable_w + EPS and p.w <= rules.usable_h + EPS)
        if not fits:
            raise ValueError('%s (%g x %g mm) does not fit inside the usable sheet %g x %g mm. Split it into panels first.'
                             % (p.name, p.w, p.h, rules.usable_w, rules.usable_h))
    if not parts: return [], {'tried': 0, 'strategy': None}
    n = len(parts)
    if attempts is None: attempts = max(20, min(300, 30000 // max(n, 1)))
    rng = random.Random(seed)
    best, best_score, tried, best_name = None, None, 0, None
    stop = should_stop or (lambda: False)
    prog = progress if isinstance(progress, Progress) else Progress(progress)
    stopped = False
    candidates = []
    for oname, order in _orders(parts):
        for h in HEURISTICS:
            for gb in (False, True):
                for orient in ORIENTS:
                    candidates.append((f'{oname} / {h}{" / global" if gb else ""}{"" if orient == "free" else " / all " + orient}', order, h, gb, orient))
    for k in range(attempts):
        order = list(parts); rng.shuffle(order)
        h = HEURISTICS[k % len(HEURISTICS)]
        orient = ORIENTS[(k // len(HEURISTICS)) % len(ORIENTS)]
        candidates.append((f'shuffle {k + 1} / {h}{"" if orient == "free" else " / all " + orient}', order, h, k % 3 == 0, orient))
    for name, order, h, gb, orient in candidates:
        if time_budget and tried >= 2 and time.monotonic() - t0 > time_budget: break
        if tried >= 1 and stop(): stopped = True; break      # one candidate always finishes: it takes milliseconds
        try: sheets = _pack_all(order, rules, h, gb, orient)
        except ValueError:
            if orient == 'free': raise
            continue        # a forced orientation cannot place a part that only fits the other way round
        tried += 1
        sc = score(sheets, rules)
        if best_score is None or sc < best_score:
            best, best_score, best_name = sheets, sc, name
        so_far = prog.state.get('best_sheets')
        prog(stage='boxes', boxes=tried, best_sheets=len(best) if so_far is None else min(so_far, len(best)))
    return best, {'tried': tried, 'strategy': best_name, 'score': best_score, 'engine': 'rects', 'stopped': stopped}


def validate(sheets, parts, rules):
    """Hard checks every layout must pass.  Returns list of problems (empty = ok)."""
    placed_all = [p for s in sheets for p in s.placed]
    if any(p.part.shaped or abs((p.angle / 90.0) - round(p.angle / 90.0)) > 1e-9 for p in placed_all):
        from .shapenest import validate_shapes
        return validate_shapes(sheets, parts, rules)
    problems = []
    placed = [p for s in sheets for p in s.placed]
    if len(placed) != len(parts): problems.append(f'placed {len(placed)} of {len(parts)} parts')
    names = sorted(p.part.name for p in placed)
    if names != sorted(p.name for p in parts): problems.append('placed parts do not match the input parts')
    m = rules.margin
    for s_i, s in enumerate(sheets, 1):
        for p in s.placed:
            exp = (p.part.h, p.part.w) if p.rotated else (p.part.w, p.part.h)
            if abs(p.w - exp[0]) > EPS or abs(p.h - exp[1]) > EPS: problems.append(f'{p.part.name}: size changed')
            if p.rotated and not p.part.rotate: problems.append(f'{p.part.name}: rotated but must not be')
            if p.x < m - EPS or p.y < m - EPS or p.x + p.w > rules.sheet_w - m + EPS or p.y + p.h > rules.sheet_h - m + EPS:
                problems.append(f'sheet {s_i}: {p.part.name} breaks the {m} mm edge margin')
        for i in range(len(s.placed)):
            for j in range(i + 1, len(s.placed)):
                a, b = s.placed[i], s.placed[j]
                dx = max(a.x - (b.x + b.w), b.x - (a.x + a.w))
                dy = max(a.y - (b.y + b.h), b.y - (a.y + a.h))
                if max(dx, dy) < rules.gap - EPS:
                    problems.append(f'sheet {s_i}: {a.part.name} and {b.part.name} are {max(dx, dy):.2f} mm apart (rule {rules.gap} mm)')
    return problems
