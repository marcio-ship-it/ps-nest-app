"""Local PS Nest NAS settings. The password is never written to an application file."""
import json
import ipaddress
import os
import shutil
import subprocess
import sys
import tempfile
import threading
from urllib.parse import urlsplit

if sys.platform == 'darwin':
    import ctypes


class SettingsError(ValueError):
    pass


def require_tailnet_peer(details):
    if not details['host'].startswith('http://'): return
    try:
        target = urlsplit(details['host']).hostname
        candidates = ['/usr/local/bin/tailscale', '/Applications/Tailscale.app/Contents/MacOS/Tailscale']
        if sys.platform == 'win32':
            candidates = [os.path.join(os.environ[key], 'Tailscale', 'tailscale.exe')
                          for key in ('ProgramFiles', 'ProgramFiles(x86)') if os.environ.get(key)]
        executable = shutil.which('tailscale') or next((p for p in candidates if os.path.isfile(p)), None)
        if not executable: raise SettingsError('Tailscale is not available on this computer.')
        result = subprocess.run([executable, 'status', '--json'], capture_output=True, timeout=4, check=True)
        status = json.loads(result.stdout)
        peers = status.get('Peer') or {}
        if status.get('BackendState') == 'Running' and any(target in (p.get('TailscaleIPs') or []) and p.get('Online') for p in peers.values()):
            return
    except (OSError, subprocess.SubprocessError, ValueError, TypeError): pass
    raise SettingsError('Connect Tailscale and confirm this NAS is an online Tailscale peer before using its HTTP address.')


def validate(data):
    if not isinstance(data, dict): raise SettingsError('Enter a NAS address, user, password and folder.')
    host, user, root = (data.get(k) for k in ('host', 'user', 'root'))
    if not isinstance(host, str) or not host or any(c.isspace() or ord(c) < 32 for c in host):
        raise SettingsError('Enter a valid HTTPS NAS address.')
    try: p = urlsplit(host)
    except ValueError: raise SettingsError('Enter a valid HTTPS NAS address.') from None
    try: port = p.port
    except ValueError: raise SettingsError('Enter a valid HTTPS NAS address.') from None
    tailnet = data.get('tailnetOnly', False)
    if not isinstance(tailnet, bool): raise SettingsError('Confirm the Tailscale connection setting.')
    try: tail_address = ipaddress.ip_address(p.hostname) in ipaddress.ip_network('100.64.0.0/10')
    except ValueError: tail_address = False
    if (p.scheme != 'https' and not (p.scheme == 'http' and tailnet and tail_address)) or not p.hostname or p.username or p.password or p.path not in ('', '/') or p.query or p.fragment or not p.netloc or port == 0:
        raise SettingsError('Enter a valid HTTPS NAS address.')
    if not isinstance(user, str) or not user.strip() or user != user.strip() or any(ord(c) < 32 for c in user):
        raise SettingsError('Enter a valid NAS user.')
    if root is None or root == '': root = '/Platinum'
    if not isinstance(root, str) or not root.startswith('/') or root == '/' or '\\' in root or any(ord(c) < 32 for c in root) or any(s in ('.', '..') for s in root.split('/')):
        raise SettingsError('Enter an absolute NAS folder, such as /Platinum.')
    if not isinstance(data.get('password', ''), str): raise SettingsError('Enter a NAS password.')
    return {'host': f'{p.scheme}://{p.netloc.lower()}', 'user': user, 'root': root.rstrip('/'), 'tailnetOnly': tailnet if p.scheme == 'http' else False}, data.get('password', '')


class MacKeychain:
    """Security.framework generic-password item, through native calls (no shell or argv)."""
    def __init__(self, service='au.com.platinumsigns.psnest.nas'):
        if sys.platform != 'darwin': raise SettingsError('Remembering NAS passwords requires macOS Keychain.')
        self.sec = ctypes.CDLL('/System/Library/Frameworks/Security.framework/Security')
        self.cf = ctypes.CDLL('/System/Library/Frameworks/CoreFoundation.framework/CoreFoundation')
        self.cf.CFStringCreateWithCString.restype = ctypes.c_void_p
        self.cf.CFStringCreateWithCString.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_uint32]
        self.cf.CFDictionaryCreate.restype = ctypes.c_void_p
        self.cf.CFDictionaryCreate.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_void_p), ctypes.POINTER(ctypes.c_void_p), ctypes.c_long, ctypes.c_void_p, ctypes.c_void_p]
        self.cf.CFDataCreate.restype = ctypes.c_void_p
        self.cf.CFDataCreate.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_long]
        self.cf.CFDataGetLength.argtypes = [ctypes.c_void_p]; self.cf.CFDataGetLength.restype = ctypes.c_long
        self.cf.CFDataGetBytePtr.argtypes = [ctypes.c_void_p]; self.cf.CFDataGetBytePtr.restype = ctypes.c_void_p
        self.cf.CFRelease.argtypes = [ctypes.c_void_p]
        self.sec.SecItemCopyMatching.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_void_p)]
        self.sec.SecItemAdd.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
        self.sec.SecItemUpdate.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
        self.sec.SecItemDelete.argtypes = [ctypes.c_void_p]
        self.service = service

    def _string(self, value):
        return self.cf.CFStringCreateWithCString(None, value.encode(), 0x08000100)

    def _dictionary(self, values):
        keys = (ctypes.c_void_p * len(values))(*values.keys())
        vals = (ctypes.c_void_p * len(values))(*values.values())
        return self.cf.CFDictionaryCreate(None, keys, vals, len(values), None, None)

    def _query(self, result=False):
        owned = [self._string(self.service), self._string('connection')]
        vals = {ctypes.c_void_p.in_dll(self.sec, 'kSecClass').value: ctypes.c_void_p.in_dll(self.sec, 'kSecClassGenericPassword').value,
                ctypes.c_void_p.in_dll(self.sec, 'kSecAttrService').value: owned[0],
                ctypes.c_void_p.in_dll(self.sec, 'kSecAttrAccount').value: owned[1]}
        if result: vals[ctypes.c_void_p.in_dll(self.sec, 'kSecReturnData').value] = ctypes.c_void_p.in_dll(self.cf, 'kCFBooleanTrue').value
        return vals, owned

    def get(self):
        vals, owned = self._query(True); q = self._dictionary(vals); result = ctypes.c_void_p()
        try:
            status = self.sec.SecItemCopyMatching(q, ctypes.byref(result))
            if status == -25300: return None
            if status != 0: raise SettingsError('Could not read the NAS password from Keychain.')
            return ctypes.string_at(self.cf.CFDataGetBytePtr(result), self.cf.CFDataGetLength(result)).decode()
        finally:
            if result.value: self.cf.CFRelease(result)
            self.cf.CFRelease(q)
            for x in owned: self.cf.CFRelease(x)

    def set(self, secret):
        vals, owned = self._query(); raw = secret.encode(); buffer = ctypes.create_string_buffer(raw)
        data = self.cf.CFDataCreate(None, buffer, len(raw)); key = ctypes.c_void_p.in_dll(self.sec, 'kSecValueData').value
        q = self._dictionary(vals); value = self._dictionary({key: data})
        try:
            status = self.sec.SecItemUpdate(q, value)
            if status == -25300:
                add = self._dictionary({**vals, key: data})
                try: status = self.sec.SecItemAdd(add, None)
                finally: self.cf.CFRelease(add)
            if status != 0: raise SettingsError('Could not save the NAS password to Keychain.')
        finally:
            self.cf.CFRelease(q); self.cf.CFRelease(value); self.cf.CFRelease(data)
            for x in owned: self.cf.CFRelease(x)

    def delete(self):
        vals, owned = self._query(); q = self._dictionary(vals)
        try:
            if self.sec.SecItemDelete(q) not in (0, -25300): raise SettingsError('Could not remove the NAS password from Keychain.')
        finally:
            self.cf.CFRelease(q)
            for x in owned: self.cf.CFRelease(x)


class NasSettings:
    def __init__(self, path=None, secretstore=None):
        app_dir = (os.path.join(os.environ.get('APPDATA') or os.path.expanduser('~'), 'PS Nest') if sys.platform == 'win32'
                   else os.path.expanduser('~/Library/Application Support/PS Nest') if sys.platform == 'darwin'
                   else os.path.expanduser('~/.config/PS Nest'))
        self.path = path or os.path.join(app_dir, 'nas-settings.json')
        self.secretstore = secretstore if secretstore is not None else (MacKeychain() if sys.platform == 'darwin' else None)
        self.session = None
        self.lock = threading.RLock()

    def _read(self):
        try:
            with open(self.path) as f: return json.load(f)
        except FileNotFoundError: return None
        except (OSError, ValueError): raise SettingsError('Could not read local NAS settings.') from None

    def _write(self, data):
        folder = os.path.dirname(self.path); os.makedirs(folder, mode=0o700, exist_ok=True)
        fd, temp = tempfile.mkstemp(prefix='.nas-', dir=folder)
        try:
            with os.fdopen(fd, 'w') as f:
                json.dump(data, f); f.flush(); os.fsync(f.fileno())
            os.replace(temp, self.path)
        finally:
            if os.path.exists(temp): os.unlink(temp)

    def current(self, legacy=None):
        with self.lock:
            if self.session: return {**self.session[0], 'password': self.session[1], 'source': 'session'}
            saved = self._read()
            if saved is not None:
                if not isinstance(saved, dict): raise SettingsError('Could not read local NAS settings.')
                if saved.get('disabled'): return None
                password = self.secretstore.get() if self.secretstore else None
                if password:
                    try: details, _ = validate({**saved, 'password': password})
                    except SettingsError: raise SettingsError('Saved NAS settings are invalid. Clear them and set up the connection again.') from None
                    return {**details, 'password': password, 'source': 'saved'}
                return None
            if legacy:
                host, user, password = legacy
                return {'host': host, 'user': user, 'password': password, 'root': '/Platinum', 'tailnetOnly': host.startswith('http://'), 'source': 'legacy'}
            return None

    def status(self, legacy=None):
        warning = None
        try:
            c = self.current(legacy)
            saved = self._read()
            can_forget = bool(c or (saved and not saved.get('disabled')))
        except SettingsError as e:
            c, can_forget, warning = None, True, str(e)
        return {'configured': bool(c), 'source': c['source'] if c else 'none',
                'canForget': can_forget,
                'host': c['host'] if c else '', 'user': c['user'] if c else '',
                'root': c['root'] if c else '/Platinum',
                'tailnetOnly': c.get('tailnetOnly', False) if c else False,
                'storage': 'macos_keychain' if self.secretstore else 'session',
                'message': warning or ('NAS connection configured.' if c else 'Enter your NAS connection details.')}

    def candidate(self, data, legacy=None):
        details, password = validate(data)
        if not password:
            previous = self.current(legacy)
            if not previous or (details['host'], details['user']) != (previous['host'], previous['user']):
                raise SettingsError('Enter the password for this NAS address and user.')
            password = previous['password']
        return details, password

    def save(self, details, password, remember):
        if not isinstance(remember, bool): raise SettingsError('Choose whether to remember this connection.')
        with self.lock:
            if remember:
                if not self.secretstore: raise SettingsError('Remembering NAS passwords requires macOS Keychain.')
                old_password = self.secretstore.get()
                self.secretstore.set(password)
                try: self._write(details)
                except Exception:
                    if old_password is None: self.secretstore.delete()
                    else: self.secretstore.set(old_password)
                    raise
                self.session = None
            else:
                old_password = self.secretstore.get() if self.secretstore else None
                if self.secretstore: self.secretstore.delete()
                try: self._write({'disabled': True})
                except Exception:
                    if old_password is not None: self.secretstore.set(old_password)
                    raise
                self.session = (details, password)

    def clear(self):
        with self.lock:
            old_password = self.secretstore.get() if self.secretstore else None
            if self.secretstore: self.secretstore.delete()
            try: self._write({'disabled': True})
            except Exception:
                if old_password is not None: self.secretstore.set(old_password)
                raise
            self.session = None
