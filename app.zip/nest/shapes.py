"""Shape specs (from the UI / saved jobs) -> part geometry.

A spec is a small dict: {'type': 'circle'} ... {'type': 'star', 'n': 5, 'inner': 0.45},
{'type': 'outline', 'key': <upload key>, 'index': 0, 'scale': 1.0}, {'type': 'text', 'text': 'PLATINUM', 'height': 300, 'font': 'Arial Bold'}.
`build` returns a list of geometry dicts {outline, holes, islands, w, h, label} (text gives one per character).
"""
from __future__ import annotations
from . import geom, importers

TYPES = ('rect', 'circle', 'ellipse', 'triangle', 'right_triangle', 'rhombus', 'polygon', 'star', 'outline', 'text')


def _tuple_loops(loops): return tuple(tuple((float(x), float(y), float(b)) for x, y, b in o) for o in loops)


def _geom(outline, holes=(), islands=()):
    loops, w, h = geom.normalise_loops([outline] + list(islands))
    x0, y0, _, _ = geom.bbox_loops([outline] + list(islands))
    hs = []
    for hh in holes:
        c, _, _ = geom.normalise(hh); hx0, hy0, _, _ = geom.bbox_outline(hh)
        hs.append(geom.reverse(geom.translate(c, hx0 - x0, hy0 - y0)))
    return {'outline': _tuple_loops([loops[0]])[0], 'islands': _tuple_loops(loops[1:]), 'holes': _tuple_loops(hs), 'w': w, 'h': h}


def build(spec, w, h, outlines=None):
    """spec dict (or None) + row width/height -> [geometry dict, ...].  Rectangles return [] (use w x h)."""
    t = (spec or {}).get('type', 'rect')
    if t not in TYPES: raise ValueError(f'unknown shape "{t}"')
    if t == 'rect': return []
    if t == 'circle': return [_geom(geom.circle(w))]
    if t == 'ellipse': return [_geom(geom.ellipse(w, h))]
    if t == 'triangle': return [_geom(geom.triangle(w, h))]
    if t == 'right_triangle': return [_geom(geom.right_triangle(w, h))]
    if t == 'rhombus': return [_geom(geom.rhombus(w, h))]
    if t == 'polygon':
        n = int(spec.get('n', 6))
        if n < 3 or n > 64: raise ValueError('polygon: sides must be 3..64')
        return [_geom(geom.regular_polygon(n, w))]
    if t == 'star':
        n = int(spec.get('n', 5)); inner = float(spec.get('inner', 0.45))
        if n < 3 or n > 32: raise ValueError('star: points must be 3..32')
        if not 0.1 <= inner <= 0.95: raise ValueError('star: inner ratio must be 0.1..0.95')
        return [_geom(geom.star(n, w, inner))]
    if t == 'text':
        text = str(spec.get('text', '')).strip()
        if not text: raise ValueError('text: nothing to cut')
        height = float(spec.get('height') or h or 100)
        if height <= 0: raise ValueError('text: letter height must be above zero')
        font = spec.get('font') or 'Arial Bold'
        out, seen = [], {}
        for ch in text:                     # one geometry per distinct character, 'count' = how often it occurs
            if not ch.strip(): continue
            if ch in seen:
                if seen[ch] is not None: seen[ch]['count'] += 1
                continue
            parts = importers.text_parts(ch, height, font)
            if not parts: seen[ch] = None; continue
            g = parts[0][1]
            gg = _geom(g['outline'], g['holes'], g['islands']); gg['label'] = ch; gg['count'] = 1
            seen[ch] = gg; out.append(gg)
        if not out: raise ValueError(f'text "{text}": no glyph outlines in {font}')
        return out
    if t == 'outline':
        if not outlines or spec.get('key') not in outlines: raise ValueError('outline upload not found on the server; upload it again')
        entry = outlines[spec['key']]
        idx = int(spec.get('index', 0))
        if idx < 0 or idx >= len(entry['parts']): raise ValueError('outline index out of range')
        g = entry['parts'][idx]
        scale = float(spec.get('scale') or 1.0)
        if w and abs(w - g['w']) > 1e-9 and not spec.get('scale'): scale = w / g['w']   # row width overrides: uniform scale
        if scale <= 0: raise ValueError('outline scale must be above zero')
        sc = lambda loop: [(x * scale, y * scale, b) for x, y, b in loop]
        return [_geom(sc(g['outline']), [sc(hh) for hh in g['holes']], [sc(i) for i in g['islands']])]
    return []


def parse_upload(name, data):
    """Uploaded DXF/SVG bytes -> outline store entry {name, kind, parts: [geom dicts], summary, warnings}."""
    low = name.lower()
    text = data.decode('utf-8', 'replace') if isinstance(data, bytes) else data
    if low.endswith('.svg') or text.lstrip().startswith('<'):
        res = importers.parse_svg(text); kind = 'svg'
    else:
        res = importers.parse_dxf(text); kind = 'dxf'
    parts = []
    for p in importers.loops_to_parts(res.loops, 'separate'):
        g = _geom(p['outline'], p['holes'], p['islands'])
        g['area'] = round(geom.area(g['outline']) + sum(geom.area(o) for o in g['islands']) - sum(geom.area(hh) for hh in g['holes']), 1)
        parts.append(g)
    if not parts: raise ValueError(f'{name}: no closed outlines found ({res.summary()})')
    return {'name': name, 'kind': kind, 'parts': parts, 'summary': res.summary(), 'warnings': res.warnings, 'units': res.units}
