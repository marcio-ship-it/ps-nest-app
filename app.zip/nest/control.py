"""Cooperative stop and live progress shared by the two engines (engine._nest_rects and shapenest.nest_shapes).

should_stop() protocol: falsy = keep searching; 1 / True = stop once a layout has finished (the first layout is
finished if none has, so the user gets something back); 2 or more = abandon the layout in progress even if none
has finished, which raises Stopped up to the caller.
"""
from __future__ import annotations
import time


class Stopped(Exception):
    """The search was abandoned before any layout was finished, so there is nothing to return."""


class Progress:
    """Rate-limited progress reporter.  The search loops call it freely; the caller's callback sees the full
    accumulated state at most ~4 times a second, plus every call marked force=True (end of a layout)."""
    def __init__(self, cb): self.cb = cb; self.state = {}; self.last = 0.0
    def __call__(self, force=False, **fields):
        self.state.update(fields)
        if self.cb is None: return
        now = time.monotonic()
        if force or now - self.last >= 0.25:
            self.last = now; self.cb(**self.state)
