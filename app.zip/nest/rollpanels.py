"""Roll media: a print & cut piece wider than the roll is split into overlapping panels ("drops").

A piece that fits the roll is never touched.  A piece that does not fit is split only when its CutContour line is a
plain rectangle: each panel becomes its own artwork (the original artwork clipped to the panel window plus bleed, with
a CutContour rectangle on the window), so the PRINT file, the CUT file and the DXF carry every panel as an ordinary
placed piece.  Shaped pieces (round corners, letters, holes) are refused with a clear message: where the seams go on a
shape is a person's call.

Overlap: neighbouring panels share ``overlap`` mm of artwork so the installer can lap one over the other.
DEFAULT_OVERLAP_MM is an [assumption], see OVERLAP_SOURCE; the job may set its own with the rule ``panel_overlap``.
"""
import io
import math

from . import geom, outputs, pdfcut

MM = outputs.MM
FIT_TOL = 1e-6
MAX_PANELS = 40
DEFAULT_OVERLAP_MM = 20.0
OVERLAP_SOURCE = ('20 mm [assumption]: the overlap the online shop already prices for wall graphics, wall murals and '
                  'wallpaper panels. No workshop record of a vinyl panel overlap was found; set the rule panel_overlap '
                  'to use another value.')


class LeaveOut(ValueError):
    """A roll piece that cannot go on the roll as it is and that PS Nest will not split: the run leaves it out with
    this message as a staff note, and every other piece still nests (owner rule: label, never block)."""


def fits(w, h, uw, uh, rotate):
    """True when a w x h piece fits a uw (along the roll) x uh (across the roll) area, turned or not."""
    return (w <= uw + FIT_TOL and h <= uh + FIT_TOL) or (rotate and h <= uw + FIT_TOL and w <= uh + FIT_TOL)


def plan(w, h, uw, uh, rotate, overlap, gap=0.0):
    """Panel plan for a w x h piece on a roll whose usable area is uw (length) x uh (width).

    Returns None when the piece fits as it is.  Otherwise {'axis', 'n', 'panel', 'size', 'overlap', 'width'}:
    axis 'x' = the piece's width is cut into n panels of panel x h (vertical seams), 'y' = its height into n panels of
    w x panel (horizontal seams).  Panels are equal; neighbours share ``overlap`` mm.  The fewest panels win; on a
    tie, vertical seams (the usual drops).  The panel's cross-roll size is kept a ``gap`` inside the roll width so
    its bleed stays on the media.  Raises ValueError when no split fits."""
    if fits(w, h, uw, uh, rotate): return None
    overlap = float(overlap)
    if not math.isfinite(overlap) or overlap < 0: raise ValueError('Panel overlap must be 0 mm or more.')
    width = uh - max(0.0, float(gap or 0))
    best = None
    for axis, dim, other in (('x', w, h), ('y', h, w)):
        for n in range(2, MAX_PANELS + 1):
            p = (dim + (n - 1) * overlap) / n
            if p <= overlap + 1.0: break                         # panels thinner than the overlap make no sense
            pw, ph = (p, other) if axis == 'x' else (other, p)
            if fits(pw, ph, uw, width, rotate):
                if best is None or n < best['n']:
                    best = {'axis': axis, 'n': n, 'panel': p, 'size': (pw, ph), 'overlap': overlap, 'width': width}
                break
    if best is None:
        raise ValueError(f'{w:g} x {h:g} mm cannot be split into roll panels: even {MAX_PANELS} panels with a '
                         f'{overlap:g} mm overlap do not fit {uw:g} x {width:g} mm' + ('' if rotate else ' without turning') + '.')
    return best


def is_rectangle(cut, g):
    """True when the CutContour is one plain rectangle (no holes, no extra shapes, area = its box)."""
    if cut.get('loops') != 1 or cut.get('holes') or cut.get('islands'): return False
    outline = [(p[0], p[1]) for p in g['outline']]
    if any(abs(p[2]) > 1e-9 for p in g['outline'] if len(p) > 2): return False
    area = abs(geom.signed_area(outline))
    return g['w'] > 0 and g['h'] > 0 and area >= 0.995 * g['w'] * g['h']


def windows(cut, pl):
    """[(x, y, w, h)] panel windows in the artwork's page mm, panel 1 first (left, or bottom)."""
    x0, y0, w, h = cut['x0'], cut['y0'], cut['w'], cut['h']
    p, ov, out = pl['panel'], pl['overlap'], []
    for k in range(pl['n']):
        s = k * (p - ov)
        out.append((x0 + s, y0, p, h) if pl['axis'] == 'x' else (x0, y0 + s, w, p))
    return out


def panel_pdf(data, window, bleed):
    """Artwork PDF bytes -> one panel's artwork PDF bytes.

    The original artwork (CutContour unpainted) clipped to the window grown by ``bleed`` mm, on a page exactly that
    size, plus a CutContour rectangle on the window.  Artwork past the window on a seam side is the neighbour's
    picture, so the panel's bleed there is real artwork."""
    from pypdf import PdfReader, PdfWriter
    from pypdf.generic import ContentStream, DecodedStreamObject, NameObject, RectangleObject
    from reportlab.lib.colors import CMYKColorSep
    from reportlab.pdfgen import canvas
    wx, wy, ww, wh = window
    b = max(0.0, float(bleed or 0))
    bx0, by0 = (wx - b) * MM, (wy - b) * MM
    pw, ph = (ww + 2 * b) * MM, (wh + 2 * b) * MM
    clean = pdfcut.print_copy(data)                       # rotation / UserUnit baked in, every CutContour unpainted
    writer = PdfWriter()
    page = writer.add_page(PdfReader(io.BytesIO(clean)).pages[0])
    head = DecodedStreamObject()
    head.set_data(('q 1 0 0 1 %.4f %.4f cm %.4f %.4f %.4f %.4f re W n\n' % (-bx0, -by0, bx0, by0, pw, ph)).encode())
    body = ContentStream(page.get_contents(), writer) if page.get_contents() is not None else None
    merged = DecodedStreamObject()
    merged.set_data(head.get_data() + (body.get_data() if body is not None else b'') + b'\nQ\n')
    page.replace_contents(ContentStream(merged, writer))
    for box in ('/CropBox', '/TrimBox', '/BleedBox', '/ArtBox'):
        if NameObject(box) in page: del page[NameObject(box)]
    if NameObject('/Annots') in page: del page[NameObject('/Annots')]
    page.mediabox = RectangleObject([0, 0, pw, ph])
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=(pw, ph))
    c.setStrokeColor(CMYKColorSep(0, 1, 0, 0, spotName='CutContour', density=1))
    c.setLineWidth(0.25)
    c.rect(b * MM, b * MM, ww * MM, wh * MM, stroke=1, fill=0)
    c.showPage(); c.save()
    page.merge_page(PdfReader(io.BytesIO(buf.getvalue())).pages[0])
    out = io.BytesIO(); writer.write(out)
    return out.getvalue()


def split(name, art, cut, g, pl, bleed, register, lookup):
    """Make the panel artworks.  register(name, bytes) -> key; lookup(key) -> the stored artwork record.
    Returns [(panel_label, key, cut)] with every panel's CutContour checked against its window."""
    out = []
    for k, win in enumerate(windows(cut, pl), 1):
        label = f'panel {k} of {pl["n"]}'
        data = panel_pdf(art['bytes'], win, bleed)
        key = register(f'{art["name"]} {label}', data)
        pc = (lookup(key) or {}).get('cut') or {}
        if (not pc.get('found') or pc.get('error') or pc.get('loops') != 1
                or abs(pc.get('w', 0) - win[2]) > 0.5 or abs(pc.get('h', 0) - win[3]) > 0.5):
            raise ValueError(f'{name}: {label} did not come out as a clean {win[2]:.1f} x {win[3]:.1f} mm CutContour '
                             f'rectangle; nothing was nested. Split this piece by hand in the design program.')
        out.append((label, key, pc))
    return out


def note(name, w, h, pl):
    axis = 'vertical seams' if pl['axis'] == 'x' else 'horizontal seams'
    pw, ph = pl['size']
    return (f'{name}: {w:g} x {h:g} mm is wider than the roll, so it is split into {pl["n"]} panels of '
            f'{pw:.1f} x {ph:.1f} mm ({axis}), each overlapping its neighbour by {pl["overlap"]:g} mm. '
            f'Overlap: {OVERLAP_SOURCE if pl.get("default_overlap") else "set on this job (panel_overlap)."}')
