"""Filename candidates for manual imports, never artwork/customer approval.

The registered artwork bytes and name bind an explicit manual resolution.
Portal source bindings are validated separately and never use this inference.
"""
import hashlib
import re


_ORDER = re.compile(r'[A-Za-z0-9][A-Za-z0-9._-]{0,23}')
_ITEM = re.compile(r'[0-9]{1,12}[A-Za-z]{0,3}')
_NAME = re.compile(r'(?P<order>SP-[0-9]{1,12})(?: (?P<invoice>INV-[0-9]{1,12}))? - '
                   r'(?P<item>[0-9]{1,12}[A-Za-z]{0,3}) - (?P<site>.+)\.(?i:pdf)')


def filename_candidate(name):
    """Keep exact issued tokens; only strip the established artwork suffix."""
    if (not isinstance(name, str) or len(name) > 500 or re.search(r'[\x00-\x1f\x7f/\\]', name)):
        return None
    match = _NAME.fullmatch(name)
    if not match:
        return None
    site = match['site']
    suffix = re.fullmatch(r'(.+)_[A-Za-z0-9][A-Za-z0-9.-]*_(?:print|cut)_.+', site, re.I)
    if suffix:
        site = suffix[1]
    # A second reference is ambiguous, not part of a confidently parsed site.
    if not site.strip() or site != site.strip() or re.search(r'\b(?:SP|INV)-\d', site):
        return None
    return dict(order_ref=match['order'], item_number=match['item'],
                site_ref=site, invoice_ref=match['invoice'])


def resolve_manual_identity(key, artwork, order_ref='', item_number='', site_ref='', confirm=False):
    """One resolution predicate for every manual import and validation path.

    An exact filename candidate may populate fields for review. A conflict is
    held until the operator explicitly corrects it; unrecognized names require
    explicit original identifiers. None of this confirms order/artwork approval.
    """
    name = artwork.get('name') or ''
    candidate = filename_candidate(name)
    if not confirm and candidate:
        if not item_number:
            item_number = candidate['item_number']
        if not site_ref:
            site_ref = candidate['site_ref']
    fields = dict(order_ref=order_ref, item_number=item_number, site_ref=site_ref)
    reason = ''
    if not isinstance(order_ref, str) or not _ORDER.fullmatch(order_ref):
        reason = 'Choose the original order for this artwork.'
    elif candidate and order_ref != candidate['order_ref']:
        reason = f"Filename identifies {candidate['order_ref']}; correct the order assignment before continuing."
    elif candidate and item_number != candidate['item_number']:
        reason = f"Retain original item {candidate['item_number']} from the filename."
    elif not isinstance(item_number, str) or not _ITEM.fullmatch(item_number):
        reason = 'Enter the original item number, including its issued suffix.'
    elif not isinstance(site_ref, str) or not site_ref.strip() or site_ref != site_ref.strip() or len(site_ref) > 300 or re.search(r'[\x00-\x1f\x7f]', site_ref):
        reason = 'Enter the original site reference.'
    elif candidate and site_ref != candidate['site_ref'] and confirm is not True:
        reason = 'Confirm the canonical site reference; the filename site alias will be retained.'
    elif not candidate and not confirm:
        reason = 'Filename identity is missing or ambiguous. Enter and confirm the original order, item and site.'
    # A recognizable order prefix remains evidence even if the rest is invalid.
    hint = re.match(r'^(SP-[0-9]{1,12})(?=\s|$)', name) if isinstance(name, str) else None
    if not reason and not candidate and hint and order_ref != hint[1]:
        reason = f'Filename identifies {hint[1]}; correct the order assignment before continuing.'
    record = dict(schema='manual-artwork-identity-1', artwork_key=key, filename=name,
                  artwork_sha256=hashlib.sha256(artwork.get('bytes') or b'').hexdigest(),
                  candidate=candidate, explicitly_corrected=confirm is True,
                  status='held' if reason else 'resolved', reason=reason, **fields)
    return dict(**fields, manual_identity=record)


def validate_manual_identity(row, artwork):
    """Untagged saved legacy rows retain their existing validation contract."""
    record = row.get('manual_identity')
    if record is None:
        return
    if not isinstance(record, dict) or record.get('status') != 'resolved':
        raise ValueError('Manual import identity is held. Correct and confirm the original order, item and site.')
    if any(record.get(field) != row.get(field) for field in ('order_ref', 'item_number', 'site_ref')):
        raise ValueError('Manual import identity or artwork changed. Correct and confirm the original identifiers again.')
    expected = resolve_manual_identity(row.get('artwork'), artwork, row.get('order_ref'),
                                      row.get('item_number'), row.get('site_ref'),
                                      record.get('explicitly_corrected') is True)['manual_identity']
    if expected['status'] != 'resolved' or record != expected:
        raise ValueError('Manual import identity or artwork changed. Correct and confirm the original identifiers again.')
