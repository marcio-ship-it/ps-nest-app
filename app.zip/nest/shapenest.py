"""True-shape nesting for PS Nest (Phase 2, 17-Sep-2026).

Raster bottom-left-fill with free rotation steps and pair clustering.  Every part outline
is dilated by half the gap and rasterised *conservatively* on a grid of r mm (a cell is
marked when the dilated shape touches any of it), so two rasters that do not share a cell
are at least `gap` apart.  Each sheet is a list of Python big-ints (one per grid row); a
part can sit at column i of window row j when no marked cell of the part lands on a marked
cell of the sheet.  The search is bit-parallel: for a run of L marked cells starting at
column a in a part row, the forbidden start columns against sheet row m are
(m | m>>1 | ... | m>>(L-1)) >> a.

Identical rotatable parts are first paired (a copy rotated 180 or 0 degrees is slid against
the original to find the tightest interlock); a pair whose bounding box beats two singles
is nested as one unit.  Several passes (orderings x orientation x objective) run inside the
time budget and the best layout by engine.score wins.  The result is then checked exactly
with polygon distances in `validate_shapes`.  Pure Python, no dependencies.
"""
from __future__ import annotations
import math, time, random
from . import geom
from .engine import FIT_TOL
from .control import Progress, Stopped

FLAT_TOL = 0.05          # chord tolerance used when flattening arcs for the raster (added to the dilation)
CHECK_TOL = 0.01         # chord tolerance used by the exact validator
SEED = 20260916
OPEN = 1e-9              # the dilation is treated as an open set: parts exactly `gap` apart may share a cell edge
PAIR_GAIN = 0.03         # a pair must save at least this fraction of two single bounding boxes


# ------------------------------------------------------------------ rasteriser
def _spans_at(poly, y):
    xs = []
    n = len(poly)
    for i in range(n):
        x1, y1 = poly[i]; x2, y2 = poly[(i + 1) % n]
        if (y1 <= y) != (y2 <= y):
            xs.append(x1 + (y - y1) * (x2 - x1) / (y2 - y1))
    xs.sort()
    return [(xs[k], xs[k + 1]) for k in range(0, len(xs) - 1, 2)]


def rasterise(polys, r, d, K):
    """Conservative raster of the union of `polys` (bbox min at the origin) dilated by d on cells of r mm.
    Cell (c, j) covers x in [(c-K) r, (c-K+1) r) and y in [(j-K) r, (j-K+1) r).
    Returns (rows, pc, pr): rows[j] is an int whose bit c is cell (c, j); pc/pr = columns/rows used."""
    if polys and isinstance(polys[0][0], (int, float)): polys = [polys]
    x1 = max(x for p in polys for x, _ in p); y1 = max(y for p in polys for _, y in p)
    ncols = int(math.floor((x1 + d) / r + K)) + 1
    nrows = int(math.floor((y1 + d) / r + K)) + 1
    edges = [(p[i], p[(i + 1) % len(p)]) for p in polys for i in range(len(p))]
    rows = []
    for j in range(nrows):
        ylo = (j - K) * r - d + OPEN; yhi = (j - K + 1) * r + d
        iv = []
        for p in polys: iv += _spans_at(p, ylo)
        for (ax, ay), (bx, by) in edges:
            lo, hi = (ay, by) if ay <= by else (by, ay)
            if hi < ylo or lo >= yhi: continue
            if abs(by - ay) < geom.EPS: xa, xb = ax, bx
            else:
                ta = min(1.0, max(0.0, (ylo - ay) / (by - ay))); tb = min(1.0, max(0.0, (yhi - ay) / (by - ay)))
                xa = ax + ta * (bx - ax); xb = ax + tb * (bx - ax)
            iv.append((xa, xb) if xa <= xb else (xb, xa))
        iv = sorted((a - d + OPEN, b + d - OPEN) for a, b in iv)
        merged = []
        for a, b in iv:
            if merged and a <= merged[-1][1]: merged[-1] = (merged[-1][0], max(merged[-1][1], b))
            else: merged.append((a, b))
        m = 0
        for a, b in merged:
            u = a / r + K; v = b / r + K
            if v <= u: continue
            c0 = max(0, int(math.floor(u))); c1 = min(ncols - 1, int(math.ceil(v)) - 1)
            if c1 >= c0: m |= ((1 << (c1 - c0 + 1)) - 1) << c0
        rows.append(m)
    while rows and not rows[-1]: rows.pop()
    pc = max((m.bit_length() for m in rows), default=0)
    return rows, pc, len(rows)


def _runs(m):
    """[(start, length)] of the set-bit runs of m."""
    out = []
    while m:
        low = m & -m
        a = low.bit_length() - 1
        t = m >> a
        L = (t ^ (t + 1)).bit_length() - 1
        out.append((a, L))
        m &= ~(((1 << L) - 1) << a)
    return out


_SHIFTS = {}


def _shifts(L):
    """Shift schedule so that applying res |= res >> s for each s gives m | m>>1 | ... | m>>(L-1)."""
    sh = _SHIFTS.get(L)
    if sh is None:
        out = []; done = 1
        while done < L:
            step = min(done, L - done); out.append(step); done += step
        sh = _SHIFTS[L] = tuple(out)
    return sh


def _dil(m, L):
    """m | m>>1 | ... | m>>(L-1)."""
    for sft in _shifts(L): m |= m >> sft
    return m


# ------------------------------------------------------------------ nesting units
class _Item:
    """A nesting unit: one part, or a cluster of parts fixed relative to each other.
    members = [(part, member_angle, loops)] with each part's loops already rotated by its member angle
    and translated into the cluster frame (cluster bbox min at the origin).  Variants are cached by
    `key`, so they refer to members by index, never by part."""
    __slots__ = ('members', 'rotate', 'key', 'area', 'w', 'h', 'perim')

    def __init__(self, members, rotate, key):
        self.members, self.rotate, self.key = members, rotate, key
        self.area = sum(p.true_area() if p is not None else sum(geom.area(o) for o in ls) for p, _, ls in members)
        x0, y0, x1, y1 = geom.bbox_outline([v for _, _, ls in members for o in ls for v in o])
        self.w, self.h = x1 - x0, y1 - y0
        per = 0.0
        for _, _, ls in members:
          for o in ls:
            poly = geom.flatten(o, 0.5)
            per += sum(math.hypot(poly[i][0] - poly[i - 1][0], poly[i][1] - poly[i - 1][1]) for i in range(len(poly)))
        self.perim = per


def _single(part):
    ls, w, h = geom.normalise_loops(part.shape_loops())
    return _Item([(part, 0.0, ls)], part.rotate, ('one', part.shape_outline_key(), part.rotate))


class _Variant:
    """An item at one angle (and optionally reflected for the transposed search), rasterised."""
    __slots__ = ('angle', 'members', 'w', 'h', 'rows', 'pc', 'pr', 'runs', 'key')

    def __init__(self, angle, item, r, d, K, transpose):
        self.angle = angle
        outs = []                                          # one list of loops per member
        for part, ma, ls in item.members:
            mm = []
            for o in ls:
                oo = geom.rotate(o, angle) if angle else [(v[0], v[1], v[2] if len(v) > 2 else 0.0) for v in o]
                if transpose: oo = [(v[1], v[0], -v[2]) for v in oo]
                mm.append(oo)
            outs.append(mm)
        x0, y0, x1, y1 = geom.bbox_loops([o for mm in outs for o in mm])
        outs = [[geom.translate(o, -x0, -y0) for o in mm] for mm in outs]
        self.w, self.h = x1 - x0, y1 - y0
        self.members = []
        polys = []
        arcs = False
        for mi, ((_, ma, _), mm) in enumerate(zip(item.members, outs)):
            bx0, by0, bx1, by1 = geom.bbox_loops(mm)
            self.members.append((mi, (angle + ma) % 360.0, bx0, by0, bx1 - bx0, by1 - by0))
            for oo in mm:
                polys.append(geom.flatten(oo, FLAT_TOL))
                arcs = arcs or any(abs(v[2]) > 1e-12 for v in oo)
        # chords sit inside the true arc: widen the dilation by the chord error
        self.rows, self.pc, self.pr = rasterise(polys, r, d + (FLAT_TOL if arcs else 0.0), K)
        self.runs = [_runs(m) for m in self.rows]
        self.key = tuple(self.rows)


def _variants(item, angles, r, d, K, transpose):
    out, seen = [], set()
    for a in angles:
        v = _Variant(a, item, r, d, K, transpose)
        if v.key in seen: continue
        seen.add(v.key); out.append(v)
    return out


def part_angles(part, rot_step):
    if not part.rotate: return [0.0]
    step = float(rot_step) if rot_step and rot_step > 0 else 90.0
    n = max(1, int(round(360.0 / step)))
    return [round(k * 360.0 / n, 6) for k in range(n)]


# ------------------------------------------------------------------ sheet grid
class _SheetGrid:
    __slots__ = ('occ', 'ncols', 'nrows', 'cache', 'placed', 'top', 'right', 'uw', 'uh', 'r', 'rules')

    def __init__(self, ncols, nrows, uw=None, uh=None, r=None):
        self.occ = [0] * nrows; self.ncols = ncols; self.nrows = nrows
        self.uw, self.uh, self.r = uw, uh, r        # exact usable size (mm) and cell size, when known
        self.cache = [None] * nrows; self.placed = []
        self.top = 0; self.right = 0     # rows / columns beyond these are empty
        self.rules = None                # the sheet's own rules (size) when it is a stock sheet

    def find(self, v):
        """Lowest (row, col) where variant v fits, or None."""
        span = self.ncols - v.pc + 1
        last = self.nrows - v.pr
        if self.r:      # the exact bbox must stay inside the usable area (the raster only bounds the dilated cells)
            span = min(span, int(math.floor((self.uw + FIT_TOL - v.w) / self.r + 1e-9)) + 1)
            last = min(last, int(math.floor((self.uh + FIT_TOL - v.h) / self.r + 1e-9)))
        if span <= 0 or last < 0: return None
        full = (1 << span) - 1
        occ = self.occ; cache = self.cache; runs = v.runs; pr = v.pr; top = self.top
        for j in range(min(top, last) + 1):
            if j >= top: return (j, 0)                      # nothing above the pile: sits at the left edge
            forb = 0; blocked = False
            for k in range(min(pr, top - j)):
                m = occ[j + k]
                if not m: continue
                rc = cache[j + k]
                if rc is None: rc = cache[j + k] = {}
                for a, L in runs[k]:
                    dm = rc.get(L)
                    if dm is None:
                        dm = m
                        for sft in _shifts(L): dm |= dm >> sft
                        rc[L] = dm
                    forb |= dm >> a
                if (forb & full) == full: blocked = True; break
            if blocked: continue
            free = ~forb & full
            if free: return (j, (free & -free).bit_length() - 1)
        return None

    def place(self, v, i, j, item=None):
        occ = self.occ
        for k, m in enumerate(v.rows):
            if m: occ[j + k] |= m << i
        self.top = max(self.top, j + v.pr); self.right = max(self.right, i + v.pc)
        self.cache = [None] * self.nrows
        self.placed.append((v, i, j, item))


# ------------------------------------------------------------------ pairing
def _slide(A, B, stop=None):
    """B (rows/pc/pr/runs) slid down each column dx in [0, A.pc] against A fixed at (0, 0):
    returns {dx: lowest dy >= 0 with no shared cell}.  Raises Stopped when `stop()` turns true mid-sweep."""
    full = (1 << (A.pc + 1)) - 1
    best = {}; remaining = full
    for dy in range(A.pr + 1):
        if stop is not None and dy % 8 == 7 and stop(): raise Stopped('stopped while pairing')
        if dy >= A.pr: free = full
        else:
            forb = 0
            for k in range(min(B.pr, A.pr - dy)):
                m = A.rows[dy + k]
                if not m: continue
                for a, L in B.runs[k]: forb |= _dil(m, L) >> a
            free = ~forb & full
        new = free & remaining
        while new:
            low = new & -new; best[low.bit_length() - 1] = dy; new ^= low
        remaining &= ~free
        if not remaining: break
    return best


class _Raster:
    __slots__ = ('rows', 'pc', 'pr', 'runs')

    def __init__(self, rows):
        self.rows = rows; self.pc = max((m.bit_length() for m in rows), default=0); self.pr = len(rows)
        self.runs = [_runs(m) for m in rows]


def pair_offset(loops, partner_angles, r, d, K, rotate=True, stop=None):
    """Best interlock of a part (its outer loops) with a copy of itself rotated by one of `partner_angles`.
    Returns (partner_angle, dx_cells, dy_cells, pair_cells, single_cells) or None when no
    pairing saves at least PAIR_GAIN of two single bounding boxes.  dy may be negative."""
    if loops and isinstance(loops[0][0], (int, float)): loops = [loops]
    l0, w, h = geom.normalise_loops(loops)
    base = _Variant(0.0, _Item([(None, 0.0, l0)], rotate, None), r, d, K, False)
    A = _Raster(base.rows)
    single = A.pc * A.pr
    best = None
    for pa in partner_angles:
        B = _Raster(_Variant(float(pa), _Item([(None, 0.0, l0)], rotate, None), r, d, K, False).rows)
        cands = []
        for dx, dy in _slide(A, B, stop).items(): cands.append((dx, dy))
        Af = _Raster(list(reversed(A.rows))); Bf = _Raster(list(reversed(B.rows)))
        for dx, dyf in _slide(Af, Bf, stop).items(): cands.append((dx, A.pr - B.pr - dyf))
        for dx, dy in cands:
            W = max(A.pc, dx + B.pc)
            H = max(A.pr, dy + B.pr) - min(0, dy)
            cells = W * H
            if best is None or cells < best[3]: best = (float(pa), dx, dy, cells, single)
    if best is None or best[3] > 2 * single * (1.0 - PAIR_GAIN): return None
    return best


def refine_pair(loops, pa, dx, dy, gap, step, stop=None):
    """Slide the raster pair offset (mm) back towards the origin in sub-cell steps while the exact
    polygon distance stays >= gap (+0.01 mm safety).  Returns the refined (dx, dy) in mm."""
    if loops and isinstance(loops[0][0], (int, float)): loops = [loops]
    la, _, _ = geom.normalise_loops(loops)
    lb, _, _ = geom.normalise_loops([geom.rotate(o, pa) for o in la])
    qa = [geom.flatten(o, CHECK_TOL) for o in la]; qb0 = [geom.flatten(o, CHECK_TOL) for o in lb]
    need = gap + 0.01
    def ok(x, y):
        for pa_ in qa:
            for pb_ in qb0:
                qb = [(px + x, py + y) for px, py in pb_]
                if geom.poly_distance(pa_, qb, stop_at=need) < need: return False
        return True
    if not ok(dx, dy): return dx, dy
    for axis in (0, 1):
        while True:
            if stop is not None and stop(): raise Stopped('stopped while pairing')
            v = (dx, dy)[axis]
            if abs(v) < step * 0.5: break
            nv = v - step if v > 0 else v + step
            cand = (nv, dy) if axis == 0 else (dx, nv)
            if not ok(*cand): break
            dx, dy = cand
    return dx, dy


def _pair_item(parts, pa, dx, dy):
    """Two identical parts as one cluster: parts[0] at 0 deg, parts[1] rotated pa at (dx, dy) mm."""
    a, b = parts
    la, _, _ = geom.normalise_loops(a.shape_loops())
    lb, _, _ = geom.normalise_loops([geom.rotate(o, pa) for o in la])
    ay = max(0.0, -dy); by = max(0.0, dy)
    members = [(a, 0.0, [geom.translate(o, 0.0, ay) for o in la]), (b, float(pa), [geom.translate(o, dx, by) for o in lb])]
    return _Item(members, a.rotate, ('pair', a.shape_outline_key(), a.rotate, pa, round(dx, 6), round(dy, 6)))


# ------------------------------------------------------------------ nesting
def pick_grid(rules):
    """Cell size: the requested grid, shrunk so that half the gap is a whole number of cells."""
    d = rules.gap / 2.0
    r = float(getattr(rules, 'grid', 2.0) or 2.0)
    if d > 0:
        k = math.ceil(d / r - 1e-9)
        if k > 0: r = d / k
    return max(r, 0.25)


DEFAULT_PASSES = [('area', False, 'bl'), ('area', True, 'bl'), ('area', False, 'bbox'), ('area', True, 'bbox'),
                  ('max', False, 'bl'), ('max', True, 'bbox'), ('h', False, 'bl'), ('w', True, 'bl'),
                  ('perim', False, 'bbox'), ('perim', True, 'bl')]


def nest_shapes(parts, rules, time_budget=45.0, seed=SEED, passes=None, pairing=True, info=None,
                should_stop=None, progress=None):
    """Place every part; returns a list of engine.Sheet.  Raises ValueError when a part cannot fit an empty sheet.
    `info` (dict) receives 'passes', 'pairs' and 'grid' when given."""
    from .engine import Placed, Sheet, score
    stop = should_stop or (lambda: False)
    prog = progress if isinstance(progress, Progress) else Progress(progress)
    t0 = time.monotonic()
    r = pick_grid(rules)
    d = rules.gap / 2.0
    K = int(math.ceil((d + FLAT_TOL) / r - 1e-9))
    uw, uh = rules.usable_w, rules.usable_h
    beds = [(uw, uh)] + [(rules.for_size(sz).usable_w, rules.for_size(sz).usable_h) for sz in rules.stock_sizes()]

    vcache = {}
    def variants(item, transpose):
        key = (item.key, transpose)
        if key not in vcache:
            angles = part_angles(item.members[0][0], rules.rot_step) if item.rotate else [0.0]
            vcache[key] = _variants(item, angles, r, d, K, transpose)
        return vcache[key]

    def fits_empty(item):
        return any(v.w <= bw + FIT_TOL and v.h <= bh + FIT_TOL for bw, bh in beds for v in variants(item, False))

    pins = {str(p[0]): p for p in (rules.pins or ())}
    singles = {id(p): _single(p) for p in parts}      # keyed by the object, not the label: two rows may share a name
    for p in parts:
        if not fits_empty(singles[id(p)]):
            raise ValueError(f'part {p.name} ({p.w:g} x {p.h:g}) does not fit the usable sheet area {uw:g} x {uh:g}')

    # pair identical non-rectangular parts (largest shapes first, within a quarter of the budget)
    items = []; pairs = []
    groups = {}
    for p in parts: groups.setdefault((p.shape_outline_key(), p.rotate), []).append(p)
    order = sorted(groups.values(), key=lambda g: -g[0].true_area() * len(g))
    prog(stage='pairing', force=True)
    for grp in order:
        p0 = grp[0]
        prog(stage='pairing', pairs=len(pairs))
        if pairing and len(grp) >= 2 and p0.shaped and not stop() and time.monotonic() - t0 < time_budget * 0.25 \
                and not any(p.name in pins for p in grp):
            pa = [180.0, 0.0] if p0.rotate else [0.0]
            try:
                po = pair_offset(p0.shape_loops(), pa, r, d, K, p0.rotate, stop=stop)
                if po is not None:
                    ang, dx, dy, cells, single = po
                    dx, dy = refine_pair(p0.shape_loops(), ang, dx * r, dy * r, rules.gap, r / 4.0, stop=stop)
            except Stopped: po = None            # Stop pressed mid-pair: this group nests as singles
            if po is not None:
                trial = _pair_item(grp[:2], ang, dx, dy)
                if fits_empty(trial):
                    pairs.append((p0.name, ang, round(dx, 3), round(dy, 3), round(1.0 - cells / (2.0 * single), 3)))
                    k = 0
                    while k + 1 < len(grp):
                        items.append(_pair_item(grp[k:k + 2], ang, dx, dy)); k += 2
                    for p in grp[k:]: items.append(singles[id(p)])
                    continue
        for p in grp: items.append(singles[id(p)])

    sizes = rules.stock_sizes()          # stock sheets (remnants / a second size) are filled first, in order
    def sheet_rules(k):
        return rules.for_size(sizes[k]) if k < len(sizes) else rules

    def grid_dims(transpose, uw=uw, uh=uh):
        w, h = (uh, uw) if transpose else (uw, uh)
        # enough cells for a part the full usable size plus its half-gap dilation; the exact bbox test in
        # _SheetGrid.find keeps parts inside the usable area
        return int(math.ceil((w + d + FLAT_TOL) / r + K - 1e-9)) + 1, int(math.ceil((h + d + FLAT_TOL) / r + K - 1e-9)) + 1

    def choose(g, vs, objective):
        best = None
        for vi, v in enumerate(vs):
            pos = g.find(v)
            if pos is None: continue
            j, i = pos
            if objective == 'bbox': k = (max(g.right, i + v.pc) * max(g.top, j + v.pr), j, i, vi)
            else: k = (j, i, vi)
            if best is None or k < best: best = k
        if best is None: return None
        return best[-3], best[-2], best[-1]    # j, i, vi

    def new_grid(grids, transpose):
        k = len(grids); rk = sheet_rules(k)
        ncols, nrows = grid_dims(transpose, rk.usable_w, rk.usable_h)
        g = _SheetGrid(ncols, nrows, rk.usable_h if transpose else rk.usable_w, rk.usable_w if transpose else rk.usable_h, r)
        g.rules = rk; grids.append(g)
        return g

    def pin_item(grids, item, pin, transpose):
        """Place a locked part where the user left it (by its bounding box) on the sheet the pin names."""
        want = int(pin[1]); ang = float(pin[4]) if len(pin) > 4 else 0.0
        while len(grids) <= want: new_grid(grids, transpose)
        g = grids[want]; rk = g.rules
        vs = variants(item, transpose)
        v = min(vs, key=lambda v: abs(((v.members[0][1] - ang + 180.0) % 360.0) - 180.0))
        mi, wa, mx, my, mw, mh = v.members[0]
        px, py = float(pin[2]), float(pin[3])
        if transpose: j, i = (px - rk.ml - my) / r, (py - rk.mb - mx) / r
        else: i, j = (px - rk.ml - mx) / r, (py - rk.mb - my) / r
        i = min(max(int(round(i)), 0), max(0, g.ncols - v.pc)); j = min(max(int(round(j)), 0), max(0, g.nrows - v.pr))
        g.place(v, i, j, item)

    def run_pass(order, transpose, objective):
        grids = []
        rest = []
        for item in order:
            pin = pins.get(item.members[0][0].name) if len(item.members) == 1 else None
            if pin is not None: pin_item(grids, item, pin, transpose)
            else: rest.append(item)
        for n, item in enumerate(rest):
            if abandon(): raise Stopped('stopped mid-layout')
            prog(stage='layouts', placed=n, total=len(rest))
            vs = variants(item, transpose)
            hit = None
            for g in grids:
                hit = choose(g, vs, objective)
                if hit is not None: break
            while hit is None:
                g = new_grid(grids, transpose)
                hit = choose(g, vs, objective)
                if hit is None and len(grids) > len(sizes):
                    raise ValueError(f'part {item.members[0][0].name} does not fit an empty sheet')
            j, i, vi = hit
            g.place(vs[vi], i, j, item)
        sheets = []
        for g in grids:
            if not g.placed: continue                     # an empty stock sheet stays on the rack
            rk = g.rules; placed = []
            for v, i, j, item in g.placed:
                for mi, wa, mx, my, mw, mh in v.members:
                    part = item.members[mi][0]
                    if transpose: x, y, w, h = rk.ml + j * r + my, rk.mb + i * r + mx, mh, mw
                    else: x, y, w, h = rk.ml + i * r + mx, rk.mb + j * r + my, mw, mh
                    placed.append(Placed(part, x, y, w, h, rotated=abs(wa % 360.0) > 1e-9, angle=wa % 360.0))
            sheets.append(Sheet(placed, size=(rk.sheet_w, rk.sheet_h) if rk is not rules else None))
        return sheets

    keyf = {'area': lambda it: -it.area, 'max': lambda it: -max(it.w, it.h), 'h': lambda it: -it.h,
            'w': lambda it: -it.w, 'perim': lambda it: -it.perim}
    rng = random.Random(seed)
    if passes is None: passes = DEFAULT_PASSES
    passes = [(p[0], p[1], p[2] if len(p) > 2 else 'bl') for p in passes]
    best = None; best_score = None; tried = []
    idx = 0; stopped = False
    # Stop protocol (control.py): 1 keeps the best finished layout, finishing the first if none has; 2 abandons.
    def abandon():
        s = stop()
        return bool(s) and (best is not None or s >= 2)
    while True:
        if abandon(): stopped = True; break
        if idx < len(passes):
            name, transpose, objective = passes[idx]
            order = sorted(items, key=keyf[name])
        else:
            name, transpose, objective = 'shuffle', bool(idx % 2), ('bl', 'bbox')[(idx // 2) % 2]
            order = list(sorted(items, key=keyf['area']))
            for _ in range(max(1, len(order) // 4)):          # perturb: swap a few neighbours, keep big parts first
                a = rng.randrange(len(order)); b = min(len(order) - 1, a + rng.randrange(1, 4))
                order[a], order[b] = order[b], order[a]
        t1 = time.monotonic()
        try: sheets = run_pass(order, transpose, objective)
        except Stopped: stopped = True; break
        sc = score(sheets, rules)
        tried.append((name, transpose, objective, len(sheets), round(time.monotonic() - t1, 3)))
        if best_score is None or sc < best_score: best, best_score = sheets, sc
        prog(stage='layouts', tried=len(tried), best_sheets=len(best), force=True)
        idx += 1
        elapsed = time.monotonic() - t0
        if idx >= len(passes) + 8: break
        if elapsed > time_budget and idx >= 2: break
    if info is not None:
        info['passes'] = tried; info['pairs'] = pairs; info['grid'] = r; info['seconds'] = round(time.monotonic() - t0, 2)
        info['stopped'] = stopped
    return best


# ------------------------------------------------------------------ exact validation
def validate_shapes(sheets, parts, rules):
    """Hard checks with real geometry (arcs flattened to CHECK_TOL mm): every part placed once,
    inside the margin, at an allowed angle, and at least `gap` from every other part."""
    issues = []
    placed = [pl for s in sheets for pl in s.placed]
    names = sorted(p.name for p in parts); got = sorted(pl.part.name for pl in placed)
    if names != got: issues.append(f'placed {len(got)} of {len(names)} parts')
    for s in sheets:
        rs = rules.for_sheet(s); W, H = rs.sheet_w, rs.sheet_h
        polys = []
        for pl in s.placed:
            ls = geom.world_loops(pl.part.shape_loops(), pl.angle, pl.x, pl.y)
            x0, y0, x1, y1 = geom.bbox_loops(ls)
            if x0 < rs.ml - FIT_TOL or y0 < rs.mb - FIT_TOL or x1 > W - rs.mr + FIT_TOL or y1 > H - rs.mt + FIT_TOL:
                issues.append(f'{pl.part.name} outside the margin: bbox {x0:.2f},{y0:.2f}-{x1:.2f},{y1:.2f}')
            if not pl.part.rotate and abs(pl.angle % 360.0) > 1e-9:
                issues.append(f'{pl.part.name} rotated {pl.angle:g} but rotation is locked')
            elif pl.part.rotate:
                step = float(rules.rot_step) if rules.rot_step else 90.0
                if abs((pl.angle / step) - round(pl.angle / step)) > 1e-6:
                    issues.append(f'{pl.part.name} angle {pl.angle:g} is not a multiple of {step:g}')
            for o in ls:
                poly = geom.flatten(o, CHECK_TOL)
                polys.append((pl, poly, geom.bbox_poly(poly)))
        g = rules.gap
        for a in range(len(polys)):
            pa, qa, ba = polys[a]
            for b in range(a + 1, len(polys)):
                pb, qb, bb = polys[b]
                if pa is pb: continue
                if ba[2] + g <= bb[0] - 1e-6 or bb[2] + g <= ba[0] - 1e-6 or ba[3] + g <= bb[1] - 1e-6 or bb[3] + g <= ba[1] - 1e-6:
                    continue
                dist = geom.poly_distance(qa, qb, stop_at=g)
                if dist <= 1e-9 and geom.polys_overlap(qa, qb):        # gap 0 allows touching, never one part over another
                    issues.append(f'{pa.part.name} and {pb.part.name} overlap')
                elif dist < g - 1e-6:
                    issues.append(f'{pa.part.name} and {pb.part.name} are {dist:.3f} mm apart (gap {g:g})')
    return issues
