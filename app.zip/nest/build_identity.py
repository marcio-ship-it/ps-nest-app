"""Identity of the source copied into a distributable build.

The build scripts replace this file inside the staged application. A source
checkout deliberately reports ``development`` so an acceptance script cannot
mistake an unsealed checkout for a packaged release.
"""

BUILD = {
    'source_commit': 'development',
    'built_at': None,
}
