"""Safe printed identifiers for combined-order nests.

The labels are production marks, not nesting geometry.  They are planned only
after a layout exists and are refused unless every identifier fits in clear
sheet space outside every part's artwork/bleed box.  Callers can therefore
leave this module unused for ordinary jobs without changing their layouts or
files.
"""
from __future__ import annotations

from decimal import Decimal, ROUND_HALF_UP
import math

from . import customcuts, geom


FONT_NAME = 'Helvetica'
FONT_SIZE = 6.0                 # plain, minimal production reference proposed size; physical readability requires a sample
PAD_MM = 0.35
PAGE_CLEAR_MM = 0.25
OBJECT_CLEAR_MM = 0.25
CUT_CLEAR_MM = 0.5
REGISTRATION_CLEAR_MM = 0.5
ASSOCIATION_MARGIN_MM = 1.0


def _text_size(text):
    from reportlab.pdfbase.pdfmetrics import getAscentDescent, stringWidth
    from .outputs import MM
    ascent, descent = getAscentDescent(FONT_NAME, FONT_SIZE)
    return (stringWidth(text, FONT_NAME, FONT_SIZE) / MM + 2 * PAD_MM,
            (ascent - descent) / MM + 2 * PAD_MM)


def min_gap(overhang):
    """Smallest part gap (to the 0.5 mm gap field step) whose waste strip between two
    bleeds holds a reference that is still clearly nearer its own part."""
    need = 2 * overhang + _text_size('0')[1] + 2 * OBJECT_CLEAR_MM + ASSOCIATION_MARGIN_MM
    return math.ceil((need + 0.01) * 2) / 2


def _whole_mm(value):
    """Display millimetres half-up without changing the exact part geometry."""
    return int(Decimal(str(value)).quantize(Decimal('1'), rounding=ROUND_HALF_UP))


def compact_ref(order_ref, piece_id, finished_w=None, finished_h=None):
    """Operator-facing identity, optionally followed by finished dimensions.

    Arbitrary externally supplied IDs retain their full value after the dot;
    only the canonical order-prefixed form is shortened.
    """
    prefix = order_ref + ':'
    sequence = piece_id[len(prefix):] if piece_id.startswith(prefix) and piece_id[len(prefix):] else piece_id
    text = f'{order_ref} · {sequence}'
    if finished_w is not None and finished_h is not None:
        text += f' · {_whole_mm(finished_w)} × {_whole_mm(finished_h)} mm'
    return text


def printed_ref(part):
    """Exact compact reference printed beside a combined-order finished part (a roll panel says which panel)."""
    panel = getattr(part, 'panel', '') or ''
    tail = f' · {panel}' if panel else ''
    if part.item_number and getattr(part, 'piece_id_base', ''):
        return (f'{part.order_ref} · item {part.item_number} · part {part.source_part_id} · copy {part.copy_number}'
                f' · {_whole_mm(part.w)} × {_whole_mm(part.h)} mm' + tail)
    if part.item_number:
        return (f'{part.order_ref} · item {part.item_number} · copy {part.copy_number}'
                f' · {_whole_mm(part.w)} × {_whole_mm(part.h)} mm' + tail)
    return compact_ref(part.order_ref, part.piece_id, part.w, part.h) + tail


def _expanded_box(pl, bleed):
    b = max(0.0, float(bleed or 0))
    return (pl.x - b, pl.y - b, pl.x + pl.w + b, pl.y + pl.h + b)


def _overlaps(a, b, clear=0.0):
    """True when axis-aligned boxes overlap or come within ``clear`` mm."""
    return not (a[2] + clear <= b[0] or b[2] + clear <= a[0] or
                a[3] + clear <= b[1] or b[3] + clear <= a[1])


def _box_distance(a, b):
    """Euclidean clearance between disjoint boxes; zero if they overlap."""
    dx = max(b[0] - a[2], a[0] - b[2], 0.0)
    dy = max(b[1] - a[3], a[1] - b[3], 0.0)
    return math.hypot(dx, dy)


def _registration_boxes(rules, ccd_dots):
    """Conservative boxes around the active cutter-camera dots on this sheet."""
    if not ccd_dots:
        return []
    from .outputs import ccd_dot_positions, dot_diameter
    radius = dot_diameter(ccd_dots) / 2
    return [(x - radius, y - radius, x + radius, y + radius)
            for x, y in ccd_dot_positions(rules.sheet_w, rules.sheet_h, ccd_dots)]


def _line_hits_box(line, box):
    """Conservative polyline/rectangle collision, including a clearance-expanded box."""
    x0, y0, x1, y1 = box
    edges = [((x0, y0), (x1, y0)), ((x1, y0), (x1, y1)),
             ((x1, y1), (x0, y1)), ((x0, y1), (x0, y0))]
    inside = lambda p: x0 <= p[0] <= x1 and y0 <= p[1] <= y1
    for a, b in zip(line, line[1:]):
        if inside(a) or inside(b): return True
        if any(geom.segments_intersect(a, b, c, d) for c, d in edges): return True
    return False


def _candidates(target, w, h):
    """Deterministic candidates immediately adjacent to the identified part."""
    x0, y0, x1, y1 = target
    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
    xs = (x0, cx - w / 2, x1 - w)
    ys = (y0, cy - h / 2, y1 - h)
    gap = OBJECT_CLEAR_MM
    out = []
    out += [(x, y0 - gap - h) for x in xs]
    out += [(x, y1 + gap) for x in xs]
    out += [(x0 - gap - w, y) for y in ys]
    out += [(x1 + gap, y) for y in ys]
    # Preserve order while removing duplicate coordinates.
    seen = set(); unique = []
    for x, y in out:
        key = (round(x, 6), round(y, 6))
        if key not in seen: seen.add(key); unique.append((x, y))
    return unique


def plan_labels(sheets, rules, bleed, ccd_dots=None):
    """Return per-sheet printed label records for a combined-order layout.

    A record has ``text``, order/source/piece identifiers, the source part
    name, and its axis-aligned ``x``, ``y``, ``w``, ``h`` box in sheet mm.
    Labels remain page-oriented even when the source part is rotated or
    mirrored.  ``ValueError`` is raised instead of painting over artwork,
    finished geometry, a camera-registration mark, a separation cut, another
    label, or the page edge.  A label is also refused unless its intended part
    is unambiguously nearer than every other part.
    """
    planned = []
    piece_ids = set()
    for sheet_i, sheet in enumerate(sheets, 1):
        rs = rules.for_sheet(sheet)
        # Keep production text out of edge/clamp/reference zones.  Cutter camera
        # marks and sheet references live there; a label that only fits there is
        # held rather than risking a registration collision.
        xmin = max(PAGE_CLEAR_MM, rs.ml)
        ymin = max(PAGE_CLEAR_MM, rs.mb)
        xmax = min(rs.sheet_w - PAGE_CLEAR_MM, rs.sheet_w - rs.mr)
        ymax = min(rs.sheet_h - PAGE_CLEAR_MM, rs.sheet_h - rs.mt)
        obstacles = [_expanded_box(pl, bleed) for pl in sheet.placed]
        registration = _registration_boxes(rs, ccd_dots)
        cuts = customcuts.paths(sheet, rs)
        labels = []
        for part_i, pl in enumerate(sheet.placed, 1):
            order_ref = str(getattr(pl.part, 'order_ref', '') or '').strip()
            source_part_id = str(getattr(pl.part, 'source_part_id', '') or '').strip()
            piece_id = str(getattr(pl.part, 'piece_id', '') or '').strip()
            if not order_ref or not piece_id:
                raise ValueError(f'Sheet {sheet_i}, part {pl.part.name}: combined-order labels need order_ref and piece_id.')
            if piece_id in piece_ids:
                raise ValueError(f'Duplicate combined-order piece_id: {piece_id}.')
            piece_ids.add(piece_id)
            text = printed_ref(pl.part)
            w, h = _text_size(text)
            target = obstacles[part_i - 1]
            chosen = None
            for x, y in _candidates(target, w, h):
                box = (x, y, x + w, y + h)
                if x < xmin or y < ymin or x + w > xmax or y + h > ymax:
                    continue
                if any(_overlaps(box, obstacle, OBJECT_CLEAR_MM) for obstacle in obstacles):
                    continue
                target_distance = _box_distance(box, target)
                if any(_box_distance(box, obstacle) < target_distance + ASSOCIATION_MARGIN_MM - 1e-9
                       for obstacle_i, obstacle in enumerate(obstacles) if obstacle_i != part_i - 1):
                    continue
                if any(_overlaps(box, other['_box'], OBJECT_CLEAR_MM) for other in labels):
                    continue
                if any(_overlaps(box, mark, REGISTRATION_CLEAR_MM) for mark in registration):
                    continue
                cut_box = (x - CUT_CLEAR_MM, y - CUT_CLEAR_MM, x + w + CUT_CLEAR_MM, y + h + CUT_CLEAR_MM)
                if any(_line_hits_box(line, cut_box) for line in cuts):
                    continue
                chosen = box
                break
            if chosen is None:
                raise ValueError(f'No safe printed-label space for {piece_id} ({order_ref}) on sheet {sheet_i}. Review the spacing or split the batch; labels have not increased the stock or moved parts.')
            x, y, x1, y1 = chosen
            labels.append({'text': text, 'order_ref': order_ref, 'source_part_id': source_part_id,
                           'piece_id': piece_id, 'part': pl.part.name, 'part_index': part_i,
                           'finished_w_mm': pl.part.w, 'finished_h_mm': pl.part.h,
                           'x': round(x, 4), 'y': round(y, 4), 'w': round(x1 - x, 4),
                           'h': round(y1 - y, 4), 'font_size': FONT_SIZE, '_box': chosen})
        for label in labels: label.pop('_box', None)
        planned.append(labels)
    return planned
