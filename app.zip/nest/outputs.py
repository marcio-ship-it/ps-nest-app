"""Output writers: DXF cut file, 1:1 print PDF, CutContour cut PDF, operator layout PDF, SVG preview, JSON report."""
from __future__ import annotations
import io, json, math, re, zipfile
from .engine import strip_offcut, largest_empty_rect, trim_line, trim_cut, remnant, remnant_polygon
from . import geom, customcuts

MM = 72 / 25.4          # PDF points per mm
BULGE90 = math.tan(math.radians(90) / 4)   # bulge for a 90-degree arc

# ---------------------------------------------------------------- placed geometry (shared by every writer)
def placed_loops(pl, corner_radius=0.0):
    """World loops of a placement: [(outer/hole flag, [(x, y, bulge), ...]), ...].
    Rectangles get the optional corner radius; shaped parts use their real outline, islands and holes
    rotated by pl.angle with the bbox of outline+islands at (pl.x, pl.y)."""
    part = pl.part
    if not part.shaped and abs(pl.angle % 90) < 1e-9:        # pl.w / pl.h are already swapped for 90 / 270
        return [('outer', rect_path(pl.x, pl.y, pl.w, pl.h, corner_radius))]
    loops = part.shape_loops() if part.shaped else [rect_path(0, 0, part.w, part.h, corner_radius)]
    n_out = len(loops)
    loops = loops + [list(h) for h in part.holes]
    world = geom.world_loops(loops, pl.angle, pl.x, pl.y)
    return [('outer' if i < n_out else 'hole', w) for i, w in enumerate(world)]


def place_transform(pl):
    """(angle_deg, tx, ty) in mm such that world = R(angle) . frame + (tx, ty) for the part's own frame."""
    part = pl.part
    loops = part.shape_loops() if part.shaped else [[(0, 0, 0), (part.w, 0, 0), (part.w, part.h, 0), (0, part.h, 0)]]
    rot = [geom.rotate(o, pl.angle) if pl.angle else o for o in loops]
    x0, y0, _, _ = geom.bbox_loops(rot)
    return pl.angle, pl.x - x0, pl.y - y0


def _poly_points(loop, tol=0.05):
    """Closed (x, y, bulge) loop -> flattened [(x, y)] for drawing."""
    return geom.flatten(loop, tol)


# ---------------------------------------------------------------- DXF
# Full-form AutoCAD 2000 (AC1015) file: every table, block record and entity carries a handle,
# owner (330) and AcDb subclass markers.  A minimal "header + entities" DXF is NOT enough:
# Tempus Tools rejected exactly that form on 3-Sep-2026 (parts showed "undefined x undefined mm")
# and again on 16-Sep-2026 (blank import), while this full form imports with correct dimensions.
_H = {'vport_t': '1', 'ltype_t': '2', 'layer_t': '3', 'style_t': '4', 'view_t': '5', 'ucs_t': '6',
      'appid_t': '7', 'dimstyle_t': '8', 'blkrec_t': '9', 'vport': 'A', 'byblock': 'B', 'bylayer': 'C',
      'continuous': 'D', 'layer0': 'E', 'cut': 'F', 'sheet': '10', 'label': '11', 'style': '12', 'appid': '13',
      'dimstyle': '14', 'model_rec': '15', 'paper_rec': '16', 'model_blk': '17', 'model_end': '18',
      'paper_blk': '19', 'paper_end': '1A', 'rootdict': '1B'}
_FIRST_ENTITY = 0x20

def _n(v):
    """DXF number: fixed 4 decimals, no exponent, no trailing garbage."""
    t = ('%.4f' % v).rstrip('0').rstrip('.')
    return t if t not in ('', '-0') else '0'

def _table(lines, name, handle, records, subclass=None):
    lines += ['0', 'TABLE', '2', name, '5', handle, '330', '0', '100', 'AcDbSymbolTable', '70', str(len(records))]
    if subclass: lines += ['100', subclass]
    for r in records: lines += r
    lines += ['0', 'ENDTAB']

def _layer(handle, name, colour):
    return ['0', 'LAYER', '5', handle, '330', _H['layer_t'], '100', 'AcDbSymbolTableRecord',
            '100', 'AcDbLayerTableRecord', '2', name, '70', '0', '62', str(colour), '6', 'Continuous']

def _lwpoly(handle, layer, pts, closed=True):
    """pts: [(x, y, bulge), ...]"""
    s = ['0', 'LWPOLYLINE', '5', handle, '330', _H['model_rec'], '100', 'AcDbEntity', '8', layer,
         '100', 'AcDbPolyline', '90', str(len(pts)), '70', '1' if closed else '0', '43', '0']
    for x, y, b in pts:
        s += ['10', _n(x), '20', _n(y)]
        if abs(b) > 1e-12: s += ['42', '%.12f' % b]
    return s

def _text(handle, layer, x, y, h, txt):
    return ['0', 'TEXT', '5', handle, '330', _H['model_rec'], '100', 'AcDbEntity', '8', layer, '100', 'AcDbText',
            '10', _n(x), '20', _n(y), '30', '0', '40', _n(h), '1', re.sub(r'[\r\n\t]+', ' ', str(txt)), '50', '0', '7', 'Standard', '100', 'AcDbText']

def rect_path(x, y, w, h, r):
    """Counter-clockwise closed path with radius-r corners as bulge arcs."""
    r = max(0.0, min(r, w / 2, h / 2))
    if r <= 0:
        return [(x, y, 0), (x + w, y, 0), (x + w, y + h, 0), (x, y + h, 0)]
    b = BULGE90
    return [(x + r, y, 0), (x + w - r, y, b), (x + w, y + r, 0), (x + w, y + h - r, b),
            (x + w - r, y + h, 0), (x + r, y + h, b), (x, y + h - r, 0), (x, y + r, b)]

def write_dxf(sheet, rules, corner_radius=0.0, labels=False, sheet_outline=False):
    # No stock outline by default: a closed 2440x1220 polyline in the file is read as THE PART by any
    # consumer that takes the outermost loop (Tempus did on 16-Sep-2026: 'Part with web cannot fit on
    # material'), and on a router it is a cut line round the whole sheet. Parts only; the sheet is $EXTMAX.
    rules = rules.for_sheet(sheet)
    ents = []                       # [(layer, kind, payload)]
    if sheet_outline: ents.append(('SHEET', 'poly', rect_path(0, 0, rules.sheet_w, rules.sheet_h, 0)))
    for pl in sheet.placed:
        loops = placed_loops(pl, corner_radius)
        for kind, loop in loops:                     # inner loops first so a CAM that keeps file order cuts holes before the outline
            if kind == 'hole': ents.append(('CUT', 'poly', loop))
        for kind, loop in loops:
            if kind != 'hole': ents.append(('CUT', 'poly', loop))
        if labels: ents.append(('LABEL', 'text', (pl.x + 5, pl.y + 5, min(12, pl.h / 4), pl.part.name)))
    for tc in customcuts.paths(sheet, rules):
        ents.append(('CUT', 'line', [(x, y, 0) for x, y in tc]))     # the trim cut: one straight line, or the L / stairs polyline
    handseed = '%X' % (_FIRST_ENTITY + len(ents))
    L = ['0', 'SECTION', '2', 'HEADER',
         '9', '$ACADVER', '1', 'AC1015', '9', '$DWGCODEPAGE', '3', 'ANSI_1252',
         '9', '$INSBASE', '10', '0', '20', '0', '30', '0',
         '9', '$EXTMIN', '10', '0', '20', '0', '30', '0',
         '9', '$EXTMAX', '10', _n(rules.sheet_w), '20', _n(rules.sheet_h), '30', '0',
         '9', '$LIMMIN', '10', '0', '20', '0', '9', '$LIMMAX', '10', _n(rules.sheet_w), '20', _n(rules.sheet_h),
         '9', '$LUNITS', '70', '2', '9', '$LUPREC', '70', '4', '9', '$AUNITS', '70', '0', '9', '$AUPREC', '70', '4',
         '9', '$MEASUREMENT', '70', '1', '9', '$INSUNITS', '70', '4', '9', '$HANDSEED', '5', handseed,
         '0', 'ENDSEC', '0', 'SECTION', '2', 'CLASSES', '0', 'ENDSEC', '0', 'SECTION', '2', 'TABLES']
    _table(L, 'VPORT', _H['vport_t'], [['0', 'VPORT', '5', _H['vport'], '330', _H['vport_t'], '100', 'AcDbSymbolTableRecord',
                                        '100', 'AcDbViewportTableRecord', '2', '*Active', '70', '0', '10', '0', '20', '0',
                                        '11', '1', '21', '1', '12', _n(rules.sheet_w / 2), '22', _n(rules.sheet_h / 2),
                                        '40', _n(rules.sheet_h * 1.1), '41', '2']])
    lt = lambda h, name, desc: ['0', 'LTYPE', '5', h, '330', _H['ltype_t'], '100', 'AcDbSymbolTableRecord', '100', 'AcDbLinetypeTableRecord',
                                '2', name, '70', '0', '3', desc, '72', '65', '73', '0', '40', '0']
    _table(L, 'LTYPE', _H['ltype_t'], [lt(_H['byblock'], 'ByBlock', ''), lt(_H['bylayer'], 'ByLayer', ''), lt(_H['continuous'], 'Continuous', 'Solid line')])
    _table(L, 'LAYER', _H['layer_t'], [_layer(_H['layer0'], '0', 7), _layer(_H['cut'], 'CUT', 1), _layer(_H['sheet'], 'SHEET', 8), _layer(_H['label'], 'LABEL', 3)])
    _table(L, 'STYLE', _H['style_t'], [['0', 'STYLE', '5', _H['style'], '330', _H['style_t'], '100', 'AcDbSymbolTableRecord', '100', 'AcDbTextStyleTableRecord',
                                        '2', 'Standard', '70', '0', '40', '0', '41', '1', '50', '0', '71', '0', '42', '2.5', '3', 'txt', '4', '']])
    _table(L, 'VIEW', _H['view_t'], []); _table(L, 'UCS', _H['ucs_t'], [])
    _table(L, 'APPID', _H['appid_t'], [['0', 'APPID', '5', _H['appid'], '330', _H['appid_t'], '100', 'AcDbSymbolTableRecord', '100', 'AcDbRegAppTableRecord', '2', 'ACAD', '70', '0']])
    _table(L, 'DIMSTYLE', _H['dimstyle_t'], [['0', 'DIMSTYLE', '105', _H['dimstyle'], '330', _H['dimstyle_t'], '100', 'AcDbSymbolTableRecord', '100', 'AcDbDimStyleTableRecord',
                                              '2', 'Standard', '70', '0', '40', '1', '41', '2.5', '42', '0.625', '43', '3.75', '44', '1.25', '140', '2.5', '141', '2.5', '147', '0.625',
                                              '71', '0', '72', '0', '73', '0', '74', '0', '77', '1', '78', '8', '170', '0', '171', '3', '172', '1', '173', '0', '174', '0',
                                              '271', '2', '272', '2', '273', '2', '274', '3', '277', '2', '278', '44']], 'AcDbDimStyleTable')
    br = lambda h, name: ['0', 'BLOCK_RECORD', '5', h, '330', _H['blkrec_t'], '100', 'AcDbSymbolTableRecord', '100', 'AcDbBlockTableRecord', '2', name]
    _table(L, 'BLOCK_RECORD', _H['blkrec_t'], [br(_H['model_rec'], '*Model_Space'), br(_H['paper_rec'], '*Paper_Space')])
    L += ['0', 'ENDSEC', '0', 'SECTION', '2', 'BLOCKS']
    for blk, endb, rec, name in ((_H['model_blk'], _H['model_end'], _H['model_rec'], '*Model_Space'), (_H['paper_blk'], _H['paper_end'], _H['paper_rec'], '*Paper_Space')):
        L += ['0', 'BLOCK', '5', blk, '330', rec, '100', 'AcDbEntity', '8', '0', '100', 'AcDbBlockBegin', '2', name, '70', '0',
              '10', '0', '20', '0', '30', '0', '3', name, '1', '', '0', 'ENDBLK', '5', endb, '330', rec, '100', 'AcDbEntity', '8', '0', '100', 'AcDbBlockEnd']
    L += ['0', 'ENDSEC', '0', 'SECTION', '2', 'ENTITIES']
    for i, (layer, kind, payload) in enumerate(ents):
        h = '%X' % (_FIRST_ENTITY + i)
        L += _lwpoly(h, layer, payload) if kind == 'poly' else _lwpoly(h, layer, payload, closed=False) if kind == 'line' else _text(h, layer, *payload)
    L += ['0', 'ENDSEC', '0', 'SECTION', '2', 'OBJECTS', '0', 'DICTIONARY', '5', _H['rootdict'], '330', '0', '100', 'AcDbDictionary', '281', '1',
          '0', 'ENDSEC', '0', 'EOF']
    return '\r\n'.join(L) + '\r\n'

# ---------------------------------------------------------------- print PDF (1:1, one page per sheet)
FRAME_PT = 0.567      # 0.2 mm, the hairline the shop's hand-made print / cut pairs use for the sheet frame


def _sheet_frame(c, W, H):
    """The rectangle on the sheet edge that the print PDF and the cut PDF share as their common reference.  Process
    black, never CutContour: it lines the two files up, it is not a cut."""
    c.saveState(); c.setStrokeColorCMYK(0, 0, 0, 1); c.setLineWidth(FRAME_PT); c.rect(0, 0, W, H, stroke=1, fill=0); c.restoreState()


def write_print_pdf(sheets, rules, artworks, bleed=0.0, outlines=False, corner_marks=False, corner_radius=0.0, cuts=None, frame=False):
    """artworks: {key: bytes of a single-page PDF}.  cuts: {key: pdfcut.analyse result} for print & cut artwork, which
    is placed 1:1 with its CutContour line exactly on the nested outline (the bytes passed in already have the line
    removed).  Returns (pdf_bytes, warnings)."""
    cuts = cuts or {}
    from pypdf import PdfReader, PdfWriter, Transformation
    from reportlab.pdfgen import canvas
    warnings = []
    readers = {}
    writer = PdfWriter()
    for si, sheet in enumerate(sheets, 1):
        W, H = rules.for_sheet(sheet).sheet_w * MM, rules.for_sheet(sheet).sheet_h * MM
        # Blank base page at sheet size; artwork is merged onto it, then the
        # outlines / corner marks go on as a separate overlay so the artwork's
        # bleed cannot cover them.
        buf = io.BytesIO(); c = canvas.Canvas(buf, pagesize=(W, H)); c.showPage(); c.save()
        base = writer.add_page(PdfReader(io.BytesIO(buf.getvalue())).pages[0])   # on the writer first: pypdf merges onto loose pages unreliably
        obuf = io.BytesIO(); c = canvas.Canvas(obuf, pagesize=(W, H))
        c.setLineWidth(0.25)
        if frame: _sheet_frame(c, W, H)
        if corner_marks:
            m = (rules.margin / 2 if rules.margin > 0 else 8) * MM
            for (x, y) in ((m, m), (W - m, m), (m, H - m), (W - m, H - m)):
                c.circle(x, y, 3 * MM, stroke=1, fill=0)
                c.line(x - 5 * MM, y, x + 5 * MM, y); c.line(x, y - 5 * MM, x, y + 5 * MM)
        if outlines:
            for pl in sheet.placed:
                _draw_loops(c, placed_loops(pl, corner_radius), MM, 0, 0, fill=0)
        c.showPage(); c.save()
        overlay = PdfReader(io.BytesIO(obuf.getvalue())).pages[0] if (outlines or corner_marks or frame) else None
        for pl in sheet.placed:
            key = pl.part.artwork
            if not key or key not in artworks: continue
            if key not in readers: readers[key] = PdfReader(io.BytesIO(artworks[key]))
            art = readers[key].pages[0]
            if key in cuts and (pl.part.shape or {}).get('type') == 'contour':
                cut = cuts[key]
                ang, tx, ty = place_transform(pl)
                t = Transformation().translate(-cut['x0'] * MM, -cut['y0'] * MM)
                if _mirror(pl.part): t = t.scale(-1, 1).translate(pl.part.w * MM, 0)       # reverse print: flip inside the part's own box
                if ang: t = t.rotate(ang)
                base.merge_transformed_page(art, t.translate(tx * MM, ty * MM))
                continue
            aw, ah = float(art.mediabox.width), float(art.mediabox.height)
            tw, th = (pl.part.w + 2 * bleed) * MM, (pl.part.h + 2 * bleed) * MM
            if abs(aw - tw) > 0.5 * MM or abs(ah - th) > 0.5 * MM:
                msg = ('%s: artwork page is %.1f x %.1f mm but the part plus bleed is %.1f x %.1f mm; scaled uniformly to fit and centred.'
                       % (pl.part.name.split(' #')[0], aw / MM, ah / MM, tw / MM, th / MM))
                if msg not in warnings: warnings.append(msg)
            s = min(tw / aw, th / ah); sw, sh = aw * s, ah * s
            # centre the art in the part's own frame (bleed hangs outside 0..w x 0..h), then rotate and place
            ox, oy = (pl.part.w * MM - sw) / 2, (pl.part.h * MM - sh) / 2
            ang, tx, ty = place_transform(pl)
            t = Transformation().scale(s, s).translate(ox, oy)
            if _mirror(pl.part): t = t.scale(-1, 1).translate(pl.part.w * MM, 0)
            if ang: t = t.rotate(ang)
            t = t.translate(tx * MM, ty * MM)
            base.merge_transformed_page(art, t)
        if overlay is not None:
            base.merge_page(overlay)
    out = io.BytesIO(); writer.write(out)
    return out.getvalue(), warnings

def _mirror(part): return bool((part.shape or {}).get('mirror'))


def contour_overhang(cut):
    """How far (mm) the artwork page reaches past the bounding box of its CutContour line on its widest side."""
    l, b, r, t = cut['page_mm']
    return max(cut['x0'] - l, cut['y0'] - b, r - (cut['x0'] + cut['w']), t - (cut['y0'] + cut['h']), 0.0)


def write_cut_pdf(sheets, rules, cuts, frame=False, style='cutcontour'):
    """Cut file for print & cut: one page per sheet, same size and origin as the print PDF, carrying only the CutContour
    lines taken from the artwork (original lines and curves, not redrawn shapes) as a CutContour spot colour.
    cuts: {artwork key: pdfcut.analyse result}; every placed part must be a contour part (server.cut_reason checks)."""
    from reportlab.pdfgen import canvas
    from reportlab.lib.colors import CMYKColorSep
    spot = CMYKColorSep(0, 1, 0, 0, spotName='CutContour', density=1)
    buf = io.BytesIO(); c = canvas.Canvas(buf, pagesize=(rules.sheet_w * MM, rules.sheet_h * MM))
    c.setTitle('CutContour'); c.setCreator('PS Nest')
    for sheet in sheets:
        W, H = rules.for_sheet(sheet).sheet_w * MM, rules.for_sheet(sheet).sheet_h * MM
        c.setPageSize((W, H))
        if frame: _sheet_frame(c, W, H)
        for pl in sheet.placed:
            cut = cuts[pl.part.artwork]
            ang, tx, ty = place_transform(pl)
            c.saveState()
            c.translate(tx * MM, ty * MM)
            if ang: c.rotate(ang)
            if _mirror(pl.part): c.translate(pl.part.w * MM, 0); c.scale(-1, 1)
            c.translate(-cut['x0'] * MM, -cut['y0'] * MM)
            if style == 'black': c.setStrokeColorCMYK(0, 0, 0, 1); c.setLineWidth(1.0)     # the shop's rigid-material templates: 1 pt black
            else: c.setStrokeColor(spot); c.setLineWidth(0.25)
            c.setLineJoin(1); c.setLineCap(1)
            p = c.beginPath()
            for segs in cut['paths']:
                for s in segs:
                    if s[0] == 'M': p.moveTo(s[1] * MM, s[2] * MM)
                    elif s[0] == 'L': p.lineTo(s[1] * MM, s[2] * MM)
                    elif s[0] == 'C': p.curveTo(*(v * MM for v in s[1:]))
                p.close()
            c.drawPath(p, stroke=1, fill=0)
            c.restoreState()
        for tc in customcuts.paths(sheet, rules):                       # the trim cut that frees the offcut (straight, L or stairs), same pen as the part outlines
            if style == 'black': c.setStrokeColorCMYK(0, 0, 0, 1); c.setLineWidth(1.0)
            else: c.setStrokeColor(spot); c.setLineWidth(0.25)
            p = c.beginPath(); p.moveTo(tc[0][0] * MM, tc[0][1] * MM)
            for x, y in tc[1:]: p.lineTo(x * MM, y * MM)
            c.drawPath(p, stroke=1, fill=0)
        c.showPage()
    c.save()
    return buf.getvalue()


# ---------------------------------------------------------------- operator layout PDF (A4 landscape, one sheet per page)
def write_layout_pdf(sheets, rules, job_name, info, corner_radius=0.0):
    from reportlab.pdfgen import canvas
    from reportlab.lib.pagesizes import landscape, A4
    PW, PH = landscape(A4)
    buf = io.BytesIO(); c = canvas.Canvas(buf, pagesize=(PW, PH))
    total_area = sum(s.used_area() for s in sheets)
    all_rules = rules
    for i, s in enumerate(sheets, 1):
        rules = all_rules.for_sheet(s)
        c.setFont('Helvetica-Bold', 14); c.drawString(30, PH - 32, f'{job_name}  -  {"cut pass" if getattr(rules, "roll", False) else "sheet"} {i} of {len(sheets)}')
        util = s.used_area() / (rules.sheet_w * rules.sheet_h)
        rem = remnant(s, rules)
        used_len = min(rules.sheet_w, max((pl.x + pl.w for pl in s.placed), default=0.0) + rules.gap)
        c.setFont('Helvetica', 9.5)
        c.drawString(30, PH - 48, (f'Roll {rules.sheet_h:g} mm wide, pass up to {rules.sheet_w:g} mm' if getattr(rules, 'roll', False) else f'Sheet {rules.sheet_w:g} x {rules.sheet_h:g} mm' + (' (remnant)' if s.size else '')) + f'   |   {len(s.placed)} parts   |   used {util:.1%}'
                     f'   |   used length {used_len:.0f} mm   |   {"custom cuts; offcut area not measured" if s.custom_cuts is not None else offcut_words(rem, rules)}   |   edge {rules.edge:g} mm, gap {rules.gap:g} mm, clamp {rules.clamp:g} mm')
        if i == 1:
            c.drawString(30, PH - 60, f'Whole job: {len(sheets)} sheet(s), {total_area / sum(sh.area(all_rules) for sh in sheets):.1%} of material used, '
                         f'{info.get("tried", 0)} layouts tried, best: {info.get("strategy")}')
        # scale sheet to fit
        avail_w, avail_h = PW - 60, PH - 110
        k = min(avail_w / rules.sheet_w, avail_h / rules.sheet_h)
        ox, oy = 30, 30
        c.setLineWidth(0.8); c.setStrokeColorRGB(0.3, 0.3, 0.3); c.rect(ox, oy, rules.sheet_w * k, rules.sheet_h * k)
        if max(rules.ml, rules.mr, rules.mb, rules.mt) > 0:
            c.setDash(3, 3); c.setLineWidth(0.4); c.rect(ox + rules.ml * k, oy + rules.mb * k, rules.usable_w * k, rules.usable_h * k); c.setDash()
        c.setLineWidth(0.6); c.setStrokeColorRGB(0.75, 0.05, 0.15)
        for pl in s.placed:
            c.setFillColorRGB(0.97, 0.94, 0.94)
            _draw_loops(c, placed_loops(pl, corner_radius), k, ox, oy, fill=1)
            c.setFillColorRGB(0.1, 0.1, 0.1)
            fs = max(5, min(9, pl.h * k / 4)); c.setFont('Helvetica', fs)
            dims = f'  {round(pl.part.w, 1):g}x{round(pl.part.h, 1):g}' + angle_note(pl)
            label = fit_label(pl.part.name, pl.w * k / (fs * 0.52) - len(dims), dots='..') + dims
            c.drawCentredString(ox + (pl.x + pl.w / 2) * k, oy + (pl.y + pl.h / 2) * k - fs / 3, label)
        for tc in customcuts.paths(s, rules):
            c.setStrokeColorRGB(0.18, 0.49, 0.2); c.setLineWidth(0.8); c.setDash(4, 3)
            p = c.beginPath(); p.moveTo(ox + tc[0][0] * k, oy + tc[0][1] * k)
            for x, y in tc[1:]: p.lineTo(ox + x * k, oy + y * k)
            c.drawPath(p, stroke=1, fill=0)
            c.setDash(); c.setFillColorRGB(0.18, 0.49, 0.2); c.setFont('Helvetica', 7)
            tl = trim_line(s, rules)
            if s.custom_cuts is None and rem[3] in ('right', 'top') and tl:
                c.drawString(ox + (tl[1] * k + 3 if tl[0] == 'x' else 3), oy + (rules.sheet_h * k - 9 if tl[0] == 'x' else tl[1] * k + 3), f'trim cut at {tl[1]:g} mm')
            else:
                c.drawString(ox + tc[-1][0] * k + 3, oy + tc[-1][1] * k + 3, f'{"custom separation" if s.custom_cuts is not None else rem[3]}: {len(tc) - 1} straight cuts')
        c.showPage()
    c.save(); return buf.getvalue()

def offcut_words(rem, rules):
    """One phrase for the leftover a sheet gives back: 'offcut strip 390 x 1220 mm (right)', 'L-shaped offcut ...', 'no offcut'."""
    area, w, h, where = rem[0], rem[1], rem[2], rem[3]
    if area <= 0 or where == 'none': return 'no offcut worth keeping'
    if where == 'whole sheet': return 'whole sheet free'
    if where in ('right', 'top'): return f'offcut strip {w:.0f} x {h:.0f} mm ({where})'
    if where == 'L': return f'L-shaped offcut {area / 1e6:.2f} m2 (arms {w:.0f} mm on the right, {h:.0f} mm on top)'
    return f'stair-shaped offcut {area / 1e6:.2f} m2 (clear {w:.0f} mm on the right, {h:.0f} mm on top)'


def _draw_loops(c, loops, k, ox, oy, fill):
    """Draw [(kind, loop)] on a reportlab canvas at scale k (points per mm) and offset (ox, oy) points, even-odd."""
    p = c.beginPath()
    for kind, loop in loops:
        pts = _poly_points(loop)
        if not pts: continue
        p.moveTo(ox + pts[0][0] * k, oy + pts[0][1] * k)
        for x, y in pts[1:]: p.lineTo(ox + x * k, oy + y * k)
        p.close()
    c.drawPath(p, stroke=1, fill=fill, fillMode=0)      # 0 = even-odd: holes stay white


def fit_label(name, room, dots='\u2026'):
    """A part name cut down to `room` characters: the start of the name and its ' #n' counter survive, because those
    are what the operator looks for.  Names taken from artwork files are far longer than a small part is wide."""
    room = int(room)
    if len(name) <= room: return name
    head, sep, num = name.rpartition(' #')
    tail = ' #' + num if sep and num.isdigit() else ''
    keep = room - len(tail) - len(dots)
    if keep < 3: return tail.strip() if tail and len(tail.strip()) <= max(room, 2) else name[:max(room, 1)]
    return (head if tail else name)[:keep].rstrip(' _-') + dots + tail


def angle_note(pl):
    a = pl.angle % 360
    if abs(a) < 1e-9: return ''
    return '  (turned)' if abs(a - 90) < 1e-9 and not pl.part.shaped else f'  ({a:g}\u00b0)'


# ---------------------------------------------------------------- SVG preview
def write_svg(sheet, rules, corner_radius=0.0):
    rules = rules.for_sheet(sheet)
    W, H = rules.sheet_w, rules.sheet_h
    o = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="-6 -6 {W + 12} {H + 12}" font-family="-apple-system,Helvetica,Arial">',
         f'<g transform="translate(0,{H}) scale(1,-1)">',
         f'<rect x="0" y="0" width="{W}" height="{H}" fill="#fafafa" stroke="#333" stroke-width="3"/>']
    if max(rules.ml, rules.mr, rules.mb, rules.mt) > 0:
        o.append(f'<rect x="{rules.ml}" y="{rules.mb}" width="{rules.usable_w}" height="{rules.usable_h}" fill="none" stroke="#999" stroke-width="1.5" stroke-dasharray="12 8"/>')
    poly = remnant_polygon(sheet, rules) if sheet.custom_cuts is None else None
    if poly:
        o.append(f'<polygon points="{" ".join(f"{x:.1f},{y:.1f}" for x, y in poly)}" fill="#e8f5e9"/>')
    elif sheet.custom_cuts is None:
        strip = strip_offcut(sheet, rules)
        if strip[0] > 0 and strip[3] != 'whole sheet':
            if strip[3] == 'right': o.append(f'<rect x="{W - strip[1]}" y="0" width="{strip[1]}" height="{H}" fill="#e8f5e9"/>')
            else: o.append(f'<rect x="0" y="{H - strip[2]}" width="{W}" height="{strip[2]}" fill="#e8f5e9"/>')
    for tc in customcuts.paths(sheet, rules):
        o.append(f'<polyline class="separation" points="{" ".join(f"{x:.1f},{y:.1f}" for x, y in tc)}" fill="none" stroke="#2e7d32" stroke-width="3" stroke-dasharray="24 14" stroke-linejoin="round"/>')
    for pl in sheet.placed:
        o.append(f'<path d="{svg_path(placed_loops(pl, corner_radius))}" fill="#fde8ec" fill-rule="evenodd" stroke="#c8102e" stroke-width="2" stroke-linejoin="round"/>')
    o.append('</g>')
    for pl in sheet.placed:
        fs = max(14, min(34, pl.h / 5, pl.w / 8))
        cx, cy = pl.x + pl.w / 2, H - (pl.y + pl.h / 2)
        o.append(f'<text x="{cx}" y="{cy}" font-size="{fs}" text-anchor="middle" dominant-baseline="middle" fill="#222">{_esc(fit_label(pl.part.name, pl.w / (fs * 0.58)))}'
                 f'<tspan x="{cx}" dy="{fs * 1.1}" font-size="{fs * 0.8}" fill="#666">{round(pl.part.w, 1):g} x {round(pl.part.h, 1):g}{angle_note(pl).replace("(", "").replace(")", "")}</tspan></text>')
    o.append('</svg>')
    return ''.join(o)

def _esc(s): return s.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')


def svg_path(loops, tol=0.05):
    """[(kind, loop)] -> SVG path data (arcs flattened), one closed subpath per loop."""
    d = []
    for _, loop in loops:
        pts = _poly_points(loop, tol)
        if not pts: continue
        d.append('M' + ' '.join(f'{x:.2f},{y:.2f}' for x, y in pts) + 'Z')
    return ''.join(d)

# ---------------------------------------------------------------- report + bundle
def report(sheets, rules, info, job_name, settings):
    out = {'job': job_name, 'sheet_mm': [rules.sheet_w, rules.sheet_h], 'rules': settings,
           'sheets': [], 'sheet_count': len(sheets), 'layouts_tried': info.get('tried'), 'strategy': info.get('strategy'),
           'engine': info.get('engine', 'rect'), 'pairs': info.get('pairs', []), 'seconds': info.get('seconds')}
    total = 0.0; area_all = 0.0
    for i, s in enumerate(sheets, 1):
        rs = rules.for_sheet(s)
        strip = strip_offcut(s, rs); ler = largest_empty_rect(s, rs); rem = remnant(s, rs); tc = trim_cut(s, rs)
        if s.custom_cuts is not None: tc = None
        total += s.used_area(); area_all += rs.sheet_w * rs.sheet_h
        # how far along the sheet the parts reach plus the edge margin: on a roll, the length that has to be printed
        used_len = min(rs.sheet_w, max((pl.x + pl.w for pl in s.placed), default=0.0) + rs.margin) if s.placed else 0.0
        out['sheets'].append({'n': i, 'parts': len(s.placed), 'utilisation': round(s.used_area() / (rs.sheet_w * rs.sheet_h), 4),
                              'sheet_mm': [rs.sheet_w, rs.sheet_h], 'remnant_sheet': bool(s.size),
                              'used_length_mm': round(used_len, 1),
                              'offcut_strip_mm': [round(strip[1], 1), round(strip[2], 1), strip[3]],
                              'trim_line_mm': list(trim_line(s, rs)) if s.custom_cuts is None and trim_line(s, rs) else None,
                              'automatic_cuts_mm': [trim_cut(s,rs)] if trim_cut(s,rs) else [],
                              'custom_cuts': s.custom_cuts, 'separation_cuts_mm': customcuts.paths(s, rs),
                              'cut_clearance_mm': customcuts.clearance(rs, settings.get('bit_diameter', 0)) + 0.021,
                              'trim_cut_mm': [[round(x, 3), round(y, 3)] for x, y in tc] if tc else None,
                              'offcut': {'shape':'custom', 'area_m2':None, 'w':None, 'h':None, 'words':'custom separation cuts; reusable area not measured'} if s.custom_cuts is not None else {'shape': rem[3], 'area_m2': round(rem[0] / 1e6, 4), 'w': round(rem[1], 1), 'h': round(rem[2], 1),
                                         'words': offcut_words(rem, rs)},
                              'largest_empty_rect_mm': [round(ler[3], 1), round(ler[4], 1)],
                              'placements': [{'part': p.part.name, 'x': round(p.x, 3), 'y': round(p.y, 3), 'w': round(p.w, 3), 'h': round(p.h, 3), 'turned': p.rotated, 'angle': round(p.angle % 360, 3)} for p in s.placed]})
    out['utilisation'] = round(total / area_all, 4) if sheets and area_all > 0 else 0
    out['offcut_shape'] = rules.offcut_shape
    return out

def bundle(files):
    """files: {name: bytes} -> zip bytes"""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as z:
        for n, b in files.items(): z.writestr(n, b)
    return buf.getvalue()
