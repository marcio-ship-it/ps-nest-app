"""Output writers: DXF cut file, 1:1 print PDF, CutContour cut PDF, operator layout PDF, SVG preview, JSON report."""
from __future__ import annotations
import io, json, math, re, zipfile
from .engine import strip_offcut, largest_empty_rect, trim_line, trim_cut, remnant, remnant_polygon
from . import geom, customcuts

MM = 72 / 25.4          # PDF points per mm
BULGE90 = math.tan(math.radians(90) / 4)   # bulge for a 90-degree arc
LAYOUT_MIN_REF_FONT = 6.0
LAYOUT_KEY_FONT = 7.0


def roll_used_extent_mm(sheet, rules):
    """Farthest placed edge plus the saved right margin, independent of allocation.

    A legacy roll page can be longer than its placed work.  Keep that exported
    page length separate from the extent the contours and required margin use.
    """
    rs = rules.for_sheet(sheet)
    return max((pl.x + pl.w for pl in sheet.placed), default=0.0) + rs.mr if sheet.placed else 0.0

# ---------------------------------------------------------------- placed geometry (shared by every writer)
def placed_loops(pl, corner_radius=0.0):
    """World loops of a placement: [(outer/hole flag, [(x, y, bulge), ...]), ...].
    Rectangles get the optional corner radius; shaped parts use their real outline, islands and holes
    rotated by pl.angle with the bbox of outline+islands at (pl.x, pl.y)."""
    part = pl.part
    if not part.shaped and abs(pl.angle % 90) < 1e-9:        # pl.w / pl.h are already swapped for 90 / 270
        return [('outer', rect_path(pl.x, pl.y, pl.w, pl.h, corner_radius))]
    loops = part.shape_loops() if part.shaped else [rect_path(0, 0, part.w, part.h, corner_radius)]
    n_out = len(loops)
    loops = loops + [list(h) for h in part.holes]
    world = geom.world_loops(loops, pl.angle, pl.x, pl.y)
    return [('outer' if i < n_out else 'hole', w) for i, w in enumerate(world)]


def place_transform(pl):
    """(angle_deg, tx, ty) in mm such that world = R(angle) . frame + (tx, ty) for the part's own frame."""
    part = pl.part
    loops = part.shape_loops() if part.shaped else [[(0, 0, 0), (part.w, 0, 0), (part.w, part.h, 0), (0, part.h, 0)]]
    rot = [geom.rotate(o, pl.angle) if pl.angle else o for o in loops]
    x0, y0, _, _ = geom.bbox_loops(rot)
    return pl.angle, pl.x - x0, pl.y - y0


def _poly_points(loop, tol=0.05):
    """Closed (x, y, bulge) loop -> flattened [(x, y)] for drawing."""
    return geom.flatten(loop, tol)


# ---------------------------------------------------------------- DXF
# Full-form AutoCAD 2000 (AC1015) file: every table, block record and entity carries a handle,
# owner (330) and AcDb subclass markers.  A minimal "header + entities" DXF is NOT enough:
# Tempus Tools rejected exactly that form on 3-Sep-2026 (parts showed "undefined x undefined mm")
# and again on 16-Sep-2026 (blank import), while this full form imports with correct dimensions.
_H = {'vport_t': '1', 'ltype_t': '2', 'layer_t': '3', 'style_t': '4', 'view_t': '5', 'ucs_t': '6',
      'appid_t': '7', 'dimstyle_t': '8', 'blkrec_t': '9', 'vport': 'A', 'byblock': 'B', 'bylayer': 'C',
      'continuous': 'D', 'layer0': 'E', 'cut': 'F', 'sheet': '10', 'label': '11', 'style': '12', 'appid': '13',
      'dimstyle': '14', 'model_rec': '15', 'paper_rec': '16', 'model_blk': '17', 'model_end': '18',
      'paper_blk': '19', 'paper_end': '1A', 'rootdict': '1B'}
_FIRST_ENTITY = 0x20
# Layer handles when a cutter export profile is in use: the unused slots below _FIRST_ENTITY (layer 0 keeps 'E').
_PROFILE_LAYER_HANDLES = ('F', '10', '11', '1C', '1D', '1E', '1F')
_EXTRA_LAYER_COLOURS = {'LABEL': 3, 'SHEET': 8, 'MARK': 6}

def _n(v):
    """DXF number: fixed 4 decimals, no exponent, no trailing garbage."""
    t = ('%.4f' % v).rstrip('0').rstrip('.')
    return t if t not in ('', '-0') else '0'

def _table(lines, name, handle, records, subclass=None):
    lines += ['0', 'TABLE', '2', name, '5', handle, '330', '0', '100', 'AcDbSymbolTable', '70', str(len(records))]
    if subclass: lines += ['100', subclass]
    for r in records: lines += r
    lines += ['0', 'ENDTAB']

def _layer(handle, name, colour):
    return ['0', 'LAYER', '5', handle, '330', _H['layer_t'], '100', 'AcDbSymbolTableRecord',
            '100', 'AcDbLayerTableRecord', '2', name, '70', '0', '62', str(colour), '6', 'Continuous']

def _colour(colour):
    """Group 62 on the entity (a cutter that picks tools by line colour, not layer), or nothing: BYLAYER."""
    return ['62', str(colour)] if colour is not None else []

def _lwpoly(handle, layer, pts, closed=True, colour=None):
    """pts: [(x, y, bulge), ...]"""
    s = ['0', 'LWPOLYLINE', '5', handle, '330', _H['model_rec'], '100', 'AcDbEntity', '8', layer, *_colour(colour),
         '100', 'AcDbPolyline', '90', str(len(pts)), '70', '1' if closed else '0', '43', '0']
    for x, y, b in pts:
        s += ['10', _n(x), '20', _n(y)]
        if abs(b) > 1e-12: s += ['42', '%.12f' % b]
    return s

def _text(handle, layer, x, y, h, txt, colour=None):
    return ['0', 'TEXT', '5', handle, '330', _H['model_rec'], '100', 'AcDbEntity', '8', layer, *_colour(colour), '100', 'AcDbText',
            '10', _n(x), '20', _n(y), '30', '0', '40', _n(h), '1', re.sub(r'[\r\n\t]+', ' ', str(txt)), '50', '0', '7', 'Standard', '100', 'AcDbText']

def rect_path(x, y, w, h, r):
    """Counter-clockwise closed path with radius-r corners as bulge arcs."""
    r = max(0.0, min(r, w / 2, h / 2))
    if r <= 0:
        return [(x, y, 0), (x + w, y, 0), (x + w, y + h, 0), (x, y + h, 0)]
    b = BULGE90
    return [(x + r, y, 0), (x + w - r, y, b), (x + w, y + r, 0), (x + w, y + h - r, b),
            (x + w - r, y + h, 0), (x + r, y + h, b), (x, y + h - r, 0), (x, y + r, b)]

def ccd_dot_positions(sheet_w, sheet_h, dots):
    """Centres (mm, origin bottom-left, the same frame as the DXF and the 1:1 PDFs) of the CCD registration dots for a
    sheet, or [] when the profile has none.  Ameida B4 manual: solid dots 5 +/- 1 mm, an even number >= 4 in a rectangle,
    6 for files over 1200 mm, 2-5 mm between the dot and the file edge.  Four corners, plus the middle of both long
    sides when 6 are asked for and the long side is over `six_over`, or of one long side when 5 are asked for.  One helper, so print, cut and DXF always agree."""
    if not dots: return []
    d, gap = dot_diameter(dots), float(dots.get('edge_gap', 3))
    c = gap + d / 2
    W, H = float(sheet_w), float(sheet_h)
    pts = [(c, c), (W - c, c), (W - c, H - c), (c, H - c)]
    mids = [(W / 2, c), (W / 2, H - c)] if W >= H else [(c, H / 2), (W - c, H / 2)]
    n = int(dots.get('count', 4))
    if n >= 6 and max(W, H) > float(dots.get('six_over', 0)): pts += mids
    elif n == 5: pts += mids[:1]          # an odd fifth dot on one long side tells the camera which way round the sheet is
    return pts

def dot_diameter(dots):
    """A profile names the dot size 'diameter' (Ameida) or 'size_mm' (Gunner contract); 5 mm when neither is set."""
    return float(dots.get('diameter', dots.get('size_mm', 5)))

def _profile_layers(profile, labels, sheet_outline):
    """[(name, colour)] for the layer table of a profiled DXF: layer 0, the profile's cut layers, then LABEL / SHEET /
    MARK only when the file carries them."""
    colours = dict(profile.get('colours') or {})
    names = []
    for n in list((profile.get('layers') or {}).values()) + [n for n in colours if n not in _EXTRA_LAYER_COLOURS]:
        if n not in names: names.append(n)
    if labels: names.append('LABEL')
    if sheet_outline: names.append('SHEET')
    if profile.get('ccd_dots'): names.append((profile['ccd_dots'] or {}).get('layer', 'MARK'))
    out = [('0', 7)] + [(n, colours.get(n, _EXTRA_LAYER_COLOURS.get(n, 7))) for n in names]
    if len(out) - 1 > len(_PROFILE_LAYER_HANDLES): raise ValueError('Too many layers in the export profile.')
    return out

def write_dxf(sheet, rules, corner_radius=0.0, labels=False, sheet_outline=False, profile=None):
    """profile: a cutter export profile (products.CUTTERS[<id>]['export']).  None writes the file exactly as before
    profiles existed: holes, outlines and trim cuts on CUT, colour BYLAYER.  With a profile, each entity kind goes on the
    profile's layer, every entity carries its layer colour as group 62, labels are written only if the profile allows
    them, and the profile's CCD dots go on their own layer."""
    # No stock outline by default: a closed 2440x1220 polyline in the file is read as THE PART by any
    # consumer that takes the outermost loop (Tempus did on 16-Sep-2026: 'Part with web cannot fit on
    # material'), and on a router it is a cut line round the whole sheet. Parts only; the sheet is $EXTMAX.
    rules = rules.for_sheet(sheet)
    lay = (profile or {}).get('layers') or {}
    on = {k: lay.get(k, lay.get('cut', 'CUT')) for k in ('hole', 'outer', 'trim')}     # 'cut' covers holes and outlines
    if profile is not None and not profile.get('labels'): labels = False
    ents = []                       # [(layer, kind, payload)]
    if sheet_outline: ents.append(('SHEET', 'poly', rect_path(0, 0, rules.sheet_w, rules.sheet_h, 0)))
    if profile is not None and profile.get('ccd_dots'):
        r = dot_diameter(profile['ccd_dots']) / 2
        for cx, cy in ccd_dot_positions(rules.sheet_w, rules.sheet_h, profile['ccd_dots']):   # a closed two-arc circle, as holes are written
            ents.append((profile['ccd_dots'].get('layer', 'MARK'), 'poly', [(cx - r, cy, 1.0), (cx + r, cy, 1.0)]))
    for pl in sheet.placed:
        loops = placed_loops(pl, corner_radius)
        for kind, loop in loops:                     # inner loops first so a CAM that keeps file order cuts holes before the outline
            if kind == 'hole': ents.append((on['hole'], 'poly', loop))
        for kind, loop in loops:
            if kind != 'hole': ents.append((on['outer'], 'poly', loop))
        if labels: ents.append(('LABEL', 'text', (pl.x + 5, pl.y + 5, min(12, pl.h / 4), pl.part.name)))
    for tc in customcuts.paths(sheet, rules):
        ents.append((on['trim'], 'line', [(x, y, 0) for x, y in tc]))     # the trim cut: one straight line, or the L / stairs polyline
    handseed = '%X' % (_FIRST_ENTITY + len(ents))
    L = ['0', 'SECTION', '2', 'HEADER',
         '9', '$ACADVER', '1', 'AC1015', '9', '$DWGCODEPAGE', '3', 'ANSI_1252',
         '9', '$INSBASE', '10', '0', '20', '0', '30', '0',
         '9', '$EXTMIN', '10', '0', '20', '0', '30', '0',
         '9', '$EXTMAX', '10', _n(rules.sheet_w), '20', _n(rules.sheet_h), '30', '0',
         '9', '$LIMMIN', '10', '0', '20', '0', '9', '$LIMMAX', '10', _n(rules.sheet_w), '20', _n(rules.sheet_h),
         '9', '$LUNITS', '70', '2', '9', '$LUPREC', '70', '4', '9', '$AUNITS', '70', '0', '9', '$AUPREC', '70', '4',
         '9', '$MEASUREMENT', '70', '1', '9', '$INSUNITS', '70', '4', '9', '$HANDSEED', '5', handseed,
         '0', 'ENDSEC', '0', 'SECTION', '2', 'CLASSES', '0', 'ENDSEC', '0', 'SECTION', '2', 'TABLES']
    _table(L, 'VPORT', _H['vport_t'], [['0', 'VPORT', '5', _H['vport'], '330', _H['vport_t'], '100', 'AcDbSymbolTableRecord',
                                        '100', 'AcDbViewportTableRecord', '2', '*Active', '70', '0', '10', '0', '20', '0',
                                        '11', '1', '21', '1', '12', _n(rules.sheet_w / 2), '22', _n(rules.sheet_h / 2),
                                        '40', _n(rules.sheet_h * 1.1), '41', '2']])
    lt = lambda h, name, desc: ['0', 'LTYPE', '5', h, '330', _H['ltype_t'], '100', 'AcDbSymbolTableRecord', '100', 'AcDbLinetypeTableRecord',
                                '2', name, '70', '0', '3', desc, '72', '65', '73', '0', '40', '0']
    _table(L, 'LTYPE', _H['ltype_t'], [lt(_H['byblock'], 'ByBlock', ''), lt(_H['bylayer'], 'ByLayer', ''), lt(_H['continuous'], 'Continuous', 'Solid line')])
    if profile is None:
        _table(L, 'LAYER', _H['layer_t'], [_layer(_H['layer0'], '0', 7), _layer(_H['cut'], 'CUT', 1), _layer(_H['sheet'], 'SHEET', 8), _layer(_H['label'], 'LABEL', 3)])
        colour_of = {}
    else:
        layers = _profile_layers(profile, labels, sheet_outline)
        _table(L, 'LAYER', _H['layer_t'], [_layer(_H['layer0'], '0', 7)] + [_layer(h, n, c) for h, (n, c) in zip(_PROFILE_LAYER_HANDLES, layers[1:])])
        colour_of = dict(layers)
    _table(L, 'STYLE', _H['style_t'], [['0', 'STYLE', '5', _H['style'], '330', _H['style_t'], '100', 'AcDbSymbolTableRecord', '100', 'AcDbTextStyleTableRecord',
                                        '2', 'Standard', '70', '0', '40', '0', '41', '1', '50', '0', '71', '0', '42', '2.5', '3', 'txt', '4', '']])
    _table(L, 'VIEW', _H['view_t'], []); _table(L, 'UCS', _H['ucs_t'], [])
    _table(L, 'APPID', _H['appid_t'], [['0', 'APPID', '5', _H['appid'], '330', _H['appid_t'], '100', 'AcDbSymbolTableRecord', '100', 'AcDbRegAppTableRecord', '2', 'ACAD', '70', '0']])
    _table(L, 'DIMSTYLE', _H['dimstyle_t'], [['0', 'DIMSTYLE', '105', _H['dimstyle'], '330', _H['dimstyle_t'], '100', 'AcDbSymbolTableRecord', '100', 'AcDbDimStyleTableRecord',
                                              '2', 'Standard', '70', '0', '40', '1', '41', '2.5', '42', '0.625', '43', '3.75', '44', '1.25', '140', '2.5', '141', '2.5', '147', '0.625',
                                              '71', '0', '72', '0', '73', '0', '74', '0', '77', '1', '78', '8', '170', '0', '171', '3', '172', '1', '173', '0', '174', '0',
                                              '271', '2', '272', '2', '273', '2', '274', '3', '277', '2', '278', '44']], 'AcDbDimStyleTable')
    br = lambda h, name: ['0', 'BLOCK_RECORD', '5', h, '330', _H['blkrec_t'], '100', 'AcDbSymbolTableRecord', '100', 'AcDbBlockTableRecord', '2', name]
    _table(L, 'BLOCK_RECORD', _H['blkrec_t'], [br(_H['model_rec'], '*Model_Space'), br(_H['paper_rec'], '*Paper_Space')])
    L += ['0', 'ENDSEC', '0', 'SECTION', '2', 'BLOCKS']
    for blk, endb, rec, name in ((_H['model_blk'], _H['model_end'], _H['model_rec'], '*Model_Space'), (_H['paper_blk'], _H['paper_end'], _H['paper_rec'], '*Paper_Space')):
        L += ['0', 'BLOCK', '5', blk, '330', rec, '100', 'AcDbEntity', '8', '0', '100', 'AcDbBlockBegin', '2', name, '70', '0',
              '10', '0', '20', '0', '30', '0', '3', name, '1', '', '0', 'ENDBLK', '5', endb, '330', rec, '100', 'AcDbEntity', '8', '0', '100', 'AcDbBlockEnd']
    L += ['0', 'ENDSEC', '0', 'SECTION', '2', 'ENTITIES']
    for i, (layer, kind, payload) in enumerate(ents):
        h = '%X' % (_FIRST_ENTITY + i)
        col = colour_of.get(layer)
        L += _lwpoly(h, layer, payload, colour=col) if kind == 'poly' else _lwpoly(h, layer, payload, closed=False, colour=col) if kind == 'line' else _text(h, layer, *payload, colour=col)
    L += ['0', 'ENDSEC', '0', 'SECTION', '2', 'OBJECTS', '0', 'DICTIONARY', '5', _H['rootdict'], '330', '0', '100', 'AcDbDictionary', '281', '1',
          '0', 'ENDSEC', '0', 'EOF']
    return '\r\n'.join(L) + '\r\n'

# ---------------------------------------------------------------- print PDF (1:1, one page per sheet)
FRAME_PT = 0.567      # 0.2 mm, the hairline the shop's hand-made print / cut pairs use for the sheet frame


def _sheet_frame(c, W, H):
    """The rectangle on the sheet edge that the print PDF and the cut PDF share as their common reference.  Process
    black, never CutContour: it lines the two files up, it is not a cut."""
    c.saveState(); c.setStrokeColorCMYK(0, 0, 0, 1); c.setLineWidth(FRAME_PT); c.rect(0, 0, W, H, stroke=1, fill=0); c.restoreState()


def _ccd_dots(c, sheet_w, sheet_h, dots):
    """Solid process-black CCD dots (a fill, no stroke, no crosshair) at ccd_dot_positions, in a reportlab canvas in points."""
    r = dot_diameter(dots) / 2 * MM
    c.saveState(); c.setFillColorCMYK(0, 0, 0, 1)
    for x, y in ccd_dot_positions(sheet_w, sheet_h, dots): c.circle(x * MM, y * MM, r, stroke=0, fill=1)
    c.restoreState()


def write_print_pdf(sheets, rules, artworks, bleed=0.0, outlines=False, corner_marks=False, corner_radius=0.0, cuts=None, frame=False, ccd_dots=None, cut_line=None, order_labels=None):
    """artworks: {key: bytes of a single-page PDF}.  cuts: {key: pdfcut.analyse result} for print & cut artwork, which
    is placed 1:1 with its CutContour line exactly on the nested outline (the bytes passed in already have the line
    removed).  ccd_dots: the cutter profile's camera dots (Ameida); drawn on every page in place of the hollow corner
    marks, which a CCD reading solid dots would not find.  cut_line ('cutcontour' / 'black'): also draw the cut lines on
    the same page, over the art: the Ameida's one print-and-cut file for vinyl on a roll (Danilo + owner, 20-Oct-2026).
    order_labels: optional output of order_labels.plan_labels, painted in
    process black after the artwork.  Cut PDF and DXF writers never receive or
    paint these production identifiers.  Returns (pdf_bytes, warnings)."""
    cuts = cuts or {}
    if order_labels is not None and len(order_labels) != len(sheets):
        raise ValueError('Printed order labels must contain one list per sheet.')
    from pypdf import PdfReader, PdfWriter, Transformation
    from reportlab.pdfgen import canvas
    warnings = []
    readers = {}
    writer = PdfWriter()
    for si, sheet in enumerate(sheets, 1):
        W, H = rules.for_sheet(sheet).sheet_w * MM, rules.for_sheet(sheet).sheet_h * MM
        # Blank base page at sheet size; artwork is merged onto it, then the
        # outlines / corner marks go on as a separate overlay so the artwork's
        # bleed cannot cover them.
        buf = io.BytesIO(); c = canvas.Canvas(buf, pagesize=(W, H)); c.showPage(); c.save()
        base = writer.add_page(PdfReader(io.BytesIO(buf.getvalue())).pages[0])   # on the writer first: pypdf merges onto loose pages unreliably
        obuf = io.BytesIO(); c = canvas.Canvas(obuf, pagesize=(W, H))
        c.setLineWidth(0.25)
        if frame: _sheet_frame(c, W, H)
        if ccd_dots: _ccd_dots(c, W / MM, H / MM, ccd_dots)
        elif corner_marks:
            m = (rules.margin / 2 if rules.margin > 0 else 8) * MM
            for (x, y) in ((m, m), (W - m, m), (m, H - m), (W - m, H - m)):
                c.circle(x, y, 3 * MM, stroke=1, fill=0)
                c.line(x - 5 * MM, y, x + 5 * MM, y); c.line(x, y - 5 * MM, x, y + 5 * MM)
        if outlines:
            for pl in sheet.placed:
                _draw_loops(c, placed_loops(pl, corner_radius), MM, 0, 0, fill=0)
        if cut_line: _draw_cut_lines(c, sheet, rules, cuts, cut_line, corner_radius)
        if order_labels is not None: _draw_order_labels(c, order_labels[si - 1])
        c.showPage(); c.save()
        overlay = PdfReader(io.BytesIO(obuf.getvalue())).pages[0] if (outlines or corner_marks or frame or ccd_dots or cut_line or order_labels is not None) else None
        for pl in sheet.placed:
            key = pl.part.artwork
            if not key or key not in artworks: continue
            if key not in readers: readers[key] = PdfReader(io.BytesIO(artworks[key]))
            art = readers[key].pages[0]
            if key in cuts and (pl.part.shape or {}).get('type') == 'contour':
                cut = cuts[key]
                ang, tx, ty = place_transform(pl)
                t = Transformation().translate(-cut['x0'] * MM, -cut['y0'] * MM)
                if _mirror(pl.part): t = t.scale(-1, 1).translate(pl.part.w * MM, 0)       # reverse print: flip inside the part's own box
                if ang: t = t.rotate(ang)
                base.merge_transformed_page(art, t.translate(tx * MM, ty * MM))
                continue
            aw, ah = float(art.mediabox.width), float(art.mediabox.height)
            tw, th = (pl.part.w + 2 * bleed) * MM, (pl.part.h + 2 * bleed) * MM
            if abs(aw - tw) > 0.5 * MM or abs(ah - th) > 0.5 * MM:
                msg = ('%s: artwork page is %.1f x %.1f mm but the part plus bleed is %.1f x %.1f mm; scaled uniformly to fit and centred.'
                       % (pl.part.name.split(' #')[0], aw / MM, ah / MM, tw / MM, th / MM))
                if msg not in warnings: warnings.append(msg)
            s = min(tw / aw, th / ah); sw, sh = aw * s, ah * s
            # centre the art in the part's own frame (bleed hangs outside 0..w x 0..h), then rotate and place
            ox, oy = (pl.part.w * MM - sw) / 2, (pl.part.h * MM - sh) / 2
            ang, tx, ty = place_transform(pl)
            t = Transformation().scale(s, s).translate(ox, oy)
            if _mirror(pl.part): t = t.scale(-1, 1).translate(pl.part.w * MM, 0)
            if ang: t = t.rotate(ang)
            t = t.translate(tx * MM, ty * MM)
            base.merge_transformed_page(art, t)
        if overlay is not None:
            base.merge_page(overlay)
    if getattr(rules, 'roll', False): _normalise_large_pages(writer)
    # Every merge gives the page a new content stream and leaves the previous one in the writer, unreferenced, so the
    # file grew with the square of the parts on a page: 32 stickers on a 24 m Colorado roll wrote 679 MB, all but
    # 2.8 MB of it dead copies (22-Oct-2026).  Keep only what the pages use, and compress the merged content.
    for page in writer.pages: page.compress_content_streams()
    writer.compress_identical_objects(remove_duplicates=False, remove_unreferenced=True)
    out = io.BytesIO(); writer.write(out)
    return out.getvalue(), warnings


def _draw_order_labels(c, labels):
    """Paint already-planned label records in process black on a sheet canvas."""
    from .order_labels import FONT_NAME, PAD_MM
    from reportlab.pdfbase.pdfmetrics import getAscentDescent
    c.saveState(); c.setFillColorCMYK(0, 0, 0, 1)
    for label in labels:
        size = float(label.get('font_size') or 6.0)
        _, descent = getAscentDescent(FONT_NAME, size)
        c.setFont(FONT_NAME, size)
        c.drawString((float(label['x']) + PAD_MM) * MM,
                     (float(label['y']) + PAD_MM) * MM - descent,
                     str(label['text']))
    c.restoreState()

def _mirror(part): return bool((part.shape or {}).get('mirror'))


def _normalise_large_pages(writer):
    """PDF 1.6 UserUnit keeps long roll pages within the 14,400-unit page-box limit.

    Scale content and every page box together, then restore physical dimensions with
    UserUnit. Short pages retain their original coordinates and PDF version.
    """
    from pypdf.generic import NameObject, NumberObject
    for page in writer.pages:
        unit = math.ceil(max(float(page.mediabox.width), float(page.mediabox.height)) / 14400)
        if unit <= 1: continue
        page.scale_by(1 / unit)
        page[NameObject('/UserUnit')] = NumberObject(unit)
        writer.pdf_header = '%PDF-1.6'


def _large_roll_pdf(data):
    from pypdf import PdfReader, PdfWriter
    reader = PdfReader(io.BytesIO(data))
    if all(max(float(p.mediabox.width), float(p.mediabox.height)) <= 14400 for p in reader.pages):
        return data
    writer = PdfWriter(clone_from=reader)
    _normalise_large_pages(writer)
    out = io.BytesIO(); writer.write(out)
    return out.getvalue()


def contour_overhang(cut):
    """How far (mm) the artwork page reaches past the bounding box of its CutContour line on its widest side."""
    l, b, r, t = cut['page_mm']
    return max(cut['x0'] - l, cut['y0'] - b, r - (cut['x0'] + cut['w']), t - (cut['y0'] + cut['h']), 0.0)


def _draw_cut_lines(c, sheet, rules, cuts, style='cutcontour', corner_radius=0.0):
    """One sheet's cut lines on a reportlab canvas: a contour part's own CutContour line from its artwork, any other
    part's nested outline, and the trim cuts.  style 'black' = 1 pt black, else the CutContour spot at 0.25 pt."""
    from reportlab.lib.colors import CMYKColorSep
    spot = CMYKColorSep(0, 1, 0, 0, spotName='CutContour', density=1)
    def pen():
        if style == 'black': c.setStrokeColorCMYK(0, 0, 0, 1); c.setLineWidth(1.0)     # the shop's rigid-material templates: 1 pt black
        else: c.setStrokeColor(spot); c.setLineWidth(0.25)
    for pl in sheet.placed:
        cut = (cuts or {}).get(pl.part.artwork) if (pl.part.shape or {}).get('type') == 'contour' else None
        if cut is None:                                                 # no CutContour in the art: cut on the nested outline
            c.saveState(); pen(); c.setLineJoin(1); c.setLineCap(1)
            _draw_loops(c, placed_loops(pl, corner_radius), MM, 0, 0, fill=0)
            c.restoreState(); continue
        ang, tx, ty = place_transform(pl)
        c.saveState()
        c.translate(tx * MM, ty * MM)
        if ang: c.rotate(ang)
        if _mirror(pl.part): c.translate(pl.part.w * MM, 0); c.scale(-1, 1)
        c.translate(-cut['x0'] * MM, -cut['y0'] * MM)
        pen()
        c.setLineJoin(1); c.setLineCap(1)
        p = c.beginPath()
        for segs in cut['paths']:
            for s in segs:
                if s[0] == 'M': p.moveTo(s[1] * MM, s[2] * MM)
                elif s[0] == 'L': p.lineTo(s[1] * MM, s[2] * MM)
                elif s[0] == 'C': p.curveTo(*(v * MM for v in s[1:]))
            p.close()
        c.drawPath(p, stroke=1, fill=0)
        c.restoreState()
    for tc in customcuts.paths(sheet, rules):                           # the trim cut that frees the offcut (straight, L or stairs), same pen as the part outlines
        c.saveState(); pen()
        p = c.beginPath(); p.moveTo(tc[0][0] * MM, tc[0][1] * MM)
        for x, y in tc[1:]: p.lineTo(x * MM, y * MM)
        c.drawPath(p, stroke=1, fill=0); c.restoreState()


def write_cut_pdf(sheets, rules, cuts, frame=False, style='cutcontour', ccd_dots=None):
    """Cut file for print & cut: one page per sheet, same size and origin as the print PDF, carrying only the CutContour
    lines taken from the artwork (original lines and curves, not redrawn shapes) as a CutContour spot colour.
    ccd_dots: the same camera dots as the print PDF, at the same coordinates (the Ameida maps the cut file's own dots
    onto the ones it finds in the print).
    cuts: {artwork key: pdfcut.analyse result}; every placed part must be a contour part (server.cut_reason checks)."""
    from reportlab.pdfgen import canvas
    buf = io.BytesIO(); c = canvas.Canvas(buf, pagesize=(rules.sheet_w * MM, rules.sheet_h * MM))
    c.setTitle('CutContour'); c.setCreator('PS Nest')
    for sheet in sheets:
        W, H = rules.for_sheet(sheet).sheet_w * MM, rules.for_sheet(sheet).sheet_h * MM
        c.setPageSize((W, H))
        if frame: _sheet_frame(c, W, H)
        if ccd_dots: _ccd_dots(c, W / MM, H / MM, ccd_dots)
        _draw_cut_lines(c, sheet, rules, cuts, style)
        c.showPage()
    c.save()
    return _large_roll_pdf(buf.getvalue()) if getattr(rules, 'roll', False) else buf.getvalue()


class _EPSCutCanvas:
    """The cut painter's small canvas interface, in physical PostScript points.

    Reuse the PDF painter so original Beziers, holes, islands and placement/mirror
    transforms agree. No PDF conversion: CorelDRAW 2021 ignores PDF UserUnit.
    """
    def __init__(self): self.code = []
    def _op(self, operator, *values):
        self.code.append(' '.join([*(format(float(v), '.12g') for v in values), operator]))
    def saveState(self): self.code.append('gsave')
    def restoreState(self): self.code.append('grestore')
    def translate(self, x, y): self._op('translate', x, y)
    def rotate(self, angle): self._op('rotate', angle)
    def scale(self, x, y): self._op('scale', x, y)
    def setLineJoin(self, value): self._op('setlinejoin', value)
    def setLineCap(self, value): self._op('setlinecap', value)
    def setLineWidth(self, value): self._op('setlinewidth', value)
    def setStrokeColor(self, colour):
        # _draw_cut_lines uses this method only for its exact CutContour spot.
        self.code += ['[/Separation /CutContour /DeviceCMYK { 0 exch 0 0 }] setcolorspace', '1 setcolor']
    def setStrokeColorCMYK(self, c, m, y, k): self._op('setcmykcolor', c, m, y, k)
    def beginPath(self): return _EPSCutPath()
    def drawPath(self, path, stroke=1, fill=0, **kwargs):
        if fill or not stroke: raise ValueError('Corel EPS carries stroked cut paths only.')
        self.code += ['newpath', *path.code, 'stroke']


class _EPSCutPath(_EPSCutCanvas):
    def moveTo(self, x, y): self._op('moveto', x, y)
    def lineTo(self, x, y): self._op('lineto', x, y)
    def curveTo(self, *values): self._op('curveto', *values)
    def close(self): self.code.append('closepath')


def write_cut_eps(sheet, rules, cuts, style='cutcontour'):
    """One Corel cut EPS, same physical page/origin as the corresponding print.

    EPS has no PDF page-size/UserUnit dependency. Its bounding frame is metadata,
    never a painted stock rectangle. Registration remains the cutter plugin's job.
    """
    rs = rules.for_sheet(sheet)
    W, H = rs.sheet_w * MM, rs.sheet_h * MM
    header = ['%!PS-Adobe-3.0 EPSF-3.0', '%%Creator: PS Nest', '%%Title: Corel cut',
              f'%%BoundingBox: 0 0 {math.ceil(W)} {math.ceil(H)}',
              f'%%HiResBoundingBox: 0 0 {W:.9f} {H:.9f}',
              '%%LanguageLevel: 2', '%%Pages: 1']
    if style != 'black':
        header += ['%%DocumentCustomColors: (CutContour)', '%%CMYKCustomColor: 0 1 0 0 (CutContour)']
    c = _EPSCutCanvas()
    _draw_cut_lines(c, sheet, rules, cuts, style)
    return ('\n'.join([*header, '%%EndComments', 'gsave', *c.code, 'grestore', 'showpage', '%%EOF']) + '\n').encode('ascii')


# ---------------------------------------------------------------- operator layout PDF (A4 landscape, one sheet per page)
def write_layout_pdf(sheets, rules, job_name, info, corner_radius=0.0):
    from .order_labels import printed_ref
    from reportlab.pdfgen import canvas
    from reportlab.lib.pagesizes import landscape, A4
    from reportlab.pdfbase.pdfmetrics import stringWidth
    PW, PH = landscape(A4)
    buf = io.BytesIO(); c = canvas.Canvas(buf, pagesize=(PW, PH))
    total_area = sum(s.used_area() for s in sheets)
    all_rules = rules
    for i, s in enumerate(sheets, 1):
        rules = all_rules.for_sheet(s)
        c.setFont('Helvetica-Bold', 14); c.drawString(30, PH - 32, f'{job_name}  -  {"roll length" if getattr(rules, "roll", False) else "sheet"} {i} of {len(sheets)}')
        util = s.used_area() / (rules.sheet_w * rules.sheet_h)
        rem = remnant(s, rules)
        used_len = roll_used_extent_mm(s, all_rules) if getattr(rules, 'roll', False) else min(
            rules.sheet_w, max((pl.x + pl.w for pl in s.placed), default=0.0) + rules.gap)
        c.setFont('Helvetica', 9.5)
        if getattr(rules, 'roll', False):
            _draw_fitted_line(
                c,
                f'Roll {rules.sheet_h:g} mm wide   |   allocated / export length {rules.sheet_w / 1000:.3f} m ({rules.sheet_w:g} mm)'
                f'   |   actual used extent {used_len / 1000:.3f} m ({used_len:.1f} mm, includes right margin)'
                f'   |   {len(s.placed)} parts   |   gap {rules.gap:g} mm',
                30, PH - 48, PW - 60, 'Helvetica', 9.5, 7.0)
        else: c.drawString(30, PH - 48, (f'Roll {rules.sheet_h:g} mm wide, pass up to {rules.sheet_w:g} mm' if getattr(rules, 'roll', False) else f'Sheet {rules.sheet_w:g} x {rules.sheet_h:g} mm' + (' (remnant)' if s.size else '')) + f'   |   {len(s.placed)} parts   |   used {util:.1%}'
                     f'   |   used length {used_len:.0f} mm   |   {"custom cuts; offcut area not measured" if s.custom_cuts is not None else offcut_words(rem, rules)}   |   edge {rules.edge:g} mm, gap {rules.gap:g} mm, clamp {rules.clamp:g} mm')
        if i == 1 and not getattr(rules, 'roll', False):
            detail = (f'Grouped by state and job sequence' if info.get('production_plan') else
                      f'{info.get("tried", 0)} layouts tried, best: {info.get("strategy")}')
            c.drawString(30, PH - 60, f'Whole job: {len(sheets)} sheet(s), {total_area / sum(sh.area(all_rules) for sh in sheets):.1%} of material used, ' + detail)
        # Scale the sheet to fit. Combined-order references that cannot remain
        # readable inside their footprint use a numbered marker and an exact
        # per-sheet key above the diagram. The complete identity is never
        # truncated or shrunk below LAYOUT_MIN_REF_FONT.
        avail_w, avail_h = PW - 60, PH - 110
        key_rows, callouts, key_height = [], {}, 0.0
        identified = list(enumerate(s.placed))

        def exact_label(pl):
            if getattr(pl.part, 'order_ref', ''):
                return printed_ref(pl.part) + angle_note(pl)
            return (f'{pl.part.name}  {round(pl.part.w, 1):g}x{round(pl.part.h, 1):g}'
                    + angle_note(pl))

        while True:
            usable_h = avail_h - key_height
            if usable_h <= 40:
                raise ValueError('Layout callout key leaves no readable sheet diagram.')
            k = min(avail_w / rules.sheet_w, usable_h / rules.sheet_h)
            needed = []
            for index, pl in identified:
                label = exact_label(pl)
                inside_w = max(0.0, pl.w * k - 4)
                inside_h = pl.h * k
                if (stringWidth(label, 'Helvetica', LAYOUT_MIN_REF_FONT) > inside_w or
                        inside_h < LAYOUT_MIN_REF_FONT + 2):
                    needed.append((index, pl, label))
            new_callouts = {index: number for number, (index, _pl, _label) in enumerate(needed, 1)}
            for index, pl, _label in needed:
                marker = f'#{new_callouts[index]}'
                if (stringWidth(marker, 'Helvetica', LAYOUT_KEY_FONT) > max(0.0, pl.w * k - 4)
                        or pl.h * k < LAYOUT_KEY_FONT + 2):
                    raise ValueError('Layout has no readable sheet diagram: a callout marker cannot fit inside its piece.')
            columns = 1 if len(needed) <= 1 else 2
            column_gap = 12.0
            column_width = (avail_w - column_gap * (columns - 1)) / columns
            new_rows = []
            for start in range(0, len(needed), columns):
                cells = []
                for index, _pl, label in needed[start:start + columns]:
                    marker = f'#{new_callouts[index]} = '
                    lines = _wrap_text(marker + label, 'Helvetica', LAYOUT_KEY_FONT, column_width)
                    if not lines:
                        raise ValueError('Layout callout key lost a piece identity.')
                    cells.append(lines)
                new_rows.append(cells)
            new_height = (8.0 + sum(max(len(lines) for lines in row) * (LAYOUT_KEY_FONT + 2)
                                    for row in new_rows)) if new_rows else 0.0
            if new_callouts == callouts and abs(new_height - key_height) < 0.001:
                key_rows = new_rows
                break
            callouts, key_rows, key_height = new_callouts, new_rows, new_height
        ox, oy = 30, 30
        c.setLineWidth(0.8); c.setStrokeColorRGB(0.3, 0.3, 0.3); c.rect(ox, oy, rules.sheet_w * k, rules.sheet_h * k)
        if max(rules.ml, rules.mr, rules.mb, rules.mt) > 0:
            c.setDash(3, 3); c.setLineWidth(0.4); c.rect(ox + rules.ml * k, oy + rules.mb * k, rules.usable_w * k, rules.usable_h * k); c.setDash()
        c.setLineWidth(0.6); c.setStrokeColorRGB(0.75, 0.05, 0.15)
        for index, pl in enumerate(s.placed):
            c.setFillColorRGB(0.97, 0.94, 0.94)
            _draw_loops(c, placed_loops(pl, corner_radius), k, ox, oy, fill=1)
            c.setFillColorRGB(0.1, 0.1, 0.1)
            fs = max(5, min(9, pl.h * k / 4)); c.setFont('Helvetica', fs)
            if index in callouts:
                label = f'#{callouts[index]}'
                fs = LAYOUT_KEY_FONT
            else:
                label = exact_label(pl)
                at_minimum = stringWidth(label, 'Helvetica', LAYOUT_MIN_REF_FONT)
                fs = min(max(LAYOUT_MIN_REF_FONT, fs),
                         LAYOUT_MIN_REF_FONT * (pl.w * k - 4) / at_minimum)
            width = stringWidth(label, 'Helvetica', fs)
            c.setFont('Helvetica', fs)
            # Dimensions can exceed a narrow part even after its name is shortened.
            # Keep the complete label inside the page's existing 30 pt margins.
            width = stringWidth(label, 'Helvetica', fs)
            if width > avail_w:
                fs *= avail_w / width
                width = stringWidth(label, 'Helvetica', fs)
                c.setFont('Helvetica', fs)
            cx = ox + (pl.x + pl.w / 2) * k
            cx = max(30 + width / 2, min(PW - 30 - width / 2, cx))
            c.drawCentredString(cx, oy + (pl.y + pl.h / 2) * k - fs / 3, label)
        if key_rows:
            columns = 1 if len(callouts) <= 1 else 2
            column_gap = 12.0
            column_width = (avail_w - column_gap * (columns - 1)) / columns
            key_y = oy + rules.sheet_h * k + 8
            for row in key_rows:
                row_lines = max(len(lines) for lines in row)
                for column, lines in enumerate(row):
                    x = ox + column * (column_width + column_gap)
                    for line_index, line in enumerate(lines):
                        c.setFont('Helvetica', LAYOUT_KEY_FONT)
                        c.drawString(x, key_y + (row_lines - line_index - 1) * (LAYOUT_KEY_FONT + 2), line)
                key_y += row_lines * (LAYOUT_KEY_FONT + 2)
        for tc in customcuts.paths(s, rules):
            c.setStrokeColorRGB(0.18, 0.49, 0.2); c.setLineWidth(0.8); c.setDash(4, 3)
            p = c.beginPath(); p.moveTo(ox + tc[0][0] * k, oy + tc[0][1] * k)
            for x, y in tc[1:]: p.lineTo(ox + x * k, oy + y * k)
            c.drawPath(p, stroke=1, fill=0)
            c.setDash(); c.setFillColorRGB(0.18, 0.49, 0.2); c.setFont('Helvetica', 7)
            tl = trim_line(s, rules)
            if s.custom_cuts is None and rem[3] in ('right', 'top') and tl:
                c.drawString(ox + (tl[1] * k + 3 if tl[0] == 'x' else 3), oy + (rules.sheet_h * k - 9 if tl[0] == 'x' else tl[1] * k + 3), f'trim cut at {tl[1]:g} mm')
            else:
                c.drawString(ox + tc[-1][0] * k + 3, oy + tc[-1][1] * k + 3, f'{"custom separation" if s.custom_cuts is not None else rem[3]}: {len(tc) - 1} straight cuts')
        c.showPage()
    c.save(); return buf.getvalue()


def write_packing_pdf(sheets, rules, job_name):
    """A4 project counts and piece references for sorting directly from the sheet.

    References remain in the waste. Operators identify each panel in its sheet
    position, then move it straight into its project pile; no transfer labels.
    """
    from collections import Counter
    from .order_labels import printed_ref
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas
    pieces = []
    seen = set()
    for sheet_i, sheet in enumerate(sheets, 1):
        for pl in sheet.placed:
            order_ref = str(getattr(pl.part, 'order_ref', '') or '').strip()
            piece_id = str(getattr(pl.part, 'piece_id', '') or '').strip()
            if not order_ref or not piece_id:
                raise ValueError(f'{pl.part.name}: sorting checklist needs order_ref and piece_id.')
            if piece_id in seen: raise ValueError(f'Duplicate combined-order piece_id: {piece_id}.')
            seen.add(piece_id)
            pieces.append({'order_ref': order_ref, 'sheet': sheet_i,
                           'compact_ref': printed_ref(pl.part)})
    if not pieces: raise ValueError('Sorting checklist needs at least one placed piece.')

    PW, PH = A4; margin = 32; buf = io.BytesIO(); c = canvas.Canvas(buf, pagesize=A4)
    c.setTitle(f'{job_name} project sorting checklist'); c.setCreator('PS Nest')
    page_number = 0

    def header():
        nonlocal page_number
        page_number += 1
        y = PH - 38
        for line in _wrap_text(f'{job_name} - project sorting checklist', 'Helvetica-Bold', 15, PW - 2 * margin):
            c.setFont('Helvetica-Bold', 15); c.drawString(margin, y, line); y -= 18
        instruction = ('Read the project, panel number and finished size beside each panel while it is still in its sheet position. '
                       'Lift it straight into the correct project pile. Use the project reference to sort even when sizes match. '
                       'Check the counts before bundling.')
        for line in _wrap_text(instruction, 'Helvetica', 10, PW - 2 * margin):
            c.setFont('Helvetica', 10); c.drawString(margin, y, line); y -= 12
        c.setFont('Helvetica', 8); c.drawRightString(PW - margin, 20, f'Page {page_number}')
        return y - 20

    def space(y, height):
        if y - height < margin:
            c.showPage()
            return header()
        return y

    y = header()
    c.setFont('Helvetica-Bold', 11); c.drawString(margin, y, 'Project totals'); y -= 24
    for order_ref, count in sorted(Counter(p['order_ref'] for p in pieces).items()):
        y = space(y, 24)
        c.rect(margin, y - 2, 9, 9, stroke=1, fill=0)
        c.setFont('Helvetica', 10)
        c.drawString(margin + 15, y, f'{order_ref}: {count} piece{"s" if count != 1 else ""}')
        y -= 24
    y = space(y, 60)
    c.setFont('Helvetica-Bold', 11); c.drawString(margin, y, 'Panel references'); y -= 24
    for piece in pieces:
        y = space(y, 22)
        c.rect(margin, y - 2, 8, 8, stroke=1, fill=0)
        _draw_fitted_line(c, piece['compact_ref'], margin + 15, y, PW - 2 * margin - 120, 'Helvetica', 10, 6)
        c.setFont('Helvetica', 10); c.drawRightString(PW - margin, y, f'Sheet {piece["sheet"]}')
        y -= 22
    c.showPage(); c.save(); return buf.getvalue()


def _draw_fitted_line(c, text, x, y, max_width, font, preferred, minimum):
    """Draw the complete text, shrinking only as needed; identity is never truncated."""
    from reportlab.pdfbase.pdfmetrics import stringWidth
    size = float(preferred)
    width = stringWidth(str(text), font, size)
    if width > max_width and width > 0: size = size * max_width / width
    c.setFont(font, size); c.drawString(x, y, str(text))
    return size


def _wrap_text(text, font, size, max_width):
    """Word-wrap prose to a measured PDF width."""
    from reportlab.pdfbase.pdfmetrics import stringWidth
    lines, current, words = [], '', []
    for word in str(text).split():
        # Preserve even an unbroken job reference while keeping every line
        # inside the printable width.
        while stringWidth(word, font, size) > max_width and len(word) > 1:
            cut = 1
            while cut < len(word) and stringWidth(word[:cut + 1], font, size) <= max_width: cut += 1
            words.append(word[:cut]); word = word[cut:]
        if word: words.append(word)
    for word in words:
        candidate = f'{current} {word}'.strip()
        if current and stringWidth(candidate, font, size) > max_width:
            lines.append(current); current = word
        else:
            current = candidate
    if current: lines.append(current)
    return lines

def offcut_words(rem, rules):
    """One phrase for the leftover a sheet gives back: 'offcut strip 390 x 1220 mm (right)', 'L-shaped offcut ...', 'no offcut'."""
    area, w, h, where = rem[0], rem[1], rem[2], rem[3]
    if area <= 0 or where == 'none': return 'no offcut worth keeping'
    if where == 'whole sheet': return 'whole sheet free'
    if where in ('right', 'top'): return f'offcut strip {w:.0f} x {h:.0f} mm ({where})'
    if where == 'L': return f'L-shaped offcut {area / 1e6:.2f} m2 (arms {w:.0f} mm on the right, {h:.0f} mm on top)'
    return f'stair-shaped offcut {area / 1e6:.2f} m2 (clear {w:.0f} mm on the right, {h:.0f} mm on top)'


def _draw_loops(c, loops, k, ox, oy, fill):
    """Draw [(kind, loop)] on a reportlab canvas at scale k (points per mm) and offset (ox, oy) points, even-odd."""
    p = c.beginPath()
    for kind, loop in loops:
        pts = _poly_points(loop)
        if not pts: continue
        p.moveTo(ox + pts[0][0] * k, oy + pts[0][1] * k)
        for x, y in pts[1:]: p.lineTo(ox + x * k, oy + y * k)
        p.close()
    c.drawPath(p, stroke=1, fill=fill, fillMode=0)      # 0 = even-odd: holes stay white


def fit_label(name, room, dots='\u2026'):
    """A part name cut down to `room` characters: the start of the name and its ' #n' counter survive, because those
    are what the operator looks for.  Names taken from artwork files are far longer than a small part is wide."""
    room = int(room)
    if len(name) <= room: return name
    head, sep, num = name.rpartition(' #')
    tail = ' #' + num if sep and num.isdigit() else ''
    keep = room - len(tail) - len(dots)
    if keep < 3: return tail.strip() if tail and len(tail.strip()) <= max(room, 2) else name[:max(room, 1)]
    return (head if tail else name)[:keep].rstrip(' _-') + dots + tail


def angle_note(pl):
    a = pl.angle % 360
    if abs(a) < 1e-9: return ''
    return '  (turned)' if abs(a - 90) < 1e-9 and not pl.part.shaped else f'  ({a:g}\u00b0)'


# ---------------------------------------------------------------- SVG preview
def write_svg(sheet, rules, corner_radius=0.0):
    rules = rules.for_sheet(sheet)
    W, H = rules.sheet_w, rules.sheet_h
    o = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="-6 -6 {W + 12} {H + 12}" font-family="-apple-system,Helvetica,Arial">',
         f'<g transform="translate(0,{H}) scale(1,-1)">',
         f'<rect x="0" y="0" width="{W}" height="{H}" fill="#fafafa" stroke="#333" stroke-width="3"/>']
    if max(rules.ml, rules.mr, rules.mb, rules.mt) > 0:
        o.append(f'<rect x="{rules.ml}" y="{rules.mb}" width="{rules.usable_w}" height="{rules.usable_h}" fill="none" stroke="#999" stroke-width="1.5" stroke-dasharray="12 8"/>')
    poly = remnant_polygon(sheet, rules) if sheet.custom_cuts is None else None
    if poly:
        o.append(f'<polygon points="{" ".join(f"{x:.1f},{y:.1f}" for x, y in poly)}" fill="#e8f5e9"/>')
    elif sheet.custom_cuts is None:
        strip = strip_offcut(sheet, rules)
        if strip[0] > 0 and strip[3] != 'whole sheet':
            if strip[3] == 'right': o.append(f'<rect x="{W - strip[1]}" y="0" width="{strip[1]}" height="{H}" fill="#e8f5e9"/>')
            else: o.append(f'<rect x="0" y="{H - strip[2]}" width="{W}" height="{strip[2]}" fill="#e8f5e9"/>')
    for tc in customcuts.paths(sheet, rules):
        o.append(f'<polyline class="separation" points="{" ".join(f"{x:.1f},{y:.1f}" for x, y in tc)}" fill="none" stroke="#2e7d32" stroke-width="3" stroke-dasharray="24 14" stroke-linejoin="round"/>')
    for pl in sheet.placed:
        o.append(f'<path d="{svg_path(placed_loops(pl, corner_radius))}" fill="#fde8ec" fill-rule="evenodd" stroke="#c8102e" stroke-width="2" stroke-linejoin="round"/>')
    o.append('</g>')
    for pl in sheet.placed:
        fs = max(14, min(34, pl.h / 5, pl.w / 8))
        cx, cy = pl.x + pl.w / 2, H - (pl.y + pl.h / 2)
        if getattr(pl.part, 'order_ref', ''):
            from .order_labels import printed_ref
            display = printed_ref(pl.part)
            fs = min(fs, max(1.0, pl.w / (max(1, len(display)) * 0.58)))
            detail = angle_note(pl).strip()
        else:
            display = fit_label(pl.part.name, pl.w / (fs * 0.58))
            detail = f'{round(pl.part.w, 1):g} x {round(pl.part.h, 1):g}{angle_note(pl).replace("(", "").replace(")", "")}'
        o.append(f'<text x="{cx}" y="{cy}" font-size="{fs}" text-anchor="middle" dominant-baseline="middle" fill="#222">{_esc(display)}'
                 f'<tspan x="{cx}" dy="{fs * 1.1}" font-size="{fs * 0.8}" fill="#666">{_esc(detail)}</tspan></text>')
    o.append('</svg>')
    return ''.join(o)

def _esc(s): return s.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')


def svg_path(loops, tol=0.05):
    """[(kind, loop)] -> SVG path data (arcs flattened), one closed subpath per loop."""
    d = []
    for _, loop in loops:
        pts = _poly_points(loop, tol)
        if not pts: continue
        d.append('M' + ' '.join(f'{x:.2f},{y:.2f}' for x, y in pts) + 'Z')
    return ''.join(d)

# ---------------------------------------------------------------- report + bundle
def report(sheets, rules, info, job_name, settings):
    out = {'job': job_name, 'sheet_mm': [rules.sheet_w, rules.sheet_h], 'rules': settings,
           'sheets': [], 'sheet_count': len(sheets), 'layouts_tried': info.get('tried'), 'strategy': info.get('strategy'),
           'engine': info.get('engine', 'rect'), 'pairs': info.get('pairs', []), 'seconds': info.get('seconds')}
    total = 0.0; area_all = 0.0
    for i, s in enumerate(sheets, 1):
        rs = rules.for_sheet(s)
        strip = strip_offcut(s, rs); ler = largest_empty_rect(s, rs); rem = remnant(s, rs); tc = trim_cut(s, rs)
        if s.custom_cuts is not None: tc = None
        total += s.used_area(); area_all += rs.sheet_w * rs.sheet_h
        # how far along the sheet the parts reach plus the edge margin: on a roll, the length that has to be printed
        used_len = (roll_used_extent_mm(s, rules) if rules.roll else
                    min(rs.sheet_w, max((pl.x + pl.w for pl in s.placed), default=0.0) + rs.margin)
                    if s.placed else 0.0)
        out['sheets'].append({'n': i, 'parts': len(s.placed), 'utilisation': round(s.used_area() / (rs.sheet_w * rs.sheet_h), 4),
                              'sheet_mm': [rs.sheet_w, rs.sheet_h], 'remnant_sheet': bool(s.size) and not rules.roll,
                              'used_length_mm': round(used_len, 1),
                              'offcut_strip_mm': [round(strip[1], 1), round(strip[2], 1), strip[3]],
                              'trim_line_mm': list(trim_line(s, rs)) if s.custom_cuts is None and trim_line(s, rs) else None,
                              'automatic_cuts_mm': [trim_cut(s,rs)] if trim_cut(s,rs) else [],
                              'custom_cuts': s.custom_cuts, 'separation_cuts_mm': customcuts.paths(s, rs),
                              'cut_clearance_mm': customcuts.clearance(rs, settings.get('bit_diameter', 0)) + 0.021,
                              'trim_cut_mm': [[round(x, 3), round(y, 3)] for x, y in tc] if tc else None,
                              'offcut': {'shape':'custom', 'area_m2':None, 'w':None, 'h':None, 'words':'custom separation cuts; reusable area not measured'} if s.custom_cuts is not None else {'shape': rem[3], 'area_m2': round(rem[0] / 1e6, 4), 'w': round(rem[1], 1), 'h': round(rem[2], 1),
                                         'words': offcut_words(rem, rs)},
                              'largest_empty_rect_mm': [round(ler[3], 1), round(ler[4], 1)],
                              'placements': [_placement_record(p) for p in s.placed]})
    out['utilisation'] = round(total / area_all, 4) if sheets and area_all > 0 else 0
    out['offcut_shape'] = rules.offcut_shape
    return out


def _placement_record(p):
    """Report one placement; combined-order identity is absent for legacy parts."""
    rec = {'part': p.part.name, 'x': round(p.x, 3), 'y': round(p.y, 3),
           'w': round(p.w, 3), 'h': round(p.h, 3), 'turned': p.rotated,
           'angle': round(p.angle % 360, 3)}
    for key in ('order_ref', 'source_part_id', 'piece_id', 'item_number', 'copy_number', 'site_ref', 'state', 'artwork_version'):
        value = getattr(p.part, key, '')
        if value: rec[key] = value
    return rec

def bundle(files):
    """files: {name: bytes} -> zip bytes"""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as z:
        for n, b in files.items(): z.writestr(n, b)
    return buf.getvalue()
