"""Output writers: DXF cut file, 1:1 print PDF, operator layout PDF, SVG preview, JSON report."""
from __future__ import annotations
import io, json, math, zipfile
from .engine import strip_offcut, largest_empty_rect
from . import geom

MM = 72 / 25.4          # PDF points per mm
BULGE90 = math.tan(math.radians(90) / 4)   # bulge for a 90-degree arc

# ---------------------------------------------------------------- placed geometry (shared by every writer)
def placed_loops(pl, corner_radius=0.0):
    """World loops of a placement: [(outer/hole flag, [(x, y, bulge), ...]), ...].
    Rectangles get the optional corner radius; shaped parts use their real outline, islands and holes
    rotated by pl.angle with the bbox of outline+islands at (pl.x, pl.y)."""
    part = pl.part
    if not part.shaped and abs(pl.angle % 90) < 1e-9:        # pl.w / pl.h are already swapped for 90 / 270
        return [('outer', rect_path(pl.x, pl.y, pl.w, pl.h, corner_radius))]
    loops = part.shape_loops() if part.shaped else [rect_path(0, 0, part.w, part.h, corner_radius)]
    n_out = len(loops)
    loops = loops + [list(h) for h in part.holes]
    world = geom.world_loops(loops, pl.angle, pl.x, pl.y)
    return [('outer' if i < n_out else 'hole', w) for i, w in enumerate(world)]


def place_transform(pl):
    """(angle_deg, tx, ty) in mm such that world = R(angle) . frame + (tx, ty) for the part's own frame."""
    part = pl.part
    loops = part.shape_loops() if part.shaped else [[(0, 0, 0), (part.w, 0, 0), (part.w, part.h, 0), (0, part.h, 0)]]
    rot = [geom.rotate(o, pl.angle) if pl.angle else o for o in loops]
    x0, y0, _, _ = geom.bbox_loops(rot)
    return pl.angle, pl.x - x0, pl.y - y0


def _poly_points(loop, tol=0.05):
    """Closed (x, y, bulge) loop -> flattened [(x, y)] for drawing."""
    return geom.flatten(loop, tol)


# ---------------------------------------------------------------- DXF
# Full-form AutoCAD 2000 (AC1015) file: every table, block record and entity carries a handle,
# owner (330) and AcDb subclass markers.  A minimal "header + entities" DXF is NOT enough:
# Tempus Tools rejected exactly that form on 3-Sep-2026 (parts showed "undefined x undefined mm")
# and again on 16-Sep-2026 (blank import), while this full form imports with correct dimensions.
_H = {'vport_t': '1', 'ltype_t': '2', 'layer_t': '3', 'style_t': '4', 'view_t': '5', 'ucs_t': '6',
      'appid_t': '7', 'dimstyle_t': '8', 'blkrec_t': '9', 'vport': 'A', 'byblock': 'B', 'bylayer': 'C',
      'continuous': 'D', 'layer0': 'E', 'cut': 'F', 'sheet': '10', 'label': '11', 'style': '12', 'appid': '13',
      'dimstyle': '14', 'model_rec': '15', 'paper_rec': '16', 'model_blk': '17', 'model_end': '18',
      'paper_blk': '19', 'paper_end': '1A', 'rootdict': '1B'}
_FIRST_ENTITY = 0x20

def _n(v):
    """DXF number: fixed 4 decimals, no exponent, no trailing garbage."""
    t = ('%.4f' % v).rstrip('0').rstrip('.')
    return t if t not in ('', '-0') else '0'

def _table(lines, name, handle, records, subclass=None):
    lines += ['0', 'TABLE', '2', name, '5', handle, '330', '0', '100', 'AcDbSymbolTable', '70', str(len(records))]
    if subclass: lines += ['100', subclass]
    for r in records: lines += r
    lines += ['0', 'ENDTAB']

def _layer(handle, name, colour):
    return ['0', 'LAYER', '5', handle, '330', _H['layer_t'], '100', 'AcDbSymbolTableRecord',
            '100', 'AcDbLayerTableRecord', '2', name, '70', '0', '62', str(colour), '6', 'Continuous']

def _lwpoly(handle, layer, pts, closed=True):
    """pts: [(x, y, bulge), ...]"""
    s = ['0', 'LWPOLYLINE', '5', handle, '330', _H['model_rec'], '100', 'AcDbEntity', '8', layer,
         '100', 'AcDbPolyline', '90', str(len(pts)), '70', '1' if closed else '0', '43', '0']
    for x, y, b in pts:
        s += ['10', _n(x), '20', _n(y)]
        if abs(b) > 1e-12: s += ['42', '%.12f' % b]
    return s

def _text(handle, layer, x, y, h, txt):
    return ['0', 'TEXT', '5', handle, '330', _H['model_rec'], '100', 'AcDbEntity', '8', layer, '100', 'AcDbText',
            '10', _n(x), '20', _n(y), '30', '0', '40', _n(h), '1', txt, '50', '0', '7', 'Standard', '100', 'AcDbText']

def rect_path(x, y, w, h, r):
    """Counter-clockwise closed path with radius-r corners as bulge arcs."""
    r = max(0.0, min(r, w / 2, h / 2))
    if r <= 0:
        return [(x, y, 0), (x + w, y, 0), (x + w, y + h, 0), (x, y + h, 0)]
    b = BULGE90
    return [(x + r, y, 0), (x + w - r, y, b), (x + w, y + r, 0), (x + w, y + h - r, b),
            (x + w - r, y + h, 0), (x + r, y + h, b), (x, y + h - r, 0), (x, y + r, b)]

def write_dxf(sheet, rules, corner_radius=0.0, labels=False, sheet_outline=False):
    # No stock outline by default: a closed 2440x1220 polyline in the file is read as THE PART by any
    # consumer that takes the outermost loop (Tempus did on 16-Sep-2026: 'Part with web cannot fit on
    # material'), and on a router it is a cut line round the whole sheet. Parts only; the sheet is $EXTMAX.
    ents = []                       # [(layer, kind, payload)]
    if sheet_outline: ents.append(('SHEET', 'poly', rect_path(0, 0, rules.sheet_w, rules.sheet_h, 0)))
    for pl in sheet.placed:
        loops = placed_loops(pl, corner_radius)
        for kind, loop in loops:                     # inner loops first so a CAM that keeps file order cuts holes before the outline
            if kind == 'hole': ents.append(('CUT', 'poly', loop))
        for kind, loop in loops:
            if kind != 'hole': ents.append(('CUT', 'poly', loop))
        if labels: ents.append(('LABEL', 'text', (pl.x + 5, pl.y + 5, min(12, pl.h / 4), pl.part.name)))
    handseed = '%X' % (_FIRST_ENTITY + len(ents))
    L = ['0', 'SECTION', '2', 'HEADER',
         '9', '$ACADVER', '1', 'AC1015', '9', '$DWGCODEPAGE', '3', 'ANSI_1252',
         '9', '$INSBASE', '10', '0', '20', '0', '30', '0',
         '9', '$EXTMIN', '10', '0', '20', '0', '30', '0',
         '9', '$EXTMAX', '10', _n(rules.sheet_w), '20', _n(rules.sheet_h), '30', '0',
         '9', '$LIMMIN', '10', '0', '20', '0', '9', '$LIMMAX', '10', _n(rules.sheet_w), '20', _n(rules.sheet_h),
         '9', '$LUNITS', '70', '2', '9', '$LUPREC', '70', '4', '9', '$AUNITS', '70', '0', '9', '$AUPREC', '70', '4',
         '9', '$MEASUREMENT', '70', '1', '9', '$INSUNITS', '70', '4', '9', '$HANDSEED', '5', handseed,
         '0', 'ENDSEC', '0', 'SECTION', '2', 'CLASSES', '0', 'ENDSEC', '0', 'SECTION', '2', 'TABLES']
    _table(L, 'VPORT', _H['vport_t'], [['0', 'VPORT', '5', _H['vport'], '330', _H['vport_t'], '100', 'AcDbSymbolTableRecord',
                                        '100', 'AcDbViewportTableRecord', '2', '*Active', '70', '0', '10', '0', '20', '0',
                                        '11', '1', '21', '1', '12', _n(rules.sheet_w / 2), '22', _n(rules.sheet_h / 2),
                                        '40', _n(rules.sheet_h * 1.1), '41', '2']])
    lt = lambda h, name, desc: ['0', 'LTYPE', '5', h, '330', _H['ltype_t'], '100', 'AcDbSymbolTableRecord', '100', 'AcDbLinetypeTableRecord',
                                '2', name, '70', '0', '3', desc, '72', '65', '73', '0', '40', '0']
    _table(L, 'LTYPE', _H['ltype_t'], [lt(_H['byblock'], 'ByBlock', ''), lt(_H['bylayer'], 'ByLayer', ''), lt(_H['continuous'], 'Continuous', 'Solid line')])
    _table(L, 'LAYER', _H['layer_t'], [_layer(_H['layer0'], '0', 7), _layer(_H['cut'], 'CUT', 1), _layer(_H['sheet'], 'SHEET', 8), _layer(_H['label'], 'LABEL', 3)])
    _table(L, 'STYLE', _H['style_t'], [['0', 'STYLE', '5', _H['style'], '330', _H['style_t'], '100', 'AcDbSymbolTableRecord', '100', 'AcDbTextStyleTableRecord',
                                        '2', 'Standard', '70', '0', '40', '0', '41', '1', '50', '0', '71', '0', '42', '2.5', '3', 'txt', '4', '']])
    _table(L, 'VIEW', _H['view_t'], []); _table(L, 'UCS', _H['ucs_t'], [])
    _table(L, 'APPID', _H['appid_t'], [['0', 'APPID', '5', _H['appid'], '330', _H['appid_t'], '100', 'AcDbSymbolTableRecord', '100', 'AcDbRegAppTableRecord', '2', 'ACAD', '70', '0']])
    _table(L, 'DIMSTYLE', _H['dimstyle_t'], [['0', 'DIMSTYLE', '105', _H['dimstyle'], '330', _H['dimstyle_t'], '100', 'AcDbSymbolTableRecord', '100', 'AcDbDimStyleTableRecord',
                                              '2', 'Standard', '70', '0', '40', '1', '41', '2.5', '42', '0.625', '43', '3.75', '44', '1.25', '140', '2.5', '141', '2.5', '147', '0.625',
                                              '71', '0', '72', '0', '73', '0', '74', '0', '77', '1', '78', '8', '170', '0', '171', '3', '172', '1', '173', '0', '174', '0',
                                              '271', '2', '272', '2', '273', '2', '274', '3', '277', '2', '278', '44']], 'AcDbDimStyleTable')
    br = lambda h, name: ['0', 'BLOCK_RECORD', '5', h, '330', _H['blkrec_t'], '100', 'AcDbSymbolTableRecord', '100', 'AcDbBlockTableRecord', '2', name]
    _table(L, 'BLOCK_RECORD', _H['blkrec_t'], [br(_H['model_rec'], '*Model_Space'), br(_H['paper_rec'], '*Paper_Space')])
    L += ['0', 'ENDSEC', '0', 'SECTION', '2', 'BLOCKS']
    for blk, endb, rec, name in ((_H['model_blk'], _H['model_end'], _H['model_rec'], '*Model_Space'), (_H['paper_blk'], _H['paper_end'], _H['paper_rec'], '*Paper_Space')):
        L += ['0', 'BLOCK', '5', blk, '330', rec, '100', 'AcDbEntity', '8', '0', '100', 'AcDbBlockBegin', '2', name, '70', '0',
              '10', '0', '20', '0', '30', '0', '3', name, '1', '', '0', 'ENDBLK', '5', endb, '330', rec, '100', 'AcDbEntity', '8', '0', '100', 'AcDbBlockEnd']
    L += ['0', 'ENDSEC', '0', 'SECTION', '2', 'ENTITIES']
    for i, (layer, kind, payload) in enumerate(ents):
        h = '%X' % (_FIRST_ENTITY + i)
        L += _lwpoly(h, layer, payload) if kind == 'poly' else _text(h, layer, *payload)
    L += ['0', 'ENDSEC', '0', 'SECTION', '2', 'OBJECTS', '0', 'DICTIONARY', '5', _H['rootdict'], '330', '0', '100', 'AcDbDictionary', '281', '1',
          '0', 'ENDSEC', '0', 'EOF']
    return '\r\n'.join(L) + '\r\n'

# ---------------------------------------------------------------- print PDF (1:1, one page per sheet)
def write_print_pdf(sheets, rules, artworks, bleed=0.0, outlines=False, corner_marks=False, corner_radius=0.0):
    """artworks: {key: bytes of a single-page PDF}.  Returns (pdf_bytes, warnings)."""
    from pypdf import PdfReader, PdfWriter, Transformation
    from reportlab.pdfgen import canvas
    warnings = []
    W, H = rules.sheet_w * MM, rules.sheet_h * MM
    readers = {}
    writer = PdfWriter()
    for si, sheet in enumerate(sheets, 1):
        # Blank base page at sheet size; artwork is merged onto it, then the
        # outlines / corner marks go on as a separate overlay so the artwork's
        # bleed cannot cover them.
        buf = io.BytesIO(); c = canvas.Canvas(buf, pagesize=(W, H)); c.showPage(); c.save()
        base = PdfReader(io.BytesIO(buf.getvalue())).pages[0]
        obuf = io.BytesIO(); c = canvas.Canvas(obuf, pagesize=(W, H))
        c.setLineWidth(0.25)
        if corner_marks:
            m = (rules.margin / 2 if rules.margin > 0 else 8) * MM
            for (x, y) in ((m, m), (W - m, m), (m, H - m), (W - m, H - m)):
                c.circle(x, y, 3 * MM, stroke=1, fill=0)
                c.line(x - 5 * MM, y, x + 5 * MM, y); c.line(x, y - 5 * MM, x, y + 5 * MM)
        if outlines:
            for pl in sheet.placed:
                _draw_loops(c, placed_loops(pl, corner_radius), MM, 0, 0, fill=0)
        c.showPage(); c.save()
        overlay = PdfReader(io.BytesIO(obuf.getvalue())).pages[0] if (outlines or corner_marks) else None
        for pl in sheet.placed:
            key = pl.part.artwork
            if not key or key not in artworks: continue
            if key not in readers: readers[key] = PdfReader(io.BytesIO(artworks[key]))
            art = readers[key].pages[0]
            aw, ah = float(art.mediabox.width), float(art.mediabox.height)
            tw, th = (pl.part.w + 2 * bleed) * MM, (pl.part.h + 2 * bleed) * MM
            if abs(aw - tw) > 0.5 * MM or abs(ah - th) > 0.5 * MM:
                msg = ('%s: artwork page is %.1f x %.1f mm but the part plus bleed is %.1f x %.1f mm; scaled uniformly to fit and centred.'
                       % (pl.part.name.split(' #')[0], aw / MM, ah / MM, tw / MM, th / MM))
                if msg not in warnings: warnings.append(msg)
            s = min(tw / aw, th / ah); sw, sh = aw * s, ah * s
            # centre the art in the part's own frame (bleed hangs outside 0..w x 0..h), then rotate and place
            ox, oy = (pl.part.w * MM - sw) / 2, (pl.part.h * MM - sh) / 2
            ang, tx, ty = place_transform(pl)
            t = Transformation().scale(s, s).translate(ox, oy)
            if ang: t = t.rotate(ang)
            t = t.translate(tx * MM, ty * MM)
            base.merge_transformed_page(art, t)
        if overlay is not None:
            base.merge_page(overlay)
        writer.add_page(base)
    out = io.BytesIO(); writer.write(out)
    return out.getvalue(), warnings

# ---------------------------------------------------------------- operator layout PDF (A4 landscape, one sheet per page)
def write_layout_pdf(sheets, rules, job_name, info, corner_radius=0.0):
    from reportlab.pdfgen import canvas
    from reportlab.lib.pagesizes import landscape, A4
    PW, PH = landscape(A4)
    buf = io.BytesIO(); c = canvas.Canvas(buf, pagesize=(PW, PH))
    total_area = sum(s.used_area() for s in sheets)
    for i, s in enumerate(sheets, 1):
        c.setFont('Helvetica-Bold', 14); c.drawString(30, PH - 32, f'{job_name}  -  sheet {i} of {len(sheets)}')
        util = s.used_area() / (rules.sheet_w * rules.sheet_h)
        strip = strip_offcut(s, rules)
        c.setFont('Helvetica', 9.5)
        c.drawString(30, PH - 48, f'Sheet {rules.sheet_w:g} x {rules.sheet_h:g} mm   |   {len(s.placed)} parts   |   used {util:.1%}'
                     f'   |   offcut strip {strip[1]:.0f} x {strip[2]:.0f} mm ({strip[3]})   |   edge {rules.edge:g} mm, gap {rules.gap:g} mm, clamp {rules.clamp:g} mm')
        if i == 1:
            c.drawString(30, PH - 60, f'Whole job: {len(sheets)} sheet(s), {total_area / (len(sheets) * rules.sheet_w * rules.sheet_h):.1%} of material used, '
                         f'{info.get("tried", 0)} layouts tried, best: {info.get("strategy")}')
        # scale sheet to fit
        avail_w, avail_h = PW - 60, PH - 110
        k = min(avail_w / rules.sheet_w, avail_h / rules.sheet_h)
        ox, oy = 30, 30
        c.setLineWidth(0.8); c.setStrokeColorRGB(0.3, 0.3, 0.3); c.rect(ox, oy, rules.sheet_w * k, rules.sheet_h * k)
        m = rules.margin
        if m > 0:
            c.setDash(3, 3); c.setLineWidth(0.4); c.rect(ox + m * k, oy + m * k, (rules.sheet_w - 2 * m) * k, (rules.sheet_h - 2 * m) * k); c.setDash()
        c.setLineWidth(0.6); c.setStrokeColorRGB(0.75, 0.05, 0.15)
        for pl in s.placed:
            c.setFillColorRGB(0.97, 0.94, 0.94)
            _draw_loops(c, placed_loops(pl, corner_radius), k, ox, oy, fill=1)
            c.setFillColorRGB(0.1, 0.1, 0.1)
            fs = max(5, min(9, pl.h * k / 4)); c.setFont('Helvetica', fs)
            label = f'{pl.part.name}  {round(pl.part.w, 1):g}x{round(pl.part.h, 1):g}' + angle_note(pl)
            c.drawCentredString(ox + (pl.x + pl.w / 2) * k, oy + (pl.y + pl.h / 2) * k - fs / 3, label)
        c.showPage()
    c.save(); return buf.getvalue()

def _draw_loops(c, loops, k, ox, oy, fill):
    """Draw [(kind, loop)] on a reportlab canvas at scale k (points per mm) and offset (ox, oy) points, even-odd."""
    p = c.beginPath()
    for kind, loop in loops:
        pts = _poly_points(loop)
        if not pts: continue
        p.moveTo(ox + pts[0][0] * k, oy + pts[0][1] * k)
        for x, y in pts[1:]: p.lineTo(ox + x * k, oy + y * k)
        p.close()
    c.drawPath(p, stroke=1, fill=fill, fillMode=0)      # 0 = even-odd: holes stay white


def angle_note(pl):
    a = pl.angle % 360
    if abs(a) < 1e-9: return ''
    return '  (turned)' if abs(a - 90) < 1e-9 and not pl.part.shaped else f'  ({a:g}\u00b0)'


# ---------------------------------------------------------------- SVG preview
def write_svg(sheet, rules, corner_radius=0.0):
    W, H = rules.sheet_w, rules.sheet_h
    o = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="-6 -6 {W + 12} {H + 12}" font-family="-apple-system,Helvetica,Arial">',
         f'<g transform="translate(0,{H}) scale(1,-1)">',
         f'<rect x="0" y="0" width="{W}" height="{H}" fill="#fafafa" stroke="#333" stroke-width="3"/>']
    m = rules.margin
    if m > 0:
        o.append(f'<rect x="{m}" y="{m}" width="{W - 2 * m}" height="{H - 2 * m}" fill="none" stroke="#999" stroke-width="1.5" stroke-dasharray="12 8"/>')
    strip = strip_offcut(sheet, rules)
    if strip[0] > 0 and strip[3] != 'whole sheet':
        if strip[3] == 'right': o.append(f'<rect x="{W - strip[1]}" y="0" width="{strip[1]}" height="{H}" fill="#e8f5e9"/>')
        else: o.append(f'<rect x="0" y="{H - strip[2]}" width="{W}" height="{strip[2]}" fill="#e8f5e9"/>')
    for pl in sheet.placed:
        o.append(f'<path d="{svg_path(placed_loops(pl, corner_radius))}" fill="#fde8ec" fill-rule="evenodd" stroke="#c8102e" stroke-width="2" stroke-linejoin="round"/>')
    o.append('</g>')
    for pl in sheet.placed:
        fs = max(14, min(34, pl.h / 5, pl.w / 8))
        cx, cy = pl.x + pl.w / 2, H - (pl.y + pl.h / 2)
        o.append(f'<text x="{cx}" y="{cy}" font-size="{fs}" text-anchor="middle" dominant-baseline="middle" fill="#222">{_esc(pl.part.name)}'
                 f'<tspan x="{cx}" dy="{fs * 1.1}" font-size="{fs * 0.8}" fill="#666">{round(pl.part.w, 1):g} x {round(pl.part.h, 1):g}{angle_note(pl).replace("(", "").replace(")", "")}</tspan></text>')
    o.append('</svg>')
    return ''.join(o)

def _esc(s): return s.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')


def svg_path(loops, tol=0.05):
    """[(kind, loop)] -> SVG path data (arcs flattened), one closed subpath per loop."""
    d = []
    for _, loop in loops:
        pts = _poly_points(loop, tol)
        if not pts: continue
        d.append('M' + ' '.join(f'{x:.2f},{y:.2f}' for x, y in pts) + 'Z')
    return ''.join(d)

# ---------------------------------------------------------------- report + bundle
def report(sheets, rules, info, job_name, settings):
    out = {'job': job_name, 'sheet_mm': [rules.sheet_w, rules.sheet_h], 'rules': settings,
           'sheets': [], 'sheet_count': len(sheets), 'layouts_tried': info.get('tried'), 'strategy': info.get('strategy'),
           'engine': info.get('engine', 'rect'), 'pairs': info.get('pairs', []), 'seconds': info.get('seconds')}
    total = 0.0
    for i, s in enumerate(sheets, 1):
        strip = strip_offcut(s, rules); ler = largest_empty_rect(s, rules)
        total += s.used_area()
        out['sheets'].append({'n': i, 'parts': len(s.placed), 'utilisation': round(s.used_area() / (rules.sheet_w * rules.sheet_h), 4),
                              'offcut_strip_mm': [round(strip[1], 1), round(strip[2], 1), strip[3]],
                              'largest_empty_rect_mm': [round(ler[3], 1), round(ler[4], 1)],
                              'placements': [{'part': p.part.name, 'x': round(p.x, 3), 'y': round(p.y, 3), 'w': round(p.w, 3), 'h': round(p.h, 3), 'turned': p.rotated, 'angle': round(p.angle % 360, 3)} for p in s.placed]})
    out['utilisation'] = round(total / (len(sheets) * rules.sheet_w * rules.sheet_h), 4) if sheets else 0
    return out

def bundle(files):
    """files: {name: bytes} -> zip bytes"""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as z:
        for n, b in files.items(): z.writestr(n, b)
    return buf.getvalue()
