"""Job-owned separation paths in sheet millimetres, validated before any export."""
import math
from . import geom

TOL = 0.02

def paths(sheet, rules):
    from .engine import trim_cut
    if sheet.custom_cuts is not None: return sheet.custom_cuts
    auto = trim_cut(sheet, rules)
    return [auto] if auto else []

def obstacles(sheet, corner_radius=0):
    from .outputs import placed_loops
    # Outer contours include islands. Holes deliberately remain protected: a
    # separation cut must go around the part, not through its internal scrap.
    return [{'name': p.part.name, 'poly': geom.flatten(loop, 0.02)}
            for p in sheet.placed for kind, loop in placed_loops(p, corner_radius) if kind != 'hole']

def clearance(rules, tool):
    return max(float(tool or 0) + 0.05, 0.1)

def validate(sheet, rules, value, tool=0, corner_radius=0):
    r = rules.for_sheet(sheet)
    if value is None: return None
    if r.roll: raise ValueError('Custom separation cuts are for sheets, not roll material.')
    if not isinstance(value, list) or len(value) > 100: raise ValueError('Use at most 100 separation paths per sheet.')
    out = []
    for i, line in enumerate(value, 1):
        if not isinstance(line, list) or not 2 <= len(line) <= 100: raise ValueError(f'Cut {i}: use 2–100 points.')
        clean = []
        for pt in line:
            if not isinstance(pt, (list, tuple)) or len(pt) != 2: raise ValueError(f'Cut {i}: every point needs X and Y.')
            try: x, y = map(float, pt)
            except (TypeError, ValueError): raise ValueError(f'Cut {i}: coordinates must be numbers.')
            if not math.isfinite(x) or not math.isfinite(y) or not 0 <= x <= r.sheet_w or not 0 <= y <= r.sheet_h:
                raise ValueError(f'Cut {i}: keep every point inside the sheet.')
            clean.append([round(x, 4), round(y, 4)])
        out.append(clean)
    segs = [(i, j, a, b) for i, p in enumerate(out) for j, (a, b) in enumerate(zip(p, p[1:]))]
    shapes = obstacles(sheet, corner_radius); gap = clearance(r, tool)
    for i, j, a, b in segs:
        if math.dist(a, b) < 0.1: raise ValueError(f'Cut {i+1}: remove repeated points or segments shorter than 0.1 mm.')
        if (abs(a[0]-b[0]) < TOL and min(a[0],r.sheet_w-a[0]) < TOL) or (abs(a[1]-b[1]) < TOL and min(a[1],r.sheet_h-a[1]) < TOL):
            raise ValueError(f'Cut {i+1}: a cut along the existing sheet edge is unnecessary.')
        for shape in shapes:
            poly = shape['poly']
            if geom.point_in_poly(*a, poly) or geom.point_in_poly(*b, poly) or any(geom.seg_seg_dist(a,b,c,d) < gap + 0.021 for c,d in zip(poly,poly[1:]+poly[:1])):
                # Flattened arcs deviate by <=0.02 mm; reserve that tolerance.
                raise ValueError(f'Cut {i+1} crosses or is too close to {shape["name"]}. Keep at least {gap + 0.021:g} mm clear.')
        for k,l,c,d in segs:
            if (k,l) <= (i,j): continue
            # Collinear overlap would cut a segment twice. Point crossings are
            # allowed between different paths; a path cannot cross itself.
            cross = (b[0]-a[0])*(d[1]-c[1])-(b[1]-a[1])*(d[0]-c[0])
            collinear = abs(cross) < 1e-7 and abs((b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])) < 1e-7
            axis = 0 if abs(b[0]-a[0]) >= abs(b[1]-a[1]) else 1
            overlap = min(max(a[axis],b[axis]),max(c[axis],d[axis])) - max(min(a[axis],b[axis]),min(c[axis],d[axis]))
            if collinear and overlap > TOL: raise ValueError('Separation cuts overlap: remove the duplicate segment.')
            if i==k and l>j+1 and geom.segments_intersect(a,b,c,d): raise ValueError(f'Cut {i+1} crosses itself.')
    # Require both ends to terminate on an edge or an earlier connected path.
    # Iteratively admit paths so ordering does not matter and floating groups fail.
    pending = list(enumerate(out)); connected=[]
    def anchored(pt):
        x,y=pt
        return min(x,y,r.sheet_w-x,r.sheet_h-y) < 1e-6 or any(geom.point_seg_dist(x,y,*a,*b)<1e-6 for p in connected for a,b in zip(p,p[1:]))
    while pending:
        accepted=[(i,p) for i,p in pending if anchored(p[0]) and anchored(p[-1])]
        if not accepted: raise ValueError('Connect both ends of each cut to sheet edges or an already connected cut. Snap to the edge or endpoint.')
        for i,p in accepted: connected.append(p);pending.remove((i,p))
    return out

def apply(sheets, rules, mapping, tool=0, corner_radius=0):
    if not isinstance(mapping, dict): raise ValueError('Custom cuts must be keyed by sheet number.')
    checked={}
    for key,value in mapping.items():
        if not str(key).isdigit() or str(int(key)) != str(key) or not 0 <= int(key)<len(sheets):
            raise ValueError('A sheet with custom cuts no longer exists. Reset custom cuts and nest again.')
        checked[int(key)]=validate(sheets[int(key)],rules,value,tool,corner_radius)
    for i,value in checked.items(): sheets[i].custom_cuts=value
