"""Print / cut pair check (19-Nov-2026): do a print layout and its cut file belong together?  (A sheet re-nested by hand
once left saved print files that no longer matched the cut files.)  Lays the cut file over the print page and checks:
  1. the print page and the cut file are for the same sheet size (within 1 mm);
  2. how many parts the cut file cuts (the stock-size frame, camera dots and holes inside a part are not parts);
  3. that count equals the expected quantity (ordered + spares), when one is given;
  4. every cut part has print under it, and nothing is printed far away from every part;
  5. the BACK page, mirrored left-to-right (the board is turned over like a page), passes test 4 as well.
What fails and what is only a note:
  FAIL  different sheet sizes; a part count other than the expected one; cut parts that overlap or leave the sheet; a cut
        part with no print under it (unless --allow-blank); FAR_FAIL sq mm or more of solid print that is clear of every
        part's own rectangle by more than the bleed, at the sheet edge as much as anywhere else; a printed part whose
        print stops short of its cut line along one side but runs past it on the other three (the print has slid off
        it: _bare_edge); a BACK that only fits when it is not mirrored.
  NOTE  print just off the cut shapes but inside the parts' own rectangles (openings, cut-off corners, extra bleed); small
        marks away from the parts; and everything the check could not judge (no quantity given, a DXF with no sheet
        frame, parts too narrow, a BACK that fits both ways).  Within EDGE_BAND of the sheet edge two kinds of print are
        not judged, and their area is shown on each face's line of the report: thin lines (about 1 mm wide or less: the
        sheet frame, which every paired print and cut file carries since 6 Oct 2026, and hollow corner marks; thin lines
        are dropped anywhere on the sheet) and solid marks that run no further than MARK_MAX in a straight line (camera
        dots).  Any other solid print there is judged like print anywhere else.
    python -m nest.paircheck --print FRONT.pdf [--back BACK.pdf] --cut CUT.pdf|CUT.dxf [--qty N [--spares M]]
                             [--bleed MM] [--allow-blank] [--page N] [--json]
    python -m nest.paircheck --sheet FRONT[,BACK],CUT --sheet FRONT2[,BACK2],CUT2 --qty N [--spares M]    (a job: totals)
Exit code 0 = pass.  1 = mismatch: do not print or cut with these files.  2 = not checked: a file is missing or cannot be
read (or the command was typed wrongly).  3 = not checked: this computer cannot run the check (a Python package or a PDF
renderer is missing, or the check itself broke).  Only 0 is a pass.
numpy and Pillow are loaded when a check first needs them, never when this module is imported: importing it works on a
computer without them, and the nesting server never needs them.
Cut lines are read as vectors (PDF drawing commands / DXF entities); the print is drawn to pixels (about 2 per mm) in a
temporary folder that is removed afterwards.  Nothing is written to, or next to, the input files.
What this check cannot see: it compares outlines with ink, never the artwork itself, so a white-background design shows
no slide.  A whole layout moved by less than about bleed + INK_TOL passes (on a 3 mm bleed: 3.5 to 4 mm on an 8-part
sheet, 2 to 3.5 mm on the 36-part KIVARI sheet; FAR_FAIL is an area, so long outer edges fail sooner), and up to that
point the trailing cut lines can show up to about 1 mm of bare board.  Where parts sit closer together than twice
(bleed + INK_TOL) their allowed bands join up, so print that has moved inside such a block is caught where it leaves the
block's outer edge, where it leaves a part with no print at all, or by a bare edge, and a bare edge is seen only while the
print still reaches within SLIDE_DEPTH of the cut line: one part's print slid further than about bleed + SLIDE_DEPTH into
its neighbours passes, and so does a whole layout slid that far towards a sheet edge that its parts sit within about 6 mm
of (PS Nest keeps 10 mm: engine edge).  The bare-edge test needs print running to the cut line on the other three sides,
so it says nothing for white-bordered designs, partly printed shaped ends or parts too small to judge; and a design with
a white band from about INK_TOL to SLIDE_DEPTH deep along one side only, bled on the other three, fails as slid.  A sheet
frame wider than about 1 mm inside the page, or a solid edge mark that runs further than MARK_MAX, is judged like print.
"""
import argparse, importlib, importlib.util, json, math, os, shutil, subprocess, sys, tempfile, traceback

from . import geom, importers, pdfcut

MM = 72 / 25.4
SIZE_TOL = 1.0          # mm: sheet sizes further apart than this do not agree
INK_TOL = 1.5           # mm: slack on top of the bleed band (drawing and placement)
EDGE_BAND = 12.0        # mm: the sheet edge, where the sheet frame and camera dots are drawn
MARK_MAX = 8.0          # mm: in the edge band, a closed cut shape no bigger than this is a camera dot (5 +/- 1 mm), not a part,
                        # and printed ink that runs no further than this in a straight line, across or up, is a camera dot too
STRAY_MIN = 100.0       # mm2: less off-part ink than this on the whole sheet (a 10 x 10 mm patch) is not worth a note
FAR_FAIL = 400.0        # mm2: this much solid print clear of every part (a 20 x 20 mm patch) fails the face.  It is more than
                        # twice a full set of six 6 mm camera dots (170 mm2), so registration marks drawn in from the sheet
                        # edge never fail a sheet on their own, while one sign printed in the wrong place is thousands of mm2.
FAR_NOTE = 10.0         # mm2: less print than this away from the parts is not mentioned at all
BLANK = 0.0005          # a part whose middle is inked on less than this share of its area has no print under it
SLIDE_DEPTH = 6.0       # mm: a part's print that stops short of its cut line along one side, but is there within this
EDGE_EMPTY = 0.2        # distance of it, has slid off the part (see _bare_edge).  A strip along the cut line is bare when no
EDGE_FULL = 0.8         # more than EDGE_EMPTY of it is inked, and printed when at least EDGE_FULL is
WHITE = 243             # a pixel with every channel above this is bare board
PX_PER_MM, MAX_PIXELS = 2.0, 16_000_000      # drawing scale, lowered for very large pages so memory stays small
_DXF_TYPES = {'LINE', 'ARC', 'CIRCLE', 'ELLIPSE', 'SPLINE', 'LWPOLYLINE', 'POLYLINE'}
_PAINT = ('S', 's', 'f', 'F', 'f*', 'B', 'B*', 'b', 'b*')      # PDF operators that draw the current path
_PACKAGE = {'PIL': 'Pillow', 'fitz': 'PyMuPDF'}                # module name -> the name a person installs


class NotChecked(Exception):
    """The check did not finish, so there is no verdict: never a pass.  Always one of the two kinds below."""


class Unreadable(NotChecked):
    """An input file is missing or cannot be read (exit code 2)."""


class NotRun(NotChecked):
    """This computer cannot run the check: a Python package or a PDF renderer is missing (exit code 3)."""


def _missing(names):
    names = [_PACKAGE.get(n, n) for n in names]
    return NotRun(f'The check did not run because this computer does not have the Python package{"s" if len(names) > 1 else ""} '
                  f'{" and ".join(names)} (nothing was compared, so this is not a pass).')


def _libs():
    """-> (numpy, PIL.Image, PIL.ImageDraw, PIL.ImageFilter), loaded here on first use.  NotRun names whichever is missing."""
    missing = []
    try: import numpy
    except ImportError: missing.append('numpy')
    try: from PIL import Image, ImageDraw, ImageFilter
    except ImportError: missing.append('PIL')
    if missing: raise _missing(missing)
    return numpy, Image, ImageDraw, ImageFilter


def _need(module):
    """Import a package a file reader needs (pypdf, ezdxf); NotRun names the package that is really missing."""
    try: return importlib.import_module(module)
    except ImportError as e: raise _missing([(e.name or module).split('.')[0]]) from None


def _size(wh, digits=0): return f'{wh[0]:.{digits}f} x {wh[1]:.{digits}f}'
def _area(mm2): return f'{mm2 / 100:,.0f} sq cm' if mm2 >= 100 else f'{mm2:.0f} sq mm'
def _name(path): return os.path.basename(path)


def _bad(m, allow_blank=False):
    """True for a face that fails: print far from every part, no part with print, (unless allowed) a blank part, or a
    part whose print stops short of its cut line along one side."""
    return m['stray_far_mm2'] >= FAR_FAIL or not m['with_print'] or bool(m['blank'] and not allow_blank) or bool(m['bare_edge'])


# ------------------------------------------------------------------ reading PDFs
def _pdf_page(path, index, what='PDF'):
    """-> (document, page with any /Rotate baked in, pages in the file, index used, (x0, y0, w, h) of the page in mm,
    mm per PDF unit).  A one-page PDF always gives its only page; `index` (0 = first) picks from a longer one."""
    pypdf = _need('pypdf')
    if not os.path.isfile(path): raise Unreadable(f'The {what} file "{path}" was not found.')
    try:
        reader = pypdf.PdfReader(path)
        if reader.is_encrypted and not reader.decrypt(''): raise ValueError('it is password-protected')
        n = len(reader.pages); i = index if n > 1 else 0
        if not 0 <= i < n: raise ValueError(f'it has {n} page(s), so there is no page index {index}')
        doc = pypdf.PdfWriter(); page = doc.add_page(reader.pages[i])
        if (page.rotation or 0) % 360: page.transfer_rotation_to_content()
        k = float(page.get('/UserUnit', 1) or 1) / MM
        b = page.mediabox
        box = (float(b.left) * k, float(b.bottom) * k, float(b.width) * k, float(b.height) * k)
    except Exception as e:
        raise Unreadable(f'"{_name(path)}" could not be read as a PDF: {e}.')
    return doc, page, n, i, box, k


def _pdf_paths(doc, contents, resources, ctm, out, depth=0):
    """Every painted subpath of a content stream, forms included, as (closed, segments) in the units of `ctm`.
    Any colour counts: workshop cut PDFs use a CutContour spot, plain black or magenta strokes alike."""
    ContentStream = _need('pypdf.generic').ContentStream
    stack, path, cur, start = [], [], None, None
    for operands, op in ContentStream(contents, doc).operations:
        o = op.decode('latin-1') if isinstance(op, bytes) else op
        v = [float(x) for x in operands] if o in ('cm', 'm', 'l', 'c', 'v', 'y', 're') else None
        if o == 'q': stack.append(ctm)
        elif o == 'Q': ctm = stack.pop() if stack else ctm
        elif o == 'cm': ctm = pdfcut._mul(tuple(v), ctm)
        elif o == 'm': start = cur = pdfcut._pt(ctm, v[0], v[1]); path.append([('M',) + cur])
        elif o == 'l' and path: cur = pdfcut._pt(ctm, v[0], v[1]); path[-1].append(('L',) + cur)
        elif o in ('c', 'v', 'y') and path:
            pts = [pdfcut._pt(ctm, v[i], v[i + 1]) for i in range(0, len(v), 2)]
            if o == 'v': pts.insert(0, cur)
            elif o == 'y': pts.append(pts[-1])
            cur = pts[2]; path[-1].append(('C',) + pts[0] + pts[1] + pts[2])
        elif o == 'h' and path: path[-1].append(('Z',)); cur = start
        elif o == 're':
            x, y, w, h = v
            c4 = [pdfcut._pt(ctm, *p) for p in ((x, y), (x + w, y), (x + w, y + h), (x, y + h))]
            path.append([('M',) + c4[0]] + [('L',) + p for p in c4[1:]] + [('Z',)]); start = cur = c4[0]
        elif o in _PAINT:
            for sp in path:         # a fill or a close-and-stroke closes the shape; a plain stroke only if it was drawn closed
                segs = [s for s in sp if s[0] != 'Z']
                if len(segs) > 1: out.append((o != 'S' or len(segs) != len(sp) or math.dist(segs[-1][-2:], segs[0][1:3]) <= 0.1, segs))
            path = []
        elif o == 'n': path = []                    # a clip path: nothing painted
        elif o == 'Do' and depth < 12:
            xo = None
            for r in resources:
                xs = pdfcut._resolve(pdfcut._resolve(r).get('/XObject')) if r is not None else None
                if xs is not None and operands[0] in xs: xo = pdfcut._resolve(xs[operands[0]]); break
            if xo is not None and xo.get('/Subtype') == '/Form':
                m = tuple(float(t) for t in xo.get('/Matrix', (1, 0, 0, 1, 0, 0)))
                _pdf_paths(doc, xo, [xo.get('/Resources')] + list(resources), pdfcut._mul(m, ctm), out, depth + 1)


# ------------------------------------------------------------------ reading the cut file
def read_cut(path, page=0):
    """Cut file (PDF or DXF) -> {'kind', 'method', 'pages', 'page_mm' (w, h) or None, 'loops', 'open', 'doubles'}.
    loops: closed shapes as polygons [(x, y)] in mm, y up; a PDF's are measured from the page's bottom-left corner,
    a DXF's are in the file's own coordinates.  open: lines that never close; doubles: shapes drawn twice."""
    ext = os.path.splitext(path)[1].lower()
    loops, n_open, pages, page_mm = [], 0, 1, None
    if ext == '.pdf':
        doc, pg, pages, _, (x0, y0, w, h), k = _pdf_page(path, page, 'cut')
        raw = []
        try:
            if pg.get_contents() is not None:
                _pdf_paths(doc, pg.get_contents(), [pg.get('/Resources')], (k, 0, 0, k, -x0, -y0), raw)
        except NotChecked: raise
        except Exception as e:
            raise Unreadable(f'The cut lines in "{_name(path)}" could not be read: {e}.')
        loops = [pdfcut.flatten_path(segs, 0.05) for closed, segs in raw if closed]; n_open = len(raw) - len(loops)
        page_mm, method = (w, h), 'vector paths read from the cut PDF (every painted closed path, any colour)'
    elif ext == '.dxf':
        ezdxf = _need('ezdxf')
        if not os.path.isfile(path): raise Unreadable(f'The cut file "{path}" was not found.')
        try:
            from ezdxf import disassemble, path as ezpath, units
            dxf = ezdxf.readfile(path)
            k = units.conversion_factor(dxf.units, units.MM) if dxf.units else 1.0
            chains = []
            for e in disassemble.recursive_decompose(dxf.modelspace()):          # blocks are opened up in place
                if e.dxftype() not in _DXF_TYPES: continue
                for sp in ezpath.make_path(e).sub_paths():
                    pts = [(p.x * k, p.y * k) for p in sp.flattening(0.05)]
                    if len(pts) > 3 and math.dist(pts[0], pts[-1]) <= importers.JOIN_TOL: loops.append(pts[:-1])
                    elif len(pts) >= 2: chains.append([(x, y, 0.0) for x, y in pts])
        except Exception as e:
            raise Unreadable(f'"{_name(path)}" could not be read as a DXF: {e}.')
        joined, left = importers.join_chains(chains)                             # loose lines and arcs, end to end
        loops += [[(x, y) for x, y, _ in lp] for lp in joined]; n_open = len(left)
        method = 'vector entities read from the DXF with ezdxf'
    else:
        raise Unreadable(f'The cut file "{_name(path)}" must be a PDF or a DXF.')
    seen, unique, doubles = set(), [], 0
    for p in loops:
        if len(p) < 3 or abs(geom.signed_area(p)) < 1.0: continue                # a line or a speck, not a shape
        key = tuple(round(v, 1) for v in geom.bbox_poly(p)) + (round(abs(geom.signed_area(p))),)
        if key in seen: doubles += 1; continue
        seen.add(key); unique.append(geom.simplify(p, 0.02) if len(p) > 8 else p)
    return {'kind': ext[1:], 'method': method, 'pages': pages, 'page_mm': page_mm, 'loops': unique, 'open': n_open, 'doubles': doubles}


def cut_layout(cut_path, page=0, print_mm=None):
    """Read a cut file and sort its closed shapes into the sheet frame, camera dots, parts and holes.
    -> the read_cut dict plus 'sheet' (w, h) mm, 'sheet_from' (which measurement that is), 'size_checked',
    'parts' [{'poly', 'holes', 'bbox'}] measured from the sheet's bottom-left corner, 'frame', 'marks', 'holes', 'nested'.
    Sheet size: a cut PDF's page; a DXF's outer frame rectangle; without a frame the extents of the cut shapes, or,
    when those differ from the print page (print_mm) but the shapes fit on it from the DXF's zero corner, the print
    page itself with size_checked False (PS Nest's own DXFs start at the sheet corner and may carry no frame)."""
    cut = read_cut(cut_path, page)
    loops, boxes, frame, checked = cut['loops'], [geom.bbox_poly(p) for p in cut['loops']], None, True
    for i, (p, b) in enumerate(zip(loops, boxes)):                               # the frame: a plain upright rectangle that
        w, h = b[2] - b[0], b[3] - b[1]                                          # holds every other shape, or is the PDF page
        if abs(geom.signed_area(p)) < 0.998 * w * h: continue
        holds_all = len(loops) > 1 and all(o[0] >= b[0] - 0.01 and o[1] >= b[1] - 0.01 and o[2] <= b[2] + 0.01 and o[3] <= b[3] + 0.01 for o in boxes)
        is_page = cut['page_mm'] and abs(w - cut['page_mm'][0]) <= SIZE_TOL and abs(h - cut['page_mm'][1]) <= SIZE_TOL
        if holds_all or is_page: frame = i; break
    rest = [p for i, p in enumerate(loops) if i != frame]
    if cut['kind'] == 'pdf':
        sheet, origin, source = cut['page_mm'], (0.0, 0.0), 'the page size of the cut PDF'
    elif frame is not None:
        b = boxes[frame]; sheet, origin, source = (b[2] - b[0], b[3] - b[1]), (b[0], b[1]), 'the outer frame rectangle drawn in the DXF'
    else:
        x0, y0, x1, y1 = [f(b[i] for b in boxes) for i, f in enumerate((min, min, max, max))] if boxes else (0.0, 0.0, 0.0, 0.0)
        sheet, origin, source = (x1 - x0, y1 - y0), (x0, y0), 'the overall extents of the cut shapes (the DXF has no sheet frame)'
        same = print_mm and abs(sheet[0] - print_mm[0]) <= SIZE_TOL and abs(sheet[1] - print_mm[1]) <= SIZE_TOL
        if print_mm and not same and x0 >= -SIZE_TOL and y0 >= -SIZE_TOL and x1 <= print_mm[0] + SIZE_TOL and y1 <= print_mm[1] + SIZE_TOL:
            sheet, origin, checked = tuple(print_mm), (0.0, 0.0), False
            source = 'the print page (the DXF has no sheet frame; its zero corner was taken as the sheet corner)'
    rest = [[(x - origin[0], y - origin[1]) for x, y in p] for p in rest]
    depth, parent = importers.classify_loops([[(x, y, 0.0) for x, y in p] for p in rest]) if rest else ([], [])
    parts, marks = [], 0
    for i, p in enumerate(rest):
        if depth[i]: continue                                                    # inside another shape: a hole, not a part
        b = geom.bbox_poly(p)
        if max(b[2] - b[0], b[3] - b[1]) <= MARK_MAX and min(b[0], b[1], sheet[0] - b[2], sheet[1] - b[3]) <= EDGE_BAND: marks += 1; continue
        parts.append({'poly': p, 'bbox': b, 'holes': [rest[j] for j in range(len(rest)) if parent[j] == i]})
    cut.update(sheet=sheet, sheet_from=source, size_checked=checked, parts=parts, frame=frame is not None, marks=marks,
               holes=sum(1 for d in depth if d == 1), nested=sum(1 for d in depth if d > 1))
    return cut


def _pt_seg(np, pts, poly):
    """Smallest distance from any of `pts` to the outline of `poly` (numpy arrays n x 2), in memory-safe slices."""
    a, ab = poly, np.roll(poly, -1, axis=0) - poly
    den = np.maximum((ab * ab).sum(1), 1e-18); best = math.inf
    for s in range(0, len(pts), max(1, 200_000 // len(poly))):
        d = pts[s:s + max(1, 200_000 // len(poly)), None, :] - a[None]
        t = np.clip((d * ab[None]).sum(2) / den[None], 0, 1)
        best = min(best, float(np.sqrt(((d - t[..., None] * ab[None]) ** 2).sum(2)).min()))
    return best


def _cross(np, p, q):
    """True when the outlines of two polygons properly cross (touching along an edge is not crossing)."""
    def side(a, b, c): return (b[:, None, 0] - a[:, None, 0]) * (c[None, :, 1] - a[:, None, 1]) - (b[:, None, 1] - a[:, None, 1]) * (c[None, :, 0] - a[:, None, 0])
    a, b, c, d = p, np.roll(p, -1, axis=0), q, np.roll(q, -1, axis=0)
    return bool(((side(a, b, c) * side(a, b, d) < -1e-9) & ((side(c, d, a) * side(c, d, b)).T < -1e-9)).any())


def min_gap(parts):
    """-> (smallest distance in mm between the outlines of two parts, or None for fewer than two; pairs that overlap)."""
    np = _libs()[0]
    arr = [np.asarray(p['poly'], float) for p in parts]
    def box_gap(a, b): return math.hypot(max(b[0] - a[2], a[0] - b[2], 0), max(b[1] - a[3], a[1] - b[3], 0))
    pairs = sorted((box_gap(parts[i]['bbox'], parts[j]['bbox']), i, j) for i in range(len(parts)) for j in range(i))
    best, crossing = None, 0
    for g, i, j in pairs:
        if best is not None and g > best: break                                  # boxes further apart than the best found
        if g == 0 and len(arr[i]) * len(arr[j]) <= 4_000_000 and _cross(np, arr[i], arr[j]): crossing += 1; best = 0.0; continue
        d = min(_pt_seg(np, arr[i], arr[j]), _pt_seg(np, arr[j], arr[i]))
        best = d if best is None else min(best, d)
    return best, crossing


# ------------------------------------------------------------------ drawing the print page
def _render_fitz(path, page, W, H, tmp):
    import fitz
    with fitz.open(path) as doc:
        pg = doc[page]; pg.set_cropbox(pg.mediabox)
        pix = pg.get_pixmap(matrix=fitz.Matrix(W / pg.rect.width, H / pg.rect.height), alpha=False)
        return _libs()[1].frombytes('RGB', (pix.width, pix.height), pix.samples)


def _render_pdftoppm(path, page, W, H, tmp):
    out = os.path.join(tmp, 'page')
    subprocess.run(['pdftoppm', '-f', str(page + 1), '-l', str(page + 1), '-scale-to-x', str(W), '-scale-to-y', str(H),
                    '-png', '-singlefile', path, out], check=True, capture_output=True, timeout=900)
    return _libs()[1].open(out + '.png')


def _render_sips(path, page, W, H, tmp):
    src, out = path, os.path.join(tmp, 'page.png')
    if page:                                                                     # sips draws the first page only
        pypdf = _need('pypdf')
        w = pypdf.PdfWriter(); w.add_page(pypdf.PdfReader(path).pages[page]); src = os.path.join(tmp, 'one.pdf'); w.write(src)
    subprocess.run(['sips', '-s', 'format', 'png', '-z', str(H), str(W), src, '--out', out], check=True, capture_output=True, timeout=900)
    return _libs()[1].open(out)


# (name, is it on this computer?, draw(path, page index, width px, height px, temp folder) -> PIL image), tried in order.
RENDERERS = [('fitz', lambda: importlib.util.find_spec('fitz') is not None, _render_fitz),
             ('pdftoppm', lambda: shutil.which('pdftoppm') is not None, _render_pdftoppm),
             ('sips', lambda: shutil.which('sips') is not None, _render_sips)]


def find_renderer(name=None):
    """The first renderer this computer has (or the one called `name`): (name, function), or None."""
    return next(((n, fn) for n, there, fn in RENDERERS if (name is None or n == name) and there()), None)


def render_ink(path, page, w_mm, h_mm, renderer=None):
    """Draw one PDF page -> (bool array, True where anything is printed, row 0 = top of the page; px per mm; renderer)."""
    np, Image = _libs()[:2]
    found = find_renderer(renderer)
    if not found:
        raise NotRun('The check did not run because this computer has nothing to draw a PDF with (it needs PyMuPDF, pdftoppm or '
                     'macOS sips), so the print could not be laid over the cut file (nothing was compared, so this is not a pass).')
    name, fn = found; ppm = min(PX_PER_MM, math.sqrt(MAX_PIXELS / (w_mm * h_mm)))
    W, H = max(1, round(w_mm * ppm)), max(1, round(h_mm * ppm))
    with tempfile.TemporaryDirectory(prefix='paircheck-') as tmp:
        try:
            img = fn(path, page, W, H, tmp)
            if img.mode != 'RGB':                                                # nothing drawn (transparent) is bare board
                rgba = img.convert('RGBA'); img = Image.new('RGB', rgba.size, (255, 255, 255)); img.paste(rgba, mask=rgba.split()[3])
            if img.size != (W, H): img = img.resize((W, H))
            ink = np.asarray(img).min(axis=2) <= WHITE
        except NotChecked: raise
        except Exception as e:
            raise Unreadable(f'"{_name(path)}" could not be drawn with {name}: {e}.')
    return ink, ppm, name


# ------------------------------------------------------------------ print over cut
def _moved(np, a, dr, dc):
    """a moved dr rows down and dc columns right; what moves in from outside is bare."""
    out = np.zeros_like(a); H, W = a.shape
    out[max(dr, 0):H + min(dr, 0), max(dc, 0):W + min(dc, 0)] = a[max(-dr, 0):H + min(-dr, 0), max(-dc, 0):W + min(-dc, 0)]
    return out


def _long_runs(np, m, n):
    """The pixels of m that lie on an unbroken straight run, across or up the page, of at least n pixels."""
    out = np.zeros_like(m)
    for ax in (0, 1):
        e, k = np.moveaxis(m.copy(), ax, 0), 1
        while k < n:                                                             # shrink: e[i] = m[i] and m[i + 1] ... m[i + k]
            s = min(k, n - k); e[:-s] &= e[s:].copy(); e[-s:] = False; k += s
        k = 1
        while k < n:                                                             # grow back over the whole run
            s = min(k, n - k); e[s:] |= e[:-s].copy(); k += s
        out |= np.moveaxis(e, 0, ax)
    return out


def _bare_edge(np, shape, ink, k, q):
    """The side ('left', 'right', 'top' or 'bottom' as the cut file is drawn) along which a part's print stops short of
    its cut line, or None.  shape: the part's outline filled; ink: the print over the same pixels; k, q: (rows, columns)
    in pixels for INK_TOL and SLIDE_DEPTH.  A side is bare when its outer INK_TOL strip inside the cut line carries at
    most EDGE_EMPTY of ink, while at least EDGE_FULL of the lines running in from that side meet print within
    SLIDE_DEPTH, and the strips along the other three sides carry at least EDGE_FULL: the print runs to the cut line
    everywhere else, and is right there a few mm in.  That is print that has slid off the part (or no bleed on one side);
    a sign with a white border all round, or a white band along one side deeper than about SLIDE_DEPTH, is not bare."""
    sides, share, reach = {'left': (0, 1, 1), 'right': (0, -1, 1), 'top': (1, 0, 0), 'bottom': (-1, 0, 0)}, {}, {}
    for side, (dr, dc, along) in sides.items():
        kk, qq = (k[1], q[1]) if dc else (k[0], q[0])
        edge = shape & ~_moved(np, shape, dr * kk, dc * kk)                          # within INK_TOL of the cut line on this side
        deeper = shape & ~_moved(np, shape, dr * qq, dc * qq) & ~edge                # INK_TOL to SLIDE_DEPTH in
        n, lines = int(edge.sum()), deeper.any(axis=along)
        if n < 20 or lines.sum() < 20: return None                               # too small to tell
        share[side] = float((ink & edge).sum()) / n
        reach[side] = float((ink & deeper).any(axis=along)[lines].mean())
    for side in sides:
        if share[side] <= EDGE_EMPTY and reach[side] >= EDGE_FULL and all(share[o] >= EDGE_FULL for o in sides if o != side): return side
    return None


def overlay(ink, parts, sheet, bleed_mm):
    """Lay the parts over the drawn page.  -> {'with_print', 'blank', 'blank_parts', 'not_judged', 'bare_edge',
    'bare_parts', 'stray_mm2', 'stray_box_mm', 'stray_far_mm2', 'stray_far_box_mm', 'edge_marks_mm2', 'cover_median'}.
    stray: solid ink further out from the cut shapes than bleed + INK_TOL; lines about 1 mm wide or less never count,
    and within EDGE_BAND of the sheet edge neither does a mark that runs no further than MARK_MAX in a straight line
    across or up (a camera dot).  Their area is edge_marks_mm2.  stray_far: the share of stray that is also outside every
    part's own bounding rectangle grown by the same allowance; this is the ink that fails a face (FAR_FAIL), the rest is
    only reported.  Ink on a part is judged leniently: its middle (the part less the same band, less its holes) only has
    to carry some ink.  blank_parts: indexes into `parts` of those with none.  bare_parts: [index, side] of printed parts
    whose print stops short of the cut line along one side (_bare_edge)."""
    np, Image, ImageDraw, ImageFilter = _libs()
    H, W = ink.shape; sx, sy = W / sheet[0], H / sheet[1]; a = bleed_mm + INK_TOL
    def px(poly, ox=0, oy=0): return [(x * sx - ox, (sheet[1] - y) * sy - oy) for x, y in poly]
    band = max(1, round(a * (sx + sy)))                                          # stroke width: the allowance on both sides
    k, q = (max(1, round(INK_TOL * sy)), max(1, round(INK_TOL * sx))), (round(SLIDE_DEPTH * sy), round(SLIDE_DEPTH * sx))
    allowed, near = Image.new('L', (W, H), 0), Image.new('L', (W, H), 0); draw, dnear = ImageDraw.Draw(allowed), ImageDraw.Draw(near)
    cover, bare = [], []
    for i, p in enumerate(parts):
        xy = px(p['poly'])
        draw.polygon(xy, fill=255); draw.line(xy + xy[:2], fill=255, width=band, joint='curve')
        x0, y0, x1, y1 = p['bbox']
        dnear.rectangle([(x0 - a) * sx, (sheet[1] - y1 - a) * sy, (x1 + a) * sx, (sheet[1] - y0 + a) * sy], fill=255)
        c0, r0, c1, r1 = max(0, int(x0 * sx)), max(0, int((sheet[1] - y1) * sy)), min(W, math.ceil(x1 * sx)), min(H, math.ceil((sheet[1] - y0) * sy))
        if c1 <= c0 or r1 <= r0: cover.append(None); continue                    # off the page
        core = Image.new('L', (c1 - c0, r1 - r0), 0); dc = ImageDraw.Draw(core); loc = px(p['poly'], c0, r0)
        dc.polygon(loc, fill=255); shape = np.asarray(core) > 0
        for hole in p['holes']: dc.polygon(px(hole, c0, r0), fill=0)
        dc.line(loc + loc[:2], fill=0, width=band, joint='curve')
        m = np.asarray(core) > 0; n = int(m.sum()); crop = ink[r0:r1, c0:c1]
        cover.append(float((crop & m).sum()) / n if n >= 20 else None)          # too thin to have a middle: not judged
        on_page = x0 >= 0 and y0 >= 0 and x1 <= sheet[0] and y1 <= sheet[1]
        if cover[-1] is not None and cover[-1] >= BLANK and on_page and (side := _bare_edge(np, shape, crop, k, q)): bare.append([i, side])
    stray = ink & (np.asarray(allowed) == 0)
    grown = Image.fromarray(np.pad(stray, 1).astype(np.uint8) * 255).filter(ImageFilter.MinFilter(3)).filter(ImageFilter.MaxFilter(3))
    solid = (np.asarray(grown) > 0)[1:-1, 1:-1]                                  # thin lines gone; beyond the page counts as bare
    ex, ey = max(1, round(EDGE_BAND * sx)), max(1, round(EDGE_BAND * sy))
    edge = np.ones_like(stray); edge[ey:H - ey, ex:W - ex] = False
    if (solid & edge).any(): solid &= ~edge | _long_runs(np, solid, int(MARK_MAX * max(sx, sy)) + 1)   # camera dots at the edge
    far = solid & (np.asarray(near) == 0)
    def area(mask): return round(float(mask.sum()) / (sx * sy), 1)
    def box(mask):                                                               # [left, bottom, right, top] in mm, or None
        if not mask.any(): return None
        rows, cols = np.flatnonzero(mask.any(axis=1)), np.flatnonzero(mask.any(axis=0))
        return [round(cols[0] / sx), round(sheet[1] - (rows[-1] + 1) / sy), round((cols[-1] + 1) / sx), round(sheet[1] - rows[0] / sy)]
    judged = [c for c in cover if c is not None]
    blank = [i for i, c in enumerate(cover) if c is not None and c < BLANK]
    return {'with_print': len(judged) - len(blank), 'blank': len(blank), 'blank_parts': blank, 'not_judged': len(cover) - len(judged),
            'bare_edge': len(bare), 'bare_parts': bare,
            'stray_mm2': area(solid), 'stray_box_mm': box(solid), 'stray_far_mm2': area(far), 'stray_far_box_mm': box(far),
            'edge_marks_mm2': area(stray & edge & ~solid), 'cover_median': round(float(np.median(judged)), 4) if judged else None}


def _face(name, path, page, lay, size_ok, front_mm, bleed_mm, renderer, allow_blank, problems, warnings):
    """Check one print face against the cut layout; BACK is mirrored left-to-right first.  -> the face's dict."""
    doc, pg, pages, idx, (_, _, w, h), _k = _pdf_page(path, page, 'print')
    res = {'file': path, 'page_mm': [round(w, 2), round(h, 2)], 'page_index': idx, 'mirrored': name == 'BACK', 'compared': False}
    if pages > 1: warnings.append(f'{name}: "{_name(path)}" has {pages} pages; only page {idx + 1} was checked.')
    if name == 'BACK' and (abs(w - front_mm[0]) > SIZE_TOL or abs(h - front_mm[1]) > SIZE_TOL):
        problems.append(f'The BACK page is {_size((w, h))} mm but the FRONT page is {_size(front_mm)} mm. Both faces must be the same size.')
        res['why_not'] = 'the BACK and FRONT pages are different sizes'; return res
    if not size_ok or not lay['parts']:
        res['why_not'] = 'the sheet sizes differ' if not size_ok else 'the cut file has no parts'; return res
    parts, sheet = lay['parts'], lay['sheet']; n = len(parts)
    ink, ppm, used = render_ink(path, idx, w, h, renderer)
    m = overlay(ink[:, ::-1] if name == 'BACK' else ink, parts, sheet, bleed_mm)
    res.update(m, compared=True, renderer=used, px_per_mm=round(ppm, 3))
    if name == 'BACK':
        as_saved = _bad(overlay(ink, parts, sheet, bleed_mm), allow_blank)       # the page as it was saved, not turned over
        if _bad(m, allow_blank) and not as_saved:
            problems.append('BACK: this page lines up with the cut file only when it is NOT mirrored. The board is turned over left-to-right '
                            'before the back is printed, so the BACK layout must be the mirror image of the FRONT. As saved it would print in the wrong places.')
            res['matches_only_unmirrored'] = True; return res
        if not _bad(m, allow_blank) and not as_saved:
            warnings.append('BACK: this page fits the cut file both mirrored and not mirrored, because the parts sit the same from the left as from '
                            'the right. This check cannot tell whether the BACK was saved the right way round; that has to be checked by eye.')
            res['fits_both_ways'] = True
    far, near = m['stray_far_mm2'], round(m['stray_mm2'] - m['stray_far_mm2'], 1)
    if not m['with_print']:
        why = ('the page is blank, the wrong page or file was given, or the print sits somewhere else on the sheet' if m['blank']
               else 'they are all too narrow, or off the page, to tell')
        problems.append(f'{name}: not one of the {n} cut parts has print under it ({why}).')
    elif m['blank']:
        b, one = parts[m['blank_parts'][0]]['bbox'], m['blank'] == 1
        text = (f'{name}: {m["blank"]} of the {n} cut parts {"has" if one else "have"} no print under {"it" if one else "them"} '
                f'({"it" if one else "the first"} starts {b[0]:.0f} mm from the left and {b[1]:.0f} mm from the bottom of the cut file)')
        if allow_blank: warnings.append(text + '. Accepted because --allow-blank was given.')
        else: problems.append(text + f' and would be cut from blank board. The {name} print layout is not the layout in the cut file.')
    if m['bare_edge']:
        i, side = m['bare_parts'][0]; b, one = parts[i]['bbox'], m['bare_edge'] == 1
        problems.append(f'{name}: {m["bare_edge"]} of the {n} cut parts {"has" if one else "have"} a bare edge: the print stops short of the cut line '
                        f'along one side and runs past it on the other three ({"it" if one else "the first"} starts {b[0]:.0f} mm from the left and '
                        f'{b[1]:.0f} mm from the bottom of the cut file; its {side} side, as the cut file is drawn). The print has slid off '
                        f'{"that part" if one else "those parts"}, or the artwork has no bleed on that side: bare board would show along the edge.')
    if far >= FAR_FAIL:
        x0, y0, x1, y1 = m['stray_far_box_mm']
        problems.append(f'{name}: about {_area(far)} of print lies away from every cut part (more than {bleed_mm + INK_TOL:g} mm outside the rectangle '
                        f'around the nearest part), between {x0} and {x1} mm from the left and {y0} and {y1} mm from the bottom of the cut file. '
                        f'The {name} print layout is not the layout in the cut file. (If this artwork really has more than {bleed_mm:g} mm of bleed, '
                        'run the check again with --bleed.)')
    elif far >= FAR_NOTE:
        warnings.append(f'{name}: about {_area(far)} of print lies away from every cut part. That is small enough to be marks, not a sign in the '
                        f'wrong place ({_area(FAR_FAIL)} or more fails).')
    if near >= STRAY_MIN:
        warnings.append(f'{name}: about {_area(near)} of print falls outside the cut shapes but inside the parts\' own rectangles (openings, '
                        'cut-off corners, extra bleed). Not a mismatch: that print ends up on the offcut.')
    if m['not_judged'] and m['with_print']:
        warnings.append(f'{name}: {m["not_judged"]} of the {n} cut parts are too narrow (or off the page) to tell whether they are printed.')
    return res


def _size_problem(pw, ph, lay):
    """The sentence for a print page and a cut sheet that are not the same size: both sizes and the difference."""
    sw, sh = lay['sheet']; d = 0 if max(abs(pw - sw), abs(ph - sh)) >= 10 else 1
    if lay['kind'] == 'dxf' and not lay['frame']:
        return (f'The print page is {_size((pw, ph), d)} mm, but the cut file has no sheet frame and its cut shapes span {_size((sw, sh), d)} mm '
                'and do not sit on that page measured from the drawing\'s zero corner. The two cannot be laid over each other: use the cut file '
                'that was made with this print, or add the sheet frame to the cut file.')
    diff = ' and '.join(f'{abs(a - b):.{d}f} mm {more if a > b else less}' for a, b, more, less in
                        ((pw, sw, 'wider', 'narrower'), (ph, sh, 'taller', 'shorter')) if abs(a - b) > SIZE_TOL)
    turned = ' It is the same size turned a quarter turn: one of the two files was saved sideways.' if abs(pw - sh) <= SIZE_TOL and abs(ph - sw) <= SIZE_TOL else ''
    return (f'The print page is {_size((pw, ph), d)} mm but the cut file is for a {_size((sw, sh), d)} mm sheet: the print is {diff}.{turned} '
            'These two files do not belong together; the print cannot be cut with this cut file.')


def _sheet(print_path, cut_path, back_path, bleed_mm, page, renderer, allow_blank):
    """One sheet, everything except the quantity: the check_pair dict without 'ok', 'qty', 'spares' and 'expected'."""
    _libs()                                                                      # stop before any work when numpy or Pillow is missing
    problems, warnings = [], []
    _, _, _, _, (_, _, pw, ph), _ = _pdf_page(print_path, page, 'print')
    lay = cut_layout(cut_path, page, (pw, ph)); parts, sheet = lay['parts'], lay['sheet']
    size_ok = abs(pw - sheet[0]) <= SIZE_TOL and abs(ph - sheet[1]) <= SIZE_TOL
    if not size_ok: problems.append(_size_problem(pw, ph, lay))
    elif not lay['size_checked']:
        warnings.append('The cut file has no sheet frame, so the sheet size could not be checked. Its shapes fit on the print page when both start from the same bottom-left corner.')
    if lay['pages'] > 1: warnings.append(f'"{_name(cut_path)}" has {lay["pages"]} pages; only one page was checked.')
    if not parts: problems.append('No closed cut shapes were found in the cut file, so there is nothing to cut.')
    gap, crossing = min_gap(parts)
    if crossing: problems.append(f'{crossing} pair(s) of cut parts overlap each other.')
    elif gap is not None and gap < 0.05: warnings.append('Some cut parts touch each other (no gap between them).')
    off = sum(1 for p in parts if p['bbox'][0] < -SIZE_TOL or p['bbox'][1] < -SIZE_TOL or p['bbox'][2] > sheet[0] + SIZE_TOL or p['bbox'][3] > sheet[1] + SIZE_TOL)
    if off: problems.append(f'{off} cut part(s) reach past the edge of the {_size(sheet)} mm sheet.')
    if lay['open']: warnings.append(f'{lay["open"]} cut line(s) are not closed shapes and were not counted.')
    if lay['doubles']: warnings.append(f'{lay["doubles"]} cut shape(s) are drawn twice on top of each other; each was counted once.')
    if lay['nested']: warnings.append(f'{lay["nested"]} shape(s) sit inside the hole of another part and were not counted as parts.')
    front = _face('FRONT', print_path, page, lay, size_ok, (pw, ph), bleed_mm, renderer, allow_blank, problems, warnings)
    back = _face('BACK', back_path, page, lay, size_ok, (pw, ph), bleed_mm, renderer, allow_blank, problems, warnings) if back_path else None
    return {'problems': problems, 'warnings': warnings, 'files': {'print': print_path, 'back': back_path, 'cut': cut_path},
            'sheet_mm': {'print': [round(pw, 2), round(ph, 2)], 'cut': [round(sheet[0], 2), round(sheet[1], 2)], 'cut_size_from': lay['sheet_from'], 'agree': size_ok},
            'cut_method': lay['method'], 'cut_parts': len(parts), 'min_gap_mm': None if gap is None else round(gap, 2),
            'not_parts': {'sheet_frame': int(lay['frame']), 'camera_dots': lay['marks'], 'holes': lay['holes'], 'open_lines': lay['open']},
            'parts': [{'bbox_mm': [round(v, 2) for v in p['bbox']], 'holes': len(p['holes'])} for p in parts],
            'bleed_mm': bleed_mm, 'front': front, 'back': back}


def _expected(qty, spares):
    return f'{qty + spares} are expected ({qty} ordered + {spares} spare{"" if spares == 1 else "s"})' if spares else f'the order is for {qty}'


def _count(res, found, n, qty, spares):
    """Judge the number of cut parts against the expected quantity (ordered + spares) and set 'ok', in place."""
    if qty is None:
        spares = 0
        res['warnings'].append('No expected quantity was given, so the number of parts was not checked against the order.')
    elif n and n != qty + spares:                   # no parts at all is already a problem of its own
        res['problems'].append(f'{found} but {_expected(qty, spares)}: {abs(n - qty - spares)} too {"many" if n > qty + spares else "few"}.')
    res.update(ok=not res['problems'], checked=True, qty=qty, spares=spares, expected=None if qty is None else qty + spares)
    return res


def check_pair(print_path, cut_path, back_path=None, qty=None, bleed_mm=3.0, page=0, renderer=None, spares=0, allow_blank=False):
    """Check one sheet: a print page (and optionally its BACK page) against its cut file.  -> dict with 'ok', 'problems'
    and 'warnings' (plain sentences; warnings are notes that do not fail), 'sheet_mm', 'cut_parts', 'qty', 'spares',
    'expected', 'parts', 'min_gap_mm', 'front', 'back'.  qty + spares is the number of parts the cut file must hold
    (not judged when qty is None).  page: index (0 = first) used in any PDF with more than one page.  renderer: a
    name from RENDERERS; default the first one available.  allow_blank: cut parts without print are a note, not a
    failure, as long as some part is printed.  Raises Unreadable (a file) or NotRun (this computer): no verdict."""
    res = _sheet(print_path, cut_path, back_path, bleed_mm, page, renderer, allow_blank)
    return _count(res, f'The cut file has {res["cut_parts"]} parts', res['cut_parts'], qty, spares)


def check_job(sheets, qty=None, bleed_mm=3.0, page=0, renderer=None, spares=0, allow_blank=False):
    """Several sheets of one job: sheets = [(print, back or None, cut)], each checked like check_pair; qty + spares is
    the job total.  One sheet that fails, or cannot be checked, decides the whole job."""
    if not sheets: raise Unreadable('No sheets were given to check.')
    results = [_sheet(p, c, b, bleed_mm, page, renderer, allow_blank) for p, b, c in sheets]
    for r in results: r.update(ok=not r['problems'], checked=True, qty=None, spares=0, expected=None)
    total = sum(r['cut_parts'] for r in results)
    res = {'problems': [f'Sheet {i} ({_name(r["files"]["cut"])}): {t}' for i, r in enumerate(results, 1) for t in r['problems']],
           'warnings': [f'Sheet {i} ({_name(r["files"]["cut"])}): {t}' for i, r in enumerate(results, 1) for t in r['warnings']],
           'cut_parts': total, 'sheets': results}
    return _count(res, f'The cut files hold {" + ".join(str(r["cut_parts"]) for r in results)} = {total} parts', total, qty, spares)


# ------------------------------------------------------------------ command line
def summary(res):
    """The result of check_pair or check_job as plain lines: what was compared, the problems, the notes, the verdict last."""
    out, how = [], None
    def expected(r):
        if r['expected'] is None: return ''
        split = f' = {r["qty"]} ordered + {r["spares"]} spare{"" if r["spares"] == 1 else "s"}' if r['spares'] else ''
        return f'; expected {r["expected"]}{split}: {"same" if r["cut_parts"] == r["expected"] else "DIFFERENT"}'
    for i, r in enumerate(res.get('sheets', [res]), 1):
        s, f, left_out = r['sheet_mm'], r['files'], r['not_parts']
        out.append(f'Sheet {i}: {_name(f["print"])}' + (f' + {_name(f["back"])}' if f['back'] else '') + f'  with  {_name(f["cut"])}')
        out.append(f'  Sheet size: print {_size(s["print"])} mm, cut {_size(s["cut"])} mm (from {s["cut_size_from"]}): {"same" if s["agree"] else "DIFFERENT"}')
        gap = 'n/a' if r['min_gap_mm'] is None else f'{r["min_gap_mm"]:.1f} mm apart'
        out.append(f'  Parts to cut: {r["cut_parts"]}{expected(r)}. Closest two parts: {gap}. Not counted as parts: '
                   f'{left_out["sheet_frame"]} sheet frame, {left_out["camera_dots"]} camera dots, {left_out["holes"]} holes.')
        for name in ('front', 'back'):
            if not (m := r[name]): out.append('  BACK: no file given, so only the FRONT was checked.'); continue
            label = name.upper() + (' (turned over left to right)' if m['mirrored'] else '')
            if not m['compared']: out.append(f'  {label}: not laid over the cut file ({m["why_not"]})'); continue
            how = how or f'(Print drawn with {m["renderer"]} at {m["px_per_mm"]:g} dots per mm; print allowed up to {r["bleed_mm"]:g} mm outside the cut lines.)'
            far = 'none' if m['stray_far_mm2'] < FAR_NOTE else _area(m['stray_far_mm2'])
            out.append(f'  {label}: print under {m["with_print"]} of {r["cut_parts"]} parts. Print away from every part: {far}. '
                       f'Print just off the cut shapes: {_area(m["stray_mm2"] - m["stray_far_mm2"])}. Sheet frame and camera dots at the sheet edge, not judged: {_area(m["edge_marks_mm2"])}.')
    if 'sheets' in res: out.append(f'Whole job: {res["cut_parts"]} parts to cut on {len(res["sheets"])} sheets{expected(res)}.')
    out += [f'  PROBLEM: {t}' for t in res['problems']] + [f'  Note: {t}' for t in res['warnings']]
    if how: out.append(how)
    k = len(res['problems'])
    out.append(('PASS: the print and cut files belong together.' + ('' if res['expected'] is not None else ' The number of parts was not checked against the order.'))
               if res['ok'] else f'FAIL: do not print or cut with these files. {k} problem{"" if k == 1 else "s"} listed above.')
    return '\n'.join(out)


def main(argv=None):
    ap = argparse.ArgumentParser(prog='python -m nest.paircheck', description='Check that a print layout and its cut file belong together. '
                                 'Exit code 0 = pass, 1 = mismatch (do not print or cut), 2 = not checked (a file could not be read), '
                                 '3 = not checked (this computer cannot run the check).')
    ap.add_argument('--print', dest='front', help='print PDF (the FRONT face)')
    ap.add_argument('--back', help='BACK face print PDF (checked mirrored left-to-right)')
    ap.add_argument('--cut', help='cut file: PDF or DXF')
    ap.add_argument('--sheet', action='append', default=[], metavar='PRINT[,BACK],CUT', help='one sheet of a job; repeat for every sheet (file names without commas)')
    ap.add_argument('--qty', type=int, help='parts ordered (the total of all sheets given)')
    ap.add_argument('--spares', type=int, default=0, help='extra parts cut on purpose on top of --qty (tests, spares); the cut files must hold qty + spares')
    ap.add_argument('--bleed', type=float, default=3.0, help='print allowed outside the cut line, mm (default 3)')
    ap.add_argument('--allow-blank', action='store_true', help='cut parts with no print under them are a note, not a failure (for sheets that really carry unprinted parts)')
    ap.add_argument('--page', type=int, default=0, help='page index in a PDF with several pages (0 = first)')
    ap.add_argument('--json', action='store_true', help='print the full result as JSON')
    a = ap.parse_args(argv)
    sheets = []
    if a.front or a.cut or a.back:
        if not (a.front and a.cut): ap.error('--print and --cut go together')
        sheets.append((a.front, a.back, a.cut))
    for s in a.sheet:
        f = [t.strip() for t in s.split(',')]
        if len(f) not in (2, 3): ap.error('--sheet takes PRINT,CUT or PRINT,BACK,CUT')
        sheets.append((f[0], f[1] if len(f) == 3 else None, f[-1]))
    if not sheets: ap.error('give --print and --cut, or one --sheet for every sheet')
    if a.qty is not None and a.qty < 1: ap.error('--qty must be 1 or more')
    if a.spares < 0 or (a.spares and a.qty is None): ap.error('--spares is a number of extra parts on top of --qty, so it needs --qty')
    if a.bleed < 0: ap.error('--bleed cannot be negative')
    try:
        one = sheets[0] if len(sheets) == 1 else None
        res = (check_pair(one[0], one[2], one[1], a.qty, a.bleed, a.page, spares=a.spares, allow_blank=a.allow_blank) if one
               else check_job(sheets, a.qty, a.bleed, a.page, spares=a.spares, allow_blank=a.allow_blank))
    except NotChecked as e:
        code, why = (3 if isinstance(e, NotRun) else 2), str(e)
    except Exception as e:                          # a fault in the check itself is never a pass and never a "mismatch"
        traceback.print_exc()
        code, why = 3, f'The check stopped on an unexpected fault ({type(e).__name__}: {e}), so nothing was decided and this is not a pass.'
    else:
        print(json.dumps(res, indent=2) if a.json else summary(res))
        return 0 if res['ok'] else 1
    print(json.dumps({'ok': False, 'checked': False, 'exit_code': code, 'reason': why}) if a.json else f'NOT CHECKED: {why}')
    return code


if __name__ == '__main__':
    sys.exit(main())
