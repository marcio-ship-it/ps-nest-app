"""Operator-confirmed order provenance for the local, unauthenticated PS Nest app.

These records attest to existing approvals; they do not grant client approval or
replace the portal's source-bound approval gates. Never infer approval from names.
"""
import copy
import hashlib
import json
import re
from datetime import datetime, timezone
from .artwork_identity import validate_manual_identity


def setup(body):
    """Manufacturing compatibility; stock/gap/search choices can vary in one run."""
    from .products import resolve_product, cut_process_for
    product = resolve_product(body.get('product') or 'acm', body.get('custom_material'))
    thickness = body.get('thickness')
    return dict(product=body.get('product') or 'acm', custom_material=body.get('custom_material'),
                thickness=float(thickness) if thickness not in (None, '') else None,
                printer=(body.get('printer') or product.get('printer')) if product.get('printer') else None,
                mirror=bool(body.get('mirror', product.get('mirror'))),
                cut_process=cut_process_for(product, body.get('cut_process'))[0],
                metal=body.get('metal') or None, finish=str(body.get('finish') or '').strip())


def _canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)


def _require_printed_panel(body):
    """Combined batches are scoped to printed rigid sheets.

    Product metadata is authoritative so custom flatbed-printed panels remain
    eligible while vinyl/roll and cut-only products cannot enter this workflow.
    """
    from .products import resolve_product
    product = resolve_product(body.get('product') or 'acm', body.get('custom_material'))
    if product.get('roll'):
        raise ValueError('Combined approved orders are for printed rigid panels. Vinyl / roll jobs stay in the existing ONYX workflow.')
    if not product.get('printer'):
        raise ValueError('Combined approved orders require a printed rigid-panel product. Choose a panel material with a printer, or nest this cut-only job separately.')
    return product


def _portal_binding(order, selected, artworks):
    """Retain source-bound adapter provenance, never invent a human confirmation.

    The local app cannot authenticate the portal. The portal must independently
    recheck this imported source on receipt; this record grants no release.
    """
    binding = order.get('source_binding')
    if binding is None:
        return None
    if (not isinstance(binding, dict) or binding.get('schema') not in ('portal-nest-preparation-1', 'portal-nest-preparation-2')
            or binding.get('scope') != 'source_bound_preparation'
            or binding.get('production_release') is not False
            or not isinstance(binding.get('request_id'), str) or not binding['request_id'].strip()
            or not re.fullmatch(r'[a-f0-9]{64}', str(binding.get('source_revision_sha256', '')))):
        raise ValueError('Portal preparation requires an exact source revision and no production release.')
    bound = binding.get('parts')
    if not isinstance(bound, list) or len(bound) != len(selected):
        raise ValueError('Portal source quantities do not cover the selected parts.')
    by_id = {p.get('source_part_id'): p for p in bound if isinstance(p, dict)}
    if len(by_id) != len(bound):
        raise ValueError('Portal source parts must be unique.')
    if binding['schema'] == 'portal-nest-preparation-2':
        design_ids = set(); allocation_keys = set(); item_to_line = {}; line_to_item = {}
        for p in bound:
            design_id = p.get('design_id')
            line_id = p.get('line_id')
            allocation_key = p.get('allocation_key')
            item_number = p.get('item_number')
            if (not isinstance(design_id, str) or not design_id.strip() or design_id in design_ids
                    or not isinstance(line_id, str) or not line_id.strip()
                    or not isinstance(allocation_key, str) or not allocation_key.strip() or allocation_key in allocation_keys):
                raise ValueError('Portal source design and allocation identities must be unique and complete.')
            if item_number in item_to_line and item_to_line[item_number] != line_id:
                raise ValueError('One issued portal item number cannot identify different source lines.')
            if line_id in line_to_item and line_to_item[line_id] != item_number:
                raise ValueError('One portal source line cannot carry different issued item numbers.')
            design_ids.add(design_id)
            allocation_keys.add(allocation_key)
            item_to_line[item_number] = line_id
            line_to_item[line_id] = item_number
    for row in selected:
        p = by_id.get(row.get('source_part_id')) or {}
        art = artworks.get(row.get('artwork')) or {}
        data = art.get('bytes') or b''
        if (binding['schema'] == 'portal-nest-preparation-2'
                and row.get('piece_id_base') != f"{order.get('ref')}:{p.get('source_part_id')}"):
            raise ValueError('Portal source piece identity differs from its order and source part.')
        if (not isinstance(p.get('design_id'), str) or not p['design_id'].strip()
                or p.get('item_number') != row.get('item_number')
                or type(p.get('quantity')) is not int or p['quantity'] != row.get('qty')
                or not data or p.get('artwork_sha256') != hashlib.sha256(data).hexdigest()
                or type(p.get('artwork_byte_size')) is not int or p['artwork_byte_size'] != len(data)
                or p.get('authorization_kind') not in ('customer_acknowledgement', 'approved_artwork', 'staff_source_review')
                or not isinstance(p.get('authorization_id'), str) or not p['authorization_id'].strip()):
            raise ValueError('Portal source identity, quantity, artwork or preparation evidence changed.')
    return copy.deepcopy(binding)


def validate(body, artworks):
    orders = body.get('orders') or []
    rows = body.get('parts') or []
    controlled = body.get('production_plan') is not None
    if controlled and not body.get('product'):
        raise ValueError('Automatic production preparation requires an explicit material; ACM is not a fallback.')
    if controlled and not orders:
        raise ValueError('Automatic production preparation requires identified orders.')
    if not orders:
        if any(p.get('order_ref') for p in rows):
            raise ValueError('Order-linked parts need their approved-order records. Restore the batch or clear the order assignments.')
        return []
    if not isinstance(orders, list) or len(orders) > 100:
        raise ValueError('Choose up to 100 approved orders in one batch.')
    _require_printed_panel(body)
    if not str(body.get('finish') or '').strip():
        raise ValueError('State the shared finish / laminate (or explicitly None).')
    refs = set(); records = []
    for order in orders:
        ref = order.get('ref', '')
        if not isinstance(ref, str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._-]{0,23}', ref):
            raise ValueError('Use a short order reference (letters, digits, dash, dot or underscore; up to 24 characters).')
        if ref.casefold() in refs:
            raise ValueError(f'Duplicate order reference: {ref}.')
        refs.add(ref.casefold())
        selected = [p for p in rows if p.get('order_ref') == ref]
        imported = _portal_binding(order, selected, artworks)
        if imported is None:
            for key, label in [('order_approval', 'order approval reference'), ('artwork_approval', 'artwork approval reference'), ('confirmed_by', 'operator name')]:
                if not isinstance(order.get(key), str) or not order[key].strip() or len(order[key]) > 500:
                    raise ValueError(f'{ref}: enter the {label}.')
            if order.get('approved') is not True:
                raise ValueError(f'{ref}: check the current parts against the order and artwork approvals, then confirm them.')
        if _canonical(order.get('setup')) != _canonical(setup(body)):
            raise ValueError(f'{ref}: material, thickness, printer, cutting operation or finish differs. Use a separate compatible batch.')
        if not selected:
            raise ValueError(f'{ref}: no parts are assigned. Add its parts or remove the order.')
        if _canonical(order.get('approved_parts')) != _canonical(selected):
            raise ValueError(f'{ref}: parts changed after confirmation. Recheck quantities/artwork and confirm this order again.')
        ids = set(); item_numbers = set(); item_lines = {}; sources = []
        imported_v2 = bool(imported and imported.get('schema') == 'portal-nest-preparation-2')
        imported_by_id = ({p['source_part_id']: p for p in imported['parts']} if imported else {})
        for row in selected:
            sid = row.get('source_part_id')
            if not isinstance(sid, str) or not re.fullmatch(r'[A-Za-z0-9]{1,12}', sid) or sid in ids:
                raise ValueError(f'{ref}: every row needs its own stable part ID.')
            ids.add(sid)
            item = row.get('item_number', '')
            if item or controlled:
                if not isinstance(item, str) or not re.fullmatch(r'[0-9]{1,12}[A-Za-z]{0,3}', item):
                    raise ValueError(f'{ref}/{sid}: retain the original item number, including its suffix (for example 4A).')
                if imported_v2:
                    line_id = imported_by_id[sid]['line_id']
                    if item in item_lines and item_lines[item] != line_id:
                        raise ValueError(f'{ref}: item {item} is assigned to conflicting portal source lines.')
                    item_lines[item] = line_id
                else:
                    if item in item_numbers:
                        raise ValueError(f'{ref}: duplicate item {item}; combine its copies in one source row or retain its issued suffix.')
                    item_numbers.add(item)
            if controlled and not str(row.get('site_ref') or order.get('site_ref') or '').strip():
                raise ValueError(f'{ref}/{sid}: a site reference is required for production sorting.')
            try: qty = float(row.get('qty', 1))
            except (ValueError, TypeError): qty = 0
            if not 0 < qty <= 10000 or not qty.is_integer():
                raise ValueError(f'{ref}/{sid}: quantity must be a positive whole number, at most 10000.')
            art = artworks.get(row.get('artwork'))
            if not art or not art.get('bytes'):
                raise ValueError(f'{ref}/{sid}: attach the approved print artwork before combining orders.')
            if imported is None:
                validate_manual_identity(row, art)
                manual = row.get('manual_identity') or {}
                alias = (manual.get('candidate') or {}).get('site_ref')
                canonical = row.get('site_ref')
                if alias and canonical != alias:
                    order_site = order.get('site_ref')
                    if not isinstance(order_site, str) or not order_site.strip() or canonical != order_site.strip():
                        raise ValueError(f'{ref}/{sid}: confirmed canonical site must exactly match the order site reference.')
            if (row.get('shape') or {}).get('type', 'rect') not in ('rect', 'contour', 'outline'):
                raise ValueError(f'{ref}/{sid}: combine intact artwork parts; generated lettering/shapes need a separate run.')
            source_identity = imported_by_id.get(sid) or {}
            sources.append({'source_part_id': sid, 'item_number': item,
                            'line_id': source_identity.get('line_id', ''),
                            'allocation_key': source_identity.get('allocation_key', ''),
                            'name': row.get('name'), 'quantity': int(qty),
                            'site_ref': row.get('site_ref') or order.get('site_ref') or '',
                            'state': order.get('state') or '', 'artwork_version': row.get('artwork_version') or '',
                            'artwork': row['artwork'], 'artwork_sha256': hashlib.sha256(art['bytes']).hexdigest()})
        record = copy.deepcopy(order)
        record.update(approval_basis='imported_portal_source_binding' if imported else 'operator_confirmation_of_existing_approval',
                      recorded_at=datetime.now(timezone.utc).isoformat(), sources=sources,
                      confirmed_parts_sha256=hashlib.sha256(_canonical(selected).encode()).hexdigest())
        if imported:
            # Only the originating system identifies the actual actor. Never
            # persist an operator name or checkbox as the customer's consent.
            for key in ('confirmed_by', 'order_approval', 'artwork_approval', 'approved'):
                record.pop(key, None)
            record['production_release'] = False
        records.append(record)
    if any(p.get('order_ref', '').casefold() not in refs for p in rows):
        raise ValueError('Assign every part to an approved order before nesting the batch.')
    return records
